"""Runtime evidence helper — Stage 1 (hybrid pivot).

Posts a single compliance-evidence record to the data-plane evidence API
(`hexr-evidence-api`) running in the customer's VPC. This is the wedge:
the evidence never leaves the customer's cluster.

URL resolution (first match wins):
  1. ``HEXR_EVIDENCE_URL`` env var (any deployment)
  2. In-cluster default ``http://hexr-evidence-api.hexr-system.svc:8080``
     (detected via ``KUBERNETES_SERVICE_HOST``)
  3. Legacy ``CloudConfig`` fall-back — posts to the old cloud-api at
     ``/v1/evidence/record`` so existing cloud users keep working until
     Stage 2.

The data-plane API exposes ``POST /v1/evidence`` (no ``/record`` suffix).
"""

from __future__ import annotations

import json as _json
import logging
import os
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_DATAPLANE_URL = "http://hexr-evidence-api.hexr-system.svc:8080"
_DATAPLANE_PATH = "/v1/evidence"
_LEGACY_CLOUD_PATH = "/v1/evidence/record"


def _resolve_endpoint() -> tuple[str, str, dict[str, str]]:
    """Return (base_url, path, headers). Empty base_url means 'no endpoint'."""
    override = os.environ.get("HEXR_EVIDENCE_URL", "").strip()
    if override:
        return override.rstrip("/"), _DATAPLANE_PATH, {}

    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return DEFAULT_DATAPLANE_URL, _DATAPLANE_PATH, {}

    # Legacy fall-back: CloudConfig (only meaningful for users who ran `hexr login`)
    try:
        from hexr.cli.cloud_config import CloudConfig

        cfg = CloudConfig.load()
        if cfg.is_authenticated:
            return (
                cfg.cloud_url.rstrip("/"),
                _LEGACY_CLOUD_PATH,
                {"Authorization": f"Bearer {cfg.api_key}"},
            )
    except Exception:  # pragma: no cover - best effort
        pass
    return "", _DATAPLANE_PATH, {}


def post_evidence(
    event_type: str,
    control_id: str,
    details: dict[str, Any] | None = None,
    *,
    source: str | None = None,
    framework: str = "soc2",
    severity: str = "info",
    spiffe_id: str | None = None,
    tenant_id: str | None = None,
    timeout: float = 5.0,
) -> bool:
    """Post a single compliance-evidence record. Returns True on 2xx."""
    base, path, headers = _resolve_endpoint()
    if not base:
        logger.debug("evidence: no endpoint resolved — skipping (%s/%s)", control_id, event_type)
        return False

    try:
        import httpx
    except ImportError:
        logger.warning("evidence: httpx not installed — skipping post")
        return False

    enriched = dict(details or {})
    enriched.setdefault("spiffe_id", spiffe_id or os.environ.get("HEXR_SPIFFE_ID", "local-dev"))
    enriched.setdefault("timestamp", datetime.now(timezone.utc).isoformat())

    payload = {
        "tenant_id": tenant_id or os.environ.get("HEXR_TENANT", "demo"),
        "source": source or os.environ.get("HEXR_AGENT_NAME", "hexr-sdk"),
        "event_type": event_type,
        "severity": severity,
        "framework": framework,
        "control_id": control_id,
        "spiffe_id": enriched.get("spiffe_id", ""),
        "details": _json.dumps(enriched),
    }

    try:
        with httpx.Client(base_url=base, headers=headers, timeout=timeout) as client:
            r = client.post(path, json=payload)
        if 200 <= r.status_code < 300:
            return True
        logger.warning("evidence: %s%s → HTTP %d %s", base, path, r.status_code, r.text[:160])
    except Exception as exc:
        logger.warning("evidence: post failed (non-fatal): %s", exc)
    return False


__all__ = ["post_evidence", "DEFAULT_DATAPLANE_URL"]
