"""`hexr analyze` — pure-static analysis using the Rust analyzer.

This command does NOT touch the existing build/push/deploy paths. It loads
the Rust extension `hexr_analyzer` if available; otherwise it falls back to
a Python no-op shim and prints a helpful message.

Spec: HEXR_SDK_OVERHAUL_TECH_SPEC.md §17 — declarative signature detection.
"""
from __future__ import annotations

import json
import shutil
from pathlib import Path

import click
from rich.console import Console
from rich.table import Table

from hexr.cli._signature_overlay import materialize_merged_packs, overlay_sources

console = Console()


def _try_import_native():
    """Import the Rust analyzer; return None if not built/installed yet.

    The native extension ships inside the SDK wheel at
    ``hexr._native.hexr_analyzer`` (built by maturin from the
    ``_hexr_analyzer/`` crate at repo root). For backward compatibility
    with editable ``maturin develop`` installs that drop the module at
    site-packages root, we also try the bare ``hexr_analyzer`` import.
    """
    try:
        from hexr._native import hexr_analyzer  # type: ignore[import-not-found]

        return hexr_analyzer
    except ImportError:
        pass
    try:
        import hexr_analyzer  # type: ignore[import-not-found]

        return hexr_analyzer
    except ImportError:
        return None


@click.command(name="analyze")
@click.argument("path", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--pack-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Override framework pack directory (default: packs shipped in the SDK).",
)
@click.option(
    "--pattern-dir",
    type=click.Path(path_type=Path),
    default=None,
    help="Override pattern pack directory (default: packs shipped in the SDK).",
)
@click.option("--json", "as_json", is_flag=True, help="Emit raw JSON manifest.")
@click.option(
    "--suggest",
    "suggest",
    is_flag=True,
    help=(
        "Propose framework rules for unclassified call sites. Writes an "
        "advisory YAML diff for human review; never mutates classification. "
        "Requires `pip install 'hexr-sdk[enterprise]'`."
    ),
)
def analyze_command(
    path: Path,
    pack_dir: Path | None,
    pattern_dir: Path | None,
    as_json: bool,
    suggest: bool,
) -> None:
    """Statically analyze a Python project for agent frameworks + patterns."""
    native = _try_import_native()
    if native is None:
        console.print(
            "[yellow]hexr_analyzer native extension not installed.[/yellow]\n"
            "Reinstall the SDK wheel (built with `uv build` from "
            "[cyan]sdk/python/[/cyan]) to enable `hexr analyze`. For "
            "in-tree development use [bold]maturin develop --release[/bold] "
            "from [cyan]_hexr_analyzer/[/cyan]."
        )
        raise SystemExit(2)

    if pack_dir is None or pattern_dir is None:
        # Overlay precedence: shipped → ~/.hexr/signatures → ./hexr-signatures.
        # See HEXR_SDK_OVERHAUL_TECH_SPEC.md §17 ("YAML PR, not Rust release").
        tmp_root, merged_fw, merged_pat, applied = materialize_merged_packs(
            project_root=path if path.is_dir() else path.parent,
            fw_override=pack_dir,
            pat_override=pattern_dir,
        )
        pack_dir = merged_fw
        pattern_dir = merged_pat
        if any(label != "shipped" for label in applied):
            console.print(
                f"[dim]signature overlay applied: {', '.join(applied)}[/dim]"
            )
    else:
        tmp_root = None

    try:
        raw = native.analyze_path(
            str(path),
            str(pack_dir),
            str(pattern_dir),
        )
    finally:
        if tmp_root is not None and Path(tmp_root).is_dir():
            shutil.rmtree(tmp_root, ignore_errors=True)
    manifest = json.loads(raw)

    if as_json:
        click.echo(json.dumps(manifest, indent=2))
        return

    fw = manifest.get("framework")
    if fw:
        console.print(
            f"[bold green]Framework:[/bold green] {fw['display_name']} "
            f"(id={fw['id']}, confidence={fw['confidence']:.2f})"
        )
    else:
        console.print("[yellow]No framework detected.[/yellow]")

    candidates = manifest.get("framework_candidates") or []
    if len(candidates) > 1:
        t = Table(title="Other candidates")
        t.add_column("ID")
        t.add_column("Confidence", justify="right")
        for c in candidates[1:]:
            t.add_row(c["id"], f"{c['confidence']:.2f}")
        console.print(t)

    agents = manifest.get("agents") or []
    if agents:
        t = Table(title=f"Agents ({len(agents)})")
        t.add_column("Name")
        t.add_column("Class")
        t.add_column("Framework")
        for a in agents:
            t.add_row(a.get("name") or "", a.get("class_path") or "", a.get("framework_id") or "")
        console.print(t)

    tools = manifest.get("tools") or []
    if tools:
        t = Table(title=f"Tools ({len(tools)})")
        t.add_column("Name")
        t.add_column("Framework")
        for tool in tools:
            t.add_row(tool.get("name") or "", tool.get("framework_id") or "")
        console.print(t)

    patterns = manifest.get("patterns") or []
    if patterns:
        t = Table(title=f"Patterns ({len(patterns)})")
        t.add_column("Pattern")
        t.add_column("Function")
        t.add_column("Confidence", justify="right")
        for p in patterns:
            t.add_row(p["display_name"] or p["id"], p["function"], f"{p['confidence']:.2f}")
        console.print(t)

    warnings = manifest.get("warnings") or []
    if warnings:
        console.print("[dim]warnings:[/dim]")
        for w in warnings:
            console.print(f"  [dim]- {w}[/dim]")

    # ------------------------------------------------------------------ #
    # L3 suggest mode (spec §21.3 L3 / §21.5 PR-D4 / §21.6 / §21.8).     #
    # Advisory only: writes a YAML diff to a separate auto-discovered    #
    # file. NEVER mutates the manifest, NEVER feeds OPA.                 #
    # ------------------------------------------------------------------ #
    if not suggest:
        return

    unclassified = manifest.get("unclassified_calls") or []
    if not unclassified:
        console.print(
            "[green]No unclassified call sites — nothing to suggest.[/green]"
        )
        return

    if not hasattr(native, "suggest_yaml_diff"):
        console.print(
            "[yellow]This SDK build does not include the enterprise "
            "suggest backend.[/yellow]\n"
            "Install with: [cyan]pip install 'hexr-sdk[enterprise]'[/cyan]."
        )
        raise SystemExit(2)

    # Spec §21.5 PR-D7: one-line accelerator diagnostic so the user
    # immediately sees which platform-specific cargo feature path
    # (`apple-silicon` / `openblas` / `enterprise`) their installed wheel
    # is actually exercising at runtime. Pure-Python probe; never fails.
    try:
        from hexr.suggest.accel import describe, detect_backend

        backend = detect_backend()
        console.print(
            f"[dim]suggest accelerator: {backend} — {describe(backend)}[/dim]"
        )
    except Exception:  # pragma: no cover — diagnostic must never break --suggest
        pass

    # The model is bundled by the `[enterprise]` extras via the
    # `hexr-sdk-models` companion wheel (spec §21.7 / §21.7.1). Falls back
    # to ~/.hexr/models/ for users who pre-downloaded before bundling
    # existed. No --model-dir flag — this is an SDK implementation detail.
    try:
        from hexr_sdk_models import default_model_dir  # type: ignore[import-not-found]

        model_dir: Path = default_model_dir()
    except ImportError:
        model_dir = Path.home() / ".hexr" / "models" / "LateOn-Code-edge"
    if not model_dir.is_dir():
        console.print(
            "[yellow]The enterprise model weights are not installed.[/yellow]\n"
            "Install with: [cyan]pip install 'hexr-sdk[enterprise]'[/cyan]."
        )
        raise SystemExit(2)

    suggest_out = (
        Path.home()
        / ".hexr"
        / "signatures"
        / "frameworks"
        / "auto-discovered.yaml"
    )

    try:
        diff_yaml = native.suggest_yaml_diff(
            str(pack_dir),
            str(model_dir),
            json.dumps(unclassified),
            True,                   # quantized — INT8 ONNX (spec §21.8.3)
            0.45,                   # min_score — length-normalised MaxSim (§21.8.2)
            5,                      # top_k
            3,                      # min_agree
        )
    except RuntimeError as e:
        msg = str(e)
        if "enterprise" in msg.lower():
            console.print(
                "[yellow]Suggest mode requires the enterprise extras.[/yellow]\n"
                "Install with: [cyan]pip install 'hexr-sdk[enterprise]'[/cyan]"
            )
        else:
            console.print(f"[red]suggest failed:[/red] {msg}")
        raise SystemExit(2)

    suggest_out.parent.mkdir(parents=True, exist_ok=True)
    suggest_out.write_text(diff_yaml, encoding="utf-8")
    console.print(
        f"[bold green]Suggestions written:[/bold green] {suggest_out}\n"
        "[dim]advisory only — review and promote to a versioned pack PR "
        "(spec §21.6).[/dim]"
    )
