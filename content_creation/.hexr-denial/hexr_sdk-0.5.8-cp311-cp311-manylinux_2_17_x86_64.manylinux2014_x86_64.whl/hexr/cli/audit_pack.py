"""
PR-C20 — `hexr audit --framework {soc2,hipaa,iso42001}` compliance audit-pack
emitter.

Generates a PDF audit pack from the customer-side `compliance_evidence` table
(the canonical schema defined in HEXR_SDK_OVERHAUL_TECH_SPEC.md §7), mapping
rows to the relevant control family for the chosen framework. Used by GRC
enterprises during SOC2 / HIPAA / ISO 42001 audits.

Design constraints (per HEXR_SDK_OVERHAUL_TECH_SPEC.md §19.5 9b acceptance bar):
  * Reads from the customer-side evidence DB only (DSN via env or --evidence-dsn).
    Hexr Cloud never sees a single evidence row — see pivot spec §1.6.
  * Emits the §1.18 disclosure paragraph verbatim for `app_attested` rows
    (no host_pid, no binary_sha256 — auditor-facing transparency note).
  * No network calls. The PDF is built locally from query results only.

Schema-version handling (see hybrid spec §2.5.9):
  * The canonical table is `compliance_evidence` (per SDK overhaul spec §7).
  * The evidence-api implementation today populates a subset of §7 columns:
    id, tenant_id, source, event_type, severity, spiffe_id, agent_id,
    framework, control_id, details JSONB, trace_id, recorded_at. The extended
    columns (attestation_class, host_pid, binary_sha256, row_signature,
    parent_spiffe_id, spawn_depth, otel_span_id) land alongside SDK 0.6.0.
  * Until then, this query projects the available columns into the EvidenceRow
    shape used downstream, normalises `event_type` to the audit-pack `name`
    glob taxonomy, and reads tool_name from `details->>'tool_name'`.

Wire-in: this module is loaded lazily by `hexr.cli.audit.audit_command` when
`--framework` is supplied; otherwise the existing CVE/SBOM/drift path runs
unchanged.

Optional dependency: `reportlab` (declared in `[project.optional-dependencies]
audit-pack`). The PDF builder degrades gracefully with an actionable error
when reportlab is not installed.
"""
from __future__ import annotations

import os
import re
import sys
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

# ---------------------------------------------------------------------------
# Framework -> control family mapping
#
# Minimal but real. Each entry says which controls a given evidence-row class
# satisfies. The mapping is intentionally small and conservative — auditors
# accept "the row exists with a verifiable signature" as evidence; they do
# NOT accept "this control is implied because the SDK said so."
# ---------------------------------------------------------------------------

#: Evidence-row "kind" → human label used in tables.
_ROW_KIND_LABEL: dict[str, str] = {
    "agent_invoke": "Agent invocation",
    "tool_invoke": "Tool invocation",
    "llm_invoke": "LLM invocation",
    "policy_decision": "Policy decision",
    "credential_issued": "Credential issued",
}

#: evidence-api `event_type` → audit-pack `name` taxonomy used by the framework
#: control mapping below. Mapping is intentionally narrow — unknown event types
#: pass through unchanged so the auditor can spot novel rows.
_EVENT_TYPE_TO_NAME: dict[str, str] = {
    "agent_started": "agent_invoke",
    "agent_finished": "agent_invoke",
    "agent_invoke": "agent_invoke",
    "tool_call_allowed": "tool_invoke",
    "tool_call_denied": "tool_invoke",
    "tool_call_audited": "tool_invoke",
    "tool_invoke": "tool_invoke",
    "llm_call": "llm_invoke",
    "llm_invoke": "llm_invoke",
    "policy_decision": "policy_decision",
    "credential_issued": "credential_issued",
}

#: framework -> { control_id -> (title, list of row-name globs that count) }
#: Row-name globs are matched against the normalised `name` derived from
#: `compliance_evidence.event_type` (see _EVENT_TYPE_TO_NAME). For example
#: 'agent_started' and 'agent_finished' both normalise to 'agent_invoke', and
#: 'tool_call_allowed' / 'tool_call_denied' / 'tool_call_audited' all
#: normalise to 'tool_invoke'. Asterisk is treated as fnmatch-style.
_FRAMEWORK_CONTROLS: dict[str, dict[str, tuple[str, list[str]]]] = {
    "soc2": {
        "CC6.1": (
            "Logical access — only authenticated identities act",
            ["agent_invoke", "tool_invoke"],
        ),
        "CC6.6": (
            "Boundary protection — every external call is mediated",
            ["tool_invoke", "llm_invoke"],
        ),
        "CC7.2": (
            "System monitoring — anomalous activity detected",
            ["policy_decision"],
        ),
        "CC8.1": (
            "Change management — every deployed agent is signed and reproducible",
            ["agent_invoke"],
        ),
    },
    "hipaa": {
        "164.312(a)(1)": (
            "Access control — unique user identification",
            ["agent_invoke", "tool_invoke"],
        ),
        "164.312(b)": (
            "Audit controls — record and examine activity in systems containing ePHI",
            ["agent_invoke", "tool_invoke", "llm_invoke", "policy_decision"],
        ),
        "164.312(c)(1)": (
            "Integrity — ePHI is not altered or destroyed in an unauthorized manner",
            ["tool_invoke", "policy_decision"],
        ),
    },
    "iso42001": {
        "A.6.2.6": (
            "AI system impact assessment — recorded inputs/outputs to AI systems",
            ["agent_invoke", "llm_invoke"],
        ),
        "A.8.2": (
            "AI system operation — controlled execution of AI workloads",
            ["agent_invoke", "tool_invoke"],
        ),
        "A.9.2": (
            "Data for AI systems — provenance of inputs",
            ["llm_invoke", "tool_invoke"],
        ),
    },
}

# §1.18 disclosure paragraph — verbatim. Auditor-facing, must not be edited.
_APP_ATTESTED_DISCLOSURE = (
    "App-attested rows: a subset of evidence rows in this report carry "
    "attestation_class='app_attested'. These rows were emitted from a "
    "managed-runtime context (e.g. AWS Bedrock AgentCore, GCP Agent Engine, "
    "Azure AI Foundry) where the Hexr SDK does not have access to the host "
    "PID namespace and cannot read its own on-disk binary for hashing. "
    "Therefore host_pid and binary_sha256 are NULL for these rows. The row "
    "remains cryptographically signed by the SDK's tenant-bound signing key "
    "and chained back to the row's trace_id; integrity, origin, and "
    "non-repudiation are unaffected. This disclosure is included so an "
    "auditor reviewing the report can immediately distinguish app-attested "
    "rows from host-attested rows without inferring it from missing fields."
)

_FRAMEWORK_LABELS = {
    "soc2": "SOC 2 Type II",
    "hipaa": "HIPAA Security Rule (45 CFR §164.312)",
    "iso42001": "ISO/IEC 42001:2023",
}


# ---------------------------------------------------------------------------
# Period parsing
# ---------------------------------------------------------------------------

def _parse_period(period: str) -> tuple[datetime, datetime]:
    """
    Resolve --period flag to a (start, end) UTC datetime window.

    Accepts: 'today', 'yesterday', 'NDd' (e.g. '7d', '30d', '90d'),
             'YYYY-MM-DD..YYYY-MM-DD', or 'all'.
    """
    now = datetime.now(timezone.utc)
    end_of_today = now.replace(hour=23, minute=59, second=59, microsecond=999_999)
    if period == "today":
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        return start, end_of_today
    if period == "yesterday":
        start = (now - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = start.replace(hour=23, minute=59, second=59, microsecond=999_999)
        return start, end
    if period == "all":
        return datetime(1970, 1, 1, tzinfo=timezone.utc), end_of_today
    m = re.fullmatch(r"(\d+)d", period)
    if m:
        days = int(m.group(1))
        start = (now - timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
        return start, end_of_today
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2})", period)
    if m:
        start = datetime.fromisoformat(m.group(1)).replace(tzinfo=timezone.utc)
        end = datetime.fromisoformat(m.group(2)).replace(
            hour=23, minute=59, second=59, microsecond=999_999, tzinfo=timezone.utc
        )
        return start, end
    raise ValueError(
        f"Unrecognized --period '{period}'. "
        "Use 'today', 'yesterday', 'all', 'NNd' (e.g. '7d'), or 'YYYY-MM-DD..YYYY-MM-DD'."
    )


# ---------------------------------------------------------------------------
# Evidence row + summary dataclasses
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class EvidenceRow:
    row_id: str
    tenant_id: str
    trace_id: str
    span_id: str
    name: str
    agent_name: str | None
    tool_name: str | None
    attestation_class: str
    host_pid: int | None
    binary_sha256: str | None
    signature: str | None
    signed_at: datetime


@dataclass
class ControlSummary:
    control_id: str
    title: str
    matching_rows: list[EvidenceRow] = field(default_factory=list)

    @property
    def row_count(self) -> int:
        return len(self.matching_rows)


@dataclass
class AuditPackResult:
    framework: str
    tenant_id: str
    period_start: datetime
    period_end: datetime
    total_rows: int
    app_attested_rows: int
    host_attested_rows: int
    unsigned_rows: int
    controls: list[ControlSummary]
    pdf_path: Path


# ---------------------------------------------------------------------------
# DB layer (small, abstract — supports psycopg2 and sqlite3 transparently
# so unit tests don't need a Postgres)
# ---------------------------------------------------------------------------

#: Canonical SELECT against `compliance_evidence` (SDK overhaul spec §7).
#: Column order is contract — _fetch_rows() depends on positional unpack.
#: Columns 7-10 (attestation_class, host_pid, binary_sha256, row_signature)
#: are projected as NULL where the live schema has not yet been extended;
#: see hybrid spec §2.5.9 for the schema-extension migration plan.
_SELECT_SQL_PG = (
    "SELECT "
    "  id              AS row_id, "
    "  tenant_id, "
    "  trace_id, "
    "  COALESCE(details->>'span_id', '')             AS span_id, "
    "  event_type, "
    "  agent_id                                       AS agent_name, "
    "  COALESCE(details->>'tool_name', '')           AS tool_name, "
    "  COALESCE(details->>'attestation_class', "
    "           CASE WHEN spiffe_id IS NOT NULL AND spiffe_id <> '' "
    "                THEN 'app_attested' ELSE 'app_attested_unsigned' END) "
    "                                                 AS attestation_class, "
    "  NULLIF(details->>'host_pid','')::int          AS host_pid, "
    "  details->>'binary_sha256'                      AS binary_sha256, "
    "  details->>'row_signature'                      AS signature, "
    "  recorded_at                                    AS signed_at "
    "FROM compliance_evidence "
    "WHERE tenant_id = %s AND recorded_at >= %s AND recorded_at <= %s "
    "ORDER BY recorded_at ASC"
)

#: sqlite variant used by unit tests — supports either evidence-api schema or
#: a minimal compliance_evidence shape (no JSON path operators, no COALESCE
#: tricks). Tests insert a flat compliance_evidence table with span_id,
#: tool_name, attestation_class, host_pid, binary_sha256, row_signature as
#: real columns.
_SELECT_SQL_SQLITE = (
    "SELECT id, tenant_id, trace_id, span_id, event_type, agent_id, tool_name, "
    "attestation_class, host_pid, binary_sha256, row_signature, recorded_at "
    "FROM compliance_evidence "
    "WHERE tenant_id = ? AND recorded_at >= ? AND recorded_at <= ? "
    "ORDER BY recorded_at ASC"
)


def _open_connection(dsn: str):
    """
    Open a DB-API 2.0 connection. Recognizes:
      * postgresql://...      -> psycopg2 (required at runtime, not at import)
      * sqlite:///path/to.db  -> sqlite3 (stdlib; used by unit tests)
    """
    if dsn.startswith("postgresql://") or dsn.startswith("postgres://"):
        try:
            import psycopg2  # type: ignore[import-not-found]
        except ImportError as e:
            raise RuntimeError(
                "psycopg2 is required to query a PostgreSQL evidence DB. "
                "Install with: pip install 'hexr-sdk[audit-pack]'"
            ) from e
        return psycopg2.connect(dsn)
    if dsn.startswith("sqlite:///"):
        import sqlite3
        path = dsn[len("sqlite:///"):]
        return sqlite3.connect(path)
    raise ValueError(
        f"Unsupported DSN scheme: {dsn!r}. Use postgresql://... or sqlite:///path."
    )


def _fetch_rows(
    dsn: str,
    tenant_id: str,
    start: datetime,
    end: datetime,
) -> list[EvidenceRow]:
    """Pull evidence rows from the customer-side DB into in-memory rows."""
    is_postgres = dsn.startswith("postgres")
    conn = _open_connection(dsn)
    try:
        cur = conn.cursor()
        if is_postgres:
            sql = _SELECT_SQL_PG
            params: tuple = (tenant_id, start, end)
        else:
            # sqlite3: ? placeholders; default adapter rejects tz-aware
            # datetimes on 3.12+. Strip tz and bind as naive UTC datetimes
            # so it matches the on-disk text format produced by the same
            # adapter at insert time.
            sql = _SELECT_SQL_SQLITE
            params = (
                tenant_id,
                start.replace(tzinfo=None) if start.tzinfo else start,
                end.replace(tzinfo=None) if end.tzinfo else end,
            )
        cur.execute(sql, params)
        rows = cur.fetchall()
        cur.close()
    finally:
        conn.close()

    out: list[EvidenceRow] = []
    for r in rows:
        signed_at = r[11]
        if isinstance(signed_at, str):
            # sqlite stores timestamps as text
            signed_at = datetime.fromisoformat(signed_at.replace("Z", "+00:00"))
        raw_event = str(r[4]) if r[4] else ""
        name = _EVENT_TYPE_TO_NAME.get(raw_event, raw_event)
        out.append(
            EvidenceRow(
                row_id=str(r[0]),
                tenant_id=str(r[1]),
                trace_id=str(r[2]) if r[2] else "",
                span_id=str(r[3]) if r[3] else "",
                name=name,
                agent_name=r[5] if r[5] not in (None, "") else None,
                tool_name=r[6] if r[6] not in (None, "") else None,
                attestation_class=str(r[7]) if r[7] else "app_attested_unsigned",
                host_pid=int(r[8]) if r[8] is not None else None,
                binary_sha256=str(r[9]) if r[9] else None,
                signature=str(r[10]) if r[10] else None,
                signed_at=signed_at,
            )
        )
    return out


# ---------------------------------------------------------------------------
# Mapping rows -> controls
# ---------------------------------------------------------------------------

def _row_matches(row: EvidenceRow, name_globs: Sequence[str]) -> bool:
    import fnmatch
    return any(fnmatch.fnmatch(row.name, g) for g in name_globs)


def _summarize(framework: str, rows: Sequence[EvidenceRow]) -> list[ControlSummary]:
    catalogue = _FRAMEWORK_CONTROLS[framework]
    summaries: list[ControlSummary] = []
    for control_id, (title, name_globs) in catalogue.items():
        matched = [r for r in rows if _row_matches(r, name_globs)]
        summaries.append(ControlSummary(control_id=control_id, title=title, matching_rows=matched))
    return summaries


# ---------------------------------------------------------------------------
# License-tier gating
#
# Drives whether the rendered PDF carries the "HEXR EVALUATION" watermark.
# Two tiers are recognised:
#   * "licensed"   — clean, auditor-deliverable PDF.
#   * "evaluation" — diagonal watermark on every page, stamped non-production.
#
# The resolver is intentionally **fail-safe-closed**: any unrecognised,
# missing, or unparseable input (no config file, malformed JSON, unknown
# tier string, etc.) resolves to "evaluation". A buggy license read must
# NEVER silently produce a clean PDF.
#
# Resolution order (highest precedence first):
#   1. explicit `tier` argument (callable / test override).
#   2. environment variable HEXR_LICENSE_TIER.
#   3. `tier` field on the persisted ~/.hexr/config.json (CloudConfig).
# ---------------------------------------------------------------------------

_VALID_TIERS = ("evaluation", "licensed")


def _resolve_license_tier(explicit: str | None = None) -> str:
    """Resolve the license tier for audit-pack rendering. Fails closed."""
    candidates: list[str] = []
    if explicit:
        candidates.append(explicit)
    env_value = os.environ.get("HEXR_LICENSE_TIER")
    if env_value:
        candidates.append(env_value)
    try:
        # Local import: cloud_config pulls in httpx, which we don't want
        # to load at module-import time for non-PDF audit code paths.
        from hexr.cli.cloud_config import CloudConfig
        cfg_tier = CloudConfig.load().tier
        if cfg_tier:
            candidates.append(cfg_tier)
    except Exception:
        # Any failure reading config -> ignore and fall through to evaluation.
        pass
    for c in candidates:
        normalised = c.strip().lower()
        if normalised in _VALID_TIERS:
            return normalised
    return "evaluation"


def _draw_evaluation_watermark(
    canvas, doc,
    *,
    tenant_id: str,
    period_label: str,
    report_id: str,
    generated_at: str,
) -> None:
    """reportlab page callback: diagonal evaluation watermark + footer line.

    Wired in via SimpleDocTemplate.build(onFirstPage=, onLaterPages=) when the
    resolved license tier is "evaluation". Never invoked for "licensed".
    """
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter

    page_w, page_h = letter
    canvas.saveState()
    # Diagonal body watermark.
    canvas.setFillColor(colors.Color(0.75, 0.75, 0.75, alpha=0.45))
    canvas.setFont("Helvetica-Bold", 60)
    canvas.translate(page_w / 2.0, page_h / 2.0)
    canvas.rotate(35)
    canvas.drawCentredString(0, 0, "HEXR EVALUATION\u2003\u2014\u2003NON-PRODUCTION")
    canvas.restoreState()
    # Footer line with the report identifier so a recipient can never confuse
    # an evaluation copy for a licensed deliverable.
    canvas.saveState()
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.setFont("Helvetica", 7)
    footer = (
        f"HEXR EVALUATION COPY \u2014 NON-PRODUCTION  \u00b7  "
        f"tenant={tenant_id}  \u00b7  period={period_label}  \u00b7  "
        f"report_id={report_id}  \u00b7  generated_at={generated_at}"
    )
    canvas.drawCentredString(page_w / 2.0, 0.35 * 72, footer)
    canvas.restoreState()


# ---------------------------------------------------------------------------
# PDF rendering (reportlab; lazy import so the SDK doesn't grow by ~3 MB
# unless the audit-pack extra is installed)
# ---------------------------------------------------------------------------

def _render_pdf(
    *,
    out_path: Path,
    framework: str,
    tenant_id: str,
    period_start: datetime,
    period_end: datetime,
    rows: Sequence[EvidenceRow],
    controls: Sequence[ControlSummary],
    tier: str = "evaluation",
) -> None:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.platypus import (
            SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
        )
    except ImportError as e:
        raise RuntimeError(
            "reportlab is required to render the audit-pack PDF. "
            "Install with: pip install 'hexr-sdk[audit-pack]'"
        ) from e

    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(out_path), pagesize=letter,
        leftMargin=0.6 * inch, rightMargin=0.6 * inch,
        topMargin=0.7 * inch, bottomMargin=0.7 * inch,
        title=f"Hexr Audit Pack — {tenant_id} — {framework}",
        author="Hexr SDK",
    )

    styles = getSampleStyleSheet()
    h1 = styles["Heading1"]
    h2 = styles["Heading2"]
    body = styles["BodyText"]
    mono = ParagraphStyle("mono", parent=body, fontName="Courier", fontSize=8)
    small = ParagraphStyle("small", parent=body, fontSize=8, textColor=colors.HexColor("#444"))

    story: list = []

    # --- Cover ---
    story.append(Paragraph("Hexr Audit Pack", h1))
    story.append(Paragraph(_FRAMEWORK_LABELS[framework], h2))
    story.append(Spacer(1, 0.15 * inch))
    cover_data = [
        ["Tenant", tenant_id],
        ["Framework", framework.upper()],
        ["Period start (UTC)", period_start.strftime("%Y-%m-%d %H:%M:%S")],
        ["Period end (UTC)", period_end.strftime("%Y-%m-%d %H:%M:%S")],
        ["Generated (UTC)", datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")],
        ["Total evidence rows", str(len(rows))],
    ]
    t = Table(cover_data, colWidths=[2.0 * inch, 4.4 * inch])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), "Helvetica"),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.grey),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f3f3f3")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t)

    # --- Attestation summary ---
    app_attested = sum(1 for r in rows if r.attestation_class == "app_attested")
    host_attested = sum(1 for r in rows if r.attestation_class == "host_attested")
    unsigned = sum(1 for r in rows if not r.signature)
    story.append(Spacer(1, 0.25 * inch))
    story.append(Paragraph("Attestation summary", h2))
    summary_data = [
        ["Class", "Count"],
        ["app_attested", str(app_attested)],
        ["host_attested", str(host_attested)],
        ["unsigned (rows missing a signature)", str(unsigned)],
    ]
    t = Table(summary_data, colWidths=[3.5 * inch, 1.0 * inch])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f3b6c")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.grey),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.lightgrey),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
    ]))
    story.append(t)

    # --- §1.18 disclosure (only if any app_attested rows present) ---
    if app_attested > 0:
        story.append(Spacer(1, 0.2 * inch))
        story.append(Paragraph("Disclosure (per Hexr SDK §1.18)", h2))
        story.append(Paragraph(_APP_ATTESTED_DISCLOSURE, body))

    # --- Per-control sections ---
    story.append(PageBreak())
    story.append(Paragraph(f"Control coverage — {_FRAMEWORK_LABELS[framework]}", h1))

    for ctl in controls:
        story.append(Spacer(1, 0.15 * inch))
        story.append(Paragraph(f"{ctl.control_id} — {ctl.title}", h2))
        story.append(Paragraph(f"Rows in scope: <b>{ctl.row_count}</b>", body))

        if not ctl.matching_rows:
            story.append(Paragraph(
                "No matching evidence rows in the selected period. This may be expected "
                "for controls that exercise rare paths (e.g. policy denials).",
                small,
            ))
            continue

        header = ["signed_at (UTC)", "name", "agent", "tool", "attest", "sig"]
        # Cap at 50 rows per control to keep the PDF reasonable; auditors can
        # query the DB directly for full row-level proof.
        capped = ctl.matching_rows[:50]
        data = [header] + [[
            r.signed_at.strftime("%Y-%m-%d %H:%M:%S"),
            r.name,
            (r.agent_name or "—")[:24],
            (r.tool_name or "—")[:24],
            r.attestation_class,
            "yes" if r.signature else "no",
        ] for r in capped]
        t = Table(data, colWidths=[1.4 * inch, 1.0 * inch, 1.2 * inch, 1.2 * inch, 0.9 * inch, 0.4 * inch])
        t.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 7),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f3b6c")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("BOX", (0, 0), (-1, -1), 0.4, colors.grey),
            ("INNERGRID", (0, 0), (-1, -1), 0.2, colors.lightgrey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("LEFTPADDING", (0, 0), (-1, -1), 3),
            ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ]))
        story.append(t)
        if len(ctl.matching_rows) > 50:
            story.append(Paragraph(
                f"Showing first 50 of {len(ctl.matching_rows)} matching rows. "
                "Query compliance_evidence directly for the full set.",
                small,
            ))

    # --- Verification footer ---
    story.append(PageBreak())
    story.append(Paragraph("How an auditor can independently verify this report", h2))
    story.append(Paragraph(
        "Every row above maps to a single row in the customer-controlled "
        "compliance_evidence table. The auditor can re-run the underlying SQL "
        "(<font face='Courier'>SELECT * FROM compliance_evidence WHERE tenant_id=&lt;tenant&gt; "
        "AND recorded_at BETWEEN &lt;start&gt; AND &lt;end&gt;</font>) and reconcile "
        "row counts and signatures. The SDK does not transmit evidence rows to "
        "Hexr Cloud; this PDF is generated locally from the customer's own "
        "database.",
        body,
    ))
    story.append(Spacer(1, 0.15 * inch))
    report_id = (
        f"{tenant_id}-{framework}-"
        f"{period_start.strftime('%Y%m%d')}-{period_end.strftime('%Y%m%d')}"
    )
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    story.append(Paragraph(
        f"Generated by hexr-sdk audit-pack emitter. Report identifier: "
        f"{report_id}. Generated at: {generated_at}.",
        small,
    ))

    if tier == "evaluation":
        import functools
        period_label = (
            f"{period_start.strftime('%Y-%m-%d')}.."
            f"{period_end.strftime('%Y-%m-%d')}"
        )
        wm_cb = functools.partial(
            _draw_evaluation_watermark,
            tenant_id=tenant_id,
            period_label=period_label,
            report_id=report_id,
            generated_at=generated_at,
        )
        doc.build(story, onFirstPage=wm_cb, onLaterPages=wm_cb)
    else:
        doc.build(story)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_audit_pack(
    *,
    framework: str,
    tenant_id: str,
    period: str,
    output_dir: Path,
    evidence_dsn: str | None = None,
    tier: str | None = None,
) -> AuditPackResult:
    """
    Build a compliance audit pack PDF.

    Args:
        framework: one of {"soc2", "hipaa", "iso42001"}
        tenant_id: customer tenant identifier (filters compliance_evidence.tenant_id).
        period: 'today' | 'yesterday' | 'all' | 'NNd' | 'YYYY-MM-DD..YYYY-MM-DD'
        output_dir: directory for the generated PDF.
        evidence_dsn: DB-API DSN for the customer evidence DB. If None, falls back
                      to the HEXR_EVIDENCE_DSN environment variable.
        tier: optional explicit license tier override ("evaluation" | "licensed").
              When None, resolves from HEXR_LICENSE_TIER env var or the persisted
              CloudConfig. Unrecognised / missing values fail closed to
              "evaluation" (watermarked).

    Returns:
        AuditPackResult describing the run, including the PDF path.
    """
    if framework not in _FRAMEWORK_CONTROLS:
        raise ValueError(
            f"Unsupported framework: {framework!r}. "
            f"Supported: {sorted(_FRAMEWORK_CONTROLS)}."
        )
    dsn = evidence_dsn or os.environ.get("HEXR_EVIDENCE_DSN")
    if not dsn:
        raise RuntimeError(
            "No evidence DB DSN provided. Set HEXR_EVIDENCE_DSN or pass --evidence-dsn. "
            "Example: postgresql://hexr:****@<rds-endpoint>:5432/evidence"
        )

    period_start, period_end = _parse_period(period)
    rows = _fetch_rows(dsn, tenant_id, period_start, period_end)
    controls = _summarize(framework, rows)

    resolved_tier = _resolve_license_tier(tier)
    out_path = output_dir / f"audit-{framework}-{tenant_id}-{period_start.strftime('%Y%m%d')}-{period_end.strftime('%Y%m%d')}.pdf"
    _render_pdf(
        out_path=out_path,
        framework=framework,
        tenant_id=tenant_id,
        period_start=period_start,
        period_end=period_end,
        rows=rows,
        controls=controls,
        tier=resolved_tier,
    )

    return AuditPackResult(
        framework=framework,
        tenant_id=tenant_id,
        period_start=period_start,
        period_end=period_end,
        total_rows=len(rows),
        app_attested_rows=sum(1 for r in rows if r.attestation_class == "app_attested"),
        host_attested_rows=sum(1 for r in rows if r.attestation_class == "host_attested"),
        unsigned_rows=sum(1 for r in rows if not r.signature),
        controls=list(controls),
        pdf_path=out_path,
    )
