"""`hexr update signatures` — pull signed framework/pattern signature packs.

Implements HEXR_SDK_OVERHAUL_TECH_SPEC.md §21.4 (signed-feed mechanism) on
top of the §17 declarative-signatures architecture.

Flow for the default signed source:
  1. GET <index_url> (default `https://signatures.hexr.cloud/latest.json`)
     with ETag/If-None-Match. 304 → noop, exit 2.
  2. Validate `min_sdk <= hexr.__version__ <= max_sdk` (incompat → exit 66).
  3. Skip if installed `current/.manifest.json.version == latest.version`.
  4. Download tarball + signature(s) to `~/.hexr/signatures/.staging/<ver>/`.
     Modern Sigstore bundle (`.tar.gz.sigstore.json`) preferred; detached
     `.tar.gz.sig` + `.tar.gz.crt` accepted for back-compat.
  5. Verify SHA-256 against latest.json.
  6. Cosign keyless verify (Fulcio cert subject regex + OIDC issuer) using
     the `sigstore` Python lib (lazy import — kept out of default install).
     Verify failure → delete staging, exit 65.
  7. Extract into `~/.hexr/signatures/<version>/`, atomically swap
     `~/.hexr/signatures/current` symlink, write `.manifest.json`.

Back-compat sources:
  * Local directory             — copies frameworks/+patterns/, no verify
  * Local .tar.gz               — extracts, no verify
  * https://…/latest.tar.gz     — direct tarball; verifies if .sig+.crt
                                  siblings exist, otherwise warns
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sys
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import click
from rich.console import Console

import hexr

console = Console()

# ─── Constants (spec §21.4) ──────────────────────────────────────────────────

_DEFAULT_SOURCE = "https://signatures.hexr.cloud/latest.json"
_USER_DIR = Path.home() / ".hexr" / "signatures"
_STAGING_DIR_NAME = ".staging"
_CURRENT_LINK_NAME = "current"
_MANIFEST_NAME = ".manifest.json"

# Build-time constants embedded so the trust root cannot be overridden by a
# tampered latest.json (spec §21.4.3: "no keys to rotate, no PKI to operate").
# sigstore-python's Identity policy is exact-match; the {version} placeholder is
# substituted at call time from idx.version (signed feed) or parsed from the
# tarball URL (direct mode).
_COSIGN_IDENTITY_TEMPLATE = (
    "https://github.com/hexrdev/hexr-signatures/"
    ".github/workflows/release.yml@refs/tags/{version}"
)
_COSIGN_OIDC_ISSUER = "https://token.actions.githubusercontent.com"

# Exit codes per spec §21.4.4 — intentionally non-overlapping with shell builtins.
EXIT_OK = 0
EXIT_NOOP = 2
EXIT_NETWORK = 64
EXIT_VERIFY = 65
EXIT_INCOMPAT = 66

_HTTP_TIMEOUT = 30  # seconds


# ─── HTTP helpers ────────────────────────────────────────────────────────────


def _http_get(url: str, *, etag: Optional[str] = None) -> tuple[bytes, dict[str, str]]:
    """GET url; return (body, headers_lowercase). Raises URLError on transport.

    Caller handles 304 by catching HTTPError(code=304).
    """
    headers = {"User-Agent": f"hexr-cli/{hexr.__version__} signatures-update"}
    if etag:
        headers["If-None-Match"] = etag
    req = Request(url, headers=headers)
    with urlopen(req, timeout=_HTTP_TIMEOUT) as resp:  # noqa: S310 — https enforced upstream
        body = resp.read()
        hdrs = {k.lower(): v for k, v in resp.headers.items()}
    return body, hdrs


def _http_get_optional(url: str) -> Optional[bytes]:
    """GET url; return body or None on 404. Other errors re-raise."""
    try:
        body, _ = _http_get(url)
        return body
    except HTTPError as exc:
        if exc.code == 404:
            return None
        raise


# ─── Signed-index flow (spec §21.4.4) ────────────────────────────────────────


@dataclass
class _LatestIndex:
    version: str
    tarball_url: str
    sha256: str
    size_bytes: int
    min_sdk: str
    max_sdk: Optional[str]
    raw: dict
    etag: Optional[str]


def _parse_latest(body: bytes, etag: Optional[str]) -> _LatestIndex:
    try:
        doc = json.loads(body)
    except json.JSONDecodeError as exc:
        raise click.ClickException(f"latest.json is not valid JSON: {exc}")
    required = ("version", "tarball_url", "sha256", "size_bytes", "min_sdk")
    missing = [k for k in required if k not in doc]
    if missing:
        raise click.ClickException(f"latest.json missing required fields: {missing}")
    if not isinstance(doc["sha256"], str) or len(doc["sha256"]) != 64:
        raise click.ClickException("latest.json sha256 must be a 64-char hex string")
    return _LatestIndex(
        version=str(doc["version"]),
        tarball_url=str(doc["tarball_url"]),
        sha256=doc["sha256"].lower(),
        size_bytes=int(doc["size_bytes"]),
        min_sdk=str(doc["min_sdk"]),
        max_sdk=doc.get("max_sdk"),
        raw=doc,
        etag=etag,
    )


def _semver_tuple(v: str) -> tuple[int, ...]:
    # Tolerant: ignore pre-release / build for compat gating; we just need
    # an ordered tuple. "0.5.5", "1.2.0.dev3" → leading numeric parts only.
    parts = []
    for chunk in v.split("."):
        m = re.match(r"^(\d+)", chunk)
        if not m:
            break
        parts.append(int(m.group(1)))
    return tuple(parts) if parts else (0,)


def _compat(installed: str, min_sdk: str, max_sdk: Optional[str]) -> bool:
    cur = _semver_tuple(installed)
    if cur < _semver_tuple(min_sdk):
        return False
    if max_sdk and cur > _semver_tuple(max_sdk):
        return False
    return True


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fp:
        for chunk in iter(lambda: fp.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_current_manifest(target: Path) -> Optional[dict]:
    link = target / _CURRENT_LINK_NAME
    if not link.exists():
        return None
    manifest = link / _MANIFEST_NAME
    if not manifest.is_file():
        return None
    try:
        doc = json.loads(manifest.read_text())
    except (OSError, json.JSONDecodeError):
        return None
    # Cross-check the manifest version against the symlink target. The symlink
    # is written atomically from the verified `idx.version` on a successful
    # install; if the version field disagrees, the manifest has been edited
    # post-install and must not be trusted (e.g. for ETag-based 304 noop).
    try:
        link_target = os.readlink(link)
    except OSError:
        return None
    if doc.get("version") != link_target:
        return None
    return doc


def _verify_cosign(tarball: Path, *, expected_version: str,
                   bundle: Optional[bytes],
                   sig: Optional[bytes], cert: Optional[bytes]) -> None:
    """Cosign keyless verify. Raises click.ClickException on failure.

    Lazy-imports `sigstore` so default `pip install hexr-sdk` does NOT pull
    cryptography/securesystemslib. Users running `hexr update signatures`
    against the signed registry need `pip install hexr-sdk[ops]`.
    """
    try:
        from sigstore.models import Bundle  # type: ignore[import-not-found]
        from sigstore.verify import Verifier  # type: ignore[import-not-found]
        from sigstore.verify.policy import Identity  # type: ignore[import-not-found]
    except ImportError as exc:
        raise click.ClickException(
            "Signature verification requires the `sigstore` library. Install it "
            "with `pip install 'hexr-sdk[ops]'` (or pass `--no-verify` for "
            "air-gapped / pre-verified packs)."
        ) from exc

    policy = Identity(
        identity=_COSIGN_IDENTITY_TEMPLATE.format(version=expected_version),
        issuer=_COSIGN_OIDC_ISSUER,
    )
    verifier = Verifier.production()
    artifact_bytes = tarball.read_bytes()

    if bundle is not None:
        sig_bundle = Bundle.from_json(bundle)
        verifier.verify_artifact(
            input_=artifact_bytes,
            bundle=sig_bundle,
            policy=policy,
        )
        return

    if sig is None or cert is None:
        raise click.ClickException(
            "No signature material found alongside the tarball. Expected either "
            "`.sigstore.json` (preferred) or both `.sig` + `.crt` siblings."
        )

    # Detached cosign format (legacy). Construct a Bundle if sigstore exposes
    # the helper; otherwise fall back to building one. v3.x of sigstore-python
    # accepts detached verification via Bundle.from_parts or similar; if the
    # installed version does not, surface a clear error so the operator
    # publishes the modern bundle format instead.
    if hasattr(Bundle, "from_parts"):
        sig_bundle = Bundle.from_parts(cert=cert, signature=sig)  # type: ignore[attr-defined]
        verifier.verify_artifact(
            input_=artifact_bytes,
            bundle=sig_bundle,
            policy=policy,
        )
        return

    raise click.ClickException(
        "Detached .sig + .crt format requires sigstore>=3.5 with Bundle.from_parts. "
        "Either upgrade `sigstore` or publish the artifact with the modern "
        "`.sigstore.json` bundle format (cosign --bundle)."
    )


def _atomic_swap_symlink(link: Path, new_target_relative: str) -> None:
    """Atomic-replace `link` to point at `new_target_relative` (sibling name)."""
    tmp = link.with_name(link.name + ".tmp")
    if tmp.exists() or tmp.is_symlink():
        tmp.unlink()
    os.symlink(new_target_relative, tmp)
    os.replace(tmp, link)


def _extract_tarball(tarball: Path, dest: Path) -> int:
    """Extract `tarball` into `dest` (must not exist). Returns YAML file count."""
    dest.mkdir(parents=True, exist_ok=False)
    with tarfile.open(tarball) as tf:
        tf.extractall(dest, filter="data")
    count = 0
    for sub in ("frameworks", "patterns"):
        sub_dir = dest / sub
        if sub_dir.is_dir():
            count += sum(1 for _ in sub_dir.glob("*.yaml"))
    return count


def _flow_signed_index(index_url: str, target: Path, *, no_verify: bool) -> int:
    """The §21.4.4 7-step flow. Returns process exit code."""
    target.mkdir(parents=True, exist_ok=True)
    staging_root = target / _STAGING_DIR_NAME
    staging_root.mkdir(exist_ok=True)
    current_link = target / _CURRENT_LINK_NAME

    cur_manifest = _read_current_manifest(target)
    cached_etag = cur_manifest.get("etag") if cur_manifest else None

    # Step 1 — fetch index
    try:
        body, hdrs = _http_get(index_url, etag=cached_etag)
    except HTTPError as exc:
        if exc.code == 304:
            console.print(f"[dim]✓ Already current ({cur_manifest['version']}, 304).[/dim]")
            return EXIT_NOOP
        console.print(f"[red]✗[/red] HTTP {exc.code} fetching {index_url}: {exc.reason}")
        return EXIT_NETWORK
    except URLError as exc:
        console.print(f"[red]✗[/red] Network error fetching {index_url}: {exc.reason}")
        return EXIT_NETWORK

    # Step 2 — parse + compat gate
    idx = _parse_latest(body, etag=hdrs.get("etag"))
    if not _compat(hexr.__version__, idx.min_sdk, idx.max_sdk):
        console.print(
            f"[red]✗[/red] Pack {idx.version} requires SDK in "
            f"[{idx.min_sdk}, {idx.max_sdk or '∞'}]; you have {hexr.__version__}."
        )
        return EXIT_INCOMPAT

    # Step 3 — version dedup
    if cur_manifest and cur_manifest.get("version") == idx.version:
        console.print(f"[dim]✓ Already current ({idx.version}).[/dim]")
        return EXIT_NOOP

    # Step 4 — download tarball + signature material into per-version staging
    ver_staging = staging_root / idx.version
    if ver_staging.exists():
        shutil.rmtree(ver_staging)
    ver_staging.mkdir(parents=True)

    tarball = ver_staging / Path(idx.tarball_url).name
    try:
        body, _ = _http_get(idx.tarball_url)
        tarball.write_bytes(body)
        if len(body) != idx.size_bytes:
            console.print(
                f"[red]✗[/red] Size mismatch: got {len(body)}, "
                f"latest.json said {idx.size_bytes}."
            )
            shutil.rmtree(ver_staging)
            return EXIT_VERIFY
    except (HTTPError, URLError) as exc:
        reason = getattr(exc, "reason", str(exc))
        console.print(f"[red]✗[/red] Could not download tarball: {reason}")
        shutil.rmtree(ver_staging, ignore_errors=True)
        return EXIT_NETWORK

    # Step 5 — SHA-256
    got = _sha256_file(tarball)
    if got != idx.sha256:
        console.print(
            f"[red]✗[/red] SHA-256 mismatch:\n  expected {idx.sha256}\n  got      {got}"
        )
        shutil.rmtree(ver_staging)
        return EXIT_VERIFY

    # Step 6 — cosign verify
    if not no_verify:
        bundle_bytes = _http_get_optional(idx.tarball_url + ".sigstore.json")
        sig_bytes = _http_get_optional(idx.tarball_url + ".sig") if bundle_bytes is None else None
        crt_bytes = _http_get_optional(idx.tarball_url + ".crt") if bundle_bytes is None else None
        try:
            _verify_cosign(tarball, expected_version=idx.version,
                           bundle=bundle_bytes, sig=sig_bytes, cert=crt_bytes)
        except click.ClickException as exc:
            console.print(f"[red]✗[/red] Signature verification failed: {exc.message}")
            shutil.rmtree(ver_staging)
            return EXIT_VERIFY
        except Exception as exc:  # noqa: BLE001 — sigstore raises typed errors but we don't import them at top level
            console.print(f"[red]✗[/red] Signature verification failed: {exc}")
            shutil.rmtree(ver_staging)
            return EXIT_VERIFY

    # Step 7 — extract, atomic swap, manifest
    final_dir = target / idx.version
    if final_dir.exists():
        shutil.rmtree(final_dir)
    count = _extract_tarball(tarball, final_dir)

    manifest = {
        "version": idx.version,
        "sha256": idx.sha256,
        "size_bytes": idx.size_bytes,
        "min_sdk": idx.min_sdk,
        "max_sdk": idx.max_sdk,
        "etag": idx.etag,
        "verified": not no_verify,
        "source": index_url,
        "released_at": idx.raw.get("released_at"),
        "fulcio_subject": idx.raw.get("fulcio_subject"),
        "rekor_log_index": idx.raw.get("rekor_log_index"),
    }
    (final_dir / _MANIFEST_NAME).write_text(json.dumps(manifest, indent=2))

    _atomic_swap_symlink(current_link, idx.version)
    shutil.rmtree(ver_staging, ignore_errors=True)

    verify_note = "verified" if not no_verify else "[yellow]UNVERIFIED[/yellow]"
    console.print(
        f"[green]✓[/green] Installed signatures {idx.version} "
        f"({count} YAML file(s), {verify_note}) into {final_dir}\n"
        f"[dim]Next `hexr analyze` picks them up via `current/` symlink.[/dim]"
    )
    return EXIT_OK


# ─── Local + legacy-direct-tarball flows (back-compat) ───────────────────────


def _copy_tree(src: Path, dst: Path) -> int:
    """Copy frameworks/+patterns/*.yaml from src into dst. Returns YAML count."""
    count = 0
    for sub in ("frameworks", "patterns"):
        src_sub = src / sub
        if not src_sub.is_dir():
            continue
        dst_sub = dst / sub
        dst_sub.mkdir(parents=True, exist_ok=True)
        for yml in src_sub.glob("*.yaml"):
            shutil.copy2(yml, dst_sub / yml.name)
            count += 1
    return count


def _flow_local(source: Path, target: Path) -> int:
    """Unverified local install — air-gap / dev workflow."""
    target.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        n = _copy_tree(source, target)
    elif source.is_file() and source.suffixes[-2:] == [".tar", ".gz"]:
        with tempfile.TemporaryDirectory(prefix="hexr-sig-pull-") as tmp:
            with tarfile.open(source) as tf:
                tf.extractall(tmp, filter="data")
            n = _copy_tree(Path(tmp), target)
    else:
        raise click.UsageError(
            f"Unsupported local source: {source} "
            f"(expected a directory or .tar.gz file)"
        )
    console.print(
        f"[green]✓[/green] Installed {n} signature file(s) into {target} "
        f"[yellow](UNVERIFIED — local source)[/yellow]"
    )
    return EXIT_OK


def _flow_direct_tarball(url: str, target: Path, *, no_verify: bool) -> int:
    """Legacy `--source https://…/latest.tar.gz` (NOT latest.json).

    Spec §21.4.5 recommends pointing `--source` at `latest.json` (the index)
    for the cheap noop fast path. We still accept a direct tarball URL for
    operators with custom mirrors.
    """
    target.mkdir(parents=True, exist_ok=True)
    try:
        body, _ = _http_get(url)
    except (HTTPError, URLError) as exc:
        reason = getattr(exc, "reason", str(exc))
        console.print(
            f"[red]✗[/red] Could not reach {url}: {reason}\n"
            f"[dim]If `signatures.hexr.cloud` is not online yet for your tenant, "
            f"use `hexr update signatures --source ./pack/` instead.[/dim]"
        )
        return EXIT_NETWORK

    with tempfile.TemporaryDirectory(prefix="hexr-sig-direct-") as tmp_str:
        tmp = Path(tmp_str)
        tarball = tmp / Path(url).name
        tarball.write_bytes(body)

        if not no_verify:
            bundle = _http_get_optional(url + ".sigstore.json")
            sig = _http_get_optional(url + ".sig") if bundle is None else None
            crt = _http_get_optional(url + ".crt") if bundle is None else None
            if bundle is None and (sig is None or crt is None):
                console.print(
                    "[yellow]⚠[/yellow]  No signature material found for direct "
                    "tarball; proceeding UNVERIFIED. Pass `--no-verify` to "
                    "silence this warning, or point `--source` at a `latest.json`."
                )
            else:
                # Derive the expected version from the URL path: the canonical
                # layout is `…/v/<version>/hexr-signatures-<version>.tar.gz`.
                m = re.search(r"/v/([^/]+)/hexr-signatures-", url)
                if not m:
                    console.print(
                        "[red]✗[/red] Direct-tarball URL must match "
                        "`.../v/<version>/hexr-signatures-<version>.tar.gz` "
                        "to bind the cosign identity to a specific release tag."
                    )
                    return EXIT_VERIFY
                try:
                    _verify_cosign(tarball, expected_version=m.group(1),
                                   bundle=bundle, sig=sig, cert=crt)
                except click.ClickException as exc:
                    console.print(f"[red]✗[/red] Signature verification failed: {exc.message}")
                    return EXIT_VERIFY

        with tarfile.open(tarball) as tf:
            tf.extractall(tmp, filter="data")
        n = _copy_tree(tmp, target)

    console.print(
        f"[green]✓[/green] Installed {n} signature file(s) into {target} "
        f"[dim](direct tarball mode)[/dim]"
    )
    return EXIT_OK


# ─── Click surface ───────────────────────────────────────────────────────────


@click.group(name="update")
def update_command() -> None:
    """Update SDK assets that ship outside the wheel (signature packs, etc.)."""


@update_command.command(name="signatures")
@click.option(
    "--source",
    default=_DEFAULT_SOURCE,
    show_default=True,
    help=(
        "Signature pack source. Recommended: `latest.json` URL (signed index). "
        "Also accepts a local dir, local .tar.gz, or direct .tar.gz URL."
    ),
)
@click.option(
    "--target",
    type=click.Path(path_type=Path),
    default=_USER_DIR,
    show_default=True,
    help="Where to install the pack (overlay precedence: shipped < user < project).",
)
@click.option(
    "--no-verify",
    is_flag=True,
    help=(
        "Skip cosign keyless verification. ONLY for air-gapped customers using "
        "ConfigMap-distributed packs that were verified at build time (spec "
        "§21.4.6)."
    ),
)
def signatures_command(source: str, target: Path, no_verify: bool) -> None:
    """Pull framework/pattern signature packs into the user overlay dir.

    Exit codes (spec §21.4.4): 0=updated, 2=already current, 64=network,
    65=signature verification failed, 66=SDK incompatible.
    """
    if source.startswith("http://"):
        raise click.UsageError("HTTP sources are not allowed; use https:// or a local path.")

    if source.startswith("https://"):
        if source.endswith(".json"):
            code = _flow_signed_index(source, target, no_verify=no_verify)
        else:
            code = _flow_direct_tarball(source, target, no_verify=no_verify)
    else:
        code = _flow_local(Path(source).expanduser().resolve(), target)

    sys.exit(code)
