"""Runtime evidence helper — Stage 1 (hybrid pivot).

Posts a single compliance-evidence record to the data-plane evidence API
(`hexr-evidence-api`) running in the customer's VPC. This is the wedge:
the evidence never leaves the customer's cluster.

URL resolution (first match wins):
  1. ``HEXR_EVIDENCE_URL`` env var (any deployment)
  2. In-cluster default ``http://hexr-evidence-api.hexr-system.svc:8080``
     (detected via ``KUBERNETES_SERVICE_HOST``)

If neither resolves, no evidence is posted. That is deliberate: there is no
third option, and in particular no fall-back to the control plane.

A third branch used to exist here. When the first two missed, it loaded
``CloudConfig`` from ``~/.hexr/config.json`` and posted the record to
``cfg.cloud_url`` + ``/v1/evidence/record`` with the user's API key as a
bearer token. That was written while the SaaS still ran. After the hybrid
pivot it was actively harmful:

  * ``cloud_url`` on any machine that ever ran ``hexr login`` points at
    ``https://api.hexr.cloud`` — the CONTROL PLANE. So an agent run outside
    a cluster shipped evidence rows (tool name, SPIFFE ID, tenant, control
    mapping) plus a live API key to Hexr, breaking the single load-bearing
    promise of the pivot: evidence never leaves the customer's VPC, and only
    five scalars ever cross DP → CP.
  * It could not even succeed. ``/v1/evidence/record`` was served by the
    decommissioned cloud-api; ``hexr-license-api`` registers only
    ``/v1/healthz``, ``/v1/cli/agents`` and the two ``spire`` routes, so
    every attempt was a 404 that leaked the request before failing.

The data-plane API exposes ``POST /v1/evidence`` (no ``/record`` suffix).
"""

from __future__ import annotations

import json as _json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_DATAPLANE_URL = "http://hexr-evidence-api.hexr-system.svc:8080"
_DATAPLANE_PATH = "/v1/evidence"


def _resolve_endpoint() -> tuple[str, str, dict[str, str]]:
    """Return (base_url, path, headers). Empty base_url means 'no endpoint'."""
    override = os.environ.get("HEXR_EVIDENCE_URL", "").strip()
    if override:
        return override.rstrip("/"), _DATAPLANE_PATH, {}

    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return DEFAULT_DATAPLANE_URL, _DATAPLANE_PATH, {}

    # No fall-back. See module docstring: the removed CloudConfig branch sent
    # evidence to the control plane. Returning "" makes post_evidence a no-op.
    return "", _DATAPLANE_PATH, {}


# ── Fire-and-forget that does not forget ─────────────────────────────────────
#
# Evidence is posted on a background thread so a tool call never blocks on the
# evidence store. The first version used a daemon thread, which the interpreter
# kills at exit without waiting. A short-lived process — a spawned sub-agent
# that does one job and returns, which is EXACTLY the pattern per-process
# identity exists for — therefore exited before its POST landed, and its
# evidence vanished. Two sub-agents with two correct identities and zero rows
# between them, on 2026-09-18.
#
# So in-flight emits are tracked, and an atexit hook waits for them — bounded,
# because a hung evidence API must not be able to pin a process open forever.

import atexit
import threading

_INFLIGHT: set[threading.Thread] = set()
_INFLIGHT_LOCK = threading.Lock()
_FLUSH_TIMEOUT_SECONDS = float(os.environ.get("HEXR_EVIDENCE_FLUSH_TIMEOUT", "5"))


def emit_in_background(fn, *args, name: str = "hexr-evidence-emit") -> None:
    """Run ``fn(*args)`` on a tracked thread that ``flush_evidence`` will wait for."""
    def _run() -> None:
        try:
            fn(*args)
        finally:
            with _INFLIGHT_LOCK:
                _INFLIGHT.discard(threading.current_thread())

    # daemon=True is still correct: if flush_evidence times out, the process
    # must be allowed to exit. The atexit hook is what gives the thread its
    # chance; daemon status is what stops it holding the process hostage.
    t = threading.Thread(target=_run, name=name, daemon=True)
    with _INFLIGHT_LOCK:
        _INFLIGHT.add(t)
    t.start()


def flush_evidence(timeout: float | None = None) -> int:
    """Wait for in-flight evidence posts. Returns how many were still pending.

    Called automatically at interpreter exit. Also safe to call explicitly at
    the end of a short-lived worker, which is the honest thing to do in a
    process whose whole lifetime is shorter than one HTTP round-trip.
    """
    deadline = time.monotonic() + (timeout if timeout is not None else _FLUSH_TIMEOUT_SECONDS)
    with _INFLIGHT_LOCK:
        pending = list(_INFLIGHT)
    for t in pending:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        t.join(timeout=remaining)
    with _INFLIGHT_LOCK:
        left = len(_INFLIGHT)
    if left:
        logger.warning(
            "evidence: %d post(s) still in flight at exit after %.1fs — "
            "rows may be lost; raise HEXR_EVIDENCE_FLUSH_TIMEOUT if the store is slow",
            left, _FLUSH_TIMEOUT_SECONDS,
        )
    return left


atexit.register(flush_evidence)


def post_evidence(
    event_type: str,
    control_id: str,
    details: dict[str, Any] | None = None,
    *,
    source: str | None = None,
    framework: str = "soc2",
    severity: str = "info",
    spiffe_id: str | None = None,
    tenant_id: str | None = None,
    timeout: float = 5.0,
) -> bool:
    """Post a single compliance-evidence record. Returns True on 2xx."""
    base, path, headers = _resolve_endpoint()
    if not base:
        logger.debug("evidence: no endpoint resolved — skipping (%s/%s)", control_id, event_type)
        return False

    try:
        import httpx
    except ImportError:
        logger.warning("evidence: httpx not installed — skipping post")
        return False

    enriched = dict(details or {})
    if not spiffe_id:
        # Ask the process, not the environment. An env var is inherited by every
        # child and so cannot name the process that actually wrote this row.
        from .identity import current_spiffe_id

        spiffe_id = current_spiffe_id() or "local-dev"
    enriched.setdefault("spiffe_id", spiffe_id)
    enriched.setdefault("timestamp", datetime.now(timezone.utc).isoformat())

    payload = {
        "tenant_id": tenant_id or os.environ.get("HEXR_TENANT", "demo"),
        "source": source or os.environ.get("HEXR_AGENT_NAME", "hexr-sdk"),
        "event_type": event_type,
        "severity": severity,
        "framework": framework,
        "control_id": control_id,
        "spiffe_id": enriched.get("spiffe_id", ""),
        "details": _json.dumps(enriched),
    }

    # Sign with this process's X.509-SVID where one is reachable (spec
    # §1.29.2). Best-effort by design: sign_payload returns False and leaves
    # the payload untouched whenever signing material is unavailable, and the
    # server stores the row as unsigned rather than rejecting it. Dropping
    # evidence because signing was unavailable is the worse failure — the row
    # is what the auditor needs, and its absence cannot be detected later.
    try:
        from hexr.evidence_signing import sign_payload

        if sign_payload(payload):
            logger.debug("evidence: row signed with X509-SVID")
    except Exception as exc:  # noqa: BLE001
        logger.debug("evidence: signing unavailable (%s) — posting unsigned", exc)

    try:
        with httpx.Client(base_url=base, headers=headers, timeout=timeout) as client:
            r = client.post(path, json=payload)
        if 200 <= r.status_code < 300:
            return True
        logger.warning("evidence: %s%s → HTTP %d %s", base, path, r.status_code, r.text[:160])
    except Exception as exc:
        logger.warning("evidence: post failed (non-fatal): %s", exc)
    return False


__all__ = ["post_evidence", "DEFAULT_DATAPLANE_URL"]
