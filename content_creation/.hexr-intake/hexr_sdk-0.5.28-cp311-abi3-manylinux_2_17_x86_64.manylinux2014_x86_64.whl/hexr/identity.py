"""
Who am I, right now, in THIS process.

The single place the SDK resolves the SPIFFE ID it signs evidence with.

WHY THIS MODULE EXISTS

Before it, three call sites each resolved the signer through the same chain:

    HEXR_SPIFFE_ID                     an environment variable
    get_last_registered_spiffe_id()    a module-global, "last registration wins"
    CredentialCache.get_summary()      an L2 cache shared across processes

None of those asks *who is calling*. An environment variable is inherited by
every child. A module global is whichever decorator registered last. A shared
cache answers for whoever populated it. So two ``@hexr_agent`` functions in one
pod signed every evidence row with the same identity — 234 rows over two
hours, all attributed to ``interview-scorer`` while ``resume-ranker`` made the
same calls and was credited with none.

The demo page said "two processes, two identities" while that was happening.

THE RULE

Identity is per-process. The only component that knows which process is
asking is the SPIRE Agent, because the kernel names the peer on the Workload
API socket (``SO_PEERCRED``). So this module asks the Workload API, and caches
the answer **keyed by PID** — which means a spawned child gets a cache miss and
resolves its own identity rather than inheriting its parent's.

Everything else in the old chain survives only as a fallback for the case where
the Workload API is unreachable, and it is logged as such so a fallback never
silently becomes the normal path.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)

# PID -> (spiffe_id, resolved_at). Keyed by PID on purpose: a forked or spawned
# child has a different PID, so it cannot read its parent's entry. That is the
# entire property this cache exists to preserve.
_BY_PID: dict[int, tuple[str, float]] = {}
_LOCK = threading.Lock()

# An X509-SVID lives for an hour by default; re-asking every few minutes is
# cheap insurance against a rotation the cache would otherwise miss.
_TTL_SECONDS = 300.0


def _from_workload_api() -> Optional[str]:
    """Ask the SPIRE Agent. It identifies us by socket peer credentials."""
    try:
        from .spiffe.workload_api_client import WorkloadAPIClient

        svid = WorkloadAPIClient().fetch_x509_svid()
        sid = getattr(svid, "spiffe_id", None)
        return str(sid) if sid else None
    except Exception as exc:  # noqa: BLE001 — unavailable is a normal condition off-cluster
        logger.debug("workload api unavailable for identity resolution: %s", exc)
        return None


def _fallback() -> str:
    """The pre-2026-09-18 chain. Kept ONLY for when the Workload API is down.

    Order matters less than it looks, because every branch here is already
    wrong in the same way — none is process-scoped. It is retained so an
    off-cluster developer run still produces attributable rows, not so that
    production ever relies on it.
    """
    sid = os.environ.get("HEXR_SPIFFE_ID", "")
    if sid:
        return sid
    try:
        from .synchronous_registration import get_last_registered_spiffe_id

        sid = get_last_registered_spiffe_id() or ""
    except Exception:  # noqa: BLE001
        sid = ""
    if sid:
        return sid
    try:
        from .credential.cache import CredentialCache

        summary = CredentialCache.get_instance().get_summary()
        sid = (summary.get("jwt_svid") or {}).get("spiffe_id", "") or ""
    except Exception:  # noqa: BLE001
        sid = ""
    return sid


def current_spiffe_id(*, refresh: bool = False) -> str:
    """Return the SPIFFE ID of THIS process, or "" if it has none.

    Resolution:
      1. PID-keyed cache, if fresh and ``refresh`` is False.
      2. The Workload API — authoritative, because SO_PEERCRED names the caller.
      3. The legacy chain, logged at WARNING so it cannot become invisible.

    An empty string means "this process has no identity", which is a true and
    useful answer: it is what an undecorated process gets, and evidence written
    under it is correctly unattributable.
    """
    pid = os.getpid()
    now = time.monotonic()

    if not refresh:
        with _LOCK:
            hit = _BY_PID.get(pid)
        if hit and (now - hit[1]) < _TTL_SECONDS:
            return hit[0]

    sid = _from_workload_api()
    if sid:
        with _LOCK:
            _BY_PID[pid] = (sid, now)
        return sid

    sid = _fallback()
    if sid:
        # Fallback attribution is NOT cached: if the Workload API comes back,
        # the very next call should ask it rather than keep serving a guess.
        logger.warning(
            "identity resolved via fallback (not the Workload API) for pid %d: %s — "
            "evidence attribution may be process-inaccurate",
            pid, sid,
        )
    return sid


def forget_current_process() -> None:
    """Drop this PID's cached identity. For tests and for post-fork hooks."""
    with _LOCK:
        _BY_PID.pop(os.getpid(), None)


# A forked child must never serve its parent's cached identity. os.register_at_fork
# runs in the child after fork(), where getpid() already returns the new PID —
# but clearing is still the right hygiene, and it makes the property hold even
# if PID reuse ever lands a child on an old key.
try:
    os.register_at_fork(after_in_child=lambda: _BY_PID.clear())
except AttributeError:  # not on this platform
    pass
