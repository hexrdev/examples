"""
Hexr A2A Client — Agent-to-Agent Communication

The A2AClient sends requests to remote agents through Envoy's outbound proxy.
Traffic flows: Python SDK → Envoy outbound (:15001) → target agent's Envoy
→ OPA → target agent's A2A sidecar (:8090).

For cross-cluster A2A (different Kubernetes clusters sharing the same
SPIFFE trust domain), pass ``spiffe_socket`` to enable direct mTLS:
    - The client fetches its own X.509 SVID from the SPIRE Workload API
    - Establishes a mutual TLS connection directly to the callee's Envoy
      inbound listener (port 8443, LoadBalancer Service)
    - No Envoy iptables interception is used in this mode

Features:
    - Agent Card discovery via GET /.well-known/agent.json (cached 5 min)
    - message/send, tasks/get, tasks/cancel via JSON-RPC 2.0
    - Automatic retry with exponential backoff
    - Trace context propagation (W3C traceparent)
    - Connection pooling via httpx

Usage (intra-cluster via Envoy mesh):
    from hexr.a2a import A2AClient, Message

    async with A2AClient("http://research-agent.hexr-agents.svc.cluster.local") as client:
        card = await client.discover()
        task = await client.send(Message.user("Find papers on quantum computing"))
        result = await client.get_task(task.id)

Usage (cross-cluster mTLS):
    async with A2AClient(
        "https://<callee-lb-ip>:8443",
        spiffe_socket="/run/spire/sockets/agent.sock",
    ) as client:
        task = await client.send(Message.user("Analyze sector: fintech"))
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import ssl
import tempfile
import time
import uuid
from typing import Any

import httpx

from .errors import A2AError, TaskNotFoundError, TaskTimeoutError
from .json_rpc import (
    JSONRPCResponse,
    build_cancel_task_request,
    build_get_task_request,
    build_send_request,
    parse_json_rpc_response,
)
from .models import AgentCard, Message, Task

logger = logging.getLogger("hexr.a2a.client")

# OTel integration — graceful degradation if not installed
try:
    from hexr.observability import get_tracer
    from hexr.observability.spans import SpanNames, SpanAttributes
    _tracer = get_tracer("hexr.a2a.client")
    _OTEL_AVAILABLE = True
except ImportError:
    _OTEL_AVAILABLE = False
    _tracer = None


def _nullcontext():
    """No-op context manager when OTel is not available."""
    return contextlib.nullcontext()


class A2AClient:
    """Client for calling remote A2A agents through Envoy mesh.

    Args:
        base_url: Target agent's service URL.
            - Intra-cluster: ``http://agent.namespace.svc.cluster.local``
            - Cross-cluster: ``https://<callee-lb-ip>:8443``
        timeout: Request timeout in seconds (default: 300 = 5 min for long tasks)
        max_retries: Maximum retry attempts for transient failures (default: 3)
        card_cache_ttl: Agent Card cache TTL in seconds (default: 300)
        spiffe_socket: Path to SPIRE Workload API socket for cross-cluster mTLS.
            When set, the client fetches its X.509 SVID via the Workload API and
            establishes direct mTLS to the callee (no Envoy iptables proxy).
            Example: ``/run/spire/sockets/agent.sock``
    """

    def __init__(
        self,
        base_url: str,
        *,
        timeout: float = 300.0,
        max_retries: int = 3,
        card_cache_ttl: float = 300.0,
        spiffe_socket: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.card_cache_ttl = card_cache_ttl
        self.spiffe_socket = spiffe_socket

        self._client: httpx.AsyncClient | None = None
        self._card_cache: AgentCard | None = None
        self._card_cached_at: float = 0.0
        # Temp files for SPIFFE certs — kept alive while client is open
        self._spiffe_cert_file: Any = None
        self._spiffe_key_file: Any = None
        self._spiffe_bundle_file: Any = None

    async def __aenter__(self) -> A2AClient:
        if self.spiffe_socket:
            self._client = await self._build_mtls_client()
        else:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None
        for tmp in (self._spiffe_cert_file, self._spiffe_key_file, self._spiffe_bundle_file):
            if tmp is not None:
                try:
                    tmp.close()
                except Exception:
                    pass
        self._spiffe_cert_file = None
        self._spiffe_key_file = None
        self._spiffe_bundle_file = None

    async def _build_mtls_client(self) -> httpx.AsyncClient:
        """Build an httpx client with SPIFFE mTLS for cross-cluster A2A.

        Fetches the X.509 SVID and trust bundle from the local SPIRE Workload API
        socket, writes them to temp files, and creates an SSL context for mutual TLS.

        The callee's Envoy inbound listener (port 8443) validates:
          - Our client cert (presented SVID from the shared trust domain)
          - Our SPIFFE SAN (must match spiffe://<trust_domain>/*)

        We validate the callee using the SPIRE trust bundle (same CA root).
        """
        try:
            from spiffe import WorkloadApiClient  # type: ignore[import]
        except ImportError as exc:
            raise A2AError(
                "spiffe package is required for cross-cluster mTLS. "
                "Install with: pip install spiffe",
                code=-32603,
            ) from exc

        socket_path = self.spiffe_socket
        if not socket_path.startswith("unix://"):
            socket_path = f"unix://{socket_path}"

        logger.info("Fetching X.509 SVID from SPIRE socket: %s", socket_path)
        try:
            # py-spiffe's constructor takes socket_path (unix:// URI). The
            # previous keyword never existed in any released version, so this
            # path — the caller presenting ITS OWN identity — had never run.
            # The July 2026 A2A proof went through a port-forward around mTLS.
            with WorkloadApiClient(socket_path=socket_path) as wapi:
                svid_list = wapi.fetch_x509_svids()
                if not svid_list:
                    raise A2AError(
                        "No X.509 SVIDs returned from SPIRE Workload API. "
                        "Is the SPIRE agent running and has a registration entry been created?",
                        code=-32603,
                    )
                svid = svid_list[0]
                bundle = wapi.fetch_x509_bundles()
        except A2AError:
            raise
        except Exception as exc:
            raise A2AError(
                f"Failed to fetch SVID from SPIRE Workload API: {exc}",
                code=-32603,
            ) from exc

        # Write PEM cert chain, private key, and CA bundle to temp files.
        # We keep references to prevent GC/deletion while the client is alive.
        self._spiffe_cert_file = tempfile.NamedTemporaryFile(suffix=".pem", delete=False)
        self._spiffe_key_file = tempfile.NamedTemporaryFile(suffix=".pem", delete=False)
        self._spiffe_bundle_file = tempfile.NamedTemporaryFile(suffix=".pem", delete=False)

        try:
            from cryptography.hazmat.primitives import serialization

            # py-spiffe hands back cryptography objects, not PEM strings.
            cert_pem = b"".join(c.public_bytes(serialization.Encoding.PEM) for c in svid.cert_chain)
            key_pem = svid.private_key.private_bytes(
                serialization.Encoding.PEM,
                serialization.PrivateFormat.PKCS8,
                serialization.NoEncryption(),
            )

            # Gather trust bundle PEM: every authority of every trust domain the
            # Workload API knows (own domain, plus any federated ones).
            bundle_pems: list[bytes] = []
            # X509BundleSet.bundles is a collection of X509Bundle (a set in
            # current py-spiffe; a mapping in older releases).
            td_bundles = bundle.bundles.values() if hasattr(bundle.bundles, "values") else bundle.bundles
            for td_bundle in td_bundles:
                auths = td_bundle.x509_authorities
                for authority in (auths() if callable(auths) else auths):
                    bundle_pems.append(authority.public_bytes(serialization.Encoding.PEM))
            if not bundle_pems:
                raise A2AError(
                    "No trust bundle entries returned from SPIRE Workload API.",
                    code=-32603,
                )
            combined_bundle_pem = b"\n".join(bundle_pems)

            if isinstance(cert_pem, str):
                cert_pem = cert_pem.encode()
            if isinstance(key_pem, str):
                key_pem = key_pem.encode()

            self._spiffe_cert_file.write(cert_pem)
            self._spiffe_cert_file.flush()
            self._spiffe_key_file.write(key_pem)
            self._spiffe_key_file.flush()
            self._spiffe_bundle_file.write(combined_bundle_pem)
            self._spiffe_bundle_file.flush()

            cert_path = self._spiffe_cert_file.name
            key_path = self._spiffe_key_file.name
            bundle_path = self._spiffe_bundle_file.name

        except A2AError:
            raise
        except Exception as exc:
            raise A2AError(
                f"Failed to write SPIFFE cert material to temp files: {exc}",
                code=-32603,
            ) from exc

        ssl_ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=bundle_path)
        ssl_ctx.load_cert_chain(certfile=cert_path, keyfile=key_path)
        # The callee's CN will be a SPIFFE URI SAN, not a hostname — disable hostname check.
        # The CA validation (trust bundle) still applies, so mTLS integrity is maintained.
        ssl_ctx.check_hostname = False

        logger.info(
            "mTLS client ready — SVID: %s, trust bundle: %d CA(s)",
            svid.spiffe_id,
            len(bundle_pems),
        )
        return httpx.AsyncClient(
            verify=ssl_ctx,
            timeout=httpx.Timeout(self.timeout, connect=10.0),
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
        )

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            if self.spiffe_socket:
                raise A2AError(
                    "A2AClient with spiffe_socket must be used as an async context manager "
                    "(async with A2AClient(...) as client:)",
                    code=-32603,
                )
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout, connect=10.0),
                limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
            )
        return self._client

    # -------------------------------------------------------------------
    # Agent Card Discovery
    # -------------------------------------------------------------------

    async def discover(self, *, force: bool = False) -> AgentCard:
        """Fetch the agent's Agent Card (/.well-known/agent.json).

        Results are cached for card_cache_ttl seconds.

        Args:
            force: Bypass cache and fetch fresh.

        Returns:
            The remote agent's AgentCard.

        Raises:
            A2AError: If discovery fails.
        """
        now = time.monotonic()
        if not force and self._card_cache and (now - self._card_cached_at) < self.card_cache_ttl:
            return self._card_cache

        url = f"{self.base_url}/.well-known/agent.json"
        client = self._get_client()

        span_cm = (
            _tracer.start_as_current_span(
                SpanNames.A2A_CLIENT_DISCOVER,
                attributes={SpanAttributes.A2A_AGENT_TARGET: self.base_url},
            )
            if _OTEL_AVAILABLE
            else _nullcontext()
        )

        with span_cm as span:
            try:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json()
                card = AgentCard.model_validate(data)
                self._card_cache = card
                self._card_cached_at = now
                logger.debug("Discovered agent: %s (%d skills)", card.name, len(card.skills))
                return card
            except httpx.HTTPStatusError as e:
                if _OTEL_AVAILABLE and span:
                    span.set_attribute(SpanAttributes.ERROR_TYPE, type(e).__name__)
                raise A2AError(
                    f"Agent Card discovery failed: HTTP {e.response.status_code}",
                    code=-32603,
                ) from e
            except Exception as e:
                if _OTEL_AVAILABLE and span:
                    span.set_attribute(SpanAttributes.ERROR_TYPE, type(e).__name__)
                raise A2AError(
                    f"Agent Card discovery failed: {e}",
                    code=-32603,
                ) from e

    # -------------------------------------------------------------------
    # Core A2A Methods
    # -------------------------------------------------------------------

    async def send(
        self,
        message: Message,
        *,
        task_id: str | None = None,
        context_id: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> Task:
        """Send a message to the agent via message/send.

        This is the primary A2A method. It creates a task, executes it
        synchronously in the remote sidecar, and returns the completed task.

        Args:
            message: The message to send (use Message.user("...") for convenience).
            task_id: Client-generated task ID for idempotency. Auto-generated if omitted.
            context_id: Groups related tasks in a multi-turn conversation.
            metadata: Optional key-value metadata for the task.

        Returns:
            Completed (or failed) Task with artifacts.

        Raises:
            A2AError: On protocol or execution errors.
        """
        if task_id is None:
            task_id = str(uuid.uuid4())

        params: dict[str, Any] = {
            "id": task_id,
            "message": message.model_dump(by_alias=True, exclude_none=True),
        }
        if context_id:
            params["contextId"] = context_id
        if metadata:
            params["metadata"] = metadata

        request_id = str(uuid.uuid4())
        rpc_req = build_send_request(request_id, params)

        span_attrs = {SpanAttributes.A2A_TASK_ID: task_id, SpanAttributes.A2A_METHOD: "message/send"} if _OTEL_AVAILABLE else {}
        if _OTEL_AVAILABLE and context_id:
            span_attrs[SpanAttributes.A2A_CONTEXT_ID] = context_id

        span_cm = (
            _tracer.start_as_current_span(SpanNames.A2A_CLIENT_SEND, attributes=span_attrs)
            if _OTEL_AVAILABLE
            else _nullcontext()
        )

        with span_cm:
            response = await self._rpc_call(rpc_req.to_dict())
            return response.task()

    async def get_task(self, task_id: str) -> Task:
        """Query task state via tasks/get.

        Args:
            task_id: The task ID to query.

        Returns:
            Current Task state.

        Raises:
            TaskNotFoundError: If the task doesn't exist.
            A2AError: On protocol errors.
        """
        request_id = str(uuid.uuid4())
        rpc_req = build_get_task_request(request_id, task_id)

        span_cm = (
            _tracer.start_as_current_span(
                SpanNames.A2A_CLIENT_GET_TASK,
                attributes={SpanAttributes.A2A_TASK_ID: task_id, SpanAttributes.A2A_METHOD: "tasks/get"},
            )
            if _OTEL_AVAILABLE
            else _nullcontext()
        )

        with span_cm:
            response = await self._rpc_call(rpc_req.to_dict())
            return response.task()

    async def cancel_task(self, task_id: str) -> dict[str, Any]:
        """Request cooperative cancellation via tasks/cancel.

        This sets a cancel flag in Valkey. The sidecar checks the flag
        before and after agent execution.

        Args:
            task_id: The task ID to cancel.

        Returns:
            Response dict with cancel status.

        Raises:
            TaskNotFoundError: If the task doesn't exist.
            A2AError: On protocol errors.
        """
        request_id = str(uuid.uuid4())
        rpc_req = build_cancel_task_request(request_id, task_id)

        span_cm = (
            _tracer.start_as_current_span(
                SpanNames.A2A_CLIENT_CANCEL_TASK,
                attributes={SpanAttributes.A2A_TASK_ID: task_id, SpanAttributes.A2A_METHOD: "tasks/cancel"},
            )
            if _OTEL_AVAILABLE
            else _nullcontext()
        )

        with span_cm:
            response = await self._rpc_call(rpc_req.to_dict())

            if response.is_error:
                raise response.to_exception()
            return response.result or {}

    async def send_and_poll(
        self,
        message: Message,
        *,
        task_id: str | None = None,
        context_id: str | None = None,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> Task:
        """Send a message and poll until the task reaches a terminal state.

        Useful for long-running tasks where message/send may return before
        completion (e.g., when the sidecar supports async execution in future).

        Args:
            message: The message to send.
            task_id: Optional task ID for idempotency.
            context_id: Optional context grouping.
            poll_interval: Seconds between polls.
            timeout: Maximum wait time before raising TaskTimeoutError.

        Returns:
            Completed/failed/canceled Task.

        Raises:
            TaskTimeoutError: If timeout exceeded.
            A2AError: On protocol errors.
        """
        task = await self.send(
            message, task_id=task_id, context_id=context_id,
        )

        if task.is_terminal:
            return task

        start = time.monotonic()
        while True:
            elapsed = time.monotonic() - start
            if elapsed > timeout:
                raise TaskTimeoutError(
                    task_id=task.id,
                    message=f"Task {task.id} did not complete within {timeout}s",
                )

            await asyncio.sleep(poll_interval)
            task = await self.get_task(task.id)
            if task.is_terminal:
                return task

    # -------------------------------------------------------------------
    # Internal: JSON-RPC call with retry
    # -------------------------------------------------------------------

    async def _rpc_call(self, payload: dict[str, Any]) -> JSONRPCResponse:
        """Execute a JSON-RPC call with exponential backoff retry.

        Retries on 5xx, connection errors, and timeouts.
        Does NOT retry on 4xx or JSON-RPC application errors.
        """
        url = f"{self.base_url}/a2a"
        client = self._get_client()
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                resp = await client.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json"},
                )

                # Parse JSON-RPC response
                data = resp.json()
                rpc_resp = parse_json_rpc_response(data)

                # Log method and result
                method = payload.get("method", "unknown")
                if rpc_resp.is_error:
                    logger.warning(
                        "A2A call %s returned error: [%d] %s",
                        method, rpc_resp.error.code, rpc_resp.error.message,
                    )
                else:
                    logger.debug("A2A call %s succeeded", method)

                return rpc_resp

            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout) as e:
                last_error = e
                if attempt < self.max_retries:
                    wait = min(2 ** attempt, 30)
                    logger.warning(
                        "A2A call attempt %d/%d failed (%s), retrying in %ds",
                        attempt + 1, self.max_retries + 1, type(e).__name__, wait,
                    )
                    await asyncio.sleep(wait)
                    continue
                break

            except httpx.HTTPStatusError as e:
                if e.response.status_code >= 500 and attempt < self.max_retries:
                    last_error = e
                    wait = min(2 ** attempt, 30)
                    logger.warning(
                        "A2A call attempt %d/%d got HTTP %d, retrying in %ds",
                        attempt + 1, self.max_retries + 1,
                        e.response.status_code, wait,
                    )
                    await asyncio.sleep(wait)
                    continue
                raise A2AError(
                    f"A2A call failed: HTTP {e.response.status_code}",
                    code=-32603,
                ) from e

        raise A2AError(
            f"A2A call failed after {self.max_retries + 1} attempts: {last_error}",
            code=-32603,
        )
