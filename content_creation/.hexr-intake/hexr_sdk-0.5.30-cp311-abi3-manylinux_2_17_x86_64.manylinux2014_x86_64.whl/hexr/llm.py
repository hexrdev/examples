"""
Hexr LLM Client Instrumentation — ``hexr_llm()``

Wraps any LLM client (OpenAI, Anthropic, Google GenAI, LiteLLM, or
generic) with OTel tracing that follows the OpenTelemetry GenAI
semantic conventions.

What it records (infrastructure telemetry):
  - gen_ai.system, gen_ai.request.model, gen_ai.response.model
  - gen_ai.usage.input_tokens, gen_ai.usage.output_tokens
  - gen_ai.response.id, gen_ai.response.finish_reasons
  - hexr.llm.duration_ms, hexr.llm.stream, hexr.llm.operation
  - hexr.agent.name, hexr.agent.tenant (from Hexr context)

What it does NOT record (Galileo / Langfuse territory):
  - Prompt / response content (opt-in only via capture_content=True)
  - Output quality scores, hallucination detection
  - Cost estimation — we record raw token counts; cost computation
    belongs in Grafana recording rules or Langfuse/Galileo dashboards

Architecture:
  Proxy pattern — ``hexr_llm(client)`` returns an ``HexrLLMProxy`` that
  delegates all attribute access to the real client, but intercepts
  known completion methods to create OTel spans.  Streaming responses
  are wrapped so token usage is captured after the stream finishes.

Usage:
    from hexr import hexr_llm

    client = hexr_llm(openai.OpenAI())
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": "hello"}],
    )
    # OTel span automatically created with model, tokens, latency

Async support:
    client = hexr_llm(openai.AsyncOpenAI())
    response = await client.chat.completions.create(...)
"""

from __future__ import annotations

import functools
import inspect
import logging
import os
import threading
import time
from typing import Any, Callable, Optional, Sequence

from .observability import get_tracer, get_meter, SpanNames, SpanAttributes, GenAIAttributes, MetricNames
from . import guard as _guard
from .evidence import post_evidence
from .exceptions import GuardrailError

logger = logging.getLogger(__name__)

# ── OTel imports (graceful no-op) ────────────────────────────────────────────

try:
    from opentelemetry.trace import StatusCode
    _HAS_OTEL = True
except ImportError:
    StatusCode = None  # type: ignore[assignment,misc]
    _HAS_OTEL = False

# ── Provider detection ───────────────────────────────────────────────────────

_PROVIDER_MAP: dict[str, str] = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google.generativeai": "google_genai",
    "google.genai": "google_genai",
    "litellm": "litellm",
    "cohere": "cohere",
    "mistralai": "mistral",
}


def _detect_provider(client: Any) -> str:
    """Detect the LLM *client SDK family* from the client object's module path.

    This selects the response extractor. It is NOT the same thing as
    ``gen_ai.system`` — an OpenAI-SDK client pointed at DeepSeek is still an
    ``openai`` client, but the serving system is DeepSeek. See _detect_system.
    """
    module = type(client).__module__ or ""
    for prefix, provider in _PROVIDER_MAP.items():
        if module.startswith(prefix) or module.startswith(f"_{prefix}"):
            return provider
    return "unknown"


# OTel GenAI semconv `gen_ai.system` values, keyed by API host substring.
# OpenAI-compatible endpoints are extremely common (DeepSeek, Groq, Together,
# OpenRouter, Fireworks, xAI, local Ollama/vLLM), and every one of them reports
# as "openai" if you only look at the client class. That is materially
# misleading in a compliance row: an auditor reading `provider=openai` next to
# `response_model=deepseek-v4-flash` cannot tell which system actually
# processed the data, which is exactly the question a data-residency or
# subprocessor review asks. Names follow the OTel GenAI semconv registry.
_SYSTEM_HOST_MAP: tuple[tuple[str, str], ...] = (
    ("api.deepseek.com", "deepseek"),
    ("deepseek.com", "deepseek"),
    ("api.groq.com", "groq"),
    ("api.mistral.ai", "mistral_ai"),
    ("api.together.xyz", "together_ai"),
    ("openrouter.ai", "openrouter"),
    ("api.fireworks.ai", "fireworks_ai"),
    ("api.perplexity.ai", "perplexity"),
    ("api.x.ai", "xai"),
    ("api.anthropic.com", "anthropic"),
    ("generativelanguage.googleapis.com", "gcp.gemini"),
    ("bedrock-runtime", "aws.bedrock"),
    ("openai.azure.com", "az.ai.openai"),
    ("azure-api.net", "az.ai.openai"),
    ("api.openai.com", "openai"),
)


def _client_base_url(client: Any) -> str:
    """Best-effort base URL for a client, across SDK shapes. Never raises."""
    for attr in ("base_url", "_base_url", "api_base", "endpoint"):
        try:
            val = getattr(client, attr, None)
        except Exception:
            continue
        if val:
            try:
                return str(val)
            except Exception:
                continue
    return ""


def _detect_system(client: Any, provider: str) -> str:
    """Resolve OTel ``gen_ai.system`` — the system that actually served the call.

    Falls back to the client SDK family when the endpoint is unrecognised, so
    behaviour is never worse than before.
    """
    url = _client_base_url(client).lower()
    if url:
        for host, system in _SYSTEM_HOST_MAP:
            if host in url:
                return system
        # A non-default base_url on an OpenAI-shaped client means a
        # self-hosted or private gateway. Say so rather than claiming "openai".
        if provider == "openai" and "api.openai.com" not in url:
            return "openai_compatible"
    return provider


# ── Method-path registry ─────────────────────────────────────────────────────
#
# Each entry maps a dotted attribute path on the client to:
#   (span_name, operation_type)
# e.g. "chat.completions.create" → (SpanNames.LLM_CHAT, "chat")

_METHOD_REGISTRY: dict[str, tuple[str, str]] = {
    # OpenAI
    "chat.completions.create": (SpanNames.LLM_CHAT, "chat"),
    "completions.create": (SpanNames.LLM_COMPLETIONS, "completions"),
    "embeddings.create": (SpanNames.LLM_EMBEDDINGS, "embeddings"),
    # Anthropic
    "messages.create": (SpanNames.LLM_CHAT, "chat"),
    # Google GenAI
    "models.generate_content": (SpanNames.LLM_CHAT, "chat"),
    # LiteLLM (module-level functions are handled separately)
}


# ── Token / response extraction helpers ──────────────────────────────────────

def _extract_openai_attrs(response: Any) -> dict[str, Any]:
    """Extract span attributes from an OpenAI-style response."""
    attrs: dict[str, Any] = {}
    # ChatCompletion / Completion
    if hasattr(response, "id"):
        attrs[GenAIAttributes.RESPONSE_ID] = response.id
    if hasattr(response, "model"):
        attrs[GenAIAttributes.RESPONSE_MODEL] = response.model
    if hasattr(response, "usage") and response.usage is not None:
        attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = getattr(response.usage, "prompt_tokens", 0) or 0
        attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = getattr(response.usage, "completion_tokens", 0) or 0
    # finish_reason list
    if hasattr(response, "choices") and response.choices:
        reasons = [getattr(c, "finish_reason", None) for c in response.choices]
        attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] = str([r for r in reasons if r])
    return attrs


def _extract_anthropic_attrs(response: Any) -> dict[str, Any]:
    """Extract span attributes from an Anthropic Messages response."""
    attrs: dict[str, Any] = {}
    if hasattr(response, "id"):
        attrs[GenAIAttributes.RESPONSE_ID] = response.id
    if hasattr(response, "model"):
        attrs[GenAIAttributes.RESPONSE_MODEL] = response.model
    if hasattr(response, "usage") and response.usage is not None:
        attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = getattr(response.usage, "input_tokens", 0) or 0
        attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = getattr(response.usage, "output_tokens", 0) or 0
    if hasattr(response, "stop_reason"):
        attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] = str([response.stop_reason])
    return attrs


def _extract_google_attrs(response: Any) -> dict[str, Any]:
    """Extract span attributes from a Google GenAI response."""
    attrs: dict[str, Any] = {}
    if hasattr(response, "model"):
        attrs[GenAIAttributes.RESPONSE_MODEL] = response.model
    # usage_metadata
    meta = getattr(response, "usage_metadata", None)
    if meta is not None:
        attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = getattr(meta, "prompt_token_count", 0) or 0
        attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = getattr(meta, "candidates_token_count", 0) or 0
    # candidates finish reasons
    candidates = getattr(response, "candidates", None)
    if candidates:
        reasons = [getattr(c, "finish_reason", None) for c in candidates]
        attrs[GenAIAttributes.RESPONSE_FINISH_REASONS] = str([str(r) for r in reasons if r])
    return attrs


def _extract_generic_attrs(response: Any) -> dict[str, Any]:
    """Best-effort extraction for unknown providers."""
    attrs: dict[str, Any] = {}
    for id_attr in ("id", "response_id"):
        if hasattr(response, id_attr):
            attrs[GenAIAttributes.RESPONSE_ID] = str(getattr(response, id_attr))
            break
    if hasattr(response, "model"):
        attrs[GenAIAttributes.RESPONSE_MODEL] = str(response.model)
    # Try common usage shapes
    usage = getattr(response, "usage", None)
    if usage is not None:
        for in_key in ("prompt_tokens", "input_tokens"):
            val = getattr(usage, in_key, None)
            if val is not None:
                attrs[GenAIAttributes.USAGE_INPUT_TOKENS] = int(val)
                break
        for out_key in ("completion_tokens", "output_tokens"):
            val = getattr(usage, out_key, None)
            if val is not None:
                attrs[GenAIAttributes.USAGE_OUTPUT_TOKENS] = int(val)
                break
    return attrs


_PROVIDER_EXTRACTORS: dict[str, Callable[..., dict[str, Any]]] = {
    "openai": _extract_openai_attrs,
    "anthropic": _extract_anthropic_attrs,
    "google_genai": _extract_google_attrs,
}


# ── Request attribute extraction ─────────────────────────────────────────────

def _extract_request_attrs(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Pull gen_ai.request.* attributes from the call kwargs."""
    attrs: dict[str, Any] = {}
    if "model" in kwargs:
        attrs[GenAIAttributes.REQUEST_MODEL] = str(kwargs["model"])
    if "max_tokens" in kwargs:
        attrs[GenAIAttributes.REQUEST_MAX_TOKENS] = int(kwargs["max_tokens"])
    elif "max_completion_tokens" in kwargs:
        attrs[GenAIAttributes.REQUEST_MAX_TOKENS] = int(kwargs["max_completion_tokens"])
    if "temperature" in kwargs:
        attrs[GenAIAttributes.REQUEST_TEMPERATURE] = float(kwargs["temperature"])
    if "top_p" in kwargs:
        attrs[GenAIAttributes.REQUEST_TOP_P] = float(kwargs["top_p"])
    if "stop" in kwargs and kwargs["stop"] is not None:
        attrs[GenAIAttributes.REQUEST_STOP_SEQUENCES] = str(kwargs["stop"])
    stream = kwargs.get("stream", False)
    attrs[GenAIAttributes.REQUEST_STREAM] = bool(stream)
    return attrs


# ── Hexr context injection ───────────────────────────────────────────────────

def _hexr_context_attrs() -> dict[str, Any]:
    """Get agent name / tenant from environment (set by hexr_agent decorator)."""
    attrs: dict[str, Any] = {}
    agent_name = os.getenv("HEXR_AGENT_NAME")
    tenant = os.getenv("HEXR_TENANT_ID") or os.getenv("HEXR_TENANT")
    if agent_name:
        attrs[SpanAttributes.AGENT_NAME] = agent_name
    if tenant:
        attrs[SpanAttributes.AGENT_TENANT] = tenant
    return attrs


# ── Stream wrapper ───────────────────────────────────────────────────────────

class _StreamWrapper:
    """
    Wraps an LLM streaming response to capture chunk-level token data.

    Iterates through chunks transparently, then sets span attributes
    once the stream is exhausted.  Works with both sync and async iterators.
    """

    def __init__(self, stream: Any, span: Any, provider: str, start_time: float,
                 meter_attrs: dict[str, Any]):
        self._stream = stream
        self._span = span
        self._provider = provider
        self._start_time = start_time
        self._meter_attrs = meter_attrs
        self._chunks: list[Any] = []
        self._finished = False

    def __iter__(self):
        return self

    def __next__(self):
        try:
            chunk = next(self._stream)
            self._chunks.append(chunk)
            return chunk
        except StopIteration:
            self._finalize()
            raise

    def __enter__(self):
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *exc_info):
        self._finalize()
        if hasattr(self._stream, "__exit__"):
            return self._stream.__exit__(*exc_info)
        return False

    async def __aiter__(self):
        async for chunk in self._stream:
            self._chunks.append(chunk)
            yield chunk
        self._finalize()

    async def __aenter__(self):
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *exc_info):
        self._finalize()
        if hasattr(self._stream, "__aexit__"):
            return await self._stream.__aexit__(*exc_info)
        return False

    # Delegate everything else to the underlying stream
    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)

    def _finalize(self) -> None:
        """Record final span attributes from accumulated stream chunks and end span."""
        if self._finished:
            return
        self._finished = True

        elapsed_ms = (time.monotonic() - self._start_time) * 1000
        self._span.set_attribute(SpanAttributes.LLM_DURATION_MS, round(elapsed_ms, 1))

        # Try to extract usage from the last chunk (OpenAI sends it there)
        if self._chunks:
            last = self._chunks[-1]
            usage = getattr(last, "usage", None)
            if usage is not None:
                in_tok = getattr(usage, "prompt_tokens", None) or getattr(usage, "input_tokens", None)
                out_tok = getattr(usage, "completion_tokens", None) or getattr(usage, "output_tokens", None)
                if in_tok is not None:
                    self._span.set_attribute(GenAIAttributes.USAGE_INPUT_TOKENS, int(in_tok))
                if out_tok is not None:
                    self._span.set_attribute(GenAIAttributes.USAGE_OUTPUT_TOKENS, int(out_tok))

                # Record metrics
                self._record_token_metrics(in_tok, out_tok)

            # Model from first chunk
            first = self._chunks[0]
            if hasattr(first, "model"):
                self._span.set_attribute(GenAIAttributes.RESPONSE_MODEL, str(first.model))
            if hasattr(first, "id"):
                self._span.set_attribute(GenAIAttributes.RESPONSE_ID, str(first.id))

        # End the span now that all attributes are set
        self._span.end()

    def _record_token_metrics(self, in_tok: Any, out_tok: Any) -> None:
        """Record token count metrics."""
        meter = get_meter()
        if in_tok is not None:
            meter.create_counter(
                MetricNames.LLM_INPUT_TOKENS,
                unit="tokens",
                description="LLM input tokens",
            ).add(int(in_tok), self._meter_attrs)
        if out_tok is not None:
            meter.create_counter(
                MetricNames.LLM_OUTPUT_TOKENS,
                unit="tokens",
                description="LLM output tokens",
            ).add(int(out_tok), self._meter_attrs)


# ── Method interceptor ───────────────────────────────────────────────────────

def _make_interceptor(
    real_method: Callable[..., Any],
    span_name: str,
    operation: str,
    provider: str,
    capture_content: bool,
    system: str | None = None,
) -> Callable[..., Any]:
    """Build a sync or async interceptor for an LLM completion method."""

    # `provider` selects the response extractor; `system` is what actually
    # served the request and is what gen_ai.system / the evidence row report.
    system = system or provider

    tracer = get_tracer()
    meter = get_meter()
    call_counter = meter.create_counter(
        MetricNames.LLM_CALLS, unit="1", description="Number of LLM calls",
    )
    error_counter = meter.create_counter(
        MetricNames.LLM_CALL_ERRORS, unit="1", description="Number of LLM call errors",
    )
    duration_hist = meter.create_histogram(
        MetricNames.LLM_CALL_DURATION, unit="s", description="LLM call duration",
    )

    if inspect.iscoroutinefunction(real_method):

        @functools.wraps(real_method)
        async def async_interceptor(*args: Any, **kwargs: Any) -> Any:
            req_attrs = _extract_request_attrs(kwargs)
            ctx_attrs = _hexr_context_attrs()
            is_stream = kwargs.get("stream", False)

            metric_attrs = {
                SpanAttributes.LLM_PROVIDER: provider,
                SpanAttributes.LLM_OPERATION: operation,
                GenAIAttributes.REQUEST_MODEL: req_attrs.get(GenAIAttributes.REQUEST_MODEL, "unknown"),
            }
            call_counter.add(1, metric_attrs)
            start = time.monotonic()

            span_attrs = {
                GenAIAttributes.SYSTEM: system,
                SpanAttributes.LLM_PROVIDER: provider,
                SpanAttributes.LLM_OPERATION: operation,
                SpanAttributes.LLM_STREAM: bool(is_stream),
                **req_attrs,
                **ctx_attrs,
            }

            span = tracer.start_span(span_name, attributes=span_attrs)

            # ── LLM Guard: scan prompt before LLM call ──
            if _guard.is_enabled() and operation == "chat":
                prompt_text = _guard.extract_prompt_text(kwargs)
                if prompt_text:
                    guard_result = await _guard.scan_prompt_async(prompt_text)
                    if not guard_result.get("is_valid", True):
                        scanners = guard_result.get("scanners", {})
                        span.set_attribute("hexr.guard.prompt_blocked", True)
                        span.set_attribute("hexr.guard.scanners", str(scanners))
                        if StatusCode:
                            span.set_status(StatusCode.ERROR, "Blocked by LLM Guard")
                        span.end()
                        raise GuardrailError(
                            f"Prompt blocked by LLM Guard: {scanners}", scanners=scanners,
                        )

            try:
                response = await real_method(*args, **kwargs)
            except Exception as exc:
                elapsed = time.monotonic() - start
                error_counter.add(1, metric_attrs)
                duration_hist.record(elapsed, metric_attrs)
                span.set_attribute(SpanAttributes.ERROR_TYPE, type(exc).__name__)
                span.set_attribute(SpanAttributes.ERROR_MESSAGE, str(exc)[:256])
                span.record_exception(exc)
                if StatusCode:
                    span.set_status(StatusCode.ERROR, str(exc)[:256])
                span.end()
                raise

            elapsed = time.monotonic() - start
            duration_hist.record(elapsed, metric_attrs)
            span.set_attribute(SpanAttributes.LLM_DURATION_MS, round(elapsed * 1000, 1))

            if is_stream:
                # Span stays open; _StreamWrapper._finalize() will end it
                return _StreamWrapper(response, span, provider, start, metric_attrs)

            # Non-stream: extract response attrs immediately
            extractor = _PROVIDER_EXTRACTORS.get(provider, _extract_generic_attrs)
            resp_attrs = extractor(response)
            for k, v in resp_attrs.items():
                span.set_attribute(k, v)

            # Record token metrics
            _record_response_metrics(resp_attrs, metric_attrs, meter)
            _emit_llm_evidence(system, operation, resp_attrs, elapsed * 1000.0, client_sdk=provider)

            # Optionally capture content
            if capture_content:
                _capture_content_attrs(span, kwargs, response, provider)

            # ── LLM Guard: scan output after LLM call ──
            if _guard.is_enabled() and operation == "chat":
                output_text = _guard.extract_response_text(response, provider)
                if output_text:
                    prompt_text = _guard.extract_prompt_text(kwargs) or ""
                    out_result = await _guard.scan_output_async(prompt_text, output_text)
                    if not out_result.get("is_valid", True):
                        scanners = out_result.get("scanners", {})
                        span.set_attribute("hexr.guard.output_blocked", True)
                        span.set_attribute("hexr.guard.output_scanners", str(scanners))
                        if StatusCode:
                            span.set_status(StatusCode.ERROR, "Output blocked by LLM Guard")
                        span.end()
                        raise GuardrailError(
                            f"Output blocked by LLM Guard: {scanners}", scanners=scanners,
                        )

            span.end()
            return response

        return async_interceptor

    else:

        @functools.wraps(real_method)
        def sync_interceptor(*args: Any, **kwargs: Any) -> Any:
            req_attrs = _extract_request_attrs(kwargs)
            ctx_attrs = _hexr_context_attrs()
            is_stream = kwargs.get("stream", False)

            metric_attrs = {
                SpanAttributes.LLM_PROVIDER: provider,
                SpanAttributes.LLM_OPERATION: operation,
                GenAIAttributes.REQUEST_MODEL: req_attrs.get(GenAIAttributes.REQUEST_MODEL, "unknown"),
            }
            call_counter.add(1, metric_attrs)
            start = time.monotonic()

            span_attrs = {
                GenAIAttributes.SYSTEM: system,
                SpanAttributes.LLM_PROVIDER: provider,
                SpanAttributes.LLM_OPERATION: operation,
                SpanAttributes.LLM_STREAM: bool(is_stream),
                **req_attrs,
                **ctx_attrs,
            }

            span = tracer.start_span(span_name, attributes=span_attrs)

            # ── LLM Guard: scan prompt before LLM call ──
            if _guard.is_enabled() and operation == "chat":
                prompt_text = _guard.extract_prompt_text(kwargs)
                if prompt_text:
                    guard_result = _guard.scan_prompt(prompt_text)
                    if not guard_result.get("is_valid", True):
                        scanners = guard_result.get("scanners", {})
                        span.set_attribute("hexr.guard.prompt_blocked", True)
                        span.set_attribute("hexr.guard.scanners", str(scanners))
                        if StatusCode:
                            span.set_status(StatusCode.ERROR, "Blocked by LLM Guard")
                        span.end()
                        raise GuardrailError(
                            f"Prompt blocked by LLM Guard: {scanners}", scanners=scanners,
                        )

            try:
                response = real_method(*args, **kwargs)
            except Exception as exc:
                elapsed = time.monotonic() - start
                error_counter.add(1, metric_attrs)
                duration_hist.record(elapsed, metric_attrs)
                span.set_attribute(SpanAttributes.ERROR_TYPE, type(exc).__name__)
                span.set_attribute(SpanAttributes.ERROR_MESSAGE, str(exc)[:256])
                span.record_exception(exc)
                if StatusCode:
                    span.set_status(StatusCode.ERROR, str(exc)[:256])
                span.end()
                raise

            elapsed = time.monotonic() - start
            duration_hist.record(elapsed, metric_attrs)
            span.set_attribute(SpanAttributes.LLM_DURATION_MS, round(elapsed * 1000, 1))

            if is_stream:
                # Span stays open; _StreamWrapper._finalize() will end it
                return _StreamWrapper(response, span, provider, start, metric_attrs)

            # Non-stream: extract response attrs immediately
            extractor = _PROVIDER_EXTRACTORS.get(provider, _extract_generic_attrs)
            resp_attrs = extractor(response)
            for k, v in resp_attrs.items():
                span.set_attribute(k, v)

            # Record token metrics
            _record_response_metrics(resp_attrs, metric_attrs, meter)
            _emit_llm_evidence(system, operation, resp_attrs, elapsed * 1000.0, client_sdk=provider)

            # Optionally capture content
            if capture_content:
                _capture_content_attrs(span, kwargs, response, provider)

            # ── LLM Guard: scan output after LLM call ──
            if _guard.is_enabled() and operation == "chat":
                output_text = _guard.extract_response_text(response, provider)
                if output_text:
                    prompt_text = _guard.extract_prompt_text(kwargs) or ""
                    out_result = _guard.scan_output(prompt_text, output_text)
                    if not out_result.get("is_valid", True):
                        scanners = out_result.get("scanners", {})
                        span.set_attribute("hexr.guard.output_blocked", True)
                        span.set_attribute("hexr.guard.output_scanners", str(scanners))
                        if StatusCode:
                            span.set_status(StatusCode.ERROR, "Output blocked by LLM Guard")
                        span.end()
                        raise GuardrailError(
                            f"Output blocked by LLM Guard: {scanners}", scanners=scanners,
                        )

            span.end()
            return response

        return sync_interceptor


# ── Compliance evidence for LLM calls (spec §7; wrap-up plan §3.13) ─────────
# Until 2026-09-09 `hexr_llm()` emitted OTel spans and metrics but NEVER a
# compliance-evidence row, so `llm_call_count` on the evidence API was
# permanently 0 even while calls succeeded. `hexr audit` could therefore prove
# every tool call but not a single model invocation. The evidence API has
# accepted `llm_call` / `llm_request` / `llm_response` since it shipped
# (hexr-evidence-api/handlers.go:202) — only the emitter was missing.
#
# Deliberately records METADATA ONLY: provider, model, token counts, finish
# reason, latency. Never prompts or completions. Content capture stays behind
# the separate `capture_content` span option.

_LLM_EVIDENCE_EVENT = "llm_call"
_LLM_EVIDENCE_FRAMEWORK_DEFAULT = "soc2"
_LLM_EVIDENCE_CONTROL_DEFAULT = "CC7.2"  # System monitoring


def _resolve_spiffe_id() -> str:
    """The SPIFFE ID of THIS process. Delegates to hexr.identity — see that
    module for why the old env-var / last-registered chain was wrong."""
    from .identity import current_spiffe_id

    return current_spiffe_id()

def _emit_llm_evidence(
    system: str,
    operation: str,
    resp_attrs: dict,
    duration_ms: float,
    error: str | None = None,
    guard_blocked: bool = False,
    client_sdk: str | None = None,
) -> None:
    """Fire-and-forget evidence post for one model invocation.

    Never raises and never blocks the caller — an evidence backend being down
    must not take an agent with it (same contract as _emit_tool_evidence).
    """
    if os.getenv("HEXR_EVIDENCE_DISABLED", "").lower() in ("1", "true", "yes"):
        return

    framework = os.getenv("HEXR_LLM_EVIDENCE_FRAMEWORK", _LLM_EVIDENCE_FRAMEWORK_DEFAULT)
    control_id = os.getenv("HEXR_LLM_EVIDENCE_CONTROL", _LLM_EVIDENCE_CONTROL_DEFAULT)

    details: dict[str, Any] = {
        # `system` is the service that actually processed the data (OTel
        # gen_ai.system) — the field a data-residency or subprocessor review
        # cares about. `client_sdk` is the library used to reach it. They differ
        # whenever an OpenAI-compatible endpoint is in play.
        "system": system,
        "operation": operation,
        "duration_ms": round(duration_ms, 2),
    }
    if client_sdk and client_sdk != system:
        details["client_sdk"] = client_sdk
    for src, dst in (
        (GenAIAttributes.REQUEST_MODEL, "request_model"),
        (GenAIAttributes.RESPONSE_MODEL, "response_model"),
        (GenAIAttributes.USAGE_INPUT_TOKENS, "input_tokens"),
        (GenAIAttributes.USAGE_OUTPUT_TOKENS, "output_tokens"),
        (GenAIAttributes.RESPONSE_FINISH_REASONS, "finish_reasons"),
    ):
        val = resp_attrs.get(src)
        if val is not None:
            details[dst] = val
    if guard_blocked:
        details["guard_blocked"] = True
    if error:
        details["error"] = str(error)[:512]

    severity = "warning" if (error or guard_blocked) else "info"
    spiffe_id = _resolve_spiffe_id()

    def _bg() -> None:
        try:
            post_evidence(
                _LLM_EVIDENCE_EVENT,
                control_id,
                details,
                source="hexr-sdk",
                framework=framework,
                severity=severity,
                spiffe_id=spiffe_id or None,
                timeout=2.0,
            )
        except Exception as exc:  # never let evidence break agents
            logger.debug("llm evidence emit failed (non-fatal): %s", exc)

    from .evidence import emit_in_background

    emit_in_background(_bg, name="hexr-llm-evidence-emit")


def _record_response_metrics(
    resp_attrs: dict[str, Any],
    metric_attrs: dict[str, Any],
    meter: Any,
) -> None:
    """Record token-count counters from response attributes."""
    in_tok = resp_attrs.get(GenAIAttributes.USAGE_INPUT_TOKENS)
    out_tok = resp_attrs.get(GenAIAttributes.USAGE_OUTPUT_TOKENS)
    if in_tok is not None:
        meter.create_counter(
            MetricNames.LLM_INPUT_TOKENS, unit="tokens",
            description="LLM input tokens",
        ).add(int(in_tok), metric_attrs)
    if out_tok is not None:
        meter.create_counter(
            MetricNames.LLM_OUTPUT_TOKENS, unit="tokens",
            description="LLM output tokens",
        ).add(int(out_tok), metric_attrs)


def _capture_content_attrs(
    span: Any,
    kwargs: dict[str, Any],
    response: Any,
    provider: str,
) -> None:
    """Opt-in: record prompt/response content on the span (privacy-sensitive)."""
    # Input
    messages = kwargs.get("messages")
    if messages:
        # Truncate to prevent huge spans
        import json
        content = json.dumps(messages, default=str)[:4096]
        span.set_attribute("hexr.llm.request.content", content)

    # Output (provider-specific)
    try:
        if provider == "openai" and hasattr(response, "choices") and response.choices:
            msg = response.choices[0].message
            span.set_attribute("hexr.llm.response.content", str(getattr(msg, "content", ""))[:4096])
        elif provider == "anthropic" and hasattr(response, "content") and response.content:
            text = response.content[0].text if hasattr(response.content[0], "text") else str(response.content[0])
            span.set_attribute("hexr.llm.response.content", text[:4096])
    except Exception:
        pass  # Content capture is best-effort


# ── Namespace proxy (for chained attribute access) ───────────────────────────

class _NamespaceProxy:
    """
    Proxy for intermediate namespace objects like ``client.chat.completions``.

    Intercepts known method names (e.g. ``create``) while delegating
    everything else to the real namespace object.
    """

    def __init__(self, real_obj: Any, path: str, provider: str,
                 capture_content: bool, system: str | None = None):
        object.__setattr__(self, "_real_obj", real_obj)
        object.__setattr__(self, "_path", path)
        object.__setattr__(self, "_provider", provider)
        object.__setattr__(self, "_capture_content", capture_content)
        object.__setattr__(self, "_system", system or provider)

    def __getattr__(self, name: str) -> Any:
        real = getattr(object.__getattribute__(self, "_real_obj"), name)
        path = f"{object.__getattribute__(self, '_path')}.{name}"
        provider = object.__getattribute__(self, "_provider")
        capture = object.__getattribute__(self, "_capture_content")
        system = object.__getattribute__(self, "_system")

        # Check if this full path is an interceptable method
        entry = _METHOD_REGISTRY.get(path)
        if entry is not None and callable(real):
            span_name, operation = entry
            return _make_interceptor(real, span_name, operation, provider, capture, system)

        # If the real attribute has sub-attributes, keep proxying
        if not callable(real) or _has_sub_methods(path):
            return _NamespaceProxy(real, path, provider, capture, system)

        return real

    def __repr__(self) -> str:
        return f"<HexrLLMNamespace({object.__getattribute__(self, '_path')})>"


def _has_sub_methods(path: str) -> bool:
    """Check if any registered method starts with this path prefix."""
    prefix = path + "."
    return any(key.startswith(prefix) for key in _METHOD_REGISTRY)


# ── Main proxy ───────────────────────────────────────────────────────────────

class HexrLLMProxy:
    """
    Transparent proxy around an LLM client that instruments completion
    calls with OTel spans.

    All attribute access is delegated to the real client.  Known method
    paths (``chat.completions.create``, ``messages.create``, etc.) are
    intercepted to create spans.

    This class is NOT instantiated directly — use ``hexr_llm(client)``.
    """

    def __init__(self, client: Any, *, provider: str | None = None,
                 capture_content: bool = False):
        # Use object.__setattr__ to avoid triggering __setattr__ proxy
        object.__setattr__(self, "_client", client)
        object.__setattr__(self, "_provider", provider or _detect_provider(client))
        object.__setattr__(self, "_capture_content", capture_content)

        detected = object.__getattribute__(self, "_provider")
        object.__setattr__(self, "_system", _detect_system(client, detected))
        system = object.__getattribute__(self, "_system")
        logger.info(
            "hexr_llm: wrapping %s client (client_sdk=%s, gen_ai.system=%s)",
            type(client).__name__, detected, system,
        )

    def __getattr__(self, name: str) -> Any:
        client = object.__getattribute__(self, "_client")
        real = getattr(client, name)
        provider = object.__getattribute__(self, "_provider")
        capture = object.__getattribute__(self, "_capture_content")
        system = object.__getattribute__(self, "_system")

        # Check if top-level name is an interceptable method
        entry = _METHOD_REGISTRY.get(name)
        if entry is not None and callable(real):
            span_name, operation = entry
            return _make_interceptor(real, span_name, operation, provider, capture, system)

        # If the attribute has sub-methods, proxy it
        if _has_sub_methods(name):
            return _NamespaceProxy(real, name, provider, capture, system)

        return real

    def __setattr__(self, name: str, value: Any) -> None:
        # Proxy sets through to real client
        setattr(object.__getattribute__(self, "_client"), name, value)

    def __repr__(self) -> str:
        client = object.__getattribute__(self, "_client")
        provider = object.__getattribute__(self, "_provider")
        return f"<HexrLLMProxy({type(client).__name__}, provider={provider})>"

    @property
    def _unwrapped(self) -> Any:
        """Access the underlying client (escape hatch)."""
        return object.__getattribute__(self, "_client")


# ── Public API ───────────────────────────────────────────────────────────────

def hexr_llm(
    client: Any,
    *,
    provider: str | None = None,
    capture_content: bool = False,
) -> HexrLLMProxy:
    """
    Wrap an LLM client with Hexr OTel instrumentation.

    Args:
        client: An LLM client instance (OpenAI, Anthropic, LiteLLM, etc.)
        provider: Override auto-detected provider name.  Defaults to
            detection from ``type(client).__module__``.
        capture_content: If True, record prompt/response content on spans.
            **Privacy-sensitive** — disabled by default.  Only enable in
            development or when your OTel backend handles PII properly.

    Returns:
        HexrLLMProxy that behaves identically to the original client
        but creates OTel spans for every completion call.

    Example::

        import openai
        from hexr import hexr_llm

        client = hexr_llm(openai.OpenAI())
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "hello"}],
        )
        # Span 'hexr.llm.chat' created with gen_ai.* attributes

    Note:
        This function does NOT add any optional dependencies.  The
        LLM client library (openai, anthropic, etc.) must already be
        installed in your environment.
    """
    if isinstance(client, HexrLLMProxy):
        logger.debug("hexr_llm: client is already wrapped, returning as-is")
        return client

    return HexrLLMProxy(client, provider=provider, capture_content=capture_content)
