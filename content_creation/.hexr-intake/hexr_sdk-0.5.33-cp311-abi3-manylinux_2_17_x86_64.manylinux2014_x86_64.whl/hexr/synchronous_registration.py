"""
Synchronous SPIRE Registration for Hexr SDK
===========================================

PROACTIVE REGISTRATION: SDK calls auto-registrar API at initialization
and waits for SPIRE entry confirmation AND Agent sync before proceeding.

This eliminates timing issues where:
1. SPIRE Server has the entry (registration confirmed)
2. But SPIRE Agent hasn't synced it yet (Agent cache lag)
3. hexr_tool() fails with "no identity issued"

Architecture:
1. SDK __init__ → calls register_process_sync()
2. register_process_sync() → POST to auto-registrar /register API
3. Auto-registrar creates SPIRE entry in Server and waits for confirmation
4. SDK waits for SPIRE Agent to sync entry (tests JWT-SVID fetch)
5. SDK blocks until Agent has entry (30s retry with backoff)
6. SDK writes context files (for attestor + POD_UID isolation)
7. hexr_tool() works immediately - SPIRE Agent has identity ready
"""

import atexit
import os
import json
import threading
import time
import requests
from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass

import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Backoff tuning (§1.28.8.3(a) of HEXR_HYBRID_PIVOT_TECH_SPEC).
#
# HEXR_REGISTRATION_BACKOFF_MODE selects the retry curve for
# _wait_for_agent_sync(). Default flipped to "fast" on 2026-09-29 after the
# measurement below; set it to "legacy" to get the old curve back. Anything
# else falls back to legacy.
#
# Measured on the AKS demo plane, same workload, only this variable changed:
#
#   legacy   "Agent sync verified in 3.2s (retries: 2)"
#   fast     "Agent sync verified in 1.6s (retries: 3)"
#
#   end-to-end, entry created -> first successful tool call
#   legacy   median 1.94s  p90 3.59s  max 7.58s
#   fast     median 1.86s  p90 1.95s  max 3.53s
#
# The median barely moves; the tail halves. That is the shape to expect, because
# legacy doubles (1→2→4→8) so every extra retry costs more than the last, while
# fast starts at 200ms and is still under a second after three. Agent processes
# here live about 8 seconds, so a 7.6s worst case was most of a process's life
# and a 3.5s worst case is not.
#
# Note the retry counts: fast needed THREE checks where legacy needed two. The
# entry genuinely is not ready before ~1.4s, so this does not make SPIRE faster.
# It stops us sleeping through the moment it becomes ready.
#
# Zero sync timeouts or failed registrations were observed on fast over the
# measurement window.
#
#   legacy: 1.0 → 2.0 → 4.0 → 8.0 → 16.0 s, cap 16.0 s, timeout 60 s
#   fast:   0.2 → 0.4 → 0.8 → 1.6 → 3.2 s, cap 3.2 s, timeout 10 s
#
# The fast curve is safe at our scale because spiffe/spire#4488 and
# #6876 are upstream-fixed in v1.15.1 and only reproduce four orders of
# magnitude above us (§1.28.4(b)).
# ---------------------------------------------------------------------------

_BACKOFF_MODE = os.environ.get("HEXR_REGISTRATION_BACKOFF_MODE", "fast").lower()

if _BACKOFF_MODE == "fast":
    _INITIAL_BACKOFF_SECONDS = 0.2
    _MAX_BACKOFF_SECONDS = 3.2
    _DEFAULT_AGENT_SYNC_TIMEOUT_SECONDS = 10
else:
    # "legacy" or unknown — preserve historical behavior.
    _BACKOFF_MODE = "legacy"
    _INITIAL_BACKOFF_SECONDS = 1.0
    _MAX_BACKOFF_SECONDS = 16.0
    _DEFAULT_AGENT_SYNC_TIMEOUT_SECONDS = 60


# ---------------------------------------------------------------------------
# Circuit breaker (§1.28.8.3(b)).
#
# Loud-failure contract: after HEXR_REGISTRATION_CB_WINDOW_SECONDS (default
# 30 s) of continuous registrar HTTP failures, the breaker OPENs and
# subsequent calls raise HexrRegistrationUnavailable immediately instead of
# silently retrying. The breaker auto-transitions to HALF_OPEN after
# HEXR_REGISTRATION_CB_COOLDOWN_SECONDS (default 30 s); the next call is a
# probe — success closes the breaker, failure re-opens it.
#
# Degraded-path evidence emission (RegistrationResult.degraded=True +
# evidence_rows.attestation_class='app_attested_degraded') depends on a
# schema change in hexr-evidence-api that is tracked separately; until
# that lands, the breaker's open path raises rather than degrading.
# ---------------------------------------------------------------------------

_CB_WINDOW_SECONDS = float(os.environ.get("HEXR_REGISTRATION_CB_WINDOW_SECONDS", "30"))
_CB_COOLDOWN_SECONDS = float(os.environ.get("HEXR_REGISTRATION_CB_COOLDOWN_SECONDS", "30"))

_CB_STATE_CLOSED = "closed"
_CB_STATE_OPEN = "open"
_CB_STATE_HALF_OPEN = "half_open"


# ---------------------------------------------------------------------------
# Cached-SVID degraded fallback (§1.28.8.3(b) of HEXR_HYBRID_PIVOT_TECH_SPEC).
#
# When the registrar circuit breaker OPENs, we attempt to use a locally
# cached X509-SVID from the SPIRE Agent before raising. If the Agent
# socket still has a valid (non-expired, with comfortable rotation grace)
# SVID for this workload, the workload proceeds in degraded mode
# (RegistrationResult.degraded=True). Otherwise we raise loudly.
#
# Selector matching is automatic: the SPIRE Agent uses SO_PEERCRED to
# resolve the caller's PID and only returns SVIDs the workload is
# authorized for. We do not need to filter ourselves.
#
# The grace window prevents handing back an SVID that would expire mid
# request. Default 5 minutes is safe for typical 1h SVID TTLs.
# ---------------------------------------------------------------------------

_CACHED_SVID_SOCKET_PATH = os.environ.get(
    "SPIRE_AGENT_SOCKET", "/run/spire/sockets/agent.sock"
)
_CACHED_SVID_MIN_REMAINING_SECONDS = float(
    os.environ.get("HEXR_DEGRADED_SVID_MIN_REMAINING_SECONDS", "300")
)


class HexrRegistrationUnavailable(RuntimeError):
    """Raised when the registrar circuit breaker is open.

    Carries the most recent error response from the registrar so the
    operator-facing log line can include it verbatim.
    """

    def __init__(
        self,
        message: str,
        last_status: Optional[int] = None,
        last_body: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.last_status = last_status
        self.last_body = last_body


class _RegistrarCircuitBreaker:
    """Thread-safe 3-state circuit breaker around the registrar HTTP call.

    States: CLOSED → OPEN → HALF_OPEN → CLOSED.
    Trip rule: once a failure starts a window, if no success occurs within
    _CB_WINDOW_SECONDS of continuous failures, the breaker OPENs.
    """

    def __init__(
        self,
        window_seconds: float = _CB_WINDOW_SECONDS,
        cooldown_seconds: float = _CB_COOLDOWN_SECONDS,
        time_source: Callable[[], float] = time.monotonic,
    ) -> None:
        self._window = window_seconds
        self._cooldown = cooldown_seconds
        self._now = time_source
        self._lock = threading.Lock()
        self._state = _CB_STATE_CLOSED
        self._first_failure_at: Optional[float] = None
        self._opened_at: Optional[float] = None
        self._last_status: Optional[int] = None
        self._last_body: Optional[str] = None

    @property
    def state(self) -> str:
        with self._lock:
            return self._state

    def call(self, fn: Callable[..., requests.Response], *args: Any, **kwargs: Any) -> requests.Response:
        """Invoke fn under the breaker. Raises HexrRegistrationUnavailable when OPEN."""
        with self._lock:
            if self._state == _CB_STATE_OPEN:
                assert self._opened_at is not None
                if self._now() - self._opened_at >= self._cooldown:
                    self._state = _CB_STATE_HALF_OPEN
                    logger.warning(
                        "Registrar circuit breaker entering HALF_OPEN after %.1fs cooldown",
                        self._cooldown,
                    )
                else:
                    raise HexrRegistrationUnavailable(
                        "hexr-auto-registrar circuit breaker is OPEN; "
                        f"last status={self._last_status} body={self._last_body!r}",
                        last_status=self._last_status,
                        last_body=self._last_body,
                    )

        try:
            response = fn(*args, **kwargs)
        except requests.RequestException as exc:
            self._record_failure(status=None, body=str(exc))
            raise

        if response.status_code >= 500:
            self._record_failure(status=response.status_code, body=response.text[:512])
        else:
            self._record_success()
        return response

    def _record_failure(self, status: Optional[int], body: Optional[str]) -> None:
        with self._lock:
            now = self._now()
            self._last_status = status
            self._last_body = body
            if self._state == _CB_STATE_HALF_OPEN:
                self._state = _CB_STATE_OPEN
                self._opened_at = now
                logger.error("Registrar circuit breaker re-OPENed after HALF_OPEN probe failure")
                return
            if self._first_failure_at is None:
                self._first_failure_at = now
                return
            if now - self._first_failure_at >= self._window:
                self._state = _CB_STATE_OPEN
                self._opened_at = now
                logger.error(
                    "Registrar circuit breaker OPEN after %.1fs of continuous failures; "
                    "will retry after %.1fs",
                    self._window,
                    self._cooldown,
                )

    def _record_success(self) -> None:
        with self._lock:
            if self._state != _CB_STATE_CLOSED:
                logger.info("Registrar circuit breaker CLOSED after successful call")
            self._state = _CB_STATE_CLOSED
            self._first_failure_at = None
            self._opened_at = None
            self._last_status = None
            self._last_body = None

    def reset(self) -> None:
        """Test-only helper to force the breaker back to CLOSED."""
        with self._lock:
            self._state = _CB_STATE_CLOSED
            self._first_failure_at = None
            self._opened_at = None
            self._last_status = None
            self._last_body = None


_GLOBAL_BREAKER: Optional[_RegistrarCircuitBreaker] = None
_GLOBAL_BREAKER_LOCK = threading.Lock()


def _get_breaker() -> _RegistrarCircuitBreaker:
    global _GLOBAL_BREAKER
    with _GLOBAL_BREAKER_LOCK:
        if _GLOBAL_BREAKER is None:
            _GLOBAL_BREAKER = _RegistrarCircuitBreaker()
        return _GLOBAL_BREAKER


def _attempt_cached_svid_fallback(
    original_exc: "HexrRegistrationUnavailable",
) -> "Optional[RegistrationResult]":
    """Try to use a locally-cached SPIRE Agent X509-SVID.

    Returns a degraded RegistrationResult if a valid (non-expired beyond
    the rotation grace window) SVID is present on the SPIRE Agent
    socket. Returns None to signal the caller should re-raise the
    original HexrRegistrationUnavailable. Never raises.

    See HEXR_HYBRID_PIVOT_TECH_SPEC \u00a71.28.8.3(b).
    """
    socket_path = _CACHED_SVID_SOCKET_PATH
    if not os.path.exists(socket_path):
        logger.debug(
            "Cached-SVID fallback skipped: SPIRE Agent socket not present at %s",
            socket_path,
        )
        return None

    try:
        from hexr.spiffe.workload_api_client import WorkloadAPIClient
    except Exception as exc:  # pragma: no cover - defensive
        logger.debug("Cached-SVID fallback skipped: import error %s", exc)
        return None

    try:
        client = WorkloadAPIClient(socket_path=socket_path)
        svid = client.fetch_x509_svid()
    except Exception as exc:
        logger.debug("Cached-SVID fetch failed: %s", exc)
        return None

    try:
        from datetime import datetime, timezone

        leaf = getattr(svid, "leaf", None)
        if leaf is None:
            leaf = svid.cert_chain[0]
        not_after = getattr(leaf, "not_valid_after_utc", None)
        if not_after is None:
            # cryptography < 42 returns naive UTC
            not_after = leaf.not_valid_after
            if not_after.tzinfo is None:
                not_after = not_after.replace(tzinfo=timezone.utc)
        remaining = (not_after - datetime.now(timezone.utc)).total_seconds()
    except Exception as exc:
        logger.debug("Cached-SVID freshness check failed: %s", exc)
        return None

    if remaining < _CACHED_SVID_MIN_REMAINING_SECONDS:
        logger.warning(
            "DEGRADED_REGISTRATION_NO_VALID_CACHE: cached SVID expires in %.0fs "
            "(< %.0fs grace); re-raising registrar failure",
            remaining,
            _CACHED_SVID_MIN_REMAINING_SECONDS,
        )
        return None

    spiffe_id = str(svid.spiffe_id)
    logger.warning(
        "DEGRADED_REGISTRATION_USE_CACHE: registrar unreachable (%s); "
        "proceeding with cached SVID spiffe_id=%s remaining=%.0fs",
        original_exc.__class__.__name__,
        spiffe_id,
        remaining,
    )
    return RegistrationResult(
        success=True,
        degraded=True,
        spiffe_id=spiffe_id,
        message=(
            "registrar unreachable; using cached SPIRE Agent SVID "
            "(attestation_class=app_attested_degraded once schema lands)"
        ),
    )


@dataclass
class RegistrationResult:
    """Result of synchronous SPIRE registration."""

    success: bool
    entry_id: Optional[str] = None
    spiffe_id: Optional[str] = None
    error: Optional[str] = None
    message: Optional[str] = None
    # §1.28.8.3(b): True when the breaker was OPEN and we fell through to
    # a degraded path. The call is still "successful" from the workload's
    # perspective (it has *some* identity), but evidence rows for the
    # session should carry attestation_class='app_attested_degraded' once
    # the evidence-api schema change lands.
    degraded: bool = False


def _test_agent_sync() -> bool:
    """
    Test if SPIRE Agent can issue JWT-SVIDs (not just X509-SVIDs).
    
    CRITICAL: X509-SVIDs are streamed immediately via SyncAuthorizedEntries,
    but JWT-SVID issuance requires Agent to have fully processed the entry.
    Since hexr_tool() needs JWT-SVIDs, we must test JWT readiness specifically.
    """
    try:
        from hexr.spiffe.workload_api_client import WorkloadAPIClient
        
        client = WorkloadAPIClient()
        
        try:
            # Test JWT-SVID fetch (what hexr_tool() actually needs)
            jwt_svid = client.fetch_jwt_svid(audience=["hexr-credential-injector"])
            
            if jwt_svid and jwt_svid.get("token"):
                logger.debug(f"✅ Agent JWT-SVID ready: {jwt_svid.get('spiffe_id')}")
                return True
            
            logger.debug("⏳ JWT-SVID not ready yet")
            return False
            
        except Exception as e:
            error_msg = str(e).lower()
            if "no identity issued" in error_msg:
                logger.debug("JWT-SVID test: NOT READY (no identity issued)")
                return False
            elif "socket not found" in error_msg or "not accessible" in error_msg:
                logger.debug(f"JWT-SVID test: Socket error - {e}")
                return False
            else:
                logger.debug(f"JWT-SVID test: Unexpected error - {e}")
                return False
                
    except ImportError as e:
        logger.error(f"Agent sync test: Import failed - {e}")
        return False
        
    except Exception as e:
        logger.error(f"Agent sync test: Failed - {e}")
        return False


class SynchronousRegistration:
    """
    Handles synchronous SPIRE registration with auto-registrar.

    This ensures SPIRE entries exist BEFORE SDK returns control to user code,
    eliminating timing issues with hexr_tool() credential exchange.
    """

    def __init__(self, auto_registrar_url: Optional[str] = None):
        self.auto_registrar_url = auto_registrar_url or self._get_auto_registrar_url()
        logger.info(f"Synchronous registration initialized: {self.auto_registrar_url}")

    def _get_auto_registrar_url(self) -> str:
        """Get auto-registrar URL from environment or default."""
        return os.environ.get(
            "HEXR_AUTO_REGISTRAR_URL",
            "http://hexr-auto-registrar.hexr-system.svc.cluster.local:8080",
        )

    def _wait_for_agent_sync(self, timeout: Optional[int] = None) -> bool:
        """
        Wait for SPIRE Agent to sync entries from Server.

        Backoff curve is selected by HEXR_REGISTRATION_BACKOFF_MODE
        (see module-level docstring). Default "legacy" preserves historical
        1s→16s/60s behavior; "fast" uses 200ms→3.2s/10s per §1.28.8.3(a).
        """
        if timeout is None:
            timeout = _DEFAULT_AGENT_SYNC_TIMEOUT_SECONDS
        logger.debug(
            "Waiting for SPIRE Agent to sync entries (mode=%s, timeout=%ds)...",
            _BACKOFF_MODE,
            timeout,
        )

        start_time = time.time()
        retry_delay = _INITIAL_BACKOFF_SECONDS
        max_delay = _MAX_BACKOFF_SECONDS
        retry_count = 0

        while time.time() - start_time < timeout:
            if _test_agent_sync():
                elapsed = time.time() - start_time
                logger.info(f"✅ Agent sync verified in {elapsed:.1f}s (retries: {retry_count})")
                return True

            retry_count += 1
            logger.debug(f"Agent not ready, retry #{retry_count} in {retry_delay:.1f}s...")
            time.sleep(retry_delay)

            retry_delay = min(retry_delay * 2, max_delay)

        # Timeout reached - log at DEBUG level only (enterprise clean logs)
        elapsed = time.time() - start_time
        logger.debug(f"Agent sync timeout after {elapsed:.1f}s ({retry_count} retries)")
        return False

    def register_process_sync(
        self,
        pod_uid: str,
        process_id: int,
        tenant: str,
        framework: str,
        agent_name: str,
        sub_agent: Optional[str] = None,
        process_role: Optional[str] = None,
        resources: Optional[List[str]] = None,
        timeout: int = 30,
    ) -> RegistrationResult:
        """
        Register process with auto-registrar and wait for SPIRE confirmation.

        Args:
            pod_uid: Kubernetes pod UID
            process_id: Host process ID
            tenant: Tenant identifier
            framework: Agentic framework (crewai, langchain, etc.)
            agent_name: Agent name
            sub_agent: Sub-agent role (optional)
            process_role: Process role (optional)
            resources: Cloud resources (optional)
            timeout: Registration timeout in seconds

        Returns:
            RegistrationResult with success status and SPIRE entry details

        Raises:
            RuntimeError: If registration fails or times out
        """
        logger.info(
            f"Starting synchronous SPIRE registration for {agent_name} (PID {process_id})"
        )

        # Build registration request
        request_data = {
            "pod_uid": pod_uid,
            "process_id": str(process_id),
            "tenant": tenant,
            "framework": framework,
            "agent_name": agent_name,
            "sub_agent": sub_agent or process_role or "main",
            "process_role": process_role or sub_agent or "main",
            "resources": resources or [],
            # Ask for a bounded entry, because this SDK renews it while the
            # process runs and removes it on exit. A client that cannot
            # promise both should not send this field: the registrar then
            # creates an entry with no expiry, which is correct for the
            # long-lived Go services that self-register and have nothing to
            # renew them. Blanket expiry was tried in auto-registrar v0.4.1
            # and put every one of those on a countdown to losing its
            # identity in service.
            "lease_seconds": _lease_seconds(),
        }

        try:
            # Call auto-registrar synchronously, under the circuit breaker
            # (§1.28.8.3(b)). Breaker auto-trips after 30s of continuous
            # failures; the next call raises HexrRegistrationUnavailable
            # instead of silently retrying.
            url = f"{self.auto_registrar_url}/register"
            logger.info(f"Calling auto-registrar: {url}")

            breaker = _get_breaker()
            response = breaker.call(
                requests.post,
                url,
                json=request_data,
                timeout=timeout,
                headers={"Content-Type": "application/json"},
            )

            if response.status_code == 200:
                result = response.json()
                if result.get("status") == "success":
                    logger.info(
                        f"✅ SPIRE Server registration successful: {result.get('entry_id')}"
                    )

                    # Wait for SPIRE Agent to sync entry. Timeout/backoff
                    # curve is selected by HEXR_REGISTRATION_BACKOFF_MODE
                    # (§1.28.8.3(a)).
                    agent_synced = self._wait_for_agent_sync()
                    if not agent_synced:
                        # The entry exists on the Server but the Agent could not
                        # issue an SVID for this process within the timeout.
                        #
                        # This used to log at DEBUG and continue. That is the
                        # wrong level for this condition: the process is about to
                        # run WITHOUT an identity, so its tool calls will be
                        # refused and any evidence it writes cannot be attributed
                        # or signed. Silently proceeding turns the product's
                        # central claim off for that process, invisibly.
                        #
                        # Still non-fatal by default, because failing a workload
                        # that would otherwise run is a bigger blast radius than
                        # running it unattributed — but it is now loud, and
                        # HEXR_REQUIRE_IDENTITY=true makes it fatal for
                        # deployments that would rather stop than run unidentified.
                        logger.warning(
                            "HEXR: no SVID for pid=%s after %ss — this process will "
                            "run WITHOUT an identity. Tool calls will be refused and "
                            "its evidence cannot be attributed. Entry %s exists on the "
                            "SPIRE Server, so this is agent sync, not registration. "
                            "Set HEXR_REQUIRE_IDENTITY=true to fail closed instead.",
                            os.getpid(),
                            _DEFAULT_AGENT_SYNC_TIMEOUT_SECONDS,
                            result.get("entry_id"),
                        )
                        if os.environ.get("HEXR_REQUIRE_IDENTITY", "").lower() in (
                            "1", "true", "yes",
                        ):
                            raise RuntimeError(
                                f"HEXR_REQUIRE_IDENTITY is set and no SVID was issued "
                                f"for pid {os.getpid()} within "
                                f"{_DEFAULT_AGENT_SYNC_TIMEOUT_SECONDS}s. Refusing to "
                                f"run unidentified."
                            )

                    return RegistrationResult(
                        success=True,
                        entry_id=result.get("entry_id"),
                        spiffe_id=result.get("spiffe_id"),
                        message=result.get("message"),
                    )
                elif result.get("status") == "partial":
                    # Entry created successfully, confirmation pending
                    logger.info(
                        f"✅ SPIRE entry created: {result.get('entry_id')}"
                    )
                    return RegistrationResult(
                        success=True,  # Entry exists, safe to proceed
                        entry_id=result.get("entry_id"),
                        spiffe_id=result.get("spiffe_id"),
                        message=result.get("message"),
                    )
                else:
                    error_msg = result.get("error", "Unknown error")
                    logger.error(f"❌ SPIRE registration failed: {error_msg}")
                    return RegistrationResult(
                        success=False, error=error_msg, message=result.get("message")
                    )
            else:
                error_msg = f"HTTP {response.status_code}: {response.text}"
                logger.error(f"❌ Auto-registrar request failed: {error_msg}")
                return RegistrationResult(success=False, error=error_msg)

        except HexrRegistrationUnavailable as exc:
            # Circuit breaker is OPEN. Before failing loudly, attempt
            # the \u00a71.28.8.3(b) cached-SVID fallback: if the local
            # SPIRE Agent still has a valid X509-SVID for this workload,
            # proceed in degraded mode rather than killing the agent
            # process. The fallback returns None when no usable cached
            # SVID exists (no socket, expired, or fetch error), and we
            # re-raise loudly so the operator sees it.
            fallback = _attempt_cached_svid_fallback(exc)
            if fallback is not None:
                return fallback
            logger.error(
                "❌ Registrar unavailable and no usable cached SVID: "
                "last_status=%s last_body=%r",
                exc.last_status,
                exc.last_body,
            )
            raise
        except requests.Timeout:
            error_msg = f"Registration timed out after {timeout}s"
            logger.error(f"❌ {error_msg}")
            return RegistrationResult(success=False, error=error_msg)
        except requests.RequestException as e:
            error_msg = f"Registration request failed: {e}"
            logger.error(f"❌ {error_msg}")
            return RegistrationResult(success=False, error=error_msg)
        except Exception as e:
            error_msg = f"Unexpected error during registration: {e}"
            logger.error(f"❌ {error_msg}")
            return RegistrationResult(success=False, error=error_msg)


# Global registration instance
_registration_client: Optional[SynchronousRegistration] = None


def get_registration_client() -> SynchronousRegistration:
    """Get or create global registration client."""
    global _registration_client
    if _registration_client is None:
        _registration_client = SynchronousRegistration()
    return _registration_client


def register_current_process(
    tenant: str,
    framework: str,
    agent_name: str,
    sub_agent: Optional[str] = None,
    process_role: Optional[str] = None,
    resources: Optional[List[str]] = None,
) -> RegistrationResult:
    """
    Register current process with auto-registrar synchronously.

    This should be called during SDK initialization, BEFORE writing context files.
    It blocks until SPIRE entry is confirmed, ensuring hexr_tool() works immediately.

    Args:
        tenant: Tenant identifier
        framework: Agentic framework
        agent_name: Agent name
        sub_agent: Sub-agent role (optional)
        process_role: Process role (optional)
        resources: Cloud resources (optional)

    Returns:
        RegistrationResult with success status

    Raises:
        RuntimeError: If registration fails critically
    """
    # Get pod UID from environment (set by Kubernetes downward API)
    pod_uid = os.environ.get("POD_UID")
    if not pod_uid:
        error_msg = "POD_UID environment variable not set - required for registration"
        logger.error(f"❌ {error_msg}")
        raise RuntimeError(error_msg)

    # Get current process ID
    process_id = os.getpid()

    # Register synchronously
    client = get_registration_client()
    result = client.register_process_sync(
        pod_uid=pod_uid,
        process_id=process_id,
        tenant=tenant,
        framework=framework,
        agent_name=agent_name,
        sub_agent=sub_agent,
        process_role=process_role,
        resources=resources,
    )

    # Fail fast if registration unsuccessful
    if not result.success:
        error_msg = f"SPIRE registration failed: {result.error}"
        logger.error(f"❌ {error_msg}")
        raise RuntimeError(error_msg)

    if result.degraded:
        # §1.28.8.3(b): cached SVID was used because registrar was
        # unreachable. The workload has identity (hexr_tool works) but
        # the operator must see this — emit WARN so it shows up in
        # log-based alerts and so evidence-api downstream can tag the
        # session as attestation_class=app_attested_degraded.
        logger.warning(
            "⚠️  Process registered in DEGRADED mode (cached SVID, registrar unreachable) "
            "— hexr_tool() ready to use (SPIFFE ID: %s)",
            result.spiffe_id,
        )
    else:
        logger.info(
            f"✅ Process registered successfully - hexr_tool() ready to use (SPIFFE ID: {result.spiffe_id})"
        )
    # Cache the registered SPIFFE ID so tools.py evidence emit can attach it
    # even when JWT-SVID exchange later fails (e.g. Envoy sidecar down).
    if result.spiffe_id:
        global _LAST_REGISTERED_SPIFFE_ID
        _LAST_REGISTERED_SPIFFE_ID = result.spiffe_id

    # Whatever registered this process is now responsible for removing its
    # entry. Binding that to registration rather than to one call path is the
    # point: until 2026-09-27 the only deregistration lived in the
    # @hexr_agent decorator's finally block, so a process that registered
    # through this API without being wrapped by that decorator never removed
    # anything. The healthtech crew does exactly that (its stage workers
    # register here; the decorator sits on an uncalled card stub), and the
    # demo plane was creating ~52 entries an hour and deleting none. Expiry
    # bounded the pile at TTL x rate, roughly 1,250 entries for twelve live
    # agents, which is bounded and still absurd.
    _install_deregister_at_exit()
    _start_lease_renewal()
    return result


_LAST_REGISTERED_SPIFFE_ID: Optional[str] = None
_DEREGISTER_HOOK_PID: int | None = None
_LEASE_THREAD_PID: int | None = None
_LEASE_STOP = threading.Event()


def _lease_seconds() -> int:
    """How long an entry this SDK creates should live without renewal.

    The renewal thread runs far more often than this (hourly by default),
    so the lease only matters when renewal stops: a process that is killed
    without running its exit hook leaves an entry that disappears within
    one lease instead of never.
    """
    try:
        v = int(os.environ.get("HEXR_LEASE_SECONDS", str(24 * 3600)))
    except ValueError:
        v = 24 * 3600
    return max(0, v)


def _renew_lease_once(timeout: float = 3.0) -> int:
    """Extend this process's SPIRE entry. Returns entries renewed; never raises."""
    pod_uid = os.environ.get("POD_UID")
    if not pod_uid:
        return 0
    try:
        url = SynchronousRegistration()._get_auto_registrar_url().rstrip("/") + "/renew"
        resp = requests.post(
            url,
            json={"pod_uid": pod_uid, "process_id": str(os.getpid())},
            timeout=timeout,
        )
        if resp.ok:
            return int((resp.json() or {}).get("renewed", 0))
        logger.debug("renew returned HTTP %s: %s", resp.status_code, resp.text[:200])
    except Exception as exc:  # noqa: BLE001 - a background thread must not raise
        logger.debug("renew skipped (%s): %s", type(exc).__name__, exc)
    return 0


def _start_lease_renewal(interval_seconds: float | None = None) -> None:
    """Keep this process's SPIRE entry alive for as long as the process runs.

    Per-process entries carry an expiry so a process that dies without
    deregistering cannot leak an identity forever. That bound is only safe
    if a process which is still running can keep its own entry alive.

    Renewal is driven from here, by the process itself, rather than by the
    registrar. The registrar cannot tell whether a PID is alive: it has no
    hostPID and cannot read /proc. Renewing on POD liveness instead was
    tried and reverted on 2026-09-26, because 3,606 of 3,612 entries on the
    demo plane belonged to one long-lived pod whose workers exit after
    seconds; that would have renewed every dead worker's entry forever and
    cancelled the expiry bound outright.

    The thread is a daemon, so it never holds up interpreter exit, and it
    is started once per process. HEXR_LEASE_RENEW_SECONDS overrides the
    interval; 0 disables renewal entirely for a process that would rather
    rely on expiry alone.
    """
    global _LEASE_THREAD_PID
    pid = os.getpid()
    if _LEASE_THREAD_PID == pid:
        return
    _LEASE_THREAD_PID = pid

    if interval_seconds is None:
        try:
            interval_seconds = float(os.environ.get("HEXR_LEASE_RENEW_SECONDS", "3600"))
        except ValueError:
            interval_seconds = 3600.0
    if interval_seconds <= 0:
        logger.debug("lease renewal disabled by configuration")
        return

    def _loop() -> None:
        while True:
            # Sleep first: the entry was just created with a full TTL, so
            # renewing immediately would be a wasted call on every start.
            if _LEASE_STOP.wait(interval_seconds):
                return
            if os.getpid() != pid:
                return  # inherited by a fork; not this process's lease
            _renew_lease_once()

    threading.Thread(
        target=_loop, name="hexr-lease-renewal", daemon=True
    ).start()
    logger.debug("lease renewal started (every %ss)", interval_seconds)


def _install_deregister_at_exit() -> None:
    """Arrange for this process to drop its SPIRE entry when it exits.

    Guarded three ways:

    * once per process, so repeated registration calls do not stack hooks;
    * keyed on the PID that installed it, so a forked child does not inherit
      the parent's hook and delete the parent's entry;
    * idempotent with the decorator, because `/deregister` on an entry that
      is already gone reports zero deletions and is not an error.

    atexit does not run for a process that leaves via os._exit, which is how
    multiprocessing children exit. Those are exactly the processes the
    decorator's finally block already covers, so the two mechanisms together
    cover normal exits and worker exits. Entry expiry remains the floor for
    anything that dies without running either.
    """
    global _DEREGISTER_HOOK_PID
    pid = os.getpid()
    if _DEREGISTER_HOOK_PID == pid:
        return
    _DEREGISTER_HOOK_PID = pid

    def _hook() -> None:
        if os.getpid() != pid:
            return  # inherited by a fork; not ours to remove
        try:
            deregister_current_process()
        except Exception:  # noqa: BLE001 - exit paths must never raise
            pass

    try:
        atexit.register(_hook)
    except Exception:  # noqa: BLE001
        pass


def get_last_registered_spiffe_id() -> Optional[str]:
    """Return the most recent SPIFFE ID issued by synchronous registration."""
    return _LAST_REGISTERED_SPIFFE_ID


# ── Deregistration ───────────────────────────────────────────────────────────
#
# The process that registered removes its own entry when its work is done.
# Without this, a long-lived pod spawning a short-lived process per stage —
# the sub-agent pattern per-process identity exists for — leaves one entry per
# stage per run for the life of the pod. 64 became 396 in under an hour on one
# pod, 2026-09-18. The pod-level reaper cannot see it because the pod is alive.
#
# Called from the @hexr_agent decorator's finally block, after evidence is
# flushed and before the context file is removed. Best-effort and bounded: a
# registrar that is down must not delay a process's exit, and the reaper
# remains the safety net for anything that slips through.

def deregister_current_process(timeout: float = 3.0) -> bool:
    """Remove this process's SPIRE entry. Returns True if the registrar
    confirmed a deletion, False for any other outcome (already gone, registrar
    unreachable, not in-cluster). Never raises."""
    _LEASE_STOP.set()  # stop renewing an entry we are about to remove
    pod_uid = os.environ.get("POD_UID")
    if not pod_uid:
        return False  # not in a pod; there is no entry to remove
    try:
        url = SynchronousRegistration()._get_auto_registrar_url().rstrip("/") + "/deregister"
        resp = requests.post(
            url,
            json={"pod_uid": pod_uid, "process_id": str(os.getpid())},
            timeout=timeout,
        )
        if resp.ok:
            n = int((resp.json() or {}).get("deleted", 0))
            if n:
                logger.info("deregistered SPIRE entry for pid %d", os.getpid())
            return n > 0
        logger.debug("deregister returned HTTP %s: %s", resp.status_code, resp.text[:200])
    except Exception as exc:  # noqa: BLE001 — exit paths must not raise
        logger.debug("deregister skipped (%s): %s", type(exc).__name__, exc)
    return False
