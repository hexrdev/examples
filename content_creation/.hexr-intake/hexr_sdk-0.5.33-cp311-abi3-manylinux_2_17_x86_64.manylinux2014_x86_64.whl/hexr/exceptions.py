"""Hexr SDK exception definitions."""


class HexrError(Exception):
    """Base exception for all Hexr SDK errors."""

    pass


class AuthenticationError(HexrError):
    """Raised when SPIFFE authentication fails."""

    pass


class IdentityNotYetIssuedError(AuthenticationError):
    """SPIRE has no entry for this process *yet*.

    Distinct from every other AuthenticationError: nothing is misconfigured
    and nothing was refused on its merits. The registration entry has not
    finished propagating to the agent, so the Workload API answers
    PERMISSION_DENIED for a few seconds after a process starts.

    This exists so a startup race is not recorded as a policy denial. On the
    AKS plane 19,696 of 19,718 unsigned `tool_call_denied` rows were this
    case, which made the denial count read as enforcement activity when it
    was really processes waiting to be registered.

    Subclasses AuthenticationError so existing handlers keep working.
    """

    pass


class CredentialError(HexrError):
    """Raised when credential exchange fails."""

    pass


class ConfigurationError(HexrError):
    """Raised when SDK configuration is invalid."""

    pass


class BuildError(HexrError):
    """Raised when agent build process fails."""

    pass


class DeploymentError(HexrError):
    """Raised when agent deployment fails."""

    pass


class FrameworkError(HexrError):
    """Raised when framework detection or integration fails."""

    pass


class ProcessContextError(HexrError):
    """Raised when process context management fails."""

    pass


class GuardrailError(HexrError):
    """Raised when LLM Guard blocks a prompt or output."""

    def __init__(self, message: str, scanners: dict | None = None):
        super().__init__(message)
        self.scanners = scanners or {}
