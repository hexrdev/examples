"""Version management for Hexr SDK.

Version is sourced from installed package metadata (pyproject.toml is the single
source of truth). The hardcoded fallback only fires for editable/in-tree imports
where the package isn't installed yet — bump it when cutting a release so the
fallback never lags reality.
"""

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("hexr-sdk")
except PackageNotFoundError:  # editable/in-tree fallback
    __version__ = "0.5.9"

__version_info__ = tuple(int(p) for p in __version__.split(".")[:3] if p.isdigit())


def get_version() -> str:
    """Get the current version string."""
    return __version__


def get_version_info() -> tuple:
    """Get the current version as a tuple."""
    return __version_info__
