"""Build provenance shipped inside the wheel.

Per HEXR_SDK_OVERHAUL_TECH_SPEC §19.5 step 4: customers and auditors must be
able to verify "what we mirrored is what we resolved." The hashed lockfile
that drove the T1/T2 mirror upload is committed at
``sdk/python/requirements-mirror.txt`` and shipped inside the wheel as
``hexr/_meta/requirements-mirror.txt`` so a deployed installation can be
audited offline (no network, no repo clone).

Usage::

    from hexr._meta import requirements_mirror_path, read_requirements_mirror

    path = requirements_mirror_path()
    text = read_requirements_mirror()
"""

from __future__ import annotations

from importlib import resources
from pathlib import Path

_LOCKFILE_NAME = "requirements-mirror.txt"


def requirements_mirror_path() -> Path:
    """Return the on-disk path to the shipped lockfile."""
    return Path(__file__).resolve().parent / _LOCKFILE_NAME


def read_requirements_mirror() -> str:
    """Return the shipped lockfile contents as text."""
    return resources.files(__package__).joinpath(_LOCKFILE_NAME).read_text(
        encoding="utf-8"
    )


__all__ = ["requirements_mirror_path", "read_requirements_mirror"]
