"""
Hexr Process Tree Context Management.

CORRECT HEXR ARCHITECTURE:
1. Python SDK monitors process tree and creates JSON context files
2. Go Enhanced Attestor (in Hexr Runtime) reads these files via shared volume
3. Enhanced Attestor attests processes to SPIRE Server
4. SPIRE Server issues SPIFFE IDs based on context

Python SDK Role: Process monitoring + JSON file generation ONLY
No direct SPIRE interaction - that's handled by Hexr Runtime (Go)
"""

import os
import json
import time
import psutil
import threading
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Optional, Any

from .utils.simple_logging import get_logger

logger = get_logger(__name__)


@dataclass
class ProcessContext:
    """Individual process context within the hierarchy."""

    pid: int
    ppid: int
    agent_name: str
    role: str
    framework: str
    tenant: str
    workload_id: str
    spiffe_path_components: List[str]
    resources: List[str]
    regions: Dict[str, str]
    start_time: float
    metadata: Optional[Dict[str, Any]] = None

    def to_spiffe_path(self, base_domain: str = "hexr.internal") -> str:
        """Generate correct SPIFFE ID path per Hexr vision documents."""
        # spiffe://hexr.internal/{tenant}/{framework}/{agent}/{role}/proc-{pid}
        return f"spiffe://{base_domain}/tenant/{self.tenant}/{self.framework}/{self.agent_name}/proc-{self.pid}"


class ProcessTreeManager:
    """
    Manages hierarchical process contexts for framework-agnostic SPIFFE ID generation.

    Maintains process tree hierarchy without monkey patching any frameworks.
    Uses userspace process monitoring to detect subprocess patterns.
    """

    def __init__(self):
        self._process_tree: Dict[int, ProcessContext] = {}
        self._monitoring = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._root_pid: Optional[int] = None
        self._framework_detectors = {
            "crewai": self._detect_crewai_subprocess,
            "langchain": self._detect_langchain_subprocess,
            "strands": self._detect_strands_subprocess,
            "custom": self._detect_custom_subprocess,
        }

    def start_root_context(
        self,
        agent_name: str,
        tenant: str,
        workload_id: str,
        framework: str,
        resources: List[str],
        regions: Dict[str, str],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ProcessContext:
        """Start root process context and begin subprocess monitoring."""

        root_pid = os.getpid()
        self._root_pid = root_pid

        # Create root process context
        root_context = ProcessContext(
            pid=root_pid,
            ppid=os.getppid(),
            agent_name=agent_name,
            role="main",
            framework=framework,
            tenant=tenant,
            workload_id=workload_id,
            spiffe_path_components=[],
            resources=resources,
            regions=regions,
            start_time=time.time(),
            metadata=metadata,
        )

        self._process_tree[root_pid] = root_context

        # Start subprocess monitoring
        self._start_subprocess_monitoring()

        # Write hierarchical context to Enhanced Attestor
        self._write_process_tree_context()

        logger.info(f"Started root context: {root_context.to_spiffe_path()}")
        return root_context

    def _start_subprocess_monitoring(self) -> None:
        """Start background thread for framework-agnostic subprocess detection."""
        if self._monitoring:
            return

        self._monitoring = True
        self._monitor_thread = threading.Thread(
            target=self._monitor_subprocess_creation,
            daemon=True,
            name=f"hexr-process-tree-monitor",
        )
        self._monitor_thread.start()
        logger.info("Started framework-agnostic subprocess monitoring")

    def _monitor_subprocess_creation(self) -> None:
        """Monitor for subprocess creation and maintain process tree hierarchy."""
        try:
            known_pids = set(self._process_tree.keys())

            while self._monitoring:
                try:
                    # Get current process tree from root
                    current_process = psutil.Process(self._root_pid)
                    all_children = current_process.children(recursive=True)

                    # Detect new subprocess creation
                    for child_proc in all_children:
                        if child_proc.pid not in known_pids:
                            # New subprocess detected
                            parent_context = self._find_parent_context(
                                child_proc.ppid()
                            )
                            if parent_context:
                                subprocess_context = self._create_subprocess_context(
                                    child_proc, parent_context
                                )
                                if subprocess_context:
                                    self._process_tree[child_proc.pid] = (
                                        subprocess_context
                                    )
                                    known_pids.add(child_proc.pid)

                                    # Update hierarchical context file
                                    self._write_process_tree_context()

                                    logger.info(
                                        f"Detected subprocess: {subprocess_context.to_spiffe_path()}"
                                    )

                    # Clean up terminated processes
                    terminated_pids = []
                    for pid in known_pids:
                        if pid != self._root_pid:  # Don't check root process
                            try:
                                psutil.Process(pid)
                            except psutil.NoSuchProcess:
                                terminated_pids.append(pid)

                    for pid in terminated_pids:
                        if pid in self._process_tree:
                            del self._process_tree[pid]
                            known_pids.remove(pid)
                            logger.debug(f"Cleaned up terminated process: {pid}")

                            # Update context file after cleanup
                            self._write_process_tree_context()

                    time.sleep(0.5)  # Monitor every 500ms

                except Exception as e:
                    logger.error(f"Subprocess monitoring error: {e}")
                    time.sleep(1.0)

        except Exception as e:
            logger.error(f"Subprocess monitoring thread failed: {e}")

    def _find_parent_context(self, ppid: int) -> Optional[ProcessContext]:
        """Find parent process context for inheritance."""
        return self._process_tree.get(ppid)

    def _create_subprocess_context(
        self, process: psutil.Process, parent_context: ProcessContext
    ) -> Optional[ProcessContext]:
        """Create subprocess context inheriting from parent."""

        try:
            # Detect framework-specific role
            framework = parent_context.framework
            detector = self._framework_detectors.get(
                framework, self._detect_custom_subprocess
            )

            role_info = detector(process, parent_context)
            if not role_info:
                return None  # Not a recognized framework subprocess

            role, spiffe_components = role_info

            # Inherit parent context + add subprocess specifics
            subprocess_context = ProcessContext(
                pid=process.pid,
                ppid=process.ppid(),
                agent_name=parent_context.agent_name,
                role=role,
                framework=framework,
                tenant=parent_context.tenant,
                workload_id=parent_context.workload_id,
                spiffe_path_components=parent_context.spiffe_path_components
                + spiffe_components,
                resources=parent_context.resources,  # Inherit parent resources
                regions=parent_context.regions,
                start_time=process.create_time(),
                metadata={
                    "parent_pid": process.ppid(),
                    "cmdline": process.cmdline(),
                    "inherited_from": parent_context.to_spiffe_path(),
                },
            )

            return subprocess_context

        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            logger.debug(
                f"Failed to create subprocess context for PID {process.pid}: {e}"
            )
            return None

    def _detect_crewai_subprocess(
        self, process: psutil.Process, parent: ProcessContext
    ) -> Optional[tuple[str, List[str]]]:
        """Detect CrewAI agent subprocesses without monkey patching."""

        try:
            cmdline = " ".join(process.cmdline()).lower()

            # CrewAI detection patterns (no monkey patching required)
            if "researcher" in cmdline or "research" in cmdline:
                return "researcher", ["subprocess/researcher"]
            elif "analyst" in cmdline or "analysis" in cmdline:
                return "analyst", ["subprocess/analyst"]
            elif "writer" in cmdline or "writing" in cmdline:
                return "writer", ["subprocess/writer"]
            elif "planner" in cmdline or "planning" in cmdline:
                return "planner", ["subprocess/planner"]
            elif "reviewer" in cmdline or "review" in cmdline:
                return "reviewer", ["subprocess/reviewer"]

            # Generic CrewAI subprocess
            if "python" in cmdline and any(
                p in cmdline for p in ["crew", "agent", "task"]
            ):
                return f"agent-{process.pid}", ["subprocess/crewai-agent"]

            return None

        except Exception as e:
            logger.debug(f"CrewAI detection error for PID {process.pid}: {e}")
            return None

    def _detect_langchain_subprocess(
        self, process: psutil.Process, parent: ProcessContext
    ) -> Optional[tuple[str, List[str]]]:
        """Detect LangChain executor subprocesses without monkey patching."""

        try:
            cmdline = " ".join(process.cmdline()).lower()

            # LangChain detection patterns
            if "executor" in cmdline:
                return "executor", ["subprocess/executor"]
            elif "chain" in cmdline:
                return "chain", ["subprocess/chain"]
            elif "agent" in cmdline and "langchain" in cmdline:
                return "langchain-agent", ["subprocess/langchain-agent"]
            elif "tool" in cmdline and "langchain" in cmdline:
                return "tool-executor", ["subprocess/tool"]

            # Generic LangChain subprocess
            if "python" in cmdline and any(
                p in cmdline for p in ["langchain", "chain", "llm"]
            ):
                return f"executor-{process.pid}", ["subprocess/langchain-executor"]

            return None

        except Exception as e:
            logger.debug(f"LangChain detection error for PID {process.pid}: {e}")
            return None

    def _detect_strands_subprocess(
        self, process: psutil.Process, parent: ProcessContext
    ) -> Optional[tuple[str, List[str]]]:
        """Detect Strands worker subprocesses."""

        try:
            cmdline = " ".join(process.cmdline()).lower()

            if "strand" in cmdline:
                if "worker" in cmdline:
                    return "strand-worker", ["subprocess/strand-worker"]
                elif "coordinator" in cmdline:
                    return "strand-coordinator", ["subprocess/coordinator"]
                else:
                    return f"strand-{process.pid}", ["subprocess/strand"]

            return None

        except Exception as e:
            logger.debug(f"Strands detection error for PID {process.pid}: {e}")
            return None

    def _detect_custom_subprocess(
        self, process: psutil.Process, parent: ProcessContext
    ) -> Optional[tuple[str, List[str]]]:
        """Detect custom framework subprocesses."""

        try:
            cmdline = " ".join(process.cmdline()).lower()

            # Generic Python subprocess detection
            if "python" in cmdline:
                if any(p in cmdline for p in ["agent", "worker", "processor", "task"]):
                    return f"worker-{process.pid}", ["subprocess/worker"]
                elif "main.py" not in cmdline:  # Not main script
                    return f"subprocess-{process.pid}", ["subprocess/generic"]

            return None

        except Exception as e:
            logger.debug(f"Custom detection error for PID {process.pid}: {e}")
            return None

    def _write_process_tree_context(self) -> None:
        """Write hierarchical process tree context to Enhanced Attestor."""

        try:
            # Create hierarchical structure preserving parent-child relationships
            process_tree_context = {
                "version": "1.0",
                "timestamp": int(time.time()),
                "root_pid": self._root_pid,
                "process_tree": {},
            }

            # Build hierarchical tree structure
            for pid, context in self._process_tree.items():
                process_tree_context["process_tree"][str(pid)] = {
                    "context": asdict(context),
                    "spiffe_id": context.to_spiffe_path(),
                    "parent_pid": context.ppid if context.ppid != context.pid else None,
                    "children": [],
                }

            # Establish parent-child links
            for pid_str, proc_data in process_tree_context["process_tree"].items():
                parent_pid = proc_data["parent_pid"]
                if (
                    parent_pid
                    and str(parent_pid) in process_tree_context["process_tree"]
                ):
                    process_tree_context["process_tree"][str(parent_pid)][
                        "children"
                    ].append(int(pid_str))

            # Write SINGLE hierarchical context file for Enhanced Attestor
            context_dir = Path("/tmp/hexr-context")
            context_dir.mkdir(exist_ok=True, mode=0o755)

            context_file = context_dir / f"hexr-process-tree-{self._root_pid}.json"

            with open(context_file, "w") as f:
                json.dump(process_tree_context, f, indent=2)

            logger.debug(
                f"Updated process tree context: {len(self._process_tree)} processes"
            )

        except Exception as e:
            logger.error(f"Failed to write process tree context: {e}")

    def stop_monitoring(self) -> None:
        """Stop subprocess monitoring and cleanup."""

        self._monitoring = False

        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=2.0)

        # Cleanup context file
        try:
            context_file = Path(
                f"/tmp/hexr-context/hexr-process-tree-{self._root_pid}.json"
            )
            if context_file.exists():
                context_file.unlink()
                logger.info(f"Cleaned up process tree context file")
        except Exception as e:
            logger.warning(f"Failed to cleanup process tree context: {e}")

        self._process_tree.clear()
        logger.info("Stopped process tree monitoring")

    def get_process_tree(self) -> Dict[int, ProcessContext]:
        """Get current process tree hierarchy."""
        return self._process_tree.copy()

    def get_spiffe_hierarchy(self) -> Dict[str, str]:
        """Get SPIFFE ID hierarchy for all processes."""
        return {
            str(pid): context.to_spiffe_path()
            for pid, context in self._process_tree.items()
        }


# Global process tree manager
_process_tree_manager: Optional[ProcessTreeManager] = None


def get_process_tree_manager() -> ProcessTreeManager:
    """Get global process tree manager instance."""
    global _process_tree_manager
    if _process_tree_manager is None:
        _process_tree_manager = ProcessTreeManager()
    return _process_tree_manager
