"""
Hexr CLI commands for credential cache management.

Commands:
    hexr cache status  - Show cache status and metrics
    hexr cache clear   - Clear credential cache
    hexr cache metrics - Export cache metrics

Usage:
    $ hexr cache status
    JWT-SVID: Cached (expires in 8m 32s)
      SPIFFE ID: spiffe://hexr.internal/demo/mixed/financial-analysis/proc-15624

    Cloud Credentials:
      aws_s3:us-east-1     - Cached (expires in 45m 12s)
      aws_dynamodb:us-west-2 - Cached (expires in 38m 05s)

    $ hexr cache clear --service aws_s3 --region us-east-1
    Cache cleared successfully: aws_s3:us-east-1

    $ hexr cache metrics --format json
    {
      "jwt_svid": {
        "cache_hits": 234,
        "cache_misses": 3,
        ...
      }
    }
"""

import json

import click

from hexr.credential.cache import CredentialCache
from hexr.utils.simple_logging import get_logger

logger = get_logger(__name__)


@click.group()
def cache():
    """Manage hexr_tool credential cache."""
    pass


@cache.command()
def status():
    """Show cache status and metrics."""
    try:
        cache_instance = CredentialCache.get_instance()
        summary = cache_instance.get_cache_summary()

        # Display JWT-SVID status
        click.echo("\n" + click.style("JWT-SVID:", bold=True))
        if summary["jwt_svid"]["cached"]:
            expires_in = summary["jwt_svid"]["expires_in_seconds"]
            minutes = expires_in // 60
            seconds = expires_in % 60

            status_color = (
                "green" if expires_in > 300 else "yellow" if expires_in > 60 else "red"
            )
            click.echo(
                f"  Status: {click.style('Cached', fg=status_color)} (expires in {minutes}m {seconds}s)"
            )
            click.echo(f"  SPIFFE ID: {summary['jwt_svid']['spiffe_id']}")
        else:
            click.echo(f"  Status: {click.style('Not cached', fg='yellow')}")

        # Display cloud credentials status
        click.echo("\n" + click.style("Cloud Credentials:", bold=True))
        if summary["credentials"]:
            for cache_key, creds in summary["credentials"].items():
                expires_in = creds["expires_in_seconds"]
                minutes = expires_in // 60
                seconds = expires_in % 60

                status_color = (
                    "green"
                    if expires_in > 300
                    else "yellow"
                    if expires_in > 60
                    else "red"
                )
                click.echo(
                    f"  {cache_key:<30} - {click.style('Cached', fg=status_color)} (expires in {minutes}m {seconds}s)"
                )
        else:
            click.echo(f"  {click.style('No credentials cached', fg='yellow')}")

        # Display cache metrics
        click.echo("\n" + click.style("Cache Metrics:", bold=True))
        metrics = summary["metrics"]

        jwt_hit_rate = metrics["jwt_cache_hit_rate"] * 100
        creds_hit_rate = metrics["credentials_cache_hit_rate"] * 100

        click.echo(f"  Total SPIRE calls: {metrics['total_spire_calls']}")
        click.echo(f"  Total exchange calls: {metrics['total_exchange_calls']}")
        click.echo(f"  JWT cache hit rate: {jwt_hit_rate:.1f}%")
        click.echo(f"  Credentials cache hit rate: {creds_hit_rate:.1f}%")
        click.echo()

    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort() from e


@cache.command()
@click.option("--jwt", is_flag=True, help="Clear JWT-SVID only")
@click.option("--service", help="Clear specific service (e.g., aws_s3)")
@click.option("--region", help="Clear specific region (requires --service)")
@click.option("--all", "clear_all", is_flag=True, help="Clear entire cache")
def clear(jwt, service, region, clear_all):
    """Clear credential cache."""
    try:
        cache_instance = CredentialCache.get_instance()

        if clear_all:
            cache_instance.clear_all()
            click.echo(
                click.style(
                    "✅ Cache cleared successfully (JWT + all credentials)", fg="green"
                )
            )
        elif jwt:
            cache_instance.invalidate_jwt_svid()
            click.echo(click.style("✅ JWT-SVID cleared successfully", fg="green"))
        elif service:
            cache_instance.invalidate_credentials(service, region)
            cache_key = f"{service}:{region}" if region else f"{service}:*"
            click.echo(
                click.style(
                    f"✅ Credentials cleared successfully: {cache_key}", fg="green"
                )
            )
        else:
            click.echo(
                click.style("Error: Must specify --jwt, --service, or --all", fg="red"),
                err=True,
            )
            click.echo("\nExamples:")
            click.echo(
                "  hexr cache clear --jwt                          # Clear JWT-SVID only"
            )
            click.echo(
                "  hexr cache clear --service aws_s3               # Clear all aws_s3 credentials"
            )
            click.echo(
                "  hexr cache clear --service aws_s3 --region us-east-1  # Clear specific service+region"
            )
            click.echo(
                "  hexr cache clear --all                          # Clear everything"
            )
            raise click.Abort()

    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort() from e


@cache.command()
@click.option(
    "--format",
    type=click.Choice(["json", "prometheus", "text"]),
    default="json",
    help="Output format for metrics",
)
def metrics(format):
    """Export cache metrics."""
    try:
        cache_instance = CredentialCache.get_instance()
        metrics_data = cache_instance.get_metrics()

        if format == "json":
            click.echo(json.dumps(metrics_data, indent=2))

        elif format == "prometheus":
            # Convert to Prometheus format
            output = _to_prometheus_format(metrics_data)
            click.echo(output)

        elif format == "text":
            # Human-readable text format
            click.echo("\n" + click.style("JWT-SVID Metrics:", bold=True))
            for key, value in metrics_data["jwt_svid"].items():
                click.echo(f"  {key}: {value}")

            click.echo("\n" + click.style("Cloud Credentials Metrics:", bold=True))
            for key, value in metrics_data["cloud_credentials"].items():
                click.echo(f"  {key}: {value}")

            if metrics_data["by_service"]:
                click.echo("\n" + click.style("Per-Service Metrics:", bold=True))
                for service, service_metrics in metrics_data["by_service"].items():
                    click.echo(f"  {service}:")
                    for key, value in service_metrics.items():
                        click.echo(f"    {key}: {value}")
            click.echo()

    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"), err=True)
        raise click.Abort() from e


def _to_prometheus_format(metrics_data: dict) -> str:
    """
    Convert metrics to Prometheus exposition format.

    Args:
        metrics_data: Metrics dictionary from CredentialCache

    Returns:
        str: Prometheus-formatted metrics
    """
    lines = []

    # JWT-SVID metrics
    lines.append("# HELP hexr_jwt_svid_cache_hits_total Counter of JWT-SVID cache hits")
    lines.append("# TYPE hexr_jwt_svid_cache_hits_total counter")
    lines.append(
        f"hexr_jwt_svid_cache_hits_total {metrics_data['jwt_svid']['cache_hits']}"
    )

    lines.append(
        "# HELP hexr_jwt_svid_cache_misses_total Counter of JWT-SVID cache misses"
    )
    lines.append("# TYPE hexr_jwt_svid_cache_misses_total counter")
    lines.append(
        f"hexr_jwt_svid_cache_misses_total {metrics_data['jwt_svid']['cache_misses']}"
    )

    lines.append("# HELP hexr_jwt_svid_fetches_total Counter of SPIRE fetches")
    lines.append("# TYPE hexr_jwt_svid_fetches_total counter")
    lines.append(
        f"hexr_jwt_svid_fetches_total {metrics_data['jwt_svid']['spire_fetches']}"
    )

    lines.append(
        "# HELP hexr_jwt_svid_proactive_refreshes_total Counter of proactive refreshes"
    )
    lines.append("# TYPE hexr_jwt_svid_proactive_refreshes_total counter")
    lines.append(
        f"hexr_jwt_svid_proactive_refreshes_total {metrics_data['jwt_svid']['proactive_refreshes']}"
    )

    lines.append(
        "# HELP hexr_jwt_svid_refresh_failures_total Counter of refresh failures"
    )
    lines.append("# TYPE hexr_jwt_svid_refresh_failures_total counter")
    lines.append(
        f"hexr_jwt_svid_refresh_failures_total {metrics_data['jwt_svid']['refresh_failures']}"
    )

    # Cloud credentials metrics
    lines.append(
        "# HELP hexr_credentials_cache_hits_total Counter of credential cache hits"
    )
    lines.append("# TYPE hexr_credentials_cache_hits_total counter")
    lines.append(
        f"hexr_credentials_cache_hits_total {metrics_data['cloud_credentials']['cache_hits']}"
    )

    lines.append(
        "# HELP hexr_credentials_cache_misses_total Counter of credential cache misses"
    )
    lines.append("# TYPE hexr_credentials_cache_misses_total counter")
    lines.append(
        f"hexr_credentials_cache_misses_total {metrics_data['cloud_credentials']['cache_misses']}"
    )

    lines.append(
        "# HELP hexr_credentials_exchanges_total Counter of credential exchanges"
    )
    lines.append("# TYPE hexr_credentials_exchanges_total counter")
    lines.append(
        f"hexr_credentials_exchanges_total {metrics_data['cloud_credentials']['exchanges']}"
    )

    lines.append(
        "# HELP hexr_credentials_proactive_refreshes_total Counter of proactive refreshes"
    )
    lines.append("# TYPE hexr_credentials_proactive_refreshes_total counter")
    lines.append(
        f"hexr_credentials_proactive_refreshes_total {metrics_data['cloud_credentials']['proactive_refreshes']}"
    )

    lines.append(
        "# HELP hexr_credentials_exchange_failures_total Counter of exchange failures"
    )
    lines.append("# TYPE hexr_credentials_exchange_failures_total counter")
    lines.append(
        f"hexr_credentials_exchange_failures_total {metrics_data['cloud_credentials']['exchange_failures']}"
    )

    # Per-service metrics
    lines.append(
        "# HELP hexr_service_cache_hits_total Counter of cache hits per service"
    )
    lines.append("# TYPE hexr_service_cache_hits_total counter")
    for service, service_metrics in metrics_data["by_service"].items():
        # Parse service:region format
        parts = service.split(":", 1)
        service_name = parts[0]
        region = parts[1] if len(parts) > 1 else "None"
        lines.append(
            f'hexr_service_cache_hits_total{{service="{service_name}",region="{region}"}} {service_metrics["hits"]}'
        )

    lines.append(
        "# HELP hexr_service_cache_misses_total Counter of cache misses per service"
    )
    lines.append("# TYPE hexr_service_cache_misses_total counter")
    for service, service_metrics in metrics_data["by_service"].items():
        parts = service.split(":", 1)
        service_name = parts[0]
        region = parts[1] if len(parts) > 1 else "None"
        lines.append(
            f'hexr_service_cache_misses_total{{service="{service_name}",region="{region}"}} {service_metrics["misses"]}'
        )

    return "\n".join(lines)
