"""
Hexr CLI login command.

Authenticates with Hexr Cloud and stores credentials in ~/.hexr/config.json.

Usage:
    hexr login --key hxr_live_<64hex>              # API key login
    hexr login --key hxr_live_<64hex> --url https://api.hexr.cloud  # Custom endpoint
    hexr login --status                             # Check auth status
    hexr logout                                     # Remove stored credentials
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hexr.cli.cloud_config import (
    HEXR_CONFIG_FILE,
    CloudConfig,
    validate_api_key_format,
    validate_cloud_url,
    verify_api_key,
)

console = Console()


@click.command("login")
@click.option(
    "--key",
    "-k",
    "api_key",
    help="API key (hxr_live_<64hex>). Get one at https://app.hexr.cloud",
)
@click.option(
    "--url",
    "cloud_url",
    default=None,
    help="Cloud API endpoint (default: https://api.hexr.cloud)",
)
@click.option(
    "--status",
    is_flag=True,
    help="Show current authentication status",
)
@click.option(
    "--skip-verify",
    is_flag=True,
    hidden=True,
    help="Skip API key verification (for offline use)",
)
def login_command(
    api_key: str | None,
    cloud_url: str | None,
    status: bool,
    skip_verify: bool,
):
    """
    Authenticate with Hexr Cloud.

    Store your API key for use with hexr push --cloud and hexr deploy --cloud.

    \b
    Examples:
        hexr login --key hxr_live_c815c9d0...
        hexr login --status
    """
    if status:
        _show_status()
        return

    if not api_key:
        console.print("[red]Error:[/red] --key is required. Usage:")
        console.print("  hexr login --key hxr_live_<your_api_key>")
        console.print()
        console.print("Get an API key at [blue]https://app.hexr.cloud[/blue]")
        raise SystemExit(1)

    # Validate key format
    if not validate_api_key_format(api_key):
        console.print("[red]Error:[/red] Invalid API key format.")
        console.print("Keys must start with 'hxr_live_' followed by 64 hex characters.")
        raise SystemExit(1)

    # Resolve cloud URL
    effective_url = cloud_url or "https://api.hexr.cloud"
    if not validate_cloud_url(effective_url):
        console.print(f"[red]Error:[/red] Invalid cloud URL: {effective_url}")
        console.print("URL must use HTTPS (e.g., https://api.hexr.cloud)")
        raise SystemExit(1)

    # Verify key against API
    if not skip_verify:
        console.print(f"Verifying API key against [blue]{effective_url}[/blue]...")
        try:
            result = verify_api_key(effective_url, api_key)
            tenant_id = result.get("tenant_id", "")
            role = result.get("role", "unknown")
            # Tenant info may be nested under "tenant" object
            tenant_obj = result.get("tenant", {})
            tenant_name = tenant_obj.get("name", "") if isinstance(tenant_obj, dict) else ""
            console.print(f"[green]✓[/green] Key verified — role: [cyan]{role}[/cyan]")
            if tenant_name:
                console.print(f"[green]✓[/green] Tenant: [cyan]{tenant_name}[/cyan]")
        except RuntimeError as e:
            console.print(f"[red]✗ Verification failed:[/red] {e}")
            raise SystemExit(1)
        except Exception as e:
            console.print(f"[red]✗ Could not reach cloud API:[/red] {e}")
            console.print("Check your network connection or use --skip-verify")
            raise SystemExit(1)
    else:
        tenant_id = ""
        tenant_name = ""
        console.print("[yellow]⚠[/yellow] Skipping verification (offline mode)")

    # Save config
    config = CloudConfig(
        api_key=api_key,
        cloud_url=effective_url,
        tenant_id=tenant_id,
        tenant_name=tenant_name,
    )
    config.save()

    console.print()
    console.print(
        Panel(
            f"[green]Authenticated successfully![/green]\n"
            f"Config saved to [dim]{HEXR_CONFIG_FILE}[/dim]\n"
            f"Permissions: owner read/write only (0600)",
            title="[bold]hexr login[/bold]",
            border_style="green",
        )
    )


@click.command("logout")
def logout_command():
    """
    Remove stored Hexr Cloud credentials.

    Deletes ~/.hexr/config.json.
    """
    if HEXR_CONFIG_FILE.exists():
        HEXR_CONFIG_FILE.unlink()
        console.print("[green]✓[/green] Credentials removed.")
    else:
        console.print("No credentials found — already logged out.")


def _show_status():
    """Display current authentication status."""
    config = CloudConfig.load()

    table = Table(title="Hexr Cloud Auth Status", show_header=False, border_style="dim")
    table.add_column("Field", style="bold")
    table.add_column("Value")

    if config.is_authenticated:
        # Mask the API key: show first 12 chars + last 4
        masked = config.api_key[:12] + "..." + config.api_key[-4:]
        table.add_row("Status", "[green]Authenticated[/green]")
        table.add_row("API Key", f"[dim]{masked}[/dim]")
        table.add_row("Cloud URL", config.cloud_url)
        if config.tenant_name:
            table.add_row("Tenant", config.tenant_name)
        if config.tenant_id:
            table.add_row("Tenant ID", config.tenant_id)
        table.add_row("Config File", str(HEXR_CONFIG_FILE))
    else:
        table.add_row("Status", "[red]Not authenticated[/red]")
        table.add_row("", "Run: hexr login --key <api_key>")

    console.print(table)
