"""
Hexr Build Command Implementation

Core build functionality that transforms Python agent files into
production-ready container images and Kubernetes manifests.
"""

import os
import ast
import json
import logging
import time
import shutil
from pathlib import Path
from typing import Dict, List, Set, Optional, Any, Tuple

# Import enterprise PID mapper for real host PIDs
from hexr.enterprise_pid_mapper import (
    get_enterprise_host_pid,
    get_secure_pid_mapping_info,
)

from hexr.build.docker import DockerfileGenerator
from hexr.build.k8s import KubernetesManifestGenerator
from hexr.build.envoy import EnvoyConfigGenerator
from hexr.shared_config import BuildConfig, BuildResult
from hexr.utils.simple_logging import get_logger


class HexrBuilder:
    """Core build engine for Hexr SDK."""

    def __init__(self, config: BuildConfig):
        self.config = config
        self.logger = get_logger("hexr.build")
        self.dockerfile_generator = DockerfileGenerator()
        self.k8s_generator = KubernetesManifestGenerator()
        self.envoy_generator = EnvoyConfigGenerator(trust_domain=self.config.trust_domain)

    async def build(self) -> BuildResult:
        """Execute complete build process."""
        start_time = time.time()

        try:
            self.logger.info(f"🚀 Starting build for {self.config.agent_file}")

            # Step 1: Analyze Python agent file
            analysis = await self._analyze_agent_file()

            # Route A (managed runtime): skip Dockerfile / K8s / envoy / push-prep
            # entirely. Emit only BuildManifest.json + deploy-descriptor.<rt>.yaml
            # + control-mappings.json under .hexr/managed/ for the customer to
            # paste into their AgentCore / GEAP / Foundry deploy file.
            # See HEXR_SDK_OVERHAUL_TECH_SPEC.md sec 19.5 item 8.
            if self.config.route == "managed":
                from hexr.build.managed import write_managed_artifacts

                # Clean managed/ subtree to avoid stale artifacts across runs.
                self.config.output_dir.mkdir(parents=True, exist_ok=True)
                managed_dir = self.config.output_dir / "managed"
                if managed_dir.exists():
                    shutil.rmtree(managed_dir)

                self.logger.info("🛰️  Route A (managed runtime): emitting managed-runtime artifacts (no K8s manifests)")
                written = write_managed_artifacts(analysis, self.config)
                for label, path in written.items():
                    self.logger.info(f"✅ {label}: {path}")

                duration = time.time() - start_time
                return BuildResult(
                    success=True,
                    image_name=None,  # managed runtime owns the image
                    output_dir=self.config.output_dir,
                    duration=duration,
                    framework=analysis["framework"],
                    cloud_providers=analysis.get("cloud_providers", []),
                    resources=analysis["resources"],
                )

            # Step 2: Generate build artifacts
            build_artifacts = await self._generate_artifacts(analysis)

            # Step 3: Generate image name for hexr push command
            image_name = self._generate_image_name()

            # Step 4: Generate build summary
            await self._generate_build_summary(analysis, build_artifacts, image_name)

            duration = time.time() - start_time

            return BuildResult(
                success=True,
                image_name=image_name,
                output_dir=self.config.output_dir,
                duration=duration,
                framework=analysis["framework"],
                cloud_providers=analysis.get("cloud_providers", []),
                resources=analysis["resources"],
            )

        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"❌ Build failed: {e}")

            return BuildResult(success=False, duration=duration, error=str(e))

    async def _analyze_agent_file(self) -> dict:
        """Analyze the agent file with the native Rust analyzer."""
        if not self.config.agent_file.exists():
            raise FileNotFoundError(f"Agent file not found: {self.config.agent_file}")
        return self._analyze_native()

    def _analyze_native(self) -> dict:
        """Fast path: invoke the Rust analyzer .so and adapt the BuildManifest.

        This is intentionally thin. The Rust analyzer returns a stable
        BuildManifest JSON; we map it to the dict shape downstream
        Dockerfile / k8s / envoy generators have always consumed. Fields
        the native analyzer does not yet compute (cloud_providers,
        process_hierarchy, runtime tool_usage, etc.) default to empty
        — the legacy fallback covers them only if explicitly requested
        with --legacy-analyzer.
        """
        try:
            from hexr._native import default_pack_dirs, hexr_analyzer  # type: ignore[import-not-found]
        except ImportError as e:
            raise RuntimeError(
                "hexr_analyzer native extension not installed. Reinstall the SDK wheel."
            ) from e

        self.logger.info("🦀 Analyzing agent with native Rust analyzer…")
        t0 = time.time()
        framework_pack_dir, pattern_pack_dir = default_pack_dirs()
        # The Rust analyzer expects a directory; point it at the agent file's parent.
        scan_root = self.config.agent_file.parent.resolve()
        raw = hexr_analyzer.analyze_path(
            str(scan_root),
            str(framework_pack_dir),
            str(pattern_pack_dir),
        )
        manifest = json.loads(raw)
        elapsed_ms = (time.time() - t0) * 1000.0

        fw = manifest.get("framework") or {}
        framework_id = fw.get("id") or "bespoke"
        framework_confidence = fw.get("confidence", 0.0)

        # Map native agents → legacy agent dict shape (only `name` is read downstream).
        native_agents = manifest.get("agents") or []
        agents = [
            {"name": a.get("name") or a.get("class_path") or framework_id}
            for a in native_agents
        ]

        # Native llm_clients hint at observability / providers but the build
        # pipeline today only branches on cloud_providers, which the native
        # analyzer does not yet emit. Leave as empty until a follow-up PR
        # adds cloud-resource detection rules to the YAML packs.
        analysis: dict[str, Any] = {
            "framework": framework_id,
            "framework_confidence": framework_confidence,
            "framework_version": None,
            "agents": agents,
            "resources": [],
            "dependencies": [],
            "cloud_providers": [],
            "is_agentic": framework_id != "bespoke",
            "detected_roles": [a["name"] for a in agents if a.get("name")],
            "process_hierarchy": {},
            "coordination_patterns": {},
            "behavioral_analysis": {},
            "tool_usage": {},
            "hexr_agents": [],
            "agent_context": {},
            "source_file": str(self.config.agent_file),
            # Carry the raw native manifest so downstream consumers
            # (provenance, audit pack) can read it without
            # re-invoking the analyzer.
            "_native_manifest": manifest,
        }

        # Cloud-provider detection: text-scan agent source for hexr_tool('<prefix>_*')
        # calls so `_generate_requirements` auto-injects boto3/google-cloud-*/azure-*.
        # Rust analyzer will absorb this in a follow-up; today it doesn't emit tool_usage.
        try:
            src = self.config.agent_file.read_text()
            import re
            _tool_pattern = re.compile(r"""hexr_tool\s*\(\s*['"]([a-z]+)_""")
            _prefix_to_provider = {"aws": "aws", "gcp": "gcp", "azure": "azure"}
            detected: set[str] = set()
            for m in _tool_pattern.finditer(src):
                provider = _prefix_to_provider.get(m.group(1))
                if provider:
                    detected.add(provider)
            if detected:
                analysis["cloud_providers"] = sorted(detected)
                self.logger.info(
                    f"✅ Detected cloud providers via hexr_tool() scan: {analysis['cloud_providers']}"
                )
        except Exception as exc:
            self.logger.warning(f"cloud-provider text-scan skipped: {exc}")

        self.logger.info(
            f"✅ Framework detected: {framework_id} "
            f"(confidence={framework_confidence:.2f}, {elapsed_ms:.1f} ms)"
        )
        self.logger.info(f"✅ Found {len(agents)} agent(s)")
        return analysis

    async def _generate_artifacts(self, analysis: dict) -> dict[str, Any]:
        """Generate Dockerfile and Kubernetes manifests with enterprise PID mapping."""
        self.logger.info("📝 Generating enterprise-grade build artifacts...")
        self.logger.info(f"🔧 Enterprise PID mapping: ENABLED (HOST PID support)")

        # Safety-first cleanup for default artifact dir to avoid stale manifest carryover
        # across different flagship builds (e.g. wrong service names from prior run).
        if self.config.output_dir.exists() and self.config.output_dir.name == ".hexr":
            self.logger.info(
                f"🧹 Cleaning existing build artifacts: {self.config.output_dir}"
            )
            shutil.rmtree(self.config.output_dir)

        # Ensure output directory exists
        self.config.output_dir.mkdir(parents=True, exist_ok=True)

        # Generate Dockerfile with enterprise PID mapping support
        dockerfile_content = await self.dockerfile_generator.generate(
            analysis=analysis, config=self.config
        )

        dockerfile_path = self.config.output_dir / "Dockerfile"
        dockerfile_path.write_text(dockerfile_content)
        self.logger.info(f"✅ Generated enterprise Dockerfile: {dockerfile_path}")

        # Generate Kubernetes manifests with enterprise PID mapping integration
        manifests = await self.k8s_generator.generate(
            analysis=analysis, config=self.config
        )

        # Write manifest files
        manifests_dir = self.config.output_dir / "manifests"
        manifests_dir.mkdir(exist_ok=True)

        for manifest_name, manifest_content in manifests.items():
            manifest_path = manifests_dir / f"{manifest_name}.yaml"
            manifest_path.write_text(manifest_content)
            self.logger.info(f"✅ Generated enterprise manifest: {manifest_path}")

        # Generate ACTUAL per-agent JSON files for Enhanced Attestor
        await self._generate_per_agent_json_files(analysis, manifests_dir)

        # Generate Envoy ConfigMaps for mTLS sidecar configuration
        await self._generate_envoy_configmaps(analysis, manifests_dir)

        # Generate A2A sidecar artifacts if any agents have a2a=True
        await self._generate_a2a_artifacts(analysis, manifests_dir)

        # Generate requirements.txt with enterprise dependencies
        requirements_content = self._generate_requirements(analysis)
        requirements_path = self.config.output_dir / "requirements.txt"
        requirements_path.write_text(requirements_content)

        # Copy necessary files to output directory
        await self._copy_build_dependencies(analysis)

        # Determine if A2A was generated
        hexr_agents = analysis.get("hexr_agents", [])
        has_a2a = any(
            agent.get("a2a") is True
            or agent.get("decorator_args", {}).get("a2a") is True
            for agent in hexr_agents
        )

        return {
            "dockerfile_path": dockerfile_path,
            "manifests_dir": manifests_dir,
            "requirements_path": requirements_path,
            "manifests": manifests,
            "enterprise_features": {
                "host_pid_mapping": True,
                "enhanced_attestor": True,
                "spire_integration": True,
                "a2a_communication": has_a2a,
            },
        }

    def _generate_image_name(self) -> str:
        """Generate Docker image name based on config.

        Canonical form is ``{registry}/{tenant}/{agent}:{target}`` — byte-identical
        to the reference the manifest generator emits (``build/k8s.py``) and to the
        target ``hexr push`` builds. Previously this used ``{tenant}-{agent}`` which
        recorded a reference into build-summary.json that existed in no registry.
        Underscores are normalised to hyphens for the same reason k8s.py does it.
        """
        agent_name = (self.config.name or self.config.agent_file.stem).replace("_", "-")
        image_name = f"{self.config.tenant}/{agent_name}:{self.config.target}"

        if self.config.registry:
            image_name = f"{self.config.registry}/{image_name}"

        return image_name

    # NOTE: Docker image building moved to 'hexr push' command per architecture
    # hexr build: Generate Dockerfile + manifests only
    # hexr push: Build + push Docker image to registry
    # hexr deploy: Deploy to Kubernetes

    async def _copy_build_dependencies(self, analysis: dict):
        """Copy necessary files to output directory for Docker build."""
        # Copy agent script
        agent_script = self.config.agent_file
        if agent_script.exists():
            dest = self.config.output_dir / agent_script.name
            shutil.copy2(agent_script, dest)
            self.logger.info(f"✅ Copied agent script: {agent_script.name}")

        # NOTE: hexr.py stub no longer needed - real SDK installed at runtime via init container
        # SDK is available at /sdk-install via PYTHONPATH

        # Copy enterprise_pid_mapper.py
        pid_mapper_src = Path(__file__).parent.parent / "enterprise_pid_mapper.py"
        if pid_mapper_src.exists():
            dest = self.config.output_dir / "enterprise_pid_mapper.py"
            shutil.copy2(pid_mapper_src, dest)
            self.logger.info(f"✅ Copied enterprise PID mapper")

        # Copy config directory if it exists (for CrewAI, etc.)
        config_dir = agent_script.parent / "config"
        if config_dir.exists() and config_dir.is_dir():
            dest_config = self.config.output_dir / "config"
            if dest_config.exists():
                shutil.rmtree(dest_config)
            shutil.copytree(config_dir, dest_config)
            self.logger.info(
                f"✅ Copied config directory with {len(list(dest_config.glob('*')))} files"
            )

        # Ensure the hexr-sdk manylinux wheel is present for Dockerfile COPY
        await self._ensure_sdk_wheel_in_build_context()

    async def _ensure_sdk_wheel_in_build_context(self):
        """Ensure the hexr-sdk manylinux x86_64 wheel is in the .hexr/ build context.

        The Dockerfile always bakes hexr-sdk from a local wheel
        (COPY hexr_sdk*.whl /tmp/ -> RUN pip install /tmp/hexr_sdk*.whl)
        instead of pulling from a PyPI index at Docker build time.
        This works for all target registries (GKE, EKS, ACR) without
        any PyPI auth configuration inside Docker Build Cloud.

        Resolution order:
          1. Already present in output_dir (idempotent).
          2. Local dist/ wheel from the SDK source tree (fast, no network).
          3. pip download from pypi_url or pypi.hexr.cloud with platform override.
        """
        import sys
        import subprocess

        output_dir = self.config.output_dir

        # 1. Already present
        existing = list(output_dir.glob("hexr_sdk*.whl"))
        if existing:
            self.logger.info(f"✅ hexr-sdk wheel already in build context: {existing[0].name}")
            return

        # 2. Copy from local dist/ (cli/build.py -> cli/ -> hexr/ -> src/ -> python/ -> dist/)
        sdk_python_root = Path(__file__).parent.parent.parent.parent
        dist_dir = sdk_python_root / "dist"
        linux_wheels = sorted(
            dist_dir.glob("hexr_sdk*manylinux*x86_64*.whl"), reverse=True
        )
        if linux_wheels:
            wheel = linux_wheels[0]
            shutil.copy2(wheel, output_dir / wheel.name)
            self.logger.info(f"✅ Copied hexr-sdk wheel from local dist/: {wheel.name}")
            return

        # 3. pip download with platform override
        from hexr.version import __version__
        index_url = self.config.pypi_url or "https://pypi.hexr.cloud/simple/"
        self.logger.info(
            f"📦 Downloading hexr-sdk=={__version__} (manylinux_x86_64) from {index_url}..."
        )
        cmd = [
            sys.executable, "-m", "pip", "download",
            "--index-url", index_url,
            "--extra-index-url", "https://pypi.org/simple/",
            "--platform", "manylinux2014_x86_64",
            "--python-version", "311",
            "--only-binary", ":all:",
            "--no-deps",
            "--dest", str(output_dir),
            f"hexr-sdk=={__version__}",
        ]
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(
                f"Failed to obtain hexr-sdk wheel for Docker image build.\n"
                f"{result.stderr.strip()}\n\n"
                "Run 'uv build' in hexr/sdk/python/ to generate the wheel locally, "
                "or pass --pypi-url with an accessible package index."
            )
        self.logger.info("✅ Downloaded hexr-sdk wheel for Docker image build")

    async def _generate_build_summary(
        self,
        analysis: dict,
        artifacts: dict[str, Any],
        image_name: str | None,
    ):
        """Generate build summary JSON file."""
        summary = {
            "version": "1.0",
            "build_time": time.time(),
            "config": {
                "agent_file": str(self.config.agent_file),
                "tenant": self.config.tenant,
                "target": self.config.target,
                "framework": analysis["framework"],
            },
            "analysis": {
                "framework": analysis["framework"],
                "agents": [agent["name"] for agent in analysis["agents"]],
                "resources": analysis.get("resources", []),
                "cloud_providers": analysis.get("cloud_providers", []),
                "dependencies": analysis.get("dependencies", []),
            },
            "artifacts": {
                "dockerfile": str(artifacts["dockerfile_path"]),
                "manifests_dir": str(artifacts["manifests_dir"]),
                "image_name": image_name,
            },
        }

        summary_path = self.config.output_dir / "build-summary.json"
        summary_path.write_text(json.dumps(summary, indent=2))

        self.logger.info(f"✅ Build summary: {summary_path}")

    async def _generate_per_agent_json_files(self, analysis: dict, manifests_dir: Path):
        """Generate actual per-agent JSON files using detected agent hierarchy."""
        self.logger.info(
            "📋 Generating per-agent JSON files from detected agent hierarchy..."
        )

        # Get coordination pattern instead of framework for directory naming
        framework = analysis["framework"]  # Keep for directory name (class_heavy/etc)
        agent_context = analysis.get("agent_context", {})
        coordination_pattern = agent_context.get("coordination_style", "unknown")  # orchestrated/peer_to_peer/etc
        
        framework_dir = manifests_dir / f"{framework}-agents"
        framework_dir.mkdir(exist_ok=True)

        # Use the actual detected roles from agentic detection
        detected_roles = analysis.get("detected_roles", [])
        process_hierarchy = analysis.get("process_hierarchy", {})

        if not detected_roles:
            self.logger.warning("⚠️  No agent roles detected - using fallback generation")
            self.logger.warning("⚠️  This usually means @hexr_agent decorators were not found in the source file.")
            self.logger.warning(f"⚠️  File analyzed: {self.config.agent_file}")
            self.logger.warning("⚠️  Check that your agents have @hexr.hexr_agent(name='...') decorators")
            detected_roles = ["agent1", "agent2", "agent3"]  # Fallback

        agent_count = 0

        # Get base host PID from enterprise mapper instead of hardcoded values
        try:
            base_host_pid = get_enterprise_host_pid()
            self.logger.info(f"Using enterprise host PID base: {base_host_pid}")

            # Get mapping info for debugging
            mapping_info = get_secure_pid_mapping_info()
            self.logger.info(
                f"PID mapping mode: {mapping_info.get('security_mode', 'unknown')}"
            )

        except Exception as e:
            self.logger.warning(
                f"Could not get enterprise host PID: {e}. Using fallback simulation."
            )
            base_host_pid = 1000  # Fallback for build-time simulation

        # Generate JSON files based on ACTUAL detected agent hierarchy
        for role in detected_roles:
            agent_count += 1
            # Use actual host PIDs instead of hardcoded simulation
            current_pid = base_host_pid + agent_count

            # Determine if this is a main agent or sub-agent from hierarchy
            parent_relationships = process_hierarchy.get(
                "parent_child_relationships", []
            )
            is_main_agent = not any(
                rel["child"] == role for rel in parent_relationships
            )

            if is_main_agent:
                parent_pid = base_host_pid  # Use actual host PID as parent
                role_type = "main"
                self.logger.info(
                    f"Main agent '{role}' -> host_pid={current_pid}, parent_pid={parent_pid}"
                )
            else:
                # Find parent for this sub-agent
                parent_rel = next(
                    (rel for rel in parent_relationships if rel["child"] == role), None
                )
                if parent_rel:
                    parent_pid = parent_rel.get("parent_pid", base_host_pid)
                    role_type = "sub-agent"
                else:
                    parent_pid = base_host_pid
                    role_type = "sub-agent"
                self.logger.info(
                    f"Sub-agent '{role}' -> host_pid={current_pid}, parent_pid={parent_pid}"
                )

            # Extract tools declared for this agent from AST analysis
            agent_tools = []
            resource_mappings = {}

            # Get tool usage for this specific agent/role
            hexr_agents = analysis.get("hexr_agents", [])
            tool_usage = analysis.get("tool_usage", {})

            # Find the hexr_agent data for this role
            agent_hexr_data = None
            for hexr_agent in hexr_agents:
                if hexr_agent.get("role") == role or hexr_agent.get("name") == role:
                    agent_hexr_data = hexr_agent
                    break

            # Get tools used by this agent from AST analysis
            # Look for tools by agent role name AND by method names (e.g., ClassName.method_name)
            agent_tool_calls = []

            if self.config.debug:
                self.logger.debug(
                    f"Looking for tools for agent '{role}' in tool_usage keys: {list(tool_usage.keys())}"
                )

            # Direct role match
            if role in tool_usage:
                agent_tool_calls.extend(tool_usage[role])
                if self.config.debug:
                    self.logger.debug(f"Found direct match for role '{role}'")

            # Use AST analysis to map tools to agents - NO HARDCODED MAPPINGS
            # The AST analysis already detected which classes contain which @hexr_agent decorators
            # We use that information to map tools to agents intelligently

            # Find the agent definition from AST analysis for this role
            role_agent_data = None
            for hexr_agent_data in hexr_agents:
                if (
                    hexr_agent_data.get("role") == role
                    or hexr_agent_data.get("name") == role
                ):
                    role_agent_data = hexr_agent_data
                    break

            # If we found AST data for this agent, use it to map tools
            if role_agent_data and "function_name" in role_agent_data:
                agent_class_name = role_agent_data["function_name"]
                if self.config.debug:
                    self.logger.debug(
                        f"Agent '{role}' maps to class '{agent_class_name}' from AST analysis"
                    )

                # Find all methods belonging to this class that have tools
                for method_name, tool_calls in tool_usage.items():
                    if "." in method_name:
                        class_name = method_name.split(".")[0]
                        if class_name == agent_class_name:
                            agent_tool_calls.extend(tool_calls)
                            if self.config.debug:
                                self.logger.debug(
                                    f"✅ AST-matched method '{method_name}' to agent '{role}' via class '{agent_class_name}'"
                                )
            else:
                # Fallback: Use method names that match the role directly (standalone functions)
                if self.config.debug:
                    self.logger.debug(
                        f"No class mapping found for agent '{role}', checking standalone functions"
                    )
                for method_name, tool_calls in tool_usage.items():
                    if "." not in method_name and method_name == role:
                        agent_tool_calls.extend(tool_calls)
                        if self.config.debug:
                            self.logger.debug(
                                f"✅ Direct function match '{method_name}' to agent '{role}'"
                            )

            # Process found tool calls using intelligent resource mapping
            for tool_info in agent_tool_calls:
                tool_name = tool_info["tool_name"]
                if tool_name not in agent_tools:  # Avoid duplicates
                    agent_tools.append(tool_name)

                    # ENTERPRISE APPROACH: Use declared resources when available, intelligent inference when not
                    tool_resources = []

                    # 1. First priority: Use explicitly declared resources from @hexr_agent decorator
                    if role_agent_data and "decorator_args" in role_agent_data:
                        declared_resources = role_agent_data["decorator_args"].get(
                            "resources", []
                        )
                        if declared_resources:
                            tool_resources = declared_resources
                            if self.config.debug:
                                self.logger.debug(
                                    f"Using declared resources for tool '{tool_name}': {declared_resources}"
                                )

                    # 2. Second priority: Intelligent semantic analysis of tool name
                    if not tool_resources:
                        tool_resources = self._infer_resources_from_tool_name(tool_name)
                        if self.config.debug:
                            self.logger.debug(
                                f"Inferred resources for tool '{tool_name}': {tool_resources}"
                            )

                    # 3. Final fallback: Use analysis-level resources
                    if not tool_resources:
                        tool_resources = analysis.get("resources", [])
                        if self.config.debug:
                            self.logger.debug(
                                f"Using fallback resources for tool '{tool_name}': {tool_resources}"
                            )

                    resource_mappings[tool_name] = tool_resources

            # Generate schema-compliant agent JSON file for Enhanced Attestor consumption
            # Following updated process-context-schema.json structure
            # Simplified JSON format - removed bloat fields for Runtime Engineer
            agent_context = {
                "version": "1.0",
                "timestamp": int(time.time()),
                "pod_uid": "PLACEHOLDER_POD_UID",  # Top-level pod_uid for Runtime Engineer
                "root_pid": parent_pid,
                "process_tree": {
                    str(current_pid): {
                        "pid": current_pid,
                        "ppid": parent_pid,
                        "agent_name": role,  # Use individual agent role instead of script name
                        "role": role,
                        "framework": framework,  # Use detected agentic framework (class_heavy/sequential/etc) not coordination pattern
                        "tenant": self.config.tenant,
                        "spiffe_id": f"spiffe://hexr.internal/{self.config.tenant}/{framework}/{role}/proc-{current_pid}",  # Use framework and role for consistent identity
                        "tools": agent_tools,
                        "resources": resource_mappings if resource_mappings else {},
                        "children": [
                            rel["child_pid"]
                            for rel in parent_relationships
                            if rel.get("parent") == role
                        ],
                    }
                },
                # Internal metadata for hexr deploy coordination (marker file matching)
                "_hexr_internal": {
                    "marker_file_pattern": f"{role}-{{pid}}.marker",
                    "expected_argv_pattern": [
                        "python",
                        f"{self.config.agent_file.name}",
                        f"--agent={role}",
                    ],
                    "environment_markers": {"HEXR_AGENT_ROLE": role},
                },
            }

            # Write agent JSON file with descriptive filename
            agent_file = framework_dir / f"hexr-agent-{current_pid}-{role}.json"
            agent_file.write_text(json.dumps(agent_context, indent=2))
            self.logger.info(f"✅ Generated {role_type} agent JSON: {agent_file}")

        self.logger.info(
            f"✅ Generated {agent_count} JSON files for {len(detected_roles)} detected agents in {framework} framework"
        )

        # Generate coordination-summary.json with framework-level metadata
        self._generate_coordination_summary(
            analysis=analysis,
            framework=framework,
            coordination_pattern=coordination_pattern,  # Pass the detected coordination pattern
            framework_dir=framework_dir,
            agent_count=agent_count,
            detected_roles=detected_roles,
        )

    def _generate_coordination_summary(
        self,
        analysis: dict,
        framework: str,
        coordination_pattern: str,  # orchestrated/peer_to_peer/hierarchical/mixed
        framework_dir: Path,
        agent_count: int,
        detected_roles: list,
    ):
        """
        Generate coordination-summary.json with framework-level coordination metadata.
        This is a SEPARATE file from agent JSON files (not embedded in agent data).
        """
        self.logger.info("📊 Generating coordination-summary.json...")

        # Extract coordination patterns from AST analysis
        agent_context = analysis.get("agent_context", {})
        hierarchy_depth = agent_context.get("hierarchy_depth", 1)
        detected_patterns = agent_context.get("detected_patterns", [])
        
        # Get parent-child relationships from process hierarchy
        process_hierarchy = analysis.get("process_hierarchy", {})
        parent_child_relationships = process_hierarchy.get("parent_child_relationships", [])
        
        coordination_summary = {
            "version": "1.0",
            "timestamp": int(time.time()),
            "framework": coordination_pattern,  # Use detected coordination pattern (orchestrated/peer_to_peer/hierarchical/mixed)
            "coordination_metadata": {
                "coordination_style": coordination_pattern,
                "agent_count": agent_count,
                "hierarchy_depth": hierarchy_depth,
                "detected_patterns": detected_patterns,
                "parent_child_relationships": parent_child_relationships,
                "agent_roles": detected_roles,
            },
            "_description": "Framework-level coordination metadata extracted from AST analysis."
        }
        
        # Write coordination summary to framework directory
        coordination_file = framework_dir / "coordination-summary.json"
        coordination_file.write_text(json.dumps(coordination_summary, indent=2))
        
        self.logger.info(f"✅ Generated coordination summary: {coordination_file}")
        self.logger.info(f"   Coordination style: {coordination_pattern}")
        self.logger.info(f"   Hierarchy depth: {hierarchy_depth}")
        self.logger.info(f"   Detected patterns: {', '.join(detected_patterns) if detected_patterns else 'none'}")

    def _infer_resources_from_tool_name(self, tool_name: str) -> List[str]:
        """
        Intelligently infer cloud resources from tool names using semantic analysis.
        This is enterprise-grade inference, not hardcoded prefixes.
        """
        tool_lower = tool_name.lower()

        # AWS service patterns
        if any(
            aws_pattern in tool_lower
            for aws_pattern in ["s3", "bucket", "storage", "object"]
        ):
            return ["s3:GetObject", "s3:PutObject", "s3:ListBucket"]
        elif any(
            aws_pattern in tool_lower for aws_pattern in ["ec2", "instance", "compute"]
        ):
            return ["ec2:DescribeInstances", "ec2:RunInstances"]
        elif any(aws_pattern in tool_lower for aws_pattern in ["lambda", "function"]):
            return ["lambda:InvokeFunction"]
        elif any(
            aws_pattern in tool_lower for aws_pattern in ["dynamodb", "table", "nosql"]
        ):
            return ["dynamodb:GetItem", "dynamodb:PutItem", "dynamodb:Query"]

        # GCP service patterns
        elif any(
            gcp_pattern in tool_lower
            for gcp_pattern in ["bigquery", "bq", "query", "dataset"]
        ):
            return ["bigquery:jobs.create", "bigquery:datasets.get"]
        elif any(
            gcp_pattern in tool_lower
            for gcp_pattern in ["gcs", "cloud_storage", "gsutil"]
        ):
            return ["storage:objects.get", "storage:objects.create"]
        elif any(
            gcp_pattern in tool_lower for gcp_pattern in ["pubsub", "message", "topic"]
        ):
            return ["pubsub:topics.publish", "pubsub:subscriptions.consume"]

        # Azure service patterns
        elif any(
            azure_pattern in tool_lower for azure_pattern in ["blob", "azure_storage"]
        ):
            return ["storage:blob:read", "storage:blob:write"]
        elif any(
            azure_pattern in tool_lower for azure_pattern in ["cosmosdb", "cosmos"]
        ):
            return ["cosmosdb:read", "cosmosdb:write"]

        # Communication/API patterns
        elif any(
            comm_pattern in tool_lower for comm_pattern in ["slack", "teams", "chat"]
        ):
            return ["communication:message:send"]
        elif any(
            comm_pattern in tool_lower for comm_pattern in ["email", "smtp", "mail"]
        ):
            return ["communication:email:send"]
        elif any(
            comm_pattern in tool_lower for comm_pattern in ["webhook", "api", "rest"]
        ):
            return ["api:call:external"]

        # Data processing patterns
        elif any(
            data_pattern in tool_lower
            for data_pattern in ["analysis", "analytics", "data"]
        ):
            return ["data:read", "data:analyze"]
        elif any(
            data_pattern in tool_lower for data_pattern in ["search", "web", "scraping"]
        ):
            return ["web:search", "web:read"]
        elif any(
            data_pattern in tool_lower
            for data_pattern in ["ai", "ml", "model", "openai", "anthropic"]
        ):
            return ["ai:model:invoke"]

        # Default for unknown tools
        else:
            return ["tool:general:access"]

    def _get_framework_sub_agents(self, framework: str, agent_name: str) -> list[str]:
        """Get expected sub-agent roles based on framework patterns."""
        if framework == "crewai":
            return ["researcher", "analyst", "writer"]
        elif framework == "langchain":
            return ["planner", "executor", "reviewer"]
        elif framework == "openai_swarm":
            return ["coordinator", "specialist"]
        elif framework == "strandsagents":
            return ["controller", "worker"]
        else:
            return ["subprocess"]  # Generic subprocess for custom frameworks

    def _generate_requirements(self, analysis: dict) -> str:
        """Generate optimized requirements.txt based on analysis."""
        requirements = [
            "# Cloud provider dependencies",
        ]

        requirements.append("")
        requirements.append("# AI Framework dependencies")

        # Check the actual agent file for framework imports
        # Uses non-exclusive checks so multiple frameworks can coexist
        agent_file_content = self.config.agent_file.read_text()

        # Map of import patterns -> (packages to add)
        _FRAMEWORK_DEPS = {
            "crewai": ["crewai>=0.1.0", "pydantic>=2.5.0,<2.12.0"],
            "strands": ["strands-agents>=1.17.0"],
            "swarm": ["git+https://github.com/openai/swarm.git"],
            "langchain": ["langchain>=0.1.0", "langchain-community>=0.0.20", "langchain-openai>=0.0.5"],
            "autogen": ["autogen-agentchat>=0.2.0"],
            "openai": ["openai>=1.0.0"],
            "anthropic": ["anthropic>=0.18.0"],
            "google.generativeai": ["google-generativeai>=0.4.0"],
            "cohere": ["cohere>=5.0.0"],
            "mistralai": ["mistralai>=0.1.0"],
        }

        _seen_packages: set[str] = set()
        for module, packages in _FRAMEWORK_DEPS.items():
            if (
                f"from {module}" in agent_file_content
                or f"import {module}" in agent_file_content
            ):
                for pkg in packages:
                    if pkg not in _seen_packages:
                        requirements.append(pkg)
                        _seen_packages.add(pkg)

        # Add cloud provider SDKs based on detected usage
        for provider in analysis.get("cloud_providers", []):
            if provider == "aws":
                requirements.append("boto3>=1.34.0")
            elif provider == "gcp":
                requirements.extend(
                    [
                        "google-cloud-storage>=2.10.0",
                        "google-cloud-bigquery>=3.11.0",
                    ]
                )
            elif provider == "azure":
                requirements.extend(
                    [
                        "azure-identity>=1.15.0",
                        "azure-storage-blob>=12.19.0",
                    ]
                )

        # Detect cloud SDKs from hexr_tool() calls in AST analysis
        # hexr_tool('aws_s3') → boto3, hexr_tool('gcp_storage') → google-cloud-storage, etc.
        _TOOL_TO_PACKAGES = {
            "aws": ["boto3>=1.34.0"],
            "gcp": ["google-cloud-storage>=2.10.0", "google-cloud-bigquery>=3.11.0"],
            "azure": ["azure-identity>=1.15.0", "azure-storage-blob>=12.19.0"],
        }
        tool_usage = analysis.get("tool_usage", {})
        _detected_providers: set[str] = set()
        for _func_name, tool_calls in tool_usage.items():
            for tool_call in tool_calls:
                tool_name = tool_call.get("tool_name", "")
                for prefix in _TOOL_TO_PACKAGES:
                    if tool_name.startswith(f"{prefix}_"):
                        _detected_providers.add(prefix)
        for provider in _detected_providers:
            for pkg in _TOOL_TO_PACKAGES[provider]:
                if pkg not in _seen_packages:
                    requirements.append(pkg)
                    _seen_packages.add(pkg)
                    self.logger.info(f"✅ Auto-detected hexr_tool → {pkg}")

        requirements.append("")
        requirements.append("# System dependencies")
        requirements.extend(
            [
                "psutil>=5.9.0",
                "contextvars-extras>=0.1.0",
            ]
        )



        # NOTE: hexr-sdk is NOT added to requirements.txt.
        # The wheel is baked directly into the Docker image by _ensure_sdk_wheel_in_build_context()
        # and installed via the Dockerfile's COPY + pip install step.
        # This avoids any PyPI auth configuration inside Docker Build Cloud.

        # Add other detected dependencies
        requirements.extend(analysis.get("dependencies", []))

        # Filter out comments and empty lines for sorting, then reconstruct
        comment_lines = [
            line for line in requirements if line.startswith("#") or line == ""
        ]
        package_lines = [
            line for line in requirements if not line.startswith("#") and line != ""
        ]

        result = []
        result.append("# Cloud provider dependencies")
        cloud_packages = [
            line
            for line in package_lines
            if any(cloud in line for cloud in ["azure", "boto3", "google"])
        ]
        result.extend(sorted(cloud_packages))

        result.append("")
        result.append("# AI Framework dependencies")
        _fw_keywords = [
            "crewai", "langchain", "autogen", "openai", "strands",
            "anthropic", "generativeai", "cohere", "mistralai", "swarm",
        ]
        framework_packages = [
            line
            for line in package_lines
            if any(fw in line for fw in _fw_keywords)
        ]
        result.extend(sorted(framework_packages))

        result.append("")
        result.append("# System dependencies")
        system_packages = [
            line
            for line in package_lines
            if line not in cloud_packages and line not in framework_packages
        ]
        result.extend(sorted(system_packages))

        # NOTE: hexr-sdk is installed at runtime via init container
        # This allows Docker Build Cloud to complete without accessing private PyPI

        return "\n".join(result) + "\n"

    async def _generate_envoy_configmaps(self, analysis: dict, manifests_dir: Path):
        """
        Generate single Envoy ConfigMap for the agent pod.
        
        Creates ONE ConfigMap with Envoy bootstrap configuration for the
        shared Envoy mTLS sidecar that routes all agent requests through
        mTLS to credential-injector.
        
        Architecture: ONE Envoy sidecar per pod (shared by all agents in pod)
        """
        self.logger.info("🔧 Generating Envoy ConfigMap for agent pod...")
        
        # Get pod name from analysis - use source file name as pod identifier
        source_file = analysis.get("source_file", "hexr-agent")
        if source_file:
            # Extract filename without extension as pod name
            from pathlib import Path
            pod_name = Path(source_file).stem
        else:
            pod_name = "hexr-agent"
        
        # Sanitize for Kubernetes names
        k8s_pod_name = pod_name.replace("_", "-")
        
        # Generate single Envoy ConfigMap for the pod
        try:
            configmap_yaml = self.envoy_generator.generate_configmap_yaml(
                agent_name=k8s_pod_name,
                tenant=self.config.tenant,
                namespace=f"tenant-{self.config.tenant}",
                pod_uid_prefix="{{POD_UID_PREFIX}}",  # Template for runtime substitution
                admin_port=9901,
                listener_port=15001  # mTLS outbound port
            )
            
            # Write single ConfigMap for the agent pod
            configmap_file = manifests_dir / "agent-envoy-sidecar-config.yaml"
            configmap_file.write_text(configmap_yaml)
            
            self.logger.info(f"✅ Generated Envoy ConfigMap: {configmap_file.name}")
            
        except Exception as e:
            self.logger.error(f"Failed to generate Envoy ConfigMap: {e}")
            raise
        
        self.logger.info(
            f"✅ Generated 1 Envoy ConfigMap for agent pod (shared by all agents)"
        )

    async def _generate_a2a_artifacts(self, analysis: dict, manifests_dir: Path):
        """
        Generate A2A sidecar artifacts when agents have a2a=True.

        Produces:
        - Agent Card ConfigMap (/.well-known/agent.json)
        - A2A Service (ClusterIP for inbound A2A traffic)
        - A2A sidecar container YAML snippet
        - Envoy inbound listener for A2A port
        - Envoy cluster for local A2A sidecar
        """
        # Check if any hexr_agents have a2a enabled (populated for framework-aware builds).
        # For bespoke/unknown frameworks the list is always empty — fall through to AST scan.
        hexr_agents = analysis.get("hexr_agents", [])
        a2a_agents = [
            agent for agent in hexr_agents
            if agent.get("a2a") is True
            or agent.get("decorator_args", {}).get("a2a") is True
        ]

        if hexr_agents and not a2a_agents:
            # Framework-aware analysis ran but found no a2a=True agents — definitive skip.
            self.logger.info("ℹ️  No A2A-enabled agents found — skipping A2A artifacts")
            return

        self.logger.info(
            f"🔗 Generating A2A artifacts for {len(a2a_agents) if a2a_agents else 'source-detected'} A2A-enabled agent(s)..."
        )

        try:
            from hexr.build.a2a import (
                extract_a2a_metadata,
                generate_agent_card_json,
                generate_a2a_configmap,
                generate_a2a_service,
                generate_a2a_sidecar_container,
                generate_a2a_volumes,
                generate_a2a_envoy_inbound_listener,
                generate_a2a_envoy_cluster,
            )
        except ImportError:
            self.logger.warning("⚠️  hexr.build.a2a not available — skipping A2A artifacts")
            return

        source_file = analysis.get("source_file", str(self.config.agent_file))
        namespace = f"tenant-{self.config.tenant}"

        # Extract A2A metadata from the source file
        meta = extract_a2a_metadata(Path(source_file))

        if not meta.enabled:
            self.logger.info("ℹ️  A2A not enabled in source — skipping A2A artifacts")
            return

        # Derive agent name from source file
        agent_name = Path(source_file).stem.replace("_", "-")

        # Generate Agent Card JSON
        card_json = generate_agent_card_json(
            agent_name=agent_name,
            tenant=self.config.tenant,
            namespace=namespace,
            meta=meta,
        )
        card_path = manifests_dir / "a2a-agent-card.json"
        card_path.write_text(card_json)
        self.logger.info(f"✅ Generated Agent Card: {card_path.name}")

        # Generate Agent Card ConfigMap
        configmap_yaml = generate_a2a_configmap(
            agent_name=agent_name,
            namespace=namespace,
            card_json=card_json,
        )
        configmap_path = manifests_dir / "a2a-agent-card-configmap.yaml"
        configmap_path.write_text(configmap_yaml)
        self.logger.info(f"✅ Generated Agent Card ConfigMap: {configmap_path.name}")

        # Generate A2A Service
        service_yaml = generate_a2a_service(
            agent_name=agent_name,
            tenant=self.config.tenant,
            namespace=namespace,
        )
        service_path = manifests_dir / "a2a-service.yaml"
        service_path.write_text(service_yaml)
        self.logger.info(f"✅ Generated A2A Service: {service_path.name}")

        # Generate A2A sidecar container snippet
        # Use the build registry for the A2A sidecar image
        a2a_registry = self.config.registry or "us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images"
        a2a_sidecar_image = f"{a2a_registry}/hexr-a2a-sidecar:v1.0.0"
        sidecar_yaml = generate_a2a_sidecar_container(
            agent_name=agent_name, image=a2a_sidecar_image
        )
        sidecar_path = manifests_dir / "a2a-sidecar-container.yaml"
        sidecar_path.write_text(sidecar_yaml)
        self.logger.info(f"✅ Generated A2A sidecar container: {sidecar_path.name}")

        # Generate A2A volumes snippet
        volumes_yaml = generate_a2a_volumes(agent_name=agent_name)
        volumes_path = manifests_dir / "a2a-volumes.yaml"
        volumes_path.write_text(volumes_yaml)
        self.logger.info(f"✅ Generated A2A volumes: {volumes_path.name}")

        # Generate Envoy A2A inbound listener
        listener_yaml = generate_a2a_envoy_inbound_listener(
            agent_name=agent_name,
        )
        listener_path = manifests_dir / "a2a-envoy-inbound-listener.yaml"
        listener_path.write_text(listener_yaml)
        self.logger.info(f"✅ Generated Envoy A2A listener: {listener_path.name}")

        # Generate Envoy A2A cluster
        cluster_yaml = generate_a2a_envoy_cluster()
        cluster_path = manifests_dir / "a2a-envoy-cluster.yaml"
        cluster_path.write_text(cluster_yaml)
        self.logger.info(f"✅ Generated Envoy A2A cluster: {cluster_path.name}")

        self.logger.info(
            f"✅ A2A artifacts complete — agent '{agent_name}' is A2A-discoverable"
        )

        # Regenerate Envoy ConfigMap with mTLS A2A inbound listener (port 8443).
        # The base configmap (generated earlier) only has the outbound mTLS proxy
        # to credential-injector. For cross-cluster A2A we need an inbound mTLS
        # listener so remote agents on other clusters can call this agent directly.
        self.logger.info("🔧 Regenerating Envoy ConfigMap with A2A mTLS inbound listener...")
        try:
            a2a_configmap_yaml = self.envoy_generator.generate_configmap_yaml(
                agent_name=agent_name,
                tenant=self.config.tenant,
                namespace=f"tenant-{self.config.tenant}",
                pod_uid_prefix="{{POD_UID_PREFIX}}",
                admin_port=9901,
                listener_port=15001,
                include_a2a_inbound=True,
            )
            configmap_file = manifests_dir / "agent-envoy-sidecar-config.yaml"
            configmap_file.write_text(a2a_configmap_yaml)
            self.logger.info("✅ Envoy ConfigMap updated with A2A mTLS inbound listener (port 8443)")
        except Exception as e:
            self.logger.error(f"Failed to regenerate A2A Envoy ConfigMap: {e}")
            raise


async def build_command(
    agent_file: Path,
    tenant: str,
    name: str | None,
    target: str,
    registry: str | None,
    pypi_url: str | None,
    python_version: str,
    base_image: str,
    multi_cloud: list[str] | None,
    subprocess_support: bool,
    security_scan: bool,
    optimization_level: str,
    output_dir: Path,
    dockerfile_only: bool,
    dry_run: bool,
    verbose: bool,
    debug: bool,
    mock_mode: bool = True,
    trust_domain: str = "demo.hexr.dev",
    gcp_service_account: str | None = None,
    route: str = "kubernetes",
) -> BuildResult:
    """Execute hexr build command."""

    config = BuildConfig(
        agent_file=agent_file,
        tenant=tenant,
        name=name,
        target=target,
        framework="auto",  # Always auto-detect coordination pattern
        registry=registry,
        pypi_url=pypi_url,
        python_version=python_version,
        base_image=base_image,
        multi_cloud=multi_cloud,
        subprocess_support=subprocess_support,
        security_scan=security_scan,
        optimization_level=optimization_level,
        output_dir=output_dir,
        dockerfile_only=dockerfile_only,
        dry_run=dry_run,
        verbose=verbose,
        debug=debug,
        mock_mode=mock_mode,
        trust_domain=trust_domain,
        gcp_service_account=gcp_service_account,
        route=route,
    )

    builder = HexrBuilder(config)
    return await builder.build()
