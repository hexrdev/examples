"""
Interactive cluster selection and guidance for hexr deploy.
"""

import sys
from typing import List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, IntPrompt, Prompt
from rich.table import Table

from .cluster_types import ClusterInfo, ClusterResources

console = Console()


class ClusterSelector:
    """Interactive cluster selection with guidance."""

    def __init__(self):
        self.console = console

    def display_cluster_analysis(
        self,
        clusters: List[ClusterInfo],
        current_cluster: Optional[str],
    ):
        """Display comprehensive cluster analysis."""
        # Show current context
        if current_cluster:
            self.console.print(
                f"\n🎯 [cyan]Current Context:[/cyan] {current_cluster}",
                highlight=False,
            )
        else:
            self.console.print(
                "\n⚠️ [yellow]No current Kubernetes context set[/yellow]",
                highlight=False,
            )

        self.console.print(f"\n[cyan]📊 Available Kubernetes Clusters:[/cyan]")

    def display_available_clusters(self, clusters: List[ClusterInfo]) -> Table:
        """Display all available clusters in a table."""
        table = Table(title="🎛️  Available Kubernetes Clusters")
        table.add_column("#", style="cyan", width=3)
        table.add_column("Context Name", style="bold")
        table.add_column("Cluster", style="dim")
        table.add_column("Status", style="yellow")
        table.add_column("Notes", style="dim")

        for idx, cluster in enumerate(clusters, 1):
            # Format cluster endpoint (truncate if too long)
            cluster_endpoint = cluster.cluster
            if len(cluster_endpoint) > 40:
                cluster_endpoint = cluster_endpoint[:37] + "..."

            # Status emoji
            status_display = "✅ Reachable" if cluster.is_reachable else "❌ Unreachable"

            # Notes
            notes = []
            if cluster.is_current:
                notes.append("⭐ Current")
            if not cluster.is_reachable:
                notes.append("⚠️ Check connectivity")

            notes_str = " ".join(notes) if notes else ""

            table.add_row(
                str(idx),
                cluster.name,
                cluster_endpoint,
                status_display,
                notes_str,
            )

        self.console.print(table)
        return table

    def display_cluster_resources(
        self, cluster_name: str, resources: ClusterResources
    ):
        """Display cluster resource information."""
        self.console.print(
            f"\n[cyan]📦 Cluster Resources:[/cyan] {cluster_name}",
            highlight=False,
        )

        resource_table = Table(show_header=False, box=None, padding=(0, 2))
        resource_table.add_column("Property", style="dim")
        resource_table.add_column("Value")

        resource_table.add_row("Nodes", f"{resources.nodes}")
        resource_table.add_row("Total CPU", resources.total_cpu)
        resource_table.add_row("Total Memory", resources.total_memory)
        resource_table.add_row("Allocatable CPU", resources.allocatable_cpu)
        resource_table.add_row("Allocatable Memory", resources.allocatable_memory)
        resource_table.add_row("Kubernetes Version", resources.kubernetes_version)

        self.console.print(resource_table)

    def prompt_cluster_selection(
        self, clusters: List[ClusterInfo], recommended_cluster: Optional[str] = None
    ) -> ClusterInfo:
        """Interactive cluster selection with validation."""
        if not clusters:
            raise ValueError("No clusters available for selection")

        # Find recommended cluster index
        recommended_idx = None
        if recommended_cluster:
            for idx, cluster in enumerate(clusters, 1):
                if cluster.name == recommended_cluster:
                    recommended_idx = idx
                    break

        # Prompt for selection
        if recommended_idx:
            self.console.print(
                f"\n💡 Recommended: Cluster #{recommended_idx} ({recommended_cluster})",
                style="green",
            )

        while True:
            choice = Prompt.ask(
                "\n[bold]Select cluster number (or press Enter for recommended)[/bold]",
                default=str(recommended_idx) if recommended_idx else "1",
            )

            try:
                cluster_idx = int(choice)
                if 1 <= cluster_idx <= len(clusters):
                    selected_cluster = clusters[cluster_idx - 1]

                    # Warn if cluster is unreachable
                    if not selected_cluster.is_reachable:
                        self.console.print(
                            f"\n⚠️ [yellow]Warning: Cluster '{selected_cluster.name}' appears unreachable[/yellow]"
                        )
                        if not Confirm.ask("Continue anyway?"):
                            continue

                    return selected_cluster
                else:
                    self.console.print(
                        f"[red]Invalid choice. Please select 1-{len(clusters)}[/red]"
                    )
            except ValueError:
                self.console.print("[red]Invalid input. Please enter a number.[/red]")

    def display_final_choice(self, cluster: ClusterInfo, namespace: str):
        """Display final deployment configuration."""
        self.console.print("\n[bold green]✅ Deployment Configuration:[/bold green]")

        config_table = Table(show_header=False, box=None, padding=(0, 2))
        config_table.add_column("Property", style="cyan")
        config_table.add_column("Value", style="bold")

        config_table.add_row("Cluster Context", cluster.name)
        config_table.add_row("Cluster Endpoint", cluster.cluster)
        config_table.add_row("Namespace", namespace)

        self.console.print(config_table)

    def prompt_continue_deployment(self) -> bool:
        """Ask user if they want to continue with deployment."""
        return Confirm.ask("\n[bold]Proceed with deployment?[/bold]", default=True)

    def display_no_clusters_message(self):
        """Display message when no clusters are available."""
        panel = Panel(
            "[yellow]No Kubernetes clusters found![/yellow]\n\n"
            "Please configure kubectl with at least one cluster context.\n\n"
            "To add a cluster:\n"
            "  • Cloud providers: Use provider CLI (doctl, gcloud, az, aws)\n"
            "  • Minikube: minikube start\n"
            "  • Kind: kind create cluster\n"
            "  • Manual: kubectl config set-context <name> --cluster=<cluster>",
            title="❌ No Clusters Available",
            border_style="red",
        )
        self.console.print(panel)
