"""
Cloud configuration management for Hexr CLI.

Manages ~/.hexr/config.json for API key storage and cloud endpoint configuration.
Provides authenticated HTTP client for cloud API calls.
"""

import json
import logging
import os
import stat
from dataclasses import asdict, dataclass, field
from pathlib import Path
from urllib.parse import urlparse

import httpx

# Suppress httpx info-level request logging
logging.getLogger("httpx").setLevel(logging.WARNING)


HEXR_CONFIG_DIR = Path.home() / ".hexr"
HEXR_CONFIG_FILE = HEXR_CONFIG_DIR / "config.json"
API_KEY_PREFIX = "hxr_live_"
DEFAULT_CLOUD_URL = "https://api.hexr.cloud"


@dataclass
class CloudConfig:
    """Cloud platform configuration stored in ~/.hexr/config.json."""

    api_key: str = ""
    cloud_url: str = DEFAULT_CLOUD_URL
    tenant_id: str = ""
    tenant_name: str = ""
    # License tier. Drives gated rendering decisions (e.g. the audit-pack PDF
    # watermark in src/hexr/cli/audit_pack.py). Empty / unrecognised values
    # are treated as "evaluation" by callers so the gate fails closed.
    tier: str = ""
    # Cluster registration (written by `hexr cluster register`).
    cluster_id: str = ""
    license_id: str = ""
    license_jwt: str = ""

    @classmethod
    def load(cls) -> "CloudConfig":
        """Load config from ~/.hexr/config.json. Returns empty config if not found."""
        if not HEXR_CONFIG_FILE.exists():
            return cls()
        try:
            data = json.loads(HEXR_CONFIG_FILE.read_text(encoding="utf-8"))
            return cls(
                api_key=data.get("api_key", ""),
                cloud_url=data.get("cloud_url", DEFAULT_CLOUD_URL),
                tenant_id=data.get("tenant_id", ""),
                tenant_name=data.get("tenant_name", ""),
                tier=data.get("tier", ""),
                cluster_id=data.get("cluster_id", ""),
                license_id=data.get("license_id", ""),
                license_jwt=data.get("license_jwt", ""),
            )
        except (json.JSONDecodeError, OSError):
            return cls()

    def save(self) -> None:
        """Save config to ~/.hexr/config.json with restricted permissions (0600)."""
        HEXR_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        # Write config
        HEXR_CONFIG_FILE.write_text(
            json.dumps(asdict(self), indent=2) + "\n",
            encoding="utf-8",
        )
        # Restrict permissions: owner read/write only (SOC2: protect credentials at rest)
        HEXR_CONFIG_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)

    @property
    def is_authenticated(self) -> bool:
        """Check if a valid API key is configured."""
        return bool(self.api_key) and self.api_key.startswith(API_KEY_PREFIX)


def validate_api_key_format(key: str) -> bool:
    """Validate API key format: hxr_live_ prefix + 64 hex characters."""
    if not key.startswith(API_KEY_PREFIX):
        return False
    hex_part = key[len(API_KEY_PREFIX):]
    if len(hex_part) != 64:
        return False
    try:
        int(hex_part, 16)
        return True
    except ValueError:
        return False


def validate_cloud_url(url: str) -> bool:
    """Validate cloud URL is a valid HTTPS endpoint."""
    parsed = urlparse(url)
    return parsed.scheme == "https" and bool(parsed.netloc)


def get_cloud_client(config: CloudConfig | None = None, verify: bool = True) -> httpx.Client:
    """Create an authenticated HTTP client for the cloud API."""
    if config is None:
        config = CloudConfig.load()
    if not config.is_authenticated:
        raise RuntimeError(
            "Not authenticated. Run 'hexr login --key <api_key>' first."
        )
    return httpx.Client(
        base_url=config.cloud_url,
        headers={
            "Authorization": f"Bearer {config.api_key}",
            "User-Agent": "hexr-cli",
        },
        timeout=30.0,
        verify=verify,
    )


def verify_api_key(cloud_url: str, api_key: str) -> dict:
    """
    Verify an API key against the cloud API.

    Returns the verification response dict on success.
    Raises RuntimeError on failure.
    """
    with httpx.Client(timeout=15.0) as client:
        resp = client.get(
            f"{cloud_url}/v1/auth/verify",
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": "hexr-cli",
            },
        )
        if resp.status_code == 200:
            body = resp.json()
            # API wraps response under "data" key
            return body.get("data", body)
        elif resp.status_code == 401:
            raise RuntimeError("Invalid API key. Check your key and try again.")
        elif resp.status_code == 403:
            raise RuntimeError("API key is disabled or revoked.")
        else:
            raise RuntimeError(
                f"Cloud API returned unexpected status {resp.status_code}: {resp.text}"
            )
