"""
Hexr Audit Command Implementation

Supply chain and configuration auditing for Hexr agents:
  hexr audit                      — Full audit report (vulnerabilities + SBOM + drift)
  hexr audit --export sbom.json   — CycloneDX SBOM export
  hexr audit --verify             — Verify deployed state matches generated manifests
  hexr audit --fix                — Auto-remediate fixable vulnerabilities

Wraps pip-audit (PyPA/Google, Apache-2.0) for vulnerability scanning and
generates CycloneDX SBOMs from the Python environment. Manifest drift
detection compares kubectl live state against .hexr/ generated manifests.

All operations emit OTel spans under hexr.audit.* for observability.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

import click
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hexr.utils.simple_logging import get_logger
from hexr.cli.cloud_config import CloudConfig
from hexr.evidence import post_evidence as _post_dp_evidence

logger = get_logger("hexr.audit")
console = Console()

# ---------------------------------------------------------------------------
# OTel helpers — graceful no-op when OTel is not installed
# ---------------------------------------------------------------------------
try:
    from opentelemetry import trace
    from opentelemetry.trace import StatusCode, SpanKind

    _tracer: trace.Tracer | None = trace.get_tracer("hexr.audit", "0.1.0")
except ImportError:
    _tracer = None
    StatusCode = None  # type: ignore[assignment,misc]


class _NoOpSpan:
    """Minimal context-manager stand-in when OTel is unavailable."""

    def set_attribute(self, key: str, value: Any) -> None: ...
    def set_status(self, *a: Any, **kw: Any) -> None: ...
    def record_exception(self, exc: BaseException) -> None: ...
    def __enter__(self) -> "_NoOpSpan":
        return self
    def __exit__(self, *a: Any) -> None: ...


def _start_span(name: str, **kwargs: Any):
    if _tracer is not None:
        return _tracer.start_as_current_span(name, **kwargs)
    return _NoOpSpan()


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    NONE = "none"


@dataclass
class Vulnerability:
    package: str
    installed_version: str
    vulnerability_id: str
    fix_version: str | None
    description: str
    aliases: list[str] = field(default_factory=list)

    @property
    def is_fixable(self) -> bool:
        return self.fix_version is not None


@dataclass
class AuditResult:
    vulnerabilities: list[Vulnerability] = field(default_factory=list)
    sbom_path: Path | None = None
    drift_items: list[dict[str, Any]] = field(default_factory=list)
    scan_duration: float = 0.0
    error: str | None = None

    @property
    def total_vulns(self) -> int:
        return len(self.vulnerabilities)

    @property
    def fixable_vulns(self) -> int:
        return sum(1 for v in self.vulnerabilities if v.is_fixable)

    @property
    def has_drift(self) -> bool:
        return len(self.drift_items) > 0


# ---------------------------------------------------------------------------
# Core audit engine
# ---------------------------------------------------------------------------

class AuditEngine:
    """Orchestrates vulnerability scanning, SBOM generation, and manifest drift detection."""

    def __init__(
        self,
        output_dir: Path,
        requirements: Path | None = None,
        hexr_dir: Path | None = None,
        namespace: str | None = None,
        verbose: bool = False,
    ):
        self.output_dir = output_dir
        self.requirements = requirements
        self.hexr_dir = hexr_dir or Path(".hexr")
        self.namespace = namespace
        self.verbose = verbose

    # -- Vulnerability scanning via pip-audit --------------------------------

    def scan_vulnerabilities(self) -> list[Vulnerability]:
        """Run pip-audit and return discovered vulnerabilities."""
        with _start_span("hexr.audit.vulnerability_scan") as span:
            start = time.monotonic()
            cmd = self._build_pip_audit_cmd()

            if self.verbose:
                console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=300,
                )
            except FileNotFoundError:
                msg = (
                    "pip-audit is not installed. "
                    "Install it with: pip install pip-audit"
                )
                logger.error(msg)
                if span and StatusCode:
                    span.set_status(StatusCode.ERROR, msg)
                raise SystemExit(msg)
            except subprocess.TimeoutExpired:
                msg = "pip-audit timed out after 300 seconds"
                logger.error(msg)
                if span and StatusCode:
                    span.set_status(StatusCode.ERROR, msg)
                raise SystemExit(msg)

            if result.returncode != 0 and not result.stdout.strip():
                # pip-audit failed without producing JSON — warn
                stderr_hint = (result.stderr or "").strip().splitlines()
                hint = stderr_hint[-1] if stderr_hint else "unknown error"
                logger.warning(
                    "pip-audit exited with code %d: %s",
                    result.returncode,
                    hint,
                )
                if self.verbose:
                    console.print(
                        f"[yellow]⚠ pip-audit returned no output "
                        f"(exit {result.returncode}): {hint}[/yellow]"
                    )

            vulns = self._parse_pip_audit_json(result.stdout)
            elapsed = time.monotonic() - start

            if span:
                span.set_attribute("hexr.audit.vuln_count", len(vulns))
                span.set_attribute("hexr.audit.fixable_count", sum(1 for v in vulns if v.is_fixable))
                span.set_attribute("hexr.audit.scan_duration_s", round(elapsed, 2))

            return vulns

    def _build_pip_audit_cmd(self) -> list[str]:
        cmd = [
            sys.executable, "-m", "pip_audit",
            "--format", "json",
            "--output", "-",         # stdout
            "--progress-spinner", "off",
        ]
        if self.requirements:
            cmd.extend(["--requirement", str(self.requirements)])
        return cmd

    def _parse_pip_audit_json(self, stdout: str) -> list[Vulnerability]:
        """Parse pip-audit JSON output into Vulnerability objects."""
        if not stdout.strip():
            return []

        try:
            data = json.loads(stdout)
        except json.JSONDecodeError:
            logger.warning("Could not parse pip-audit output as JSON")
            return []

        vulns: list[Vulnerability] = []

        # pip-audit JSON format: {"dependencies": [{"name": ..., "version": ..., "vulns": [...]}]}
        for dep in data.get("dependencies", []):
            for vuln in dep.get("vulns", []):
                vulns.append(
                    Vulnerability(
                        package=dep["name"],
                        installed_version=dep["version"],
                        vulnerability_id=vuln.get("id", "UNKNOWN"),
                        fix_version=vuln.get("fix_versions", [None])[0] if vuln.get("fix_versions") else None,
                        description=vuln.get("description", ""),
                        aliases=vuln.get("aliases", []),
                    )
                )

        return vulns

    # -- SBOM generation (CycloneDX) ----------------------------------------

    def generate_sbom(self, export_path: Path | None = None) -> Path:
        """Generate a CycloneDX SBOM from the current Python environment."""
        with _start_span("hexr.audit.sbom_generate") as span:
            out = export_path or (self.output_dir / "sbom.json")
            out.parent.mkdir(parents=True, exist_ok=True)

            cmd = self._build_sbom_cmd(out)

            if self.verbose:
                console.print(f"[dim]Running: {' '.join(cmd)}[/dim]")

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=120,
                )
            except FileNotFoundError:
                msg = (
                    "cyclonedx-py is not installed. "
                    "Install it with: pip install cyclonedx-bom"
                )
                logger.error(msg)
                if span and StatusCode:
                    span.set_status(StatusCode.ERROR, msg)
                raise SystemExit(msg)

            if result.returncode != 0:
                # Fall back to pip-audit CycloneDX output
                return self._sbom_via_pip_audit(out, span)

            if span:
                span.set_attribute("hexr.audit.sbom_path", str(out))
                span.set_attribute("hexr.audit.sbom_format", "CycloneDX")

            return out

    def _build_sbom_cmd(self, out: Path) -> list[str]:
        cmd = [
            sys.executable, "-m", "cyclonedx_py",
            "environment",
            "--output-format", "json",
            "--outfile", str(out),
        ]
        if self.requirements:
            cmd = [
                sys.executable, "-m", "cyclonedx_py",
                "requirements",
                str(self.requirements),
                "--output-format", "json",
                "--outfile", str(out),
            ]
        return cmd

    def _sbom_via_pip_audit(self, out: Path, span: Any) -> Path:
        """Fallback: use pip-audit --format=cyclonedx-json if cyclonedx-py is missing."""
        cmd = [
            sys.executable, "-m", "pip_audit",
            "--format", "cyclonedx-json",
            "--output", str(out),
            "--progress-spinner", "off",
        ]
        if self.requirements:
            cmd.extend(["--requirement", str(self.requirements)])

        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
        except FileNotFoundError:
            msg = "Neither cyclonedx-py nor pip-audit available for SBOM generation"
            raise SystemExit(msg)

        if result.returncode != 0 and not out.exists():
            logger.warning(f"pip-audit SBOM fallback returned non-zero: {result.stderr}")
            # pip-audit exits non-zero when vulns exist but still writes the file
            if not out.exists():
                raise SystemExit(f"SBOM generation failed: {result.stderr}")

        if span:
            span.set_attribute("hexr.audit.sbom_path", str(out))
            span.set_attribute("hexr.audit.sbom_format", "CycloneDX")
            span.set_attribute("hexr.audit.sbom_source", "pip-audit-fallback")

        return out

    # -- Manifest drift detection -------------------------------------------

    def verify_deployed_state(self) -> list[dict[str, Any]]:
        """Compare deployed K8s resources against generated manifests in .hexr/."""
        with _start_span("hexr.audit.verify_drift") as span:
            manifests_dir = self.hexr_dir / "manifests"
            if not manifests_dir.exists():
                msg = f"No manifests found at {manifests_dir}. Run 'hexr build' first."
                logger.warning(msg)
                if span and StatusCode:
                    span.set_status(StatusCode.ERROR, msg)
                return [{"kind": "Error", "name": "no-manifests", "drift": msg}]

            drifts: list[dict[str, Any]] = []
            yaml_files = sorted(manifests_dir.glob("*.yaml"))

            if not yaml_files:
                return [{"kind": "Error", "name": "no-manifests", "drift": "No YAML files in manifests/"}]

            for manifest_file in yaml_files:
                file_drifts = self._check_manifest_drift(manifest_file)
                drifts.extend(file_drifts)

            if span:
                span.set_attribute("hexr.audit.manifests_checked", len(yaml_files))
                span.set_attribute("hexr.audit.drift_count", len(drifts))

            return drifts

    def _check_manifest_drift(self, manifest_file: Path) -> list[dict[str, Any]]:
        """Compare a single manifest file against the live cluster state."""
        drifts: list[dict[str, Any]] = []

        try:
            with open(manifest_file) as f:
                docs = list(yaml.safe_load_all(f))
        except Exception as e:
            return [{"kind": "Error", "name": str(manifest_file.name), "drift": f"Parse error: {e}"}]

        for doc in docs:
            if doc is None:
                continue
            kind = doc.get("kind", "Unknown")
            metadata = doc.get("metadata", {})
            name = metadata.get("name", "unknown")
            ns = metadata.get("namespace", self.namespace or "default")

            # Fetch live resource
            live_json = self._kubectl_get(kind, name, ns)
            if live_json is None:
                drifts.append({
                    "kind": kind,
                    "name": name,
                    "namespace": ns,
                    "drift": "NOT DEPLOYED — manifest exists but resource not found in cluster",
                    "file": str(manifest_file.name),
                })
                continue

            # Compare key fields
            field_drifts = self._compare_resource(doc, live_json, kind, name, ns, manifest_file.name)
            drifts.extend(field_drifts)

        return drifts

    def _kubectl_get(self, kind: str, name: str, namespace: str) -> dict | None:
        """Fetch a live K8s resource as JSON. Returns None if not found."""
        try:
            result = subprocess.run(
                ["kubectl", "get", kind.lower(), name, "-n", namespace, "-o", "json"],
                capture_output=True,
                text=True,
                timeout=30,
            )
            if result.returncode != 0:
                return None
            return json.loads(result.stdout)
        except (subprocess.TimeoutExpired, FileNotFoundError, json.JSONDecodeError):
            return None

    def _compare_resource(
        self,
        desired: dict,
        live: dict,
        kind: str,
        name: str,
        namespace: str,
        filename: str,
    ) -> list[dict[str, Any]]:
        """Compare desired vs live resource and report significant drifts."""
        drifts: list[dict[str, Any]] = []

        # Compare container images (most common drift source)
        if kind in ("Pod", "Deployment", "StatefulSet", "DaemonSet", "Job", "CronJob"):
            desired_containers = self._extract_containers(desired, kind)
            live_containers = self._extract_containers(live, kind)
            for cname, desired_image in desired_containers.items():
                live_image = live_containers.get(cname)
                if live_image and live_image != desired_image:
                    drifts.append({
                        "kind": kind,
                        "name": name,
                        "namespace": namespace,
                        "drift": f"Container '{cname}' image mismatch",
                        "expected": desired_image,
                        "actual": live_image,
                        "file": filename,
                    })
                elif live_image is None:
                    drifts.append({
                        "kind": kind,
                        "name": name,
                        "namespace": namespace,
                        "drift": f"Container '{cname}' missing from live resource",
                        "expected": desired_image,
                        "file": filename,
                    })

        # Compare labels
        desired_labels = desired.get("metadata", {}).get("labels", {})
        live_labels = live.get("metadata", {}).get("labels", {})
        for key, val in desired_labels.items():
            live_val = live_labels.get(key)
            if live_val is not None and live_val != val:
                drifts.append({
                    "kind": kind,
                    "name": name,
                    "namespace": namespace,
                    "drift": f"Label '{key}' mismatch",
                    "expected": val,
                    "actual": live_val,
                    "file": filename,
                })

        # Compare replicas for Deployments/StatefulSets
        if kind in ("Deployment", "StatefulSet"):
            desired_replicas = (desired.get("spec", {}).get("replicas"))
            live_replicas = (live.get("spec", {}).get("replicas"))
            if desired_replicas is not None and live_replicas is not None:
                if desired_replicas != live_replicas:
                    drifts.append({
                        "kind": kind,
                        "name": name,
                        "namespace": namespace,
                        "drift": "Replica count mismatch",
                        "expected": desired_replicas,
                        "actual": live_replicas,
                        "file": filename,
                    })

        return drifts

    def _extract_containers(self, resource: dict, kind: str) -> dict[str, str]:
        """Extract container name→image map from a resource spec."""
        containers: dict[str, str] = {}

        spec = resource.get("spec", {})
        # For Deployments, StatefulSets, DaemonSets — containers are nested under template
        if kind in ("Deployment", "StatefulSet", "DaemonSet", "Job"):
            pod_spec = spec.get("template", {}).get("spec", {})
        elif kind == "CronJob":
            pod_spec = spec.get("jobTemplate", {}).get("spec", {}).get("template", {}).get("spec", {})
        else:
            pod_spec = spec

        for c in pod_spec.get("containers", []):
            containers[c["name"]] = c.get("image", "")
        for c in pod_spec.get("initContainers", []):
            containers[f"init:{c['name']}"] = c.get("image", "")

        return containers

    # -- Full audit -----------------------------------------------------------

    def run_full_audit(self, export_sbom: Path | None = None, verify: bool = False) -> AuditResult:
        """Run complete audit: vulns + SBOM + optional drift detection."""
        start = time.monotonic()
        result = AuditResult()

        # 1. Vulnerability scan
        try:
            result.vulnerabilities = self.scan_vulnerabilities()
        except SystemExit as e:
            result.error = str(e)

        # 2. SBOM generation
        try:
            result.sbom_path = self.generate_sbom(export_sbom)
        except SystemExit as e:
            if result.error is None:
                result.error = str(e)

        # 3. Drift detection (if requested)
        if verify:
            result.drift_items = self.verify_deployed_state()

        result.scan_duration = time.monotonic() - start
        return result


# ---------------------------------------------------------------------------
# Rich output formatters
# ---------------------------------------------------------------------------

def render_vulnerability_table(vulns: list[Vulnerability]) -> None:
    """Print a rich table of vulnerabilities."""
    if not vulns:
        console.print("[bold green]✅ No known vulnerabilities found.[/bold green]")
        return

    table = Table(title="Vulnerabilities", show_lines=True)
    table.add_column("Package", style="cyan", no_wrap=True)
    table.add_column("Installed", style="yellow")
    table.add_column("ID", style="red")
    table.add_column("Fix Version", style="green")
    table.add_column("Description", max_width=50)

    for v in vulns:
        table.add_row(
            v.package,
            v.installed_version,
            v.vulnerability_id,
            v.fix_version or "—",
            v.description[:100] + ("…" if len(v.description) > 100 else ""),
        )

    console.print(table)
    fixable = sum(1 for v in vulns if v.is_fixable)
    console.print(
        f"\n[bold]{len(vulns)}[/bold] vulnerabilities found, "
        f"[bold green]{fixable}[/bold green] fixable."
    )


def render_drift_table(drifts: list[dict[str, Any]]) -> None:
    """Print a rich table of manifest drift items."""
    if not drifts:
        console.print("[bold green]✅ No drift detected — deployed state matches manifests.[/bold green]")
        return

    table = Table(title="Manifest Drift", show_lines=True)
    table.add_column("Kind", style="cyan", no_wrap=True)
    table.add_column("Name", style="yellow")
    table.add_column("Drift", style="red")
    table.add_column("Expected", style="green", max_width=40)
    table.add_column("Actual", style="magenta", max_width=40)

    for d in drifts:
        table.add_row(
            d.get("kind", ""),
            d.get("name", ""),
            d.get("drift", ""),
            str(d.get("expected", "—")),
            str(d.get("actual", "—")),
        )

    console.print(table)
    console.print(f"\n[bold red]{len(drifts)}[/bold red] drift items detected.")


def render_audit_summary(result: AuditResult) -> None:
    """Print a summary panel for the full audit."""
    lines = []
    if result.error:
        lines.append(f"[red]⚠  Error: {result.error}[/red]")

    lines.append(f"Vulnerabilities: [bold]{result.total_vulns}[/bold] ({result.fixable_vulns} fixable)")
    if result.sbom_path:
        lines.append(f"SBOM exported:   [cyan]{result.sbom_path}[/cyan]")
    if result.drift_items:
        lines.append(f"Drift items:     [bold red]{len(result.drift_items)}[/bold red]")
    else:
        lines.append("Drift:           [green]clean[/green]")
    lines.append(f"Duration:        [yellow]{result.scan_duration:.1f}s[/yellow]")

    console.print(Panel("\n".join(lines), title="Hexr Audit Summary", border_style="blue"))


# ---------------------------------------------------------------------------
# Click command
# ---------------------------------------------------------------------------

@click.command("audit")
@click.option(
    "--framework",
    type=click.Choice(["soc2", "hipaa", "iso42001"], case_sensitive=False),
    default=None,
    help="Compliance audit-pack mode. Generates a PDF mapping evidence rows to the"
         " framework's control families. When set, all CVE/SBOM/drift flags are ignored.",
)
@click.option(
    "--tenant",
    "tenant_id",
    default=None,
    help="Tenant ID (filters compliance_evidence.tenant_id). Required with --framework.",
)
@click.option(
    "--period",
    default="today",
    show_default=True,
    help="Time window for --framework: 'today', 'yesterday', 'all', 'NNd' (e.g. '7d'),"
         " or 'YYYY-MM-DD..YYYY-MM-DD'.",
)
@click.option(
    "--evidence-dsn",
    default=None,
    help="DB-API DSN for the customer evidence DB (env fallback: HEXR_EVIDENCE_DSN)."
         " Supports postgresql://... and sqlite:///path.",
)
@click.option(
    "--tier",
    "tier",
    type=click.Choice(["evaluation", "licensed"], case_sensitive=False),
    default=None,
    hidden=True,
    help="Override the resolved license tier for the audit-pack PDF"
         " (support / debug; normally inferred from ~/.hexr/config.json or"
         " HEXR_LICENSE_TIER).",
)
@click.option(
    "--export",
    "export_path",
    type=click.Path(path_type=Path),
    default=None,
    help="Export CycloneDX SBOM to this path (e.g., sbom.json)",
)
@click.option(
    "--verify",
    is_flag=True,
    default=False,
    help="Verify deployed K8s state matches generated manifests",
)
@click.option(
    "--fix",
    is_flag=True,
    default=False,
    help="Auto-update fixable vulnerable packages (pip install --upgrade)",
)
@click.option(
    "--requirements",
    "-r",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to requirements.txt (default: scan installed environment)",
)
@click.option(
    "--namespace",
    "-n",
    default=None,
    help="Kubernetes namespace for --verify (default: from manifests or 'default')",
)
@click.option(
    "--hexr-dir",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to .hexr build output directory (default: ./.hexr)",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory for audit artifacts (default: .hexr/audit)",
)
@click.option(
    "--json-output",
    "json_out",
    is_flag=True,
    default=False,
    help="Output results as JSON instead of rich tables",
)
@click.pass_context
def audit_command(
    ctx: click.Context,
    framework: str | None,
    tenant_id: str | None,
    period: str,
    evidence_dsn: str | None,
    tier: str | None,
    export_path: Path | None,
    verify: bool,
    fix: bool,
    requirements: Path | None,
    namespace: str | None,
    hexr_dir: Path | None,
    output_dir: Path | None,
    json_out: bool,
):
    """
    Audit agent dependencies for vulnerabilities and configuration drift,
    OR generate a compliance audit-pack PDF (with --framework).

    Default mode: scans Python dependencies for known CVEs using pip-audit,
    generates CycloneDX SBOMs, and optionally verifies that deployed
    Kubernetes resources match the manifests generated by 'hexr build'.

    Compliance mode (--framework {soc2|hipaa|iso42001}): queries the
    customer-side compliance_evidence table (canonical schema per
    HEXR_SDK_OVERHAUL_TECH_SPEC.md §7) for the given tenant + period and
    emits a PDF audit pack mapping rows to the framework's control
    families. Reads from HEXR_EVIDENCE_DSN (or --evidence-dsn). Hexr
    Cloud never sees a single evidence row.

    \b
    Examples:
        hexr audit                                   # CVE scan + SBOM
        hexr audit --export sbom.json                # Export CycloneDX SBOM
        hexr audit --verify                          # Drift check
        hexr audit --framework soc2 --tenant acme    # Today's SOC2 audit pack
        hexr audit --framework hipaa -t acme --period 30d
        hexr audit --framework iso42001 -t acme --period 2026-04-01..2026-04-30
    """
    # ----- Compliance audit-pack mode -----
    if framework is not None:
        if not tenant_id:
            raise click.UsageError("--tenant is required when --framework is set.")
        # Lazy import — keeps reportlab/psycopg2 out of the cold-start path.
        from hexr.cli.audit_pack import run_audit_pack

        out_dir = output_dir or Path(".hexr/audit")
        try:
            result = run_audit_pack(
                framework=framework.lower(),
                tenant_id=tenant_id,
                period=period,
                output_dir=out_dir,
                evidence_dsn=evidence_dsn,
                tier=tier.lower() if tier else None,
            )
        except (ValueError, RuntimeError) as e:
            console.print(f"[red]error:[/red] {e}")
            ctx.exit(2)
            return  # for type-checkers

        if json_out:
            import json as _json
            console.print_json(_json.dumps({
                "framework": result.framework,
                "tenant_id": result.tenant_id,
                "period_start": result.period_start.isoformat(),
                "period_end": result.period_end.isoformat(),
                "total_rows": result.total_rows,
                "app_attested_rows": result.app_attested_rows,
                "host_attested_rows": result.host_attested_rows,
                "unsigned_rows": result.unsigned_rows,
                "controls": [
                    {"control_id": c.control_id, "title": c.title, "row_count": c.row_count}
                    for c in result.controls
                ],
                "pdf_path": str(result.pdf_path),
            }))
        else:
            console.print(f"[green]✓[/green] Audit pack generated: [cyan]{result.pdf_path}[/cyan]")
            console.print(
                f"  framework={result.framework}  tenant={result.tenant_id}  "
                f"rows={result.total_rows} (app_attested={result.app_attested_rows}, "
                f"host_attested={result.host_attested_rows}, unsigned={result.unsigned_rows})"
            )
            for c in result.controls:
                console.print(f"  {c.control_id:<14} {c.title[:60]:<60} rows={c.row_count}")
        return

    # ----- Default CVE/SBOM/drift mode -----
    verbose = ctx.obj.get("verbose", False) if ctx.obj else False
    out_dir = output_dir or Path(".hexr/audit")

    engine = AuditEngine(
        output_dir=out_dir,
        requirements=requirements,
        hexr_dir=hexr_dir or Path(".hexr"),
        namespace=namespace,
        verbose=verbose,
    )

    with _start_span("hexr.audit.run", kind=SpanKind.INTERNAL if _tracer else None) as root_span:
        result = engine.run_full_audit(export_sbom=export_path, verify=verify)

        # Auto-fix if requested
        if fix and result.vulnerabilities:
            _auto_fix(result.vulnerabilities, verbose)

        if json_out:
            _print_json(result)
        else:
            render_vulnerability_table(result.vulnerabilities)
            if export_path or result.sbom_path:
                console.print(f"\n📦 SBOM written to [cyan]{result.sbom_path}[/cyan]")
            if verify:
                console.print()
                render_drift_table(result.drift_items)
            console.print()
            render_audit_summary(result)

        # AG-15: Post audit evidence to Cloud API evidence store (non-fatal, silently skips if unauthenticated)
        _post_audit_evidence(result)

        # Set exit code: non-zero if vulns or drift found
        if result.total_vulns > 0 or result.has_drift:
            if root_span and StatusCode:
                root_span.set_status(StatusCode.ERROR, "audit findings detected")
            ctx.exit(1)


# ---------------------------------------------------------------------------
# Auto-fix helper
# ---------------------------------------------------------------------------

def _auto_fix(vulns: list[Vulnerability], verbose: bool) -> None:
    """Upgrade packages that have known fix versions."""
    fixable = [v for v in vulns if v.is_fixable]
    if not fixable:
        console.print("[yellow]No auto-fixable vulnerabilities found.[/yellow]")
        return

    console.print(f"\n[bold]Upgrading {len(fixable)} fixable packages…[/bold]")

    # Deduplicate by package name (take highest fix version)
    packages: dict[str, str] = {}
    for v in fixable:
        if v.fix_version:
            existing = packages.get(v.package)
            if existing is None or v.fix_version > existing:
                packages[v.package] = v.fix_version

    for pkg, version in packages.items():
        spec = f"{pkg}>={version}"
        console.print(f"  pip install '{spec}'")
        if not verbose:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", spec],
                capture_output=True,
                text=True,
            )
        else:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", spec],
            )

    console.print("[bold green]✅ Auto-fix complete. Re-run 'hexr audit' to verify.[/bold green]")


# ---------------------------------------------------------------------------
# JSON output helper
# ---------------------------------------------------------------------------

def _print_json(result: AuditResult) -> None:
    """Print audit results as machine-readable JSON."""
    output = {
        "vulnerabilities": [
            {
                "package": v.package,
                "installed_version": v.installed_version,
                "vulnerability_id": v.vulnerability_id,
                "fix_version": v.fix_version,
                "description": v.description,
                "aliases": v.aliases,
                "fixable": v.is_fixable,
            }
            for v in result.vulnerabilities
        ],
        "sbom_path": str(result.sbom_path) if result.sbom_path else None,
        "drift": result.drift_items,
        "summary": {
            "total_vulnerabilities": result.total_vulns,
            "fixable_vulnerabilities": result.fixable_vulns,
            "drift_items": len(result.drift_items),
            "scan_duration_seconds": round(result.scan_duration, 2),
        },
        "error": result.error,
    }
    click.echo(json.dumps(output, indent=2))


# ---------------------------------------------------------------------------
# AG-15: Evidence store wiring — POST SBOM + vuln results to the data-plane API
# ---------------------------------------------------------------------------

def _post_audit_evidence(result: AuditResult, tenant_id: str | None = None) -> None:
    """Post audit results as AG-15 compliance evidence to the data-plane evidence-api.

    Per HEXR_HYBRID_PIVOT_TECH_SPEC.md §4 ("no `evidence.hexr.cloud`"), the SBOM +
    vulnerability detail rows stay inside the customer VPC. We route through
    `hexr.evidence.post_evidence()` which resolves to (in order):
      1. `HEXR_EVIDENCE_URL` env
      2. In-cluster `http://hexr-evidence-api.hexr-system.svc:8080`
    There is no third option. A `CloudConfig` fall-back to `api.hexr.cloud`
    used to sit here and was removed 2026-09-10 — it posted SBOM and
    vulnerability rows to the CONTROL PLANE, which is exactly what §4
    forbids. Falls through silently when no endpoint resolves.
    """
    tid = tenant_id
    if tid is None:
        try:
            tid = CloudConfig.load().tenant_id
        except Exception:
            tid = None

    sbom_component_count = 0
    if result.sbom_path and result.sbom_path.exists():
        try:
            sbom_data = json.loads(result.sbom_path.read_text(encoding="utf-8"))
            sbom_component_count = len(sbom_data.get("components", []))
        except Exception:
            pass

    severity = "info"
    if result.total_vulns > 0:
        severity = "high" if any(
            "CRITICAL" in v.vulnerability_id.upper() for v in result.vulnerabilities
        ) else "warning"
    if result.has_drift:
        severity = "high"

    details = {
        "total_vulnerabilities": result.total_vulns,
        "fixable_vulnerabilities": result.fixable_vulns,
        "sbom_component_count": sbom_component_count,
        "sbom_format": "CycloneDX-1.4",
        "drift_items": len(result.drift_items),
        "scan_duration_seconds": round(result.scan_duration, 2),
        "vulnerability_ids": [v.vulnerability_id for v in result.vulnerabilities[:20]],
    }

    try:
        _post_dp_evidence(
            event_type="code_provenance_audit",
            control_id="AG-15",
            details=details,
            source="hexr-audit-cli",
            framework="soc2",
            severity=severity,
            tenant_id=tid,
        )
    except Exception as exc:
        logger.debug("Evidence POST failed (non-fatal): %s", exc)
