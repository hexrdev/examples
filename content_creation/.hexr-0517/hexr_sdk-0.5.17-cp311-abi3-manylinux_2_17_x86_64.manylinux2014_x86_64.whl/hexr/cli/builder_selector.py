"""
Interactive builder selection and CI/CD guidance for hexr push.
"""

import sys
from typing import List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

from .push import BuilderInfo, BuildGuidanceResult, SystemResources

console = Console()


class BuilderSelector:
    """Interactive builder selection with guidance."""

    def __init__(self):
        self.console = console

    def display_environment_analysis(
        self,
        resources: SystemResources,
        builders: List[BuilderInfo],
        guidance: BuildGuidanceResult,
        platforms: List[str],
    ):
        """Display comprehensive environment analysis."""
        # Show platform request
        platform_str = ", ".join(platforms) if platforms else "auto-detect"
        self.console.print(
            f"\n🎯 [cyan]Target Platforms:[/cyan] {platform_str}",
            highlight=False,
        )

        # Show resources
        self.console.print(f"\n[cyan]📊 Local System Resources:[/cyan]")
        resource_table = Table(show_header=False, box=None, padding=(0, 2))
        resource_table.add_column("Property", style="dim")
        resource_table.add_column("Value")

        resource_table.add_row("CPU", f"{resources.cpu_cores} cores")
        
        # RAM with warning indicator
        ram_status = "✅" if resources.ram_gb >= 16 else "⚠️" if resources.ram_gb >= 8 else "❌"
        resource_table.add_row("RAM", f"{ram_status} {resources.ram_gb} GB")
        
        # Disk with warning indicator
        disk_status = "✅" if resources.disk_free_gb >= 100 else "⚠️" if resources.disk_free_gb >= 50 else "❌"
        resource_table.add_row("Disk Free", f"{disk_status} {resources.disk_free_gb} GB")
        
        docker_status = "✅ Running" if resources.docker_running else "❌ Not Running"
        resource_table.add_row("Docker Daemon", docker_status)
        
        buildx_status = "✅ Available" if resources.buildx_available else "❌ Not Available"
        resource_table.add_row("Docker Buildx", buildx_status)

        self.console.print(resource_table)

        # Show resource warnings if any
        if guidance.resource_warnings:
            self.console.print()
            for warning in guidance.resource_warnings:
                self.console.print(f"{warning}", style="yellow")

    def display_available_builders(self, builders: List[BuilderInfo]) -> Table:
        """Display all available builders in a table."""
        table = Table(title="🏗️  Available Docker Builders")
        table.add_column("#", style="cyan", width=3)
        table.add_column("Name", style="bold")
        table.add_column("Type", style="dim")
        table.add_column("Platforms", style="green")
        table.add_column("Status", style="yellow")
        table.add_column("Notes", style="dim")

        for idx, builder in enumerate(builders, 1):
            # Format platforms
            platform_str = ", ".join(builder.platforms[:2])  # Show first 2
            if len(builder.platforms) > 2:
                platform_str += f" (+{len(builder.platforms) - 2} more)"

            # Format notes
            notes = []
            if builder.is_cloud:
                notes.append("☁️ Cloud")
            if builder.is_default:
                notes.append("⭐ Default")
            if len(builder.platforms) > 2:
                notes.append("🌐 Multi-platform")

            notes_str = " ".join(notes) if notes else ""

            # Status emoji
            status_display = builder.status
            if builder.status == "running":
                status_display = "✅ Running"
            elif builder.status == "inactive":
                status_display = "⏸️  Inactive"

            table.add_row(
                str(idx),
                builder.name,
                builder.driver,
                platform_str,
                status_display,
                notes_str,
            )

        return table

    def display_cicd_recommendation(
        self, guidance: BuildGuidanceResult, platforms: List[str]
    ):
        """Display CI/CD recommendation with reasons."""
        if not guidance.recommend_cicd:
            return

        self.console.print()
        panel_content = "[bold yellow]💡 Recommendation: Use CI/CD for this build[/bold yellow]\n\n"
        panel_content += "[dim]Why CI/CD is recommended:[/dim]\n"

        for reason in guidance.reasons:
            panel_content += f"  • {reason}\n"

        panel_content += "\n[bold]Benefits of CI/CD:[/bold]\n"
        panel_content += "  ✅ Team runners with more resources\n"
        panel_content += "  ✅ Free for most platforms (GitHub Actions, GitLab CI)\n"
        panel_content += "  ✅ Consistent build environment\n"
        panel_content += "  ✅ Automated on git push\n"

        if len(platforms) > 1:
            panel_content += "\n[bold cyan]For multi-platform builds:[/bold cyan]\n"
            panel_content += "  ⚡ Docker Build Cloud (fastest, team cache)\n"
            panel_content += "  🔧 GitHub Actions runners (free, reliable)\n"

        self.console.print(Panel(panel_content, border_style="yellow", expand=False))

    def prompt_cicd_template_generation(self) -> bool:
        """Ask user if they want to generate CI/CD templates."""
        return Confirm.ask(
            "\n[bold]Generate GitHub Actions or GitLab CI template?[/bold]",
            default=False,
        )

    def prompt_builder_selection(
        self,
        builders: List[BuilderInfo],
        recommended_builder: Optional[str] = None,
    ) -> Optional[BuilderInfo]:
        """Prompt user to select a builder."""
        # Display builder table
        table = self.display_available_builders(builders)
        self.console.print()
        self.console.print(table)

        if recommended_builder:
            # Find builder index
            recommended_idx = None
            for idx, builder in enumerate(builders, 1):
                if builder.name == recommended_builder:
                    recommended_idx = idx
                    break

            if recommended_idx:
                self.console.print(
                    f"\n[bold green]💡 Recommended:[/bold green] Builder #{recommended_idx} ({recommended_builder})"
                )

        # Prompt for selection
        while True:
            choice = Prompt.ask(
                "\n[bold]Select builder number[/bold] (or press Enter for recommended)",
                default=str(recommended_idx) if recommended_idx else "1",
            )

            try:
                idx = int(choice)
                if 1 <= idx <= len(builders):
                    return builders[idx - 1]
                else:
                    self.console.print(
                        f"[red]Invalid choice. Please select 1-{len(builders)}[/red]"
                    )
            except ValueError:
                self.console.print("[red]Please enter a number[/red]")

    def prompt_continue_local_build(self) -> bool:
        """Ask user if they want to continue with local build despite recommendations."""
        return Confirm.ask(
            "\n[bold yellow]Continue with local build anyway?[/bold yellow]",
            default=False,
        )

    def display_final_choice(
        self, builder: BuilderInfo, platforms: List[str]
    ):
        """Display final build configuration."""
        self.console.print()
        panel_content = f"[bold green]✓ Build Configuration[/bold green]\n\n"
        panel_content += f"Builder: [cyan]{builder.name}[/cyan] ({builder.driver})\n"
        panel_content += f"Platforms: [cyan]{', '.join(platforms)}[/cyan]\n"
        panel_content += f"Status: {builder.status}\n"

        if builder.is_cloud:
            panel_content += "\n[dim]Using Docker Build Cloud for fast multi-platform build ⚡[/dim]"

        self.console.print(Panel(panel_content, border_style="green", expand=False))

    def display_cicd_abort_message(self):
        """Display message when user aborts to use CI/CD."""
        self.console.print()
        self.console.print(
            Panel.fit(
                "[bold yellow]Build cancelled[/bold yellow]\n\n"
                "💡 Run [cyan]hexr push --init-cicd[/cyan] to generate CI/CD templates",
                border_style="yellow",
            )
        )
