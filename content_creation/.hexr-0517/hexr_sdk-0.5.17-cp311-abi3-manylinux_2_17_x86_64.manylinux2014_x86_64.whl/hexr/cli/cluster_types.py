"""
Data types for cluster detection and selection.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ClusterInfo:
    """Information about a detected Kubernetes cluster."""

    name: str
    cluster: str
    user: str
    namespace: str
    is_current: bool
    is_reachable: bool


@dataclass
class ClusterResources:
    """Resource information for a Kubernetes cluster."""

    cluster_name: str
    nodes: int
    total_cpu: str
    total_memory: str
    allocatable_cpu: str
    allocatable_memory: str
    kubernetes_version: str
