"""
CI/CD template generator for hexr push workflows.
"""

from pathlib import Path
from typing import List

from rich.console import Console

console = Console()


class CICDTemplateGenerator:
    """Generate GitHub Actions and GitLab CI templates for hexr push."""

    def __init__(self, tenant: str, registry: str, platforms: List[str]):
        self.tenant = tenant
        self.registry = registry
        self.platforms = platforms or ["linux/amd64", "linux/arm64"]

    def generate_github_workflow(self, output_dir: Path) -> Path:
        """Generate GitHub Actions workflow for hexr push."""
        # Create template in .hexr/ci-cd/github/ directory
        workflow_dir = output_dir / ".hexr" / "ci-cd" / "github" / ".github" / "workflows"
        workflow_dir.mkdir(parents=True, exist_ok=True)

        workflow_file = workflow_dir / "hexr-push.yml"

        platform_flag = " ".join([f"--platform {p}" for p in self.platforms])

        content = f"""name: Hexr Push - Multi-Platform Build

on:
  push:
    branches:
      - main
      - develop
  pull_request:
    branches:
      - main
  workflow_dispatch:  # Allow manual trigger

env:
  REGISTRY: {self.registry}
  TENANT: {self.tenant}

jobs:
  build-and-push:
    name: Build & Push Multi-Platform Image
    runs-on: ubuntu-latest
    
    permissions:
      contents: read
      packages: write  # For GitHub Container Registry
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        # Note: .hexr/ directory (from hexr build) must be checked into git
        # hexr build runs LOCALLY only, not in CI/CD
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      
      - name: Install uv
        uses: astral-sh/setup-uv@v5
      
      - name: Install hexr SDK
        run: |
          uv pip install hexr-sdk
      
      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3
        with:
          platforms: {','.join(self.platforms)}
      
      - name: Login to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{{{ env.REGISTRY }}}}
          username: ${{{{ secrets.REGISTRY_USERNAME }}}}
          password: ${{{{ secrets.REGISTRY_TOKEN }}}}
      
      - name: Run hexr push (multi-platform)
        run: |
          hexr push \\
            --tenant ${{{{ env.TENANT }}}} \\
            --registry ${{{{ env.REGISTRY }}}} \\
            --tag ${{{{ github.sha }}}} \\
            {platform_flag} \\
            --scan-level standard \\
            --skip-guidance
      
      - name: Tag as latest (main branch only)
        if: github.ref == 'refs/heads/main'
        run: |
          hexr push \\
            --tenant ${{{{ env.TENANT }}}} \\
            --registry ${{{{ env.REGISTRY }}}} \\
            --tag latest \\
            {platform_flag} \\
            --skip-guidance

# Required Secrets:
# - REGISTRY_USERNAME: Container registry username
# - REGISTRY_TOKEN: Container registry access token/password
#
# For DigitalOcean Container Registry:
#   - REGISTRY_USERNAME: Your DO account email or token name
#   - REGISTRY_TOKEN: DO API token or registry token
#
# For GitHub Container Registry (ghcr.io):
#   - Use GITHUB_TOKEN (automatically provided)
#   - Set registry: ghcr.io
"""

        workflow_file.write_text(content)
        return workflow_file

    def generate_gitlab_ci(self, output_dir: Path) -> Path:
        """Generate GitLab CI configuration for hexr push."""
        # Create template in .hexr/ci-cd/gitlab/ directory
        ci_dir = output_dir / ".hexr" / "ci-cd" / "gitlab"
        ci_dir.mkdir(parents=True, exist_ok=True)
        
        ci_file = ci_dir / ".gitlab-ci.yml"

        platform_flag = " ".join([f"--platform {p}" for p in self.platforms])

        content = f"""# Hexr Push - Multi-Platform Build Pipeline

variables:
  REGISTRY: "{self.registry}"
  TENANT: "{self.tenant}"
  DOCKER_DRIVER: overlay2
  DOCKER_TLS_CERTDIR: "/certs"

stages:
  - push

# Note: .hexr/ directory (from hexr build) must be checked into git
# hexr build runs LOCALLY only, not in CI/CD

# Docker-in-Docker service for builds
services:
  - docker:dind

before_script:
  # Install Python and uv
  - apt-get update && apt-get install -y python3 python3-pip curl
  - curl -LsSf https://astral.sh/uv/install.sh | sh
  - export PATH="$HOME/.cargo/bin:$PATH"
  
  # Install hexr SDK
  - uv pip install hexr-sdk
  
  # Login to container registry
  - echo "$REGISTRY_TOKEN" | docker login $REGISTRY -u "$REGISTRY_USERNAME" --password-stdin

hexr-push-development:
  stage: push
  image: docker:latest
  script:
    - hexr push \\
        --tenant $TENANT \\
        --registry $REGISTRY \\
        --tag $CI_COMMIT_SHORT_SHA \\
        {platform_flag} \\
        --scan-level standard \\
        --skip-guidance
  only:
    - branches
  except:
    - main

hexr-push-production:
  stage: push
  image: docker:latest
  dependencies:
    - hexr-build
  script:
    # Push with commit SHA
    - hexr push \\
        --tenant $TENANT \\
        --registry $REGISTRY \\
        --tag $CI_COMMIT_SHORT_SHA \\
        {platform_flag} \\
        --scan-level strict \\
        --skip-guidance
    
    # Tag as latest
    - hexr push \\
        --tenant $TENANT \\
        --registry $REGISTRY \\
        --tag latest \\
        {platform_flag} \\
        --scan-level strict \\
        --skip-guidance
  only:
    - main

# Required CI/CD Variables (Settings > CI/CD > Variables):
# - REGISTRY_USERNAME: Container registry username
# - REGISTRY_TOKEN: Container registry access token (masked)
#
# For DigitalOcean:
#   REGISTRY_USERNAME: Your DO account email
#   REGISTRY_TOKEN: DO API token
"""

        ci_file.write_text(content)
        return ci_file

    def display_setup_instructions(self, platform: str, workflow_file: Path):
        """Display setup instructions for CI/CD."""
        console.print()
        console.print(f"[bold green]✅ Generated {platform} workflow![/bold green]")
        console.print(f"[dim]Location: {workflow_file}[/dim]")
        console.print()

        if platform == "GitHub Actions":
            console.print("[bold]📝 Next Steps:[/bold]")
            console.print()
            console.print("1. Copy the workflow to your project root:")
            console.print("   [cyan]cp -r .hexr/ci-cd/github/.github .[/cyan]")
            console.print()
            console.print("2. Add registry secrets to GitHub:")
            console.print("   [cyan]Settings > Secrets and variables > Actions > New secret[/cyan]")
            console.print()
            console.print("   [bold]REGISTRY_USERNAME[/bold]: Your container registry username")
            console.print("   [bold]REGISTRY_TOKEN[/bold]: Your container registry token")
            console.print()
            console.print("3. Commit and push the workflow:")
            console.print("   [cyan]git add .hexr/ .github/[/cyan]")
            console.print("   [cyan]git commit -m 'Add hexr push workflow'[/cyan]")
            console.print("   [cyan]git push[/cyan]")
            console.print()
            console.print("4. Monitor the workflow:")
            console.print("   [cyan]Actions tab in your GitHub repository[/cyan]")

        elif platform == "GitLab CI":
            console.print("[bold]📝 Next Steps:[/bold]")
            console.print()
            console.print("1. Copy the CI configuration to your project root:")
            console.print("   [cyan]cp .hexr/ci-cd/gitlab/.gitlab-ci.yml .[/cyan]")
            console.print()
            console.print("2. Add registry secrets to GitLab:")
            console.print("   [cyan]Settings > CI/CD > Variables > Add variable[/cyan]")
            console.print()
            console.print("   [bold]REGISTRY_USERNAME[/bold]: Your container registry username")
            console.print("   [bold]REGISTRY_TOKEN[/bold]: Your container registry token (mark as masked)")
            console.print()
            console.print("3. Commit and push the CI configuration:")
            console.print("   [cyan]git add .hexr/ .gitlab-ci.yml[/cyan]")
            console.print("   [cyan]git commit -m 'Add hexr push CI/CD pipeline'[/cyan]")
            console.print("   [cyan]git push[/cyan]")
            console.print()
            console.print("4. Monitor the pipeline:")
            console.print("   [cyan]CI/CD > Pipelines in your GitLab project[/cyan]")

        console.print()
        console.print("[dim]💡 The pipeline will automatically build and push on every commit![/dim]")

    def generate_github_deploy_workflow(
        self, output_dir: Path, environment: str, namespace: str
    ) -> Path:
        """Generate GitHub Actions workflow for hexr deploy."""
        # Create template in .hexr/ci-cd/github/ directory
        workflow_dir = output_dir / ".hexr" / "ci-cd" / "github" / ".github" / "workflows"
        workflow_dir.mkdir(parents=True, exist_ok=True)

        workflow_file = workflow_dir / "hexr-deploy.yml"

        content = f"""name: Hexr Deploy - Kubernetes Deployment

on:
  workflow_run:
    workflows: ["Hexr Push - Multi-Platform Build"]
    types:
      - completed
    branches:
      - main
      - develop
  workflow_dispatch:  # Allow manual trigger
    inputs:
      environment:
        description: 'Deployment environment'
        required: true
        default: '{environment}'
        type: choice
        options:
          - development
          - staging
          - production

env:
  TENANT: {self.tenant}
  NAMESPACE: {namespace}

jobs:
  deploy:
    name: Deploy to Kubernetes
    runs-on: ubuntu-latest
    environment: ${{{{ github.event.inputs.environment || '{environment}' }}}}
    
    permissions:
      contents: read
    
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        # Note: .hexr/ directory must be checked into git
        # hexr build and hexr push run separately
      
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.11'
      
      - name: Install uv
        uses: astral-sh/setup-uv@v5
      
      - name: Install hexr SDK
        run: |
          uv pip install hexr-sdk
      
      - name: Set up kubectl
        uses: azure/setup-kubectl@v3
        with:
          version: 'latest'
      
      - name: Configure Kubernetes context
        run: |
          mkdir -p $HOME/.kube
          echo "${{{{ secrets.KUBECONFIG }}}}" | base64 -d > $HOME/.kube/config
          chmod 600 $HOME/.kube/config
      
      - name: Verify cluster connectivity
        run: |
          kubectl cluster-info
          kubectl get nodes
      
      - name: Run hexr deploy
        run: |
          hexr deploy .hexr \\
            --env ${{{{ github.event.inputs.environment || '{environment}' }}}} \\
            --namespace ${{{{ env.NAMESPACE }}}} \\
            --skip-guidance
      
      - name: Verify deployment
        run: |
          kubectl get pods -n ${{{{ env.NAMESPACE }}}} -l app=${{{{ env.TENANT }}}}-agent
          kubectl wait --for=condition=ready pod -l app=${{{{ env.TENANT }}}}-agent -n ${{{{ env.NAMESPACE }}}} --timeout=300s

# Required Secrets:
# - KUBECONFIG: Base64-encoded Kubernetes config file
#
# To generate:
#   cat ~/.kube/config | base64 | pbcopy  # macOS
#   cat ~/.kube/config | base64 -w 0      # Linux
#
# Add to GitHub:
#   Settings > Secrets and variables > Actions > New secret
#   Name: KUBECONFIG
#   Value: <paste base64 content>
"""

        workflow_file.write_text(content)
        return workflow_file

    def generate_gitlab_deploy_ci(
        self, output_dir: Path, environment: str, namespace: str
    ) -> Path:
        """Generate GitLab CI configuration for hexr deploy."""
        # Create template in .hexr/ci-cd/gitlab/ directory as separate file
        ci_dir = output_dir / ".hexr" / "ci-cd" / "gitlab"
        ci_dir.mkdir(parents=True, exist_ok=True)

        ci_file = ci_dir / "hexr-deploy.yml"

        content = f"""# Hexr Deploy - Kubernetes Deployment Pipeline
# Note: This is a SEPARATE pipeline from hexr-push
# Include this in your main .gitlab-ci.yml or use as standalone

variables:
  TENANT: "{self.tenant}"
  NAMESPACE: "{namespace}"
  ENVIRONMENT: "{environment}"

stages:
  - deploy

# Note: .hexr/ directory must be checked into git
# hexr build and hexr push run separately

deploy-{environment}:
  stage: deploy
  image: 
    name: bitnami/kubectl:latest
    entrypoint: [""]
  
  before_script:
    # Install Python and uv
    - apt-get update && apt-get install -y python3 python3-pip curl
    - curl -LsSf https://astral.sh/uv/install.sh | sh
    - export PATH="$HOME/.cargo/bin:$PATH"
    
    # Install hexr SDK
    - uv pip install hexr-sdk
    
    # Configure kubectl
    - mkdir -p $HOME/.kube
    - echo "$KUBECONFIG_CONTENT" | base64 -d > $HOME/.kube/config
    - chmod 600 $HOME/.kube/config
  
  script:
    # Verify cluster connectivity
    - kubectl cluster-info
    - kubectl get nodes
    
    # Deploy with hexr
    - hexr deploy .hexr
        --env $ENVIRONMENT
        --namespace $NAMESPACE
        --skip-guidance
    
    # Verify deployment
    - kubectl get pods -n $NAMESPACE -l app=$TENANT-agent
    - kubectl wait --for=condition=ready pod -l app=$TENANT-agent -n $NAMESPACE --timeout=300s
  
  only:
    - main  # Change to match your branch strategy
  
  environment:
    name: {environment}
    action: start

# Required CI/CD Variables (Settings > CI/CD > Variables):
# - KUBECONFIG_CONTENT: Base64-encoded Kubernetes config (masked)
#
# To generate:
#   cat ~/.kube/config | base64 -w 0
#
# Add to GitLab:
#   Settings > CI/CD > Variables > Add variable
#   Key: KUBECONFIG_CONTENT
#   Value: <paste base64 content>
#   Type: Variable
#   Protected: Yes
#   Masked: Yes
"""

        ci_file.write_text(content)
        return ci_file

    def display_deploy_setup_instructions(self, platform: str, workflow_file: Path):
        """Display setup instructions for deploy CI/CD."""
        console.print()
        console.print(f"[bold green]✅ Generated {platform} deploy workflow![/bold green]")
        console.print(f"[dim]Location: {workflow_file}[/dim]")
        console.print()

        if platform == "GitHub Actions":
            console.print("[bold]📝 Next Steps:[/bold]")
            console.print()
            console.print("1. Copy the workflow to your project root:")
            console.print("   [cyan]cp -r .hexr/ci-cd/github/.github .[/cyan]")
            console.print()
            console.print("2. Add Kubernetes config to GitHub:")
            console.print("   [cyan]Settings > Secrets and variables > Actions > New secret[/cyan]")
            console.print()
            console.print("   [bold]KUBECONFIG[/bold]: Base64-encoded kubeconfig")
            console.print("   [dim]# Generate: cat ~/.kube/config | base64 | pbcopy[/dim]")
            console.print()
            console.print("3. Commit and push the workflow:")
            console.print("   [cyan]git add .hexr/ .github/[/cyan]")
            console.print("   [cyan]git commit -m 'Add hexr deploy workflow'[/cyan]")
            console.print("   [cyan]git push[/cyan]")
            console.print()
            console.print("4. Monitor the workflow:")
            console.print("   [cyan]Actions tab in your GitHub repository[/cyan]")
            console.print()
            console.print("[dim]💡 Deploy runs after push workflow completes![/dim]")

        elif platform == "GitLab CI":
            console.print("[bold]📝 Next Steps:[/bold]")
            console.print()
            console.print("1. Copy or include the deploy configuration:")
            console.print("   [cyan]# Option A: Copy to project root[/cyan]")
            console.print("   [cyan]cp .hexr/ci-cd/gitlab/hexr-deploy.yml .[/cyan]")
            console.print()
            console.print("   [cyan]# Option B: Include in existing .gitlab-ci.yml[/cyan]")
            console.print("   [cyan]include:[/cyan]")
            console.print("   [cyan]  - local: '.hexr/ci-cd/gitlab/hexr-deploy.yml'[/cyan]")
            console.print()
            console.print("2. Add Kubernetes config to GitLab:")
            console.print("   [cyan]Settings > CI/CD > Variables > Add variable[/cyan]")
            console.print()
            console.print("   [bold]KUBECONFIG_CONTENT[/bold]: Base64-encoded kubeconfig (masked)")
            console.print("   [dim]# Generate: cat ~/.kube/config | base64 -w 0[/dim]")
            console.print()
            console.print("3. Commit and push the configuration:")
            console.print("   [cyan]git add .hexr/ hexr-deploy.yml[/cyan]")
            console.print("   [cyan]git commit -m 'Add hexr deploy CI/CD pipeline'[/cyan]")
            console.print("   [cyan]git push[/cyan]")
            console.print()
            console.print("4. Monitor the pipeline:")
            console.print("   [cyan]CI/CD > Pipelines in your GitLab project[/cyan]")
            console.print()
            console.print("[dim]💡 Deploy runs as separate stage after push![/dim]")
