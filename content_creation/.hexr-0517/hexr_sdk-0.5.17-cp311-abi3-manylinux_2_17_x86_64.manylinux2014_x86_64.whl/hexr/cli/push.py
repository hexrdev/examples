"""
Hexr Push Command Implementation - Enterprise Edition

Complete Docker build + push workflow with:
- Multi-platform support (amd64, arm64)
- Intelligent build strategy detection (Cloud, Local, CI/CD)
- Tiered vulnerability scanning (Registry-native, Trivy, Grype)
- Enterprise registry support (DO, Harbor, ECR, GCR, ACR)
- CI/CD integration ready
- Resource-efficient builds (handles MacBook Air to enterprise clusters)
"""

import asyncio
import json
import logging
import os
import platform as py_platform
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, List, Optional, Tuple

import click
import psutil
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.prompt import Confirm, Prompt
from rich.table import Table

from hexr.utils.simple_logging import get_logger

console = Console()


class BuildStrategy(Enum):
    """Available Docker build strategies."""

    CLOUD = "docker-build-cloud"  # Fastest, multi-platform native
    LOCAL_BUILDX = "local-buildx"  # Standard, works everywhere
    LOCAL_BASIC = "local-basic"  # Fallback, single platform
    CI_REMOTE = "ci-remote"  # CI/CD environment


class ScanLevel(Enum):
    """Vulnerability scan severity levels."""

    NONE = "none"  # Skip scanning (dev only)
    BASIC = "basic"  # Warn on high/critical
    STANDARD = "standard"  # Block on critical
    STRICT = "strict"  # Block on high+critical


@dataclass
class PushConfig:
    """Configuration for hexr push command."""

    build_dir: Path
    registry: str
    tenant: str
    tag: str
    scan_level: ScanLevel = ScanLevel.STANDARD
    platforms: List[str] = field(default_factory=list)
    force_push: bool = False
    dry_run: bool = False
    verbose: bool = False
    debug: bool = False
    build_strategy: Optional[BuildStrategy] = None
    manifest_list: bool = True
    build_cache: bool = True

    def __post_init__(self):
        """Validate and normalize configuration."""
        # Convert string to Path if needed
        if isinstance(self.build_dir, str):
            self.build_dir = Path(self.build_dir)


@dataclass
class BuilderInfo:
    """Information about a Docker builder."""

    name: str
    driver: str
    platforms: List[str]
    status: str  # running, inactive, error
    is_cloud: bool = False
    is_default: bool = False
    endpoint: Optional[str] = None


@dataclass
class SystemResources:
    """System resource information."""

    cpu_cores: int
    ram_gb: float
    disk_free_gb: float
    docker_running: bool
    buildx_available: bool
    platform: str  # darwin, linux, windows


@dataclass
class BuildGuidanceResult:
    """Guidance recommendation for build strategy."""

    recommend_cicd: bool
    reasons: List[str]
    recommended_builder: Optional[str] = None
    alternative_builders: List[str] = field(default_factory=list)
    resource_warnings: List[str] = field(default_factory=list)


@dataclass
class ScanResult:
    """Security scan results."""

    scanner: str
    vulnerabilities: List[dict]
    risk_level: str
    critical_count: int
    high_count: int
    passed: bool
    timestamp: float


@dataclass
class PushResult:
    """Result of hexr push command execution."""

    success: bool
    registry_url: Optional[str] = None
    image_digest: Optional[str] = None
    platforms: List[str] = field(default_factory=list)
    scan_result: Optional[ScanResult] = None
    build_strategy: Optional[BuildStrategy] = None
    duration: float = 0.0
    error: Optional[str] = None


class BuildStrategyDetector:
    """Detects optimal Docker build strategy for current environment."""

    # Resource thresholds for CI/CD recommendation
    MIN_RAM_GB = 8
    MIN_DISK_GB = 50
    COMFORTABLE_RAM_GB = 16

    def __init__(self, logger):
        self.logger = logger
        self._cached_resources: Optional[SystemResources] = None
        self._cached_builders: Optional[List[BuilderInfo]] = None

    async def detect_best_strategy(self) -> BuildStrategy:
        """Auto-detect best available build strategy (legacy method for backward compatibility)."""

        # 1. Check if running in CI/CD environment
        if self._is_ci_environment():
            self.logger.info("🤖 Detected CI/CD environment")
            return BuildStrategy.CI_REMOTE

        # 2. Check Docker Build Cloud availability (FASTEST for multi-platform)
        if await self._has_docker_build_cloud():
            self.logger.info(
                "☁️  Docker Build Cloud available - using for fast multi-platform builds"
            )
            return BuildStrategy.CLOUD

        # 3. Check local buildx (standard fallback)
        if await self._has_local_buildx():
            self.logger.info("🔨 Using local Docker Buildx")
            return BuildStrategy.LOCAL_BUILDX

        # 4. Basic Docker (last resort, single platform only)
        self.logger.warning("⚠️  Using basic Docker build (single platform only)")
        return BuildStrategy.LOCAL_BASIC

    async def detect_all_builders(self) -> List[BuilderInfo]:
        """Detect ALL available Docker builders with their capabilities."""
        if self._cached_builders:
            return self._cached_builders

        builders = []

        try:
            # Run: docker buildx ls
            result = subprocess.run(
                ["docker", "buildx", "ls"],
                capture_output=True,
                text=True,
                check=True,
                timeout=10,
            )

            lines = result.stdout.strip().split("\n")

            for line in lines[1:]:  # Skip header
                if not line.strip():
                    continue

                parts = line.split()
                if len(parts) < 2:
                    continue

                name = parts[0].rstrip("*")
                is_default = "*" in parts[0]
                driver = parts[1] if len(parts) > 1 else "unknown"
                status = "running" if "running" in line.lower() else "inactive"

                # Parse platforms (usually in format: linux/amd64, linux/arm64)
                platforms = []
                platform_match = line.split()
                for part in platform_match:
                    if "/" in part and ("linux" in part or "darwin" in part):
                        # Clean up platform string
                        platform = part.rstrip(",").strip()
                        if platform not in platforms:
                            platforms.append(platform)

                # Detect cloud builders
                is_cloud = "cloud" in driver.lower() or "cloud" in name.lower()

                # Fallback: if no platforms detected, check if multi-platform capable
                if not platforms:
                    if driver in ["docker-container", "kubernetes", "cloud"]:
                        platforms = ["linux/amd64", "linux/arm64"]  # Assume multi-platform
                    else:
                        # Detect host platform
                        host_platform = self._get_host_platform()
                        platforms = [host_platform]

                builder = BuilderInfo(
                    name=name,
                    driver=driver,
                    platforms=platforms,
                    status=status,
                    is_cloud=is_cloud,
                    is_default=is_default,
                )
                builders.append(builder)

        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired) as e:
            self.logger.debug(f"Failed to detect builders: {e}")
            # Return minimal default builder info
            host_platform = self._get_host_platform()
            builders = [
                BuilderInfo(
                    name="default",
                    driver="docker",
                    platforms=[host_platform],
                    status="unknown",
                    is_default=True,
                )
            ]

        self._cached_builders = builders
        return builders

    def _get_host_platform(self) -> str:
        """Get current host platform."""
        system = py_platform.system().lower()
        machine = py_platform.machine().lower()

        # Map Python's machine names to Docker platform names
        arch_map = {
            "x86_64": "amd64",
            "amd64": "amd64",
            "arm64": "arm64",
            "aarch64": "arm64",
        }

        arch = arch_map.get(machine, machine)

        if system == "darwin":
            return f"darwin/{arch}"
        elif system == "linux":
            return f"linux/{arch}"
        elif system == "windows":
            return f"windows/{arch}"
        else:
            return f"linux/{arch}"  # Fallback

    async def detect_system_resources(self) -> SystemResources:
        """Detect system resources (CPU, RAM, disk space)."""
        if self._cached_resources:
            return self._cached_resources

        # CPU cores
        cpu_cores = os.cpu_count() or 1

        # RAM in GB
        ram_bytes = psutil.virtual_memory().total
        ram_gb = ram_bytes / (1024**3)

        # Disk space in GB
        disk_usage = shutil.disk_usage("/")
        disk_free_gb = disk_usage.free / (1024**3)

        # Check Docker daemon
        docker_running = await self._is_docker_running()

        # Check buildx availability
        buildx_available = await self._has_local_buildx()

        # Platform
        platform = py_platform.system().lower()

        resources = SystemResources(
            cpu_cores=cpu_cores,
            ram_gb=round(ram_gb, 1),
            disk_free_gb=round(disk_free_gb, 1),
            docker_running=docker_running,
            buildx_available=buildx_available,
            platform=platform,
        )

        self._cached_resources = resources
        return resources

    async def _is_docker_running(self) -> bool:
        """Check if Docker daemon is running."""
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
            return False

    async def analyze_and_guide(
        self, platforms: List[str], skip_guidance: bool = False
    ) -> BuildGuidanceResult:
        """Analyze environment and provide build guidance."""
        # Detect resources and builders
        resources = await self.detect_system_resources()
        builders = await self.detect_all_builders()

        reasons = []
        resource_warnings = []
        recommend_cicd = False

        # Check if in CI/CD (skip guidance)
        if self._is_ci_environment() or skip_guidance or not sys.stdout.isatty():
            # Non-interactive environment, use best available builder
            cloud_builder = next((b for b in builders if b.is_cloud), None)
            if cloud_builder:
                return BuildGuidanceResult(
                    recommend_cicd=False,
                    reasons=[],
                    recommended_builder=cloud_builder.name,
                    alternative_builders=[b.name for b in builders if not b.is_cloud],
                )
            else:
                buildx_builders = [b for b in builders if "buildx" in b.driver or b.driver == "docker-container"]
                if buildx_builders:
                    return BuildGuidanceResult(
                        recommend_cicd=False,
                        reasons=[],
                        recommended_builder=buildx_builders[0].name,
                        alternative_builders=[b.name for b in builders if b not in buildx_builders],
                    )
                else:
                    return BuildGuidanceResult(
                        recommend_cicd=False,
                        reasons=[],
                        recommended_builder=builders[0].name if builders else "default",
                    )

        # Check Docker daemon
        if not resources.docker_running:
            reasons.append("Docker daemon is not running")
            recommend_cicd = True

        # Check RAM
        if resources.ram_gb < self.MIN_RAM_GB:
            reasons.append(f"Low RAM: {resources.ram_gb}GB (minimum recommended: {self.MIN_RAM_GB}GB)")
            resource_warnings.append(f"⚠️  RAM: {resources.ram_gb}GB < {self.MIN_RAM_GB}GB recommended")
            recommend_cicd = True

        # Check disk space
        if resources.disk_free_gb < self.MIN_DISK_GB:
            reasons.append(f"Low disk space: {resources.disk_free_gb}GB (minimum: {self.MIN_DISK_GB}GB)")
            resource_warnings.append(f"⚠️  Disk: {resources.disk_free_gb}GB < {self.MIN_DISK_GB}GB recommended")
            recommend_cicd = True

        # Check multi-platform build
        if len(platforms) > 1:
            reasons.append(f"Multi-platform build requested ({', '.join(platforms)})")
            if resources.ram_gb < self.COMFORTABLE_RAM_GB:
                resource_warnings.append(f"⚠️  Multi-platform builds work best with {self.COMFORTABLE_RAM_GB}GB+ RAM")

        # Check if buildx available
        if not resources.buildx_available and len(platforms) > 1:
            reasons.append("Docker Buildx not available for multi-platform builds")
            recommend_cicd = True

        # Find best available builder
        recommended_builder = None
        alternative_builders = []

        # Priority 1: Cloud builder
        cloud_builders = [b for b in builders if b.is_cloud and b.status == "running"]
        if cloud_builders:
            recommended_builder = cloud_builders[0].name
            alternative_builders = [b.name for b in builders if not b.is_cloud]
        else:
            # Priority 2: Multi-platform buildx builder
            multi_platform_builders = [
                b for b in builders
                if len(b.platforms) > 1 and b.status == "running"
            ]
            if multi_platform_builders:
                recommended_builder = multi_platform_builders[0].name
                alternative_builders = [b.name for b in builders if b not in multi_platform_builders]
            else:
                # Priority 3: Any running builder
                running_builders = [b for b in builders if b.status == "running"]
                if running_builders:
                    recommended_builder = running_builders[0].name
                    alternative_builders = [b.name for b in builders if b.status != "running"]

        return BuildGuidanceResult(
            recommend_cicd=recommend_cicd,
            reasons=reasons,
            recommended_builder=recommended_builder,
            alternative_builders=alternative_builders,
            resource_warnings=resource_warnings,
        )

    def _is_ci_environment(self) -> bool:
        """Detect if running in CI/CD environment."""
        ci_indicators = [
            "CI",
            "GITHUB_ACTIONS",
            "GITLAB_CI",
            "JENKINS_HOME",
            "CIRCLECI",
            "TRAVIS",
            "BUILDKITE",
            "DRONE",
        ]
        return any(os.getenv(var) for var in ci_indicators)

    async def _has_docker_build_cloud(self) -> bool:
        """Check if Docker Build Cloud is available."""
        try:
            result = subprocess.run(
                ["docker", "buildx", "ls"], capture_output=True, text=True, check=True
            )
            # Find any builder using the cloud driver
            for line in result.stdout.splitlines():
                parts = line.split()
                if len(parts) >= 2 and parts[1] == "cloud":
                    # Store the cloud builder name (strip trailing *)
                    self._cloud_builder_name = parts[0].rstrip("*")
                    return True
            return False
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    async def _has_local_buildx(self) -> bool:
        """Check if Docker buildx is available."""
        try:
            result = subprocess.run(
                ["docker", "buildx", "version"],
                capture_output=True,
                text=True,
                check=True,
            )
            return bool(result.stdout.strip())
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    async def check_registry_login(self, registry: str) -> bool:
        """Check if logged into the specified registry by reading Docker config."""
        try:
            # Read Docker config file
            docker_config_path = Path.home() / ".docker" / "config.json"
            
            if not docker_config_path.exists():
                return False
            
            with open(docker_config_path, "r") as f:
                config = json.load(f)
            
            # Check auths section for registry
            auths = config.get("auths", {})
            cred_helpers = config.get("credHelpers", {})
            
            # Normalize registry URL (handle registry.digitalocean.com, docker.io, etc.)
            registry_normalized = registry.rstrip("/")
            
            # Check credHelpers (GCP, AWS ECR, etc.)
            for helper_registry in cred_helpers.keys():
                if helper_registry in registry_normalized or registry_normalized.startswith(helper_registry):
                    return True
            
            # Check if registry exists in auths
            for auth_registry in auths.keys():
                auth_registry_normalized = auth_registry.rstrip("/")
                if registry_normalized in auth_registry_normalized or auth_registry_normalized in registry_normalized:
                    # Found auth entry, check if it has credentials
                    auth_entry = auths[auth_registry]
                    if auth_entry and (auth_entry.get("auth") or auth_entry.get("identitytoken")):
                        return True
            
            return False
            
        except (FileNotFoundError, json.JSONDecodeError, PermissionError) as e:
            self.logger.debug(f"Failed to check Docker login status: {e}")
            return False


class VulnerabilityScanner:
    """Multi-tiered vulnerability scanning system."""

    def __init__(self, logger, scan_level: ScanLevel):
        self.logger = logger
        self.scan_level = scan_level

    async def scan_image(self, registry_image: str, force_push: bool) -> ScanResult:
        """Scan image using best available scanner."""

        if self.scan_level == ScanLevel.NONE:
            self.logger.warning("⚠️  Security scanning disabled (development mode)")
            return ScanResult(
                scanner="none",
                vulnerabilities=[],
                risk_level="unknown",
                critical_count=0,
                high_count=0,
                passed=True,
                timestamp=time.time(),
            )

        # Try Trivy first (most common)
        if await self._has_trivy():
            return await self._scan_with_trivy(registry_image, force_push)

        # Try Grype as fallback
        if await self._has_grype():
            return await self._scan_with_grype(registry_image, force_push)

        # No scanner available
        if self.scan_level == ScanLevel.STRICT:
            raise Exception("Strict scan level requires Trivy or Grype installed")

        self.logger.warning(
            "⚠️  No vulnerability scanner found (install Trivy or Grype)"
        )
        return ScanResult(
            scanner="none",
            vulnerabilities=[],
            risk_level="unknown",
            critical_count=0,
            high_count=0,
            passed=True,
            timestamp=time.time(),
        )

    async def _has_trivy(self) -> bool:
        """Check if Trivy is installed."""
        try:
            subprocess.run(["trivy", "version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    async def _has_grype(self) -> bool:
        """Check if Grype is installed."""
        try:
            subprocess.run(["grype", "version"], capture_output=True, check=True)
            return True
        except (subprocess.CalledProcessError, FileNotFoundError):
            return False

    async def _scan_with_trivy(self, image: str, force_push: bool) -> ScanResult:
        """Scan with Trivy."""
        self.logger.info("🔒 Scanning with Trivy...")

        try:
            result = subprocess.run(
                ["trivy", "image", "--format", "json", "--quiet", image],
                capture_output=True,
                text=True,
                check=True,
                timeout=300,  # 5 minute timeout
            )

            trivy_data = json.loads(result.stdout)

            vulnerabilities = []
            critical_count = 0
            high_count = 0

            for res in trivy_data.get("Results", []):
                for vuln in res.get("Vulnerabilities", []):
                    severity = vuln.get("Severity", "UNKNOWN")
                    if severity == "CRITICAL":
                        critical_count += 1
                    elif severity == "HIGH":
                        high_count += 1

                    vulnerabilities.append(
                        {
                            "id": vuln.get("VulnerabilityID"),
                            "severity": severity,
                            "package": vuln.get("PkgName"),
                            "version": vuln.get("InstalledVersion"),
                            "fixed_version": vuln.get("FixedVersion"),
                            "title": vuln.get("Title", "")[:100],  # Truncate
                        }
                    )

            # Determine if scan passed based on scan level
            passed = self._evaluate_scan_results(critical_count, high_count, force_push)
            risk_level = self._calculate_risk_level(
                critical_count, high_count, len(vulnerabilities)
            )

            self.logger.info(
                f"🔒 Scan complete: {len(vulnerabilities)} total, {critical_count} critical, {high_count} high"
            )

            return ScanResult(
                scanner="trivy",
                vulnerabilities=vulnerabilities[:20],  # Keep top 20 for reporting
                risk_level=risk_level,
                critical_count=critical_count,
                high_count=high_count,
                passed=passed,
                timestamp=time.time(),
            )

        except subprocess.TimeoutExpired:
            self.logger.warning("⚠️  Trivy scan timed out after 5 minutes")
            return ScanResult(
                scanner="trivy-timeout",
                vulnerabilities=[],
                risk_level="unknown",
                critical_count=0,
                high_count=0,
                passed=force_push,
                timestamp=time.time(),
            )
        except Exception as e:
            self.logger.warning(f"⚠️  Trivy scan failed: {e}")
            return ScanResult(
                scanner="trivy-failed",
                vulnerabilities=[],
                risk_level="unknown",
                critical_count=0,
                high_count=0,
                passed=force_push,
                timestamp=time.time(),
            )

    async def _scan_with_grype(self, image: str, force_push: bool) -> ScanResult:
        """Scan with Grype (alternative scanner)."""
        self.logger.info("🔒 Scanning with Grype...")

        try:
            result = subprocess.run(
                ["grype", image, "-o", "json"],
                capture_output=True,
                text=True,
                check=True,
                timeout=300,
            )

            grype_data = json.loads(result.stdout)
            vulnerabilities = []
            critical_count = 0
            high_count = 0

            for vuln in grype_data.get("matches", []):
                severity = vuln.get("vulnerability", {}).get("severity", "Unknown")
                if severity == "Critical":
                    critical_count += 1
                elif severity == "High":
                    high_count += 1

                vulnerabilities.append(
                    {
                        "id": vuln.get("vulnerability", {}).get("id"),
                        "severity": severity,
                        "package": vuln.get("artifact", {}).get("name"),
                        "version": vuln.get("artifact", {}).get("version"),
                    }
                )

            passed = self._evaluate_scan_results(critical_count, high_count, force_push)
            risk_level = self._calculate_risk_level(
                critical_count, high_count, len(vulnerabilities)
            )

            return ScanResult(
                scanner="grype",
                vulnerabilities=vulnerabilities[:20],
                risk_level=risk_level,
                critical_count=critical_count,
                high_count=high_count,
                passed=passed,
                timestamp=time.time(),
            )

        except Exception as e:
            self.logger.warning(f"⚠️  Grype scan failed: {e}")
            return ScanResult(
                scanner="grype-failed",
                vulnerabilities=[],
                risk_level="unknown",
                critical_count=0,
                high_count=0,
                passed=force_push,
                timestamp=time.time(),
            )

    def _evaluate_scan_results(self, critical: int, high: int, force: bool) -> bool:
        """Determine if scan results meet scan level requirements."""
        if force:
            return True

        if self.scan_level == ScanLevel.STRICT:
            return critical == 0 and high == 0
        elif self.scan_level == ScanLevel.STANDARD:
            return critical == 0
        elif self.scan_level == ScanLevel.BASIC:
            return critical < 5  # Allow some critical with warning

        return True

    def _calculate_risk_level(self, critical: int, high: int, total: int) -> str:
        """Calculate overall risk level."""
        if critical > 0:
            return "critical"
        elif high > 5:
            return "high"
        elif high > 0 or total > 20:
            return "medium"
        elif total > 0:
            return "low"
        return "negligible"


class HexrPusher:
    """Enterprise-grade Docker build and push orchestrator."""

    def __init__(self, config: PushConfig):
        self.config = config
        self.logger = get_logger("hexr.push")
        self.strategy_detector = BuildStrategyDetector(self.logger)
        self.scanner = VulnerabilityScanner(self.logger, config.scan_level)

    async def push(self) -> PushResult:
        """Execute complete build and push workflow."""
        start_time = time.time()

        try:
            # Derive image name from build artifacts
            image_name = await self._get_image_name()
            self.logger.info(f"🚀 Starting hexr push for {image_name}")

            # Step 1: Detect or use specified build strategy
            strategy = (
                self.config.build_strategy
                or await self.strategy_detector.detect_best_strategy()
            )

            # Step 2: Build and push Docker image (multi-platform if supported)
            registry_url, image_digest, platforms = await self._build_and_push(
                image_name, strategy
            )

            # Step 3: Vulnerability scanning
            scan_result = None
            if self.config.scan_level != ScanLevel.NONE and not self.config.dry_run:
                scan_result = await self.scanner.scan_image(
                    registry_url, self.config.force_push
                )

                if not scan_result.passed:
                    raise Exception(
                        f"Security scan failed: {scan_result.critical_count} critical, "
                        f"{scan_result.high_count} high vulnerabilities. Use --force to push anyway."
                    )

            duration = time.time() - start_time

            return PushResult(
                success=True,
                registry_url=registry_url,
                image_digest=image_digest,
                platforms=platforms,
                scan_result=scan_result,
                build_strategy=strategy,
                duration=duration,
            )

        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"❌ Push failed: {e}")

            return PushResult(success=False, duration=duration, error=str(e))

    async def _get_image_name(self) -> str:
        """Derive image name from build artifacts."""
        # Read from manifests/agent-pod.yaml to get agent name
        agent_pod_yaml = self.config.build_dir / "manifests" / "agent-pod.yaml"
        if agent_pod_yaml.exists():
            import yaml

            with open(agent_pod_yaml) as f:
                pod_spec = yaml.safe_load(f)

            # Extract agent name from annotations
            agent_name = (
                pod_spec.get("metadata", {})
                .get("annotations", {})
                .get("hexr.io/agent-name", "")
            )
            if agent_name:
                # Replace underscores with hyphens for Docker image naming
                return agent_name.replace("_", "-")

        # Fallback to build-summary.json
        build_summary = self.config.build_dir / "build-summary.json"
        if build_summary.exists():
            with open(build_summary) as f:
                summary = json.load(f)

            # Extract agent name from image name (format: tenant-agent_name:tag)
            image_name = summary.get("image_name", "")
            if ":" in image_name:
                agent_name = image_name.split(":")[0]
                # Remove tenant prefix if present
                if "-" in agent_name:
                    agent_name = "-".join(agent_name.split("-")[1:])
                return agent_name

        # Last resort: use parent directory name
        agent_name = self.config.build_dir.parent.name
        return agent_name.lower().replace("_", "-")

    async def _build_and_push(
        self, image_name: str, strategy: BuildStrategy
    ) -> tuple[str, str, List[str]]:
        """Build Docker image and push to registry using selected strategy."""

        # Build fully qualified registry image name
        registry_image = f"{self.config.registry}/{self.config.tenant}/{image_name}:{self.config.tag}"

        self.logger.info(f"🏗️  Building {image_name} with strategy: {strategy.value}")
        self.logger.info(f"📦 Target: {registry_image}")

        # Select platforms (auto-detect or use specified)
        platforms = (
            self.config.platforms
            if self.config.platforms
            else await self._detect_target_platforms()
        )

        if strategy == BuildStrategy.CLOUD:
            image_digest = await self._build_with_cloud(registry_image, platforms)
        elif strategy == BuildStrategy.LOCAL_BUILDX:
            image_digest = await self._build_with_buildx(registry_image, platforms)
        elif strategy == BuildStrategy.LOCAL_BASIC:
            if len(platforms) > 1:
                self.logger.warning(
                    "⚠️  Basic Docker build supports single platform only, using first: "
                    + platforms[0]
                )
                platforms = [platforms[0]]
            image_digest = await self._build_with_basic(registry_image, platforms[0])
        elif strategy == BuildStrategy.CI_REMOTE:
            raise Exception(
                "CI_REMOTE strategy requires CI/CD environment configuration"
            )

        return registry_image, image_digest, platforms

    async def _detect_target_platforms(self) -> List[str]:
        """Auto-detect target platforms from K8s cluster or default to common platforms."""
        # Default to multi-platform (most common for K8s)
        default_platforms = ["linux/amd64", "linux/arm64"]

        # TODO: Could detect from K8s cluster node architectures
        # kubectl get nodes -o jsonpath='{.items[*].status.nodeInfo.architecture}'

        self.logger.info(f"🎯 Target platforms: {', '.join(default_platforms)}")
        return default_platforms

    async def _build_with_cloud(self, registry_image: str, platforms: List[str]) -> str:
        """Build with Docker Build Cloud (FASTEST for multi-platform)."""
        self.logger.info("☁️  Building with Docker Build Cloud...")

        platform_str = ",".join(platforms)

        # Use dynamically detected cloud builder name
        builder_name = getattr(self.strategy_detector, '_cloud_builder_name', 'cloud-sugiv-hexr')

        cmd = [
            "docker",
            "buildx",
            "build",
            "--builder",
            builder_name,
            "--platform",
            platform_str,
            "--push",  # Build and push in one step
            "-t",
            registry_image,
            ".",  # Build context is current directory (we're running from build_dir)
        ]

        if self.config.build_cache:
            cmd.extend(
                [
                    "--cache-from",
                    f"type=registry,ref={registry_image}-cache",
                    "--cache-to",
                    f"type=registry,ref={registry_image}-cache,mode=max",
                ]
            )

        if self.config.dry_run:
            self.logger.info(f"🔍 DRY RUN: {' '.join(cmd)}")
            return "dry-run-digest"

        try:
            # Stream output in real-time to avoid buffer blocking with long builds
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,  # Combine stderr into stdout
                text=True,
                cwd=self.config.build_dir,
            )

            output_lines = []
            # Read output line by line in real-time
            if process.stdout:
                for line in process.stdout:
                    output_lines.append(line)
                    if self.config.verbose:
                        print(line, end="")  # Show progress if verbose

            # Wait for process to complete
            return_code = process.wait(timeout=900)

            if return_code != 0:
                output = "".join(output_lines)
                raise subprocess.CalledProcessError(return_code, cmd, output, output)

            # Extract digest from output
            output = "".join(output_lines)
            digest = self._extract_digest(output)
            self.logger.info(f"✓ Cloud build complete: {digest}")
            return digest

        except subprocess.TimeoutExpired:
            self.logger.error("⏱️  Docker Build Cloud timed out after 15 minutes")
            raise Exception(
                "Docker Build Cloud build exceeded 15 minute timeout. "
                "This may indicate: 1) Network issues, 2) Heavy dependencies, 3) Cloud builder limits. "
                "Try: hexr push --build-strategy local-buildx (slower but more reliable)"
            )
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Build output: {e.stdout}")
            self.logger.error(f"Build error: {e.stderr}")

            # Better error messages for common issues
            if "Canceled: context canceled" in e.stderr:
                raise Exception(
                    "Docker Build Cloud cancelled the build. This usually means: \n"
                    "1. Network connectivity issues\n"
                    "2. Docker Build Cloud service interruption\n"
                    "3. Build exceeded cloud builder limits\n"
                    "Try: hexr push --build-strategy local-buildx --platform linux/amd64 (single platform)"
                )
            elif "connection" in e.stderr.lower():
                raise Exception(f"Network error with Docker Build Cloud: {e.stderr}")
            else:
                raise Exception(f"Cloud build failed: {e.stderr}")

    def _get_buildx_driver(self) -> str:
        """Detect the current buildx driver type."""
        try:
            result = subprocess.run(
                ["docker", "buildx", "inspect", "--bootstrap"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            output = result.stdout + result.stderr
            
            if "docker-container" in output.lower():
                return "docker-container"
            if "kubernetes" in output.lower():
                return "kubernetes"
            if "cloud" in output.lower():
                return "cloud"
            
            # Default docker driver
            return "docker"
        except Exception:
            return "docker"

    def _supports_cache_export(self) -> bool:
        """Check if current buildx driver supports cache export."""
        driver = self._get_buildx_driver()
        return driver in ("docker-container", "kubernetes", "cloud")

    def _supports_multi_platform(self) -> bool:
        """Check if current buildx driver supports multi-platform builds."""
        driver = self._get_buildx_driver()
        return driver in ("docker-container", "kubernetes", "cloud")

    async def _build_with_buildx(
        self, registry_image: str, platforms: List[str]
    ) -> str:
        """Build with local Docker Buildx (QEMU emulation for multi-platform)."""
        self.logger.info("🔨 Building with Docker Buildx...")

        # Check if driver supports multi-platform
        if len(platforms) > 1 and not self._supports_multi_platform():
            self.logger.warning(
                f"⚠️  Docker driver doesn't support multi-platform builds. "
                f"Falling back to single platform: {platforms[0]}"
            )
            platforms = [platforms[0]]

        platform_str = ",".join(platforms)

        cmd = [
            "docker",
            "buildx",
            "build",
            "--platform",
            platform_str,
            "--push",
            "-t",
            registry_image,
            ".",
        ]

        # Only add cache options if driver supports it (not the default 'docker' driver)
        if self.config.build_cache and self._supports_cache_export():
            cmd.extend(
                [
                    "--cache-from",
                    f"type=registry,ref={registry_image}-cache",
                    "--cache-to",
                    f"type=registry,ref={registry_image}-cache,mode=max",
                ]
            )
        elif self.config.build_cache:
            self.logger.info("ℹ️  Skipping cache export (not supported by docker driver)")

        if self.config.dry_run:
            self.logger.info(f"🔍 DRY RUN: {' '.join(cmd)}")
            return "dry-run-digest"

        try:
            # Stream output in real-time
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=self.config.build_dir,
            )

            output_lines = []
            if process.stdout:
                for line in process.stdout:
                    output_lines.append(line)
                    if self.config.verbose:
                        print(line, end="")

            return_code = process.wait(timeout=600)

            if return_code != 0:
                output = "".join(output_lines)
                raise subprocess.CalledProcessError(return_code, cmd, output, output)

            output = "".join(output_lines)
            digest = self._extract_digest(output)
            self.logger.info(f"✓ Buildx build complete: {digest}")
            return digest

        except subprocess.TimeoutExpired:
            self.logger.error("⏱️  Local buildx timed out after 10 minutes")
            raise Exception(
                "Local buildx build exceeded 10 minute timeout. "
                "Try: hexr push --platform linux/amd64 (single platform only)"
            )
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Build output: {e.stdout}")
            self.logger.error(f"Build error: {e.stderr}")
            raise Exception(f"Buildx build failed: {e.stderr}")

    async def _build_with_basic(self, registry_image: str, platform: str) -> str:
        """Build with basic Docker (single platform, last resort)."""
        self.logger.info(f"🔧 Building with basic Docker for {platform}...")

        cmd = ["docker", "build", "--platform", platform, "-t", registry_image, "."]

        if self.config.dry_run:
            self.logger.info(f"🔍 DRY RUN: {' '.join(cmd)}")
            # Push separately for basic build
            self.logger.info(f"🔍 DRY RUN: docker push {registry_image}")
            return "dry-run-digest"

        try:
            # Build locally with streaming output
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=self.config.build_dir,
            )

            if process.stdout:
                for line in process.stdout:
                    if self.config.verbose:
                        print(line, end="")

            return_code = process.wait(timeout=300)
            if return_code != 0:
                raise subprocess.CalledProcessError(return_code, cmd)

            # Push separately (basic build doesn't have --push)
            push_process = subprocess.Popen(
                ["docker", "push", registry_image],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )

            output_lines = []
            if push_process.stdout:
                for line in push_process.stdout:
                    output_lines.append(line)
                    if self.config.verbose:
                        print(line, end="")

            return_code = push_process.wait(timeout=300)
            if return_code != 0:
                raise subprocess.CalledProcessError(
                    return_code, ["docker", "push", registry_image]
                )

            output = "".join(output_lines)
            digest = self._extract_digest(output)
            self.logger.info(f"✓ Basic build and push complete: {digest}")
            return digest

        except subprocess.TimeoutExpired:
            self.logger.error("⏱️  Basic docker build/push timed out")
            raise Exception("Basic docker build exceeded timeout")
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Build error: {e.stderr}")
            raise Exception(f"Basic build failed: {e.stderr}")

    def _extract_digest(self, output: str) -> str:
        """Extract image digest from Docker output."""
        # Look for sha256:... pattern
        import re

        match = re.search(r"sha256:[a-f0-9]{64}", output)
        if match:
            return match.group(0)
        return "unknown-digest"

    async def _verify_registry_auth(self):
        """Verify registry authentication is configured."""
        self.logger.info("🔐 Verifying registry authentication...")

        # Check if doctl is installed
        try:
            result = subprocess.run(
                ["doctl", "version"], capture_output=True, text=True, check=True
            )
            self.logger.debug(f"doctl version: {result.stdout.strip()}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            raise Exception("doctl CLI not found. Install and configure it first.")

        # Check authentication
        try:
            result = subprocess.run(
                ["doctl", "auth", "list"], capture_output=True, text=True, check=True
            )
            if not result.stdout.strip():
                raise Exception(
                    "No doctl authentication found. Run 'doctl auth init' first."
                )
        except subprocess.CalledProcessError:
            raise Exception("doctl authentication verification failed.")

        # Check registry access - skip for now due to multiple registries issue
        try:
            result = subprocess.run(
                ["doctl", "registry", "repository", "list"],
                capture_output=True,
                text=True,
                check=True,
            )
            self.logger.debug("DO registry access verified")
        except subprocess.CalledProcessError as e:
            if "multiple registries" in e.stderr:
                self.logger.warning(
                    "Multiple registries detected - skipping registry check"
                )
                # Continue execution as we know the registry exists
            elif "registry not found" in e.stderr.lower():
                raise Exception(
                    "DO Container Registry not found. Create one in DO dashboard first."
                )
            else:
                self.logger.warning(f"Registry access check inconclusive: {e.stderr}")
                # Continue execution for now

    async def _old_security_scan(self, image_name: str) -> dict[str, Any]:
        """Perform security scan on container image."""
        self.logger.info("🔒 Running security scan...")

        scan_results = {
            "vulnerabilities": [],
            "risk_level": "low",
            "scan_timestamp": time.time(),
            "scanner": "trivy",  # We'll use Trivy for scanning
        }

        try:
            # Use Trivy for security scanning if available
            result = subprocess.run(
                ["trivy", "image", "--format", "json", image_name],
                capture_output=True,
                text=True,
                check=True,
            )

            trivy_output = json.loads(result.stdout)

            # Parse Trivy results
            total_vulns = 0
            critical_vulns = 0

            for result_item in trivy_output.get("Results", []):
                vulnerabilities = result_item.get("Vulnerabilities", [])
                total_vulns += len(vulnerabilities)

                for vuln in vulnerabilities:
                    if vuln.get("Severity") == "CRITICAL":
                        critical_vulns += 1
                        scan_results["vulnerabilities"].append(
                            {
                                "id": vuln.get("VulnerabilityID"),
                                "severity": vuln.get("Severity"),
                                "title": vuln.get("Title"),
                                "package": vuln.get("PkgName"),
                            }
                        )

            # Determine risk level
            if critical_vulns > 0:
                scan_results["risk_level"] = "critical"
            elif total_vulns > 10:
                scan_results["risk_level"] = "high"
            elif total_vulns > 5:
                scan_results["risk_level"] = "medium"

            self.logger.info(
                f"🔒 Scan complete: {total_vulns} vulnerabilities, {critical_vulns} critical"
            )

            # Block push if critical vulnerabilities found (unless forced)
            if critical_vulns > 0 and not self.config.force_push:
                raise Exception(
                    f"Critical vulnerabilities found ({critical_vulns}). Use --force to push anyway."
                )

        except FileNotFoundError:
            self.logger.warning("Trivy not found. Skipping detailed security scan.")
            scan_results["scanner"] = "none"
        except subprocess.CalledProcessError:
            self.logger.warning("Security scan failed. Continuing with push.")
            scan_results["scanner"] = "failed"

        return scan_results

    async def _push_to_registry(self, registry_image: str) -> tuple[str, str]:
        """Push image to DO Container Registry."""
        self.logger.info("📤 Pushing to DO registry...")

        try:
            # First, ensure we're logged in to DO registry
            subprocess.run(
                ["doctl", "registry", "login"],
                capture_output=True,
                text=True,
                check=True,
            )

            # Push the image
            result = subprocess.run(
                ["docker", "push", registry_image],
                capture_output=True,
                text=True,
                check=True,
            )

            # Extract digest from push output (check both stderr and stdout)
            image_digest = None

            # Check stderr first (most common location for digest)
            for line in result.stderr.split("\n"):
                if "digest:" in line:
                    image_digest = line.split("digest: ")[1].strip()
                    break

            # If not found in stderr, check stdout
            if not image_digest:
                for line in result.stdout.split("\n"):
                    if "digest:" in line:
                        image_digest = line.split("digest: ")[1].strip()
                        break

            registry_url = registry_image
            self.logger.info(f"✅ Successfully pushed to {registry_url}")

            return registry_url, image_digest or "unknown"

        except subprocess.CalledProcessError as e:
            raise Exception(f"Failed to push image: {e.stderr}")


@click.command()
@click.argument("build_dir", type=click.Path(exists=False), default=".hexr")
@click.option(
    "--registry",
    "-r",
    default="us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images",
    help="Container registry URL (default: GCP AR hexr-images)",
)
@click.option(
    "--tenant", "-t", required=True, help="Tenant name for repository organization"
)
@click.option(
    "--tag", "-T", default="development", help="Image tag (default: development)"
)
@click.option(
    "--platform",
    "-p",
    multiple=True,
    help="Target platform(s) for multi-platform build (e.g., linux/amd64, linux/arm64)",
)
@click.option(
    "--scan-level",
    type=click.Choice(["none", "basic", "standard", "strict"], case_sensitive=False),
    default="standard",
    help="Security scan level (none=skip, basic=warn, standard=block-critical, strict=block-all)",
)
@click.option(
    "--build-strategy",
    type=click.Choice(
        ["cloud", "local-buildx", "local-basic", "ci-remote"], case_sensitive=False
    ),
    help="Force specific build strategy (default: auto-detect)",
)
@click.option(
    "--force", "-f", is_flag=True, help="Force push even with security issues"
)
@click.option("--no-cache", is_flag=True, help="Disable build cache optimization")
@click.option(
    "--dry-run", is_flag=True, help="Show what would be pushed without actually pushing"
)
@click.option("--verbose", "-v", is_flag=True, help="Verbose output")
@click.option("--debug", "-d", is_flag=True, help="Debug output")
@click.option(
    "--builder",
    help="Force specific builder (e.g., default, desktop-linux, hexr-cloud-builder)",
)
@click.option(
    "--skip-guidance",
    is_flag=True,
    help="Skip interactive guidance and use best available builder",
)
@click.option(
    "--init-cicd",
    is_flag=True,
    help="Generate CI/CD templates (GitHub Actions, GitLab CI) and exit",
)
@click.option(
    "--cloud",
    is_flag=True,
    help="Push via Hexr Cloud (server-side build). Requires 'hexr login' first.",
)
def push_command(
    build_dir: str,
    registry: str,
    tenant: str,
    tag: str,
    platform: tuple,
    scan_level: str,
    build_strategy: Optional[str],
    force: bool,
    no_cache: bool,
    dry_run: bool,
    verbose: bool,
    debug: bool,
    builder: Optional[str],
    skip_guidance: bool,
    init_cicd: bool,
    cloud: bool,
):
    """
    Build Docker image from hexr build artifacts and push to registry.

    BUILD_DIR: Path to .hexr directory (default: .hexr in current directory)

    Examples:
        # From workspace root (standard usage)
        hexr push --tenant acme
        hexr push --tenant acme --tag production --platform linux/amd64 --platform linux/arm64
        hexr push --tenant acme --build-strategy cloud --scan-level strict

        # Explicit path to .hexr directory
        hexr push /path/to/project/.hexr --tenant acme
    """
    from pathlib import Path
    import os

    # Setup logging early
    if debug:
        logging.basicConfig(level=logging.DEBUG)
    elif verbose:
        logging.basicConfig(level=logging.INFO)

    # Resolve build_dir to absolute path from current working directory
    build_dir_path = Path(os.getcwd()) / build_dir

    # Detect whether the user explicitly passed --registry on the command line.
    # When they did, that value MUST win over any inferred / auto-detected source.
    # (Bug 2026-05-10: previously build-summary.json silently clobbered the user's
    # --registry flag, landing images at the wrong AR path.)
    user_set_registry = False
    try:
        ctx = click.get_current_context()
        if ctx.get_parameter_source("registry").name == "COMMANDLINE":
            user_set_registry = True
    except Exception:
        pass

    if not user_set_registry:
        # Prefer the registry recorded by `hexr build` so push follows the generated
        # artifact target rather than ambient login state.
        build_summary_path = build_dir_path / "build-summary.json"
        if build_summary_path.exists():
            try:
                with open(build_summary_path) as f:
                    build_summary = json.load(f)
                built_image_name = build_summary.get("artifacts", {}).get("image_name", "")
                if built_image_name:
                    image_without_tag = built_image_name.rsplit(":", 1)[0]
                    if "/" in image_without_tag:
                        inferred_registry = image_without_tag.rsplit("/", 2)[0]
                        if inferred_registry:
                            registry = inferred_registry
            except Exception:
                pass

        # Auto-detect Hexr Cloud login and override DO-era registry default
        try:
            from hexr.cli.cloud_config import CloudConfig
            cloud_cfg = CloudConfig.load()
            if cloud_cfg.is_authenticated and "hexr.cloud" in cloud_cfg.cloud_url:
                if registry == "registry.digitalocean.com/hexr-demo":
                    registry = "us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images"
        except Exception:
            pass

    # Handle --cloud flag: server-side build via Hexr Cloud API
    if cloud:
        _push_cloud(build_dir_path, tenant, tag, dry_run)
        return

    # Handle --init-cicd flag (generate templates and exit)
    if init_cicd:
        from .cicd_templates import CICDTemplateGenerator

        console.print("\n[bold cyan]🏗️  Generating CI/CD Templates[/bold cyan]\n")

        platforms_list = list(platform) if platform else ["linux/amd64", "linux/arm64"]
        generator = CICDTemplateGenerator(tenant, registry, platforms_list)

        # Ask which platform
        cicd_choice = Prompt.ask(
            "[bold]Select CI/CD platform[/bold]",
            choices=["github", "gitlab", "both"],
            default="github",
        )

        current_dir = Path.cwd()

        if cicd_choice in ["github", "both"]:
            workflow_file = generator.generate_github_workflow(current_dir)
            generator.display_setup_instructions("GitHub Actions", workflow_file)

        if cicd_choice in ["gitlab", "both"]:
            ci_file = generator.generate_gitlab_ci(current_dir)
            generator.display_setup_instructions("GitLab CI", ci_file)

        exit(0)

    # Validate .hexr directory exists
    if not build_dir_path.exists():
        console.print(
            f"❌ Error: Build directory not found: {build_dir_path}", style="red"
        )
        console.print(
            f"\n💡 Hint: Run 'hexr build' first to generate .hexr artifacts",
            style="yellow",
        )
        exit(1)

    if not build_dir_path.is_dir():
        console.print(f"❌ Error: {build_dir_path} is not a directory", style="red")
        exit(1)

    # Validate essential files exist
    dockerfile = build_dir_path / "Dockerfile"
    manifests_dir = build_dir_path / "manifests"

    if not dockerfile.exists():
        console.print(
            f"❌ Error: Dockerfile not found in {build_dir_path}", style="red"
        )
        console.print(
            f"💡 Hint: Run 'hexr build' to generate build artifacts", style="yellow"
        )
        exit(1)

    if not manifests_dir.exists():
        console.print(
            f"❌ Error: manifests/ directory not found in {build_dir_path}", style="red"
        )
        console.print(
            f"💡 Hint: Run 'hexr build' to generate build artifacts", style="yellow"
        )
        exit(1)

    # Interactive guidance and builder selection (if not skipped)
    selected_builder_name = builder  # Use --builder flag if provided
    platforms_list = list(platform) if platform else []

    if not skip_guidance and not builder and sys.stdout.isatty():
        # Interactive mode
        from .builder_selector import BuilderSelector

        console.print("\n[bold cyan]🔍 Analyzing your environment...[/bold cyan]")

        # Create detector to analyze environment
        logger = get_logger("hexr.push")
        detector = BuildStrategyDetector(logger)

        # Auto-detect platforms if not specified
        if not platforms_list:
            platforms_list = ["linux/amd64", "linux/arm64"]  # Default multi-platform

        try:
            # Analyze environment
            resources = asyncio.run(detector.detect_system_resources())
            builders = asyncio.run(detector.detect_all_builders())
            guidance = asyncio.run(detector.analyze_and_guide(platforms_list, skip_guidance))

            # Display analysis
            selector = BuilderSelector()
            selector.display_environment_analysis(resources, builders, guidance, platforms_list)

            # Show CI/CD recommendation if applicable
            if guidance.recommend_cicd:
                selector.display_cicd_recommendation(guidance, platforms_list)

                # Ask if user wants to generate CI/CD templates
                if selector.prompt_cicd_template_generation():
                    from .cicd_templates import CICDTemplateGenerator

                    generator = CICDTemplateGenerator(tenant, registry, platforms_list)

                    cicd_choice = Prompt.ask(
                        "\n[bold]Select CI/CD platform[/bold]",
                        choices=["github", "gitlab", "both"],
                        default="github",
                    )

                    current_dir = Path.cwd()

                    if cicd_choice in ["github", "both"]:
                        workflow_file = generator.generate_github_workflow(current_dir)
                        generator.display_setup_instructions("GitHub Actions", workflow_file)

                    if cicd_choice in ["gitlab", "both"]:
                        ci_file = generator.generate_gitlab_ci(current_dir)
                        generator.display_setup_instructions("GitLab CI", ci_file)

                    # Ask if they want to continue with local build
                    if not selector.prompt_continue_local_build():
                        selector.display_cicd_abort_message()
                        exit(0)

            # Prompt for builder selection
            if builders:
                selected_builder = selector.prompt_builder_selection(
                    builders, guidance.recommended_builder
                )
                selected_builder_name = selected_builder.name
                selector.display_final_choice(selected_builder, platforms_list)
            else:
                console.print("[yellow]⚠️  No builders detected, using default[/yellow]")
                selected_builder_name = "default"

        except KeyboardInterrupt:
            console.print("\n\n[yellow]⚠️  Cancelled by user[/yellow]")
            exit(1)
        except Exception as e:
            if debug:
                console.print(f"\n[red]Error during environment analysis: {e}[/red]")
                import traceback
                console.print(traceback.format_exc())
            # Continue with default behavior if analysis fails
            pass

    # Convert scan level string to enum
    scan_level_map = {
        "none": ScanLevel.NONE,
        "basic": ScanLevel.BASIC,
        "standard": ScanLevel.STANDARD,
        "strict": ScanLevel.STRICT,
    }

    # Convert build strategy string to enum
    strategy_map = {
        "cloud": BuildStrategy.CLOUD,
        "local-buildx": BuildStrategy.LOCAL_BUILDX,
        "local-basic": BuildStrategy.LOCAL_BASIC,
        "ci-remote": BuildStrategy.CI_REMOTE,
    }

    config = PushConfig(
        build_dir=build_dir_path,  # Absolute path to .hexr directory
        registry=registry,
        tenant=tenant,
        tag=tag,
        platforms=platforms_list if platforms_list else [],
        scan_level=scan_level_map[scan_level],
        build_strategy=strategy_map.get(build_strategy) if build_strategy else None,
        manifest_list=len(platforms_list) > 1 if platforms_list else True,
        build_cache=not no_cache,
        force_push=force,
        dry_run=dry_run,
        verbose=verbose,
        debug=debug,
    )

    # Setup logging
    if debug:
        logging.basicConfig(level=logging.DEBUG)
    elif verbose:
        logging.basicConfig(level=logging.INFO)

    # Store selected builder for use in build
    if selected_builder_name:
        os.environ["HEXR_SELECTED_BUILDER"] = selected_builder_name

    # Check Docker login status for registry
    console.print("\n🔐 Checking Docker login status...", style="cyan")
    logger = get_logger("hexr.push")
    detector = BuildStrategyDetector(logger)
    is_logged_in = asyncio.run(detector.check_registry_login(registry))
    
    if is_logged_in:
        console.print(f"✅ Already logged in to {registry}", style="green")
    else:
        console.print(f"❌ Not logged in to {registry}", style="red")
        console.print(f"\n💡 Please login to the registry first:", style="yellow")
        
        # Provide registry-specific login instructions
        if "digitalocean.com" in registry:
            console.print(f"   [cyan]doctl registry login[/cyan]")
        elif "docker.io" in registry or registry == "docker.io":
            console.print(f"   [cyan]docker login[/cyan]")
        elif "ghcr.io" in registry:
            console.print(f"   [cyan]echo $GITHUB_TOKEN | docker login ghcr.io -u USERNAME --password-stdin[/cyan]")
        elif "ecr" in registry:
            console.print(f"   [cyan]aws ecr get-login-password | docker login --username AWS --password-stdin {registry}[/cyan]")
        else:
            console.print(f"   [cyan]docker login {registry}[/cyan]")
        
        exit(1)

    # Run push
    pusher = HexrPusher(config)

    if dry_run:
        console.print(
            Panel.fit(
                "🧪 DRY RUN MODE - No actual push will occur",
                title="Dry Run",
                border_style="yellow",
            )
        )

    try:
        result = asyncio.run(pusher.push())

        if result.success:
            # Display success table
            table = Table(title="🎉 Push Successful")
            table.add_column("Property", style="cyan")
            table.add_column("Value", style="green")

            table.add_row("Registry URL", result.registry_url or "N/A")
            table.add_row("Image Digest", result.image_digest or "N/A")
            table.add_row(
                "Platforms", ", ".join(result.platforms) if result.platforms else "N/A"
            )
            table.add_row(
                "Build Strategy",
                result.build_strategy.value if result.build_strategy else "N/A",
            )
            table.add_row("Duration", f"{result.duration:.2f}s")

            if result.scan_result:
                table.add_row("Security Scanner", result.scan_result.scanner)
                table.add_row("Risk Level", result.scan_result.risk_level)
                table.add_row(
                    "Critical Vulnerabilities", str(result.scan_result.critical_count)
                )
                table.add_row(
                    "High Vulnerabilities", str(result.scan_result.high_count)
                )
                table.add_row(
                    "Total Vulnerabilities",
                    str(len(result.scan_result.vulnerabilities)),
                )

            console.print(table)

            if not dry_run:
                console.print(f"\n✅ Image available at: {result.registry_url}")
        else:
            console.print(f"\n❌ Push failed: {result.error}", style="red")
            exit(1)

    except KeyboardInterrupt:
        console.print("\n⚠️  Push cancelled by user", style="yellow")
        exit(1)
    except Exception as e:
        console.print(f"\n💥 Unexpected error: {e}", style="red")
        if debug:
            import traceback

            console.print(traceback.format_exc())
        exit(1)


def _push_cloud(build_dir: "Path", tenant: str, tag: str, dry_run: bool):
    """Push agent build to Hexr Cloud via the Cloud API.

    Creates a tarball of the .hexr/ build context and uploads it as multipart
    form data. The Cloud API uploads it to GCS and triggers Cloud Build.
    """
    import io
    import tarfile

    from hexr.cli.cloud_config import CloudConfig, get_cloud_client

    config = CloudConfig.load()
    if not config.is_authenticated:
        console.print("[red]Error:[/red] Not authenticated. Run 'hexr login --key <api_key>' first.")
        raise SystemExit(1)

    # Read agent name from build metadata / summary
    agent_name = "unknown"
    metadata_file = build_dir / "build-metadata.json"
    if metadata_file.exists():
        try:
            meta = json.loads(metadata_file.read_text())
            agent_name = meta.get("agent_name", meta.get("name", "unknown"))
        except (json.JSONDecodeError, OSError):
            pass

    if agent_name == "unknown":
        summary_file = build_dir / "build-summary.json"
        if summary_file.exists():
            try:
                summary = json.loads(summary_file.read_text())
                agent_file = summary.get("config", {}).get("agent_file", "")
                if agent_file:
                    from pathlib import PurePath
                    agent_name = PurePath(agent_file).stem
            except (json.JSONDecodeError, OSError):
                pass

    if agent_name == "unknown":
        agent_name = build_dir.parent.name

    # Normalize to K8s-compatible kebab-case (matches k8s.py image naming)
    agent_name = agent_name.replace("_", "-")

    # Create tarball of the build context
    console.print(f"\n[bold cyan]☁️  Hexr Cloud Push[/bold cyan]")
    console.print(f"  Agent:  [green]{agent_name}[/green]")
    console.print(f"  Tag:    [green]{tag}[/green]")
    console.print(f"  Tenant: [green]{tenant}[/green]")
    console.print(f"  API:    [dim]{config.cloud_url}[/dim]")

    if not build_dir.exists() or not (build_dir / "Dockerfile").exists():
        console.print("[red]Error:[/red] Build directory missing or no Dockerfile. Run 'hexr build' first.")
        raise SystemExit(1)

    # Create in-memory tarball of the build context
    tar_buffer = io.BytesIO()
    with tarfile.open(fileobj=tar_buffer, mode="w:gz") as tar:
        for item in build_dir.iterdir():
            # Skip build-summary.json (metadata only, not needed for docker build)
            if item.name == "build-summary.json":
                continue
            tar.add(str(item), arcname=item.name)
    tar_bytes = tar_buffer.getvalue()

    console.print(f"  Source: [dim]{len(tar_bytes) / 1024:.0f} KB tarball[/dim]")

    if dry_run:
        console.print(f"\n[yellow]🧪 DRY RUN — would upload {len(tar_bytes)} bytes to {config.cloud_url}/v1/cli/build[/yellow]")
        return

    try:
        with get_cloud_client(config) as client:
            resp = client.post(
                "/v1/cli/build",
                data={"agent_name": agent_name, "tag": tag},
                files={"source": ("source.tar.gz", tar_bytes, "application/gzip")},
            )
            if resp.status_code in (200, 202):
                data = resp.json().get("data", resp.json())
                console.print(f"\n[green]✓[/green] Build accepted by Hexr Cloud")
                console.print(f"  Build ID: [cyan]{data.get('build_id', 'N/A')}[/cyan]")
                console.print(f"  Image:    [cyan]{data.get('image_uri', 'N/A')}[/cyan]")
                console.print(f"  Status:   [cyan]{data.get('status', 'N/A')}[/cyan]")
                if data.get("log_url"):
                    console.print(f"  Logs:     [dim]{data['log_url']}[/dim]")
                if data.get("message"):
                    console.print(f"  Message:  [dim]{data['message']}[/dim]")
            else:
                error = resp.json().get("error", resp.text)
                console.print(f"\n[red]✗ Cloud API error ({resp.status_code}):[/red] {error}")
                raise SystemExit(1)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Failed to reach Hexr Cloud:[/red] {e}")
        raise SystemExit(1)
