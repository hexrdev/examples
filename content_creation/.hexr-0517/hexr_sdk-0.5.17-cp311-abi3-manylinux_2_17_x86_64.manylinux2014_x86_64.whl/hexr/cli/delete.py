"""
Hexr Delete Command — Remove deployed agents from Kubernetes.

Supports both local (kubectl) and cloud (API) deletion.
"""

import subprocess
import sys

import click
from rich.console import Console

console = Console()


@click.command("delete")
@click.argument("agent_name")
@click.option("--cloud", is_flag=True, help="Delete via Hexr Cloud API. Requires 'hexr login' first.")
@click.option("--namespace", "-n", help="Kubernetes namespace (local mode only)")
@click.option("--tenant", "-t", help="Tenant ID (cloud mode, admin only)")
@click.option("--dry-run", is_flag=True, help="Show what would be deleted without executing")
@click.option("--force", "-f", is_flag=True, help="Skip confirmation prompt")
def delete_command(agent_name: str, cloud: bool, namespace: str | None, tenant: str | None, dry_run: bool, force: bool):
    """Delete a deployed agent and all its Kubernetes resources.

    Removes pods, services, configmaps, service accounts, roles, and role bindings
    matching the agent name.

    Examples:
        hexr delete content-creation-crew --namespace tenant-demo
        hexr delete content-creation-crew --cloud
        hexr delete content-creation-crew --cloud --tenant partner-org
    """
    if not force and not dry_run:
        if not click.confirm(f"Delete agent '{agent_name}' and all its resources?"):
            console.print("[dim]Cancelled.[/dim]")
            return

    if cloud:
        _delete_cloud(agent_name, tenant, dry_run)
    else:
        _delete_local(agent_name, namespace, dry_run)


def _delete_cloud(agent_name: str, tenant: str | None, dry_run: bool):
    """Delete agent via Hexr Cloud API."""
    from hexr.cli.cloud_config import CloudConfig, get_cloud_client

    config = CloudConfig.load()
    if not config.is_authenticated:
        console.print("[red]Error:[/red] Not authenticated. Run 'hexr login --key <api_key>' first.")
        raise SystemExit(1)

    console.print(f"\n[bold cyan]☁️  Hexr Cloud Delete[/bold cyan]")
    console.print(f"  Agent: [green]{agent_name}[/green]")
    console.print(f"  API:   [dim]{config.cloud_url}[/dim]")

    if dry_run:
        console.print(f"\n[yellow]🧪 DRY RUN — would DELETE {config.cloud_url}/v1/cli/agents/{agent_name}[/yellow]")
        return

    try:
        with get_cloud_client(config) as client:
            params = {}
            if tenant:
                params["tenant_id"] = tenant

            resp = client.delete(f"/v1/cli/agents/{agent_name}", params=params)
            if resp.status_code == 200:
                data = resp.json().get("data", resp.json())
                console.print(f"\n[green]✓[/green] Agent deleted from Hexr Cloud")
                console.print(f"  Namespace:  [cyan]{data.get('namespace', 'N/A')}[/cyan]")
                console.print(f"  Resources:  [cyan]{data.get('resources_deleted', 'N/A')} types cleaned up[/cyan]")
                console.print(f"  Status:     [cyan]{data.get('status', 'N/A')}[/cyan]")
            else:
                error = resp.json().get("error", resp.text)
                console.print(f"\n[red]✗ Cloud API error ({resp.status_code}):[/red] {error}")
                raise SystemExit(1)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"\n[red]✗ Failed to reach Hexr Cloud:[/red] {e}")
        raise SystemExit(1)


def _delete_local(agent_name: str, namespace: str | None, dry_run: bool):
    """Delete agent via local kubectl."""
    if not namespace:
        console.print("[red]Error:[/red] --namespace is required for local deletion (or use --cloud)")
        raise SystemExit(1)

    label = f"hexr.dev/agent-name={agent_name}"
    resource_types = ["pods", "services", "configmaps", "serviceaccounts", "roles", "rolebindings"]

    console.print(f"\n[bold cyan]🗑️  Local Agent Delete[/bold cyan]")
    console.print(f"  Agent:     [green]{agent_name}[/green]")
    console.print(f"  Namespace: [green]{namespace}[/green]")

    if dry_run:
        console.print(f"\n[yellow]🧪 DRY RUN — would delete resources with label {label}[/yellow]")
        for rt in resource_types:
            console.print(f"  kubectl delete {rt} -n {namespace} -l {label}")
        return

    total_deleted = 0
    for rt in resource_types:
        try:
            result = subprocess.run(
                ["kubectl", "delete", rt, "-n", namespace, "-l", label, "--ignore-not-found"],
                capture_output=True, text=True, timeout=30,
            )
            if result.stdout.strip() and "No resources found" not in result.stdout:
                for line in result.stdout.strip().split("\n"):
                    if line.strip():
                        console.print(f"  [green]✓[/green] {line.strip()}")
                        total_deleted += 1
        except subprocess.TimeoutExpired:
            console.print(f"  [yellow]⚠ Timeout deleting {rt}[/yellow]")
        except FileNotFoundError:
            console.print("[red]Error:[/red] kubectl not found. Install kubectl or use --cloud.")
            raise SystemExit(1)

    if total_deleted == 0:
        console.print(f"\n[yellow]No resources found for agent '{agent_name}' in {namespace}[/yellow]")
    else:
        console.print(f"\n[green]✓[/green] Deleted {total_deleted} resources for agent '{agent_name}'")
