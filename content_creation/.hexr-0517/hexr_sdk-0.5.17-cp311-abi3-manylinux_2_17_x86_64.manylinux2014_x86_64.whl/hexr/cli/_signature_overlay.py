"""User-overlay signature loader (HEXR_SDK_OVERHAUL_TECH_SPEC.md §17).

The Rust analyzer's `analyze_path` accepts a single framework-pack dir and a
single pattern-pack dir. To honor the §17 promise that customers can drop
new framework / pattern signatures next to their project (or in their home
dir) without rebuilding the SDK wheel, we materialize a merged tree from
three sources, in precedence order (later wins):

  1. shipped     — packs baked into the wheel (`hexr/_native/packs/...`)
  2. user        — `~/.hexr/signatures/{frameworks,patterns}/`
  3. project     — `./hexr-signatures/{frameworks,patterns}/` (cwd-relative)

The merged tree is created in a fresh temp dir on every call; the caller is
responsible for cleanup. Pure stdlib, no I/O outside the documented dirs.
"""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

from hexr._native import default_pack_dirs

_USER_DIR_ENV = "HEXR_SIGNATURES_DIR"
_PROJECT_DIR_NAME = "hexr-signatures"


def _user_overlay_root() -> Path:
    """Return the user-scope signature root.

    Precedence:
      1. $HEXR_SIGNATURES_DIR (test / power-user override)
      2. `~/.hexr/signatures/current/` if the `current` symlink exists
         (written by `hexr update signatures` per spec §21.4.4 step 7)
      3. `~/.hexr/signatures/` (legacy flat layout)
    """
    env = os.environ.get(_USER_DIR_ENV)
    if env:
        return Path(env).expanduser().resolve()
    base = Path.home() / ".hexr" / "signatures"
    current = base / "current"
    if current.is_symlink() or current.is_dir():
        try:
            return current.resolve()
        except (OSError, RuntimeError):
            pass
    return base


def _project_overlay_root(project_root: Path | None = None) -> Path:
    """Return the project-scope signature root (./hexr-signatures)."""
    base = project_root if project_root is not None else Path.cwd()
    return (base / _PROJECT_DIR_NAME).resolve()


def overlay_sources(project_root: Path | None = None) -> list[tuple[str, Path, Path]]:
    """Enumerate the three overlay tiers.

    Returns a list of (label, frameworks_dir, patterns_dir) tuples in
    precedence order (later wins). Non-existent dirs are still returned so
    callers can report "scanned 3 sources, 1 found".
    """
    shipped_fw, shipped_pat = default_pack_dirs()
    user_root = _user_overlay_root()
    project_root_dir = _project_overlay_root(project_root)
    return [
        ("shipped", shipped_fw, shipped_pat),
        ("user", user_root / "frameworks", user_root / "patterns"),
        ("project", project_root_dir / "frameworks", project_root_dir / "patterns"),
    ]


def materialize_merged_packs(
    project_root: Path | None = None,
    *,
    fw_override: Path | None = None,
    pat_override: Path | None = None,
) -> tuple[Path, Path, Path, list[str]]:
    """Build a merged frameworks/patterns tree in a fresh temp dir.

    If `fw_override` or `pat_override` is supplied, that single dir is used
    verbatim for that side (no overlay merge) — preserves the existing
    `hexr analyze --pack-dir/--pattern-dir` semantics for power users.

    Returns (tmp_root, frameworks_dir, patterns_dir, applied_labels).
    `tmp_root` is None if both overrides were supplied (no merge happened);
    otherwise the caller MUST `shutil.rmtree(tmp_root)` when done.
    """
    if fw_override is not None and pat_override is not None:
        return None, fw_override, pat_override, ["override"]

    tmp_root = Path(tempfile.mkdtemp(prefix="hexr-sigs-"))
    fw_out = tmp_root / "frameworks"
    pat_out = tmp_root / "patterns"
    fw_out.mkdir()
    pat_out.mkdir()

    applied: list[str] = []

    for label, fw_dir, pat_dir in overlay_sources(project_root):
        used = False
        if fw_override is None and fw_dir.is_dir():
            for src in sorted(fw_dir.glob("*.yaml")):
                shutil.copy2(src, fw_out / src.name)  # later wins (overwrite)
                used = True
        if pat_override is None and pat_dir.is_dir():
            for src in sorted(pat_dir.glob("*.yaml")):
                shutil.copy2(src, pat_out / src.name)
                used = True
        if used:
            applied.append(label)

    final_fw = fw_override if fw_override is not None else fw_out
    final_pat = pat_override if pat_override is not None else pat_out
    return tmp_root, final_fw, final_pat, applied
