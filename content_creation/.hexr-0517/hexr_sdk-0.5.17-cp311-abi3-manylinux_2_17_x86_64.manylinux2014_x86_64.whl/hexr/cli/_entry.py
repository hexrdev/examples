"""Console-script shim for the `hexr` command.

`[project.scripts]` installs the `hexr` executable into EVERY install, but
click and rich live in the optional `[cli]` extra so agent pods stay lean
(§18 N1 zero-new-deps rule, §22.4). Those two facts contradict each other: a
default `pip install hexr-sdk` produced a `hexr` command that died on
`ModuleNotFoundError: No module named 'click'` with a raw traceback — the first
thing anyone runs after installing.

Keeping the extra opt-in is right; agent pods must not pull CLI dependencies.
So the entry point is this shim, which turns the crash into an instruction.
Found 2026-09-10 by installing 0.5.12 from pypi.hexr.cloud into a clean venv
and running `hexr --version`.
"""

from __future__ import annotations

import sys

_CLI_EXTRA_HINT = """\
hexr: the CLI needs the optional `cli` extra, which is not installed.

    pip install --index-url https://pypi.hexr.cloud/simple/ 'hexr-sdk[cli]'

The default wheel is the lean agent-pod profile and deliberately omits click
and rich so agent pods do not carry CLI dependencies. The SDK itself
(@hexr_agent, @hexr_tool, hexr_llm) is fully functional without them.
"""


def main() -> int:
    try:
        from hexr.cli.main import cli
    except ModuleNotFoundError as exc:
        # Only intercept the missing CLI extra. Anything else is a real
        # import error and must surface with its traceback intact.
        if exc.name in {"click", "rich"} or (exc.name or "").startswith("rich."):
            sys.stderr.write(_CLI_EXTRA_HINT)
            return 1
        raise
    cli()
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
