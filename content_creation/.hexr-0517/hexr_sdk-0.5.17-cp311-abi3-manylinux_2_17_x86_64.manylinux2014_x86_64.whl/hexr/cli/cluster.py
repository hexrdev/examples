"""
hexr cluster — cluster registration with Hexr Cloud license API.

Usage:
    hexr cluster register --tenant-id acme-aws --name my-eks-cluster --distro eks
    hexr cluster list
    hexr cluster status
"""

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from hexr.cli.cloud_config import CloudConfig, get_cloud_client

console = Console()

VALID_DISTROS = ("eks", "gke", "aks", "k3s", "openshift")


@click.group("cluster")
def cluster_command():
    """Manage cluster registrations with Hexr Cloud."""
    pass


@cluster_command.command("register")
@click.option(
    "--tenant-id",
    "-t",
    required=True,
    help="Customer / tenant identifier (any stable string; used to scope the license)",
)
@click.option(
    "--name",
    "-n",
    required=True,
    help="Cluster name (must be unique per customer; idempotent on re-register)",
)
@click.option(
    "--distro",
    "-d",
    required=True,
    type=click.Choice(VALID_DISTROS, case_sensitive=False),
    help="Kubernetes distribution",
)
@click.option(
    "--email",
    "-e",
    default="",
    help="Contact email for this cluster (optional)",
)
@click.option(
    "--url",
    "cloud_url",
    default=None,
    help="Override cloud API endpoint (default: https://api.hexr.cloud)",
)
@click.option(
    "--no-verify",
    is_flag=True,
    hidden=True,
    help="Disable TLS verification (for dev/local testing only)",
)
def register_command(
    tenant_id: str,
    name: str,
    distro: str,
    email: str,
    cloud_url: str | None,
    no_verify: bool,
):
    """
    Register a Kubernetes cluster with Hexr Cloud.

    On first call: creates a license and cluster record, returns a signed
    license JWT. On re-call with the same --name: refreshes metadata and
    re-signs the JWT (idempotent).

    The returned cluster_id and license_jwt are persisted to ~/.hexr/config.json
    and used by the data-plane license-agent for heartbeats.

    \b
    Examples:
        hexr cluster register --tenant-id acme-aws --name prod-eks --distro eks
        hexr cluster register --tenant-id acme-aws --name prod-eks --distro eks \\
            --email ops@acme.com
    """
    config = CloudConfig.load()
    if cloud_url:
        config.cloud_url = cloud_url

    if not config.is_authenticated:
        console.print(
            "[red]Error:[/red] Not authenticated. Run [bold]hexr login --key <api_key>[/bold] first."
        )
        raise SystemExit(1)

    console.print(f"[bold]Registering cluster[/bold] [cyan]{name}[/cyan] "
                  f"(distro=[yellow]{distro}[/yellow], tenant=[yellow]{tenant_id}[/yellow]) …")

    payload: dict = {
        "cluster_name": name,
        "k8s_distro": distro.lower(),
        "customer_id": tenant_id,
    }
    if email:
        payload["contact_email"] = email

    try:
        with get_cloud_client(config, verify=not no_verify) as client:
            resp = client.post("/v1/clusters", json=payload)
    except Exception as exc:
        console.print(f"[red]Request failed:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code not in (200, 201):
        console.print(f"[red]API error {resp.status_code}:[/red] {resp.text}")
        raise SystemExit(1)

    body = resp.json()
    data = body.get("data", {})
    cluster_id: str = data.get("cluster_id", "")
    license_id: str = data.get("license_id", "")
    license_jwt: str = data.get("license_jwt", "")

    if not cluster_id or not license_jwt:
        console.print("[red]Error:[/red] Unexpected response — missing cluster_id or license_jwt")
        console.print(body)
        raise SystemExit(1)

    # Persist to ~/.hexr/config.json
    config.tenant_id = tenant_id
    config.cluster_id = cluster_id
    config.license_id = license_id
    config.license_jwt = license_jwt
    config.save()

    console.print()
    console.print(Panel.fit(
        f"[green bold]✓ Cluster registered[/green bold]\n\n"
        f"  Cluster ID : [cyan]{cluster_id}[/cyan]\n"
        f"  License ID : [cyan]{license_id}[/cyan]\n"
        f"  JWT        : [dim]{license_jwt[:40]}…[/dim]\n\n"
        f"[dim]Saved to ~/.hexr/config.json[/dim]\n\n"
        f"[bold]Next:[/bold] deploy the data-plane license-agent so it can POST heartbeats:\n"
        f"  [dim]helm upgrade hexr-runtime ./deployment/helm/hexr-runtime "
        f"--set licenseAgent.enabled=true[/dim]",
        title="hexr cluster register",
        border_style="green",
    ))


@cluster_command.command("list")
@click.option("--url", "cloud_url", default=None, help="Override cloud API endpoint")
@click.option("--no-verify", is_flag=True, hidden=True, help="Disable TLS verification")
def list_command(cloud_url: str | None, no_verify: bool):
    """List clusters registered under the current tenant."""
    config = CloudConfig.load()
    if cloud_url:
        config.cloud_url = cloud_url

    if not config.is_authenticated:
        console.print("[red]Not authenticated.[/red] Run [bold]hexr login --key <api_key>[/bold] first.")
        raise SystemExit(1)

    tenant_id = config.tenant_id
    if not tenant_id:
        console.print("[red]No tenant registered.[/red] Run [bold]hexr cluster register[/bold] first.")
        raise SystemExit(1)

    try:
        with get_cloud_client(config, verify=not no_verify) as client:
            resp = client.get(f"/v1/clusters?customer_id={tenant_id}")
    except Exception as exc:
        console.print(f"[red]Request failed:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code != 200:
        console.print(f"[red]API error {resp.status_code}:[/red] {resp.text}")
        raise SystemExit(1)

    clusters = resp.json().get("data", [])
    if not clusters:
        console.print("[yellow]No clusters registered yet.[/yellow]")
        return

    table = Table(title=f"Clusters — tenant [cyan]{tenant_id}[/cyan]")
    table.add_column("Cluster ID", style="cyan")
    table.add_column("Name")
    table.add_column("Distro", style="yellow")
    table.add_column("Last Heartbeat")
    table.add_column("Registered At")
    for c in clusters:
        table.add_row(
            c.get("cluster_id", ""),
            c.get("cluster_name", ""),
            c.get("k8s_distro", ""),
            c.get("last_heartbeat") or "[dim]never[/dim]",
            c.get("registered_at", ""),
        )
    console.print(table)


@cluster_command.command("status")
def status_command():
    """Show locally-stored cluster registration state."""
    config = CloudConfig.load()
    table = Table(title="Local cluster registration", show_header=False)
    table.add_column("Key", style="bold")
    table.add_column("Value")
    table.add_row("Tenant ID", config.tenant_id or "[dim]not set[/dim]")
    table.add_row("Cluster ID", getattr(config, "cluster_id", "") or "[dim]not set[/dim]")
    table.add_row("License ID", getattr(config, "license_id", "") or "[dim]not set[/dim]")
    jwt = getattr(config, "license_jwt", "")
    table.add_row("License JWT", (jwt[:40] + "…") if jwt else "[dim]not set[/dim]")
    table.add_row("Cloud URL", config.cloud_url)
    console.print(table)
