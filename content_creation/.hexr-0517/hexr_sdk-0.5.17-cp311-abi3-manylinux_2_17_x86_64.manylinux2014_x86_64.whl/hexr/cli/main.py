#!/usr/bin/env python3
"""
Hexr CLI Main Entry Point

IMPORTANT: This is the CLI command entry point (hexr build, hexr push, hexr deploy).
NOT the agent application entry point - agents run their original files directly.

Production-ready command-line interface for the Hexr SDK.
Implements the three-command workflow: build → push → deploy

HEXR Architecture vs AgentCore:
- AgentCore: @app.entrypoint + app.run() (server pattern)
- HEXR: @hexr_agent functions executed directly (native Python pattern)
"""

import asyncio
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.traceback import install

# CLI command imports
from hexr.cli.analyze import analyze_command
from hexr.cli.audit import audit_command
from hexr.cli.build import build_command
from hexr.cli.cache import cache as cache_command
from hexr.cli.cluster import cluster_command
from hexr.cli.delete import delete_command
from hexr.cli.deploy import deploy_command
from hexr.cli.init import init_command
from hexr.cli.login import login_command, logout_command
from hexr.cli.push import push_command
from hexr.cli.trust_policy import trust_policy_command
from hexr.cli.update import update_command
from hexr.version import __version__

# Install rich traceback handling for better error reporting
install(show_locals=True)

console = Console()


@click.group()
@click.version_option(__version__, prog_name="hexr")
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output")
@click.option(
    "--debug", is_flag=True, help="Enable debug mode with detailed tracebacks"
)
@click.pass_context
def main(ctx: click.Context, verbose: bool, debug: bool):
    """
    Hexr SDK - Secure Multi-Agent AI Platform

    Transform your Python AI agents into production-ready containerized deployments
    with automatic SPIFFE identity management and cloud credential injection.

    Examples:
        hexr build agent.py --tenant acme-corp
        hexr push financial-analyst --registry harbor.company.com
        hexr deploy financial-analyst --env production
    """
    # Ensure context object exists
    ctx.ensure_object(dict)

    # Store global options
    ctx.obj["verbose"] = verbose
    ctx.obj["debug"] = debug

    if verbose:
        console.print("🚀 [bold blue]Hexr SDK v{__version__}[/bold blue]")
        console.print("✨ [green]Building secure AI agent infrastructure[/green]")


@main.command()
@click.argument("agent_file", type=click.Path(exists=True, path_type=Path))
@click.option(
    "--tenant", "-t", required=True, help="Tenant identifier for multi-tenancy"
)
@click.option(
    "--name", "-n", help="Agent name (defaults to filename without extension)"
)
@click.option(
    "--target",
    default="development",
    type=click.Choice(["development", "staging", "production"]),
    help="Target environment for build optimization",
)
@click.option("--registry", help="Container registry base URL")
@click.option("--pypi-url", help="Private PyPI URL for SDK installation in agent pods")
@click.option("--python-version", default="3.11", help="Python version for container")
@click.option("--base-image", default="python:3.11-slim", help="Base container image")
@click.option("--multi-cloud", help="Comma-separated cloud providers (aws,gcp,azure)")
@click.option(
    "--subprocess-support", is_flag=True, help="Enable subprocess role management"
)
@click.option(
    "--security-scan", is_flag=True, help="Enable security scanning during build"
)
@click.option(
    "--optimization-level",
    type=click.Choice(["development", "production"]),
    default="development",
    help="Build optimization level",
)
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(path_type=Path),
    help="Output directory for build artifacts (default: .hexr)",
)
@click.option(
    "--dockerfile-only",
    is_flag=True,
    help="Generate Dockerfile and manifests only, skip image build",
)
@click.option(
    "--dry-run", is_flag=True, help="Show what would be done without executing"
)
@click.option(
    "--mock-mode/--no-mock-mode",
    default=True,
    help="Enable mock mode (default: True). Use --no-mock-mode for real cloud credentials"
)
@click.option(
    "--trust-domain",
    default="demo.hexr.dev",
    help="SPIFFE trust domain for envoy mTLS config (default: demo.hexr.dev)"
)
@click.option(
    "--gcp-service-account",
    default=None,
    help="GCP service account for Workload Identity binding on the agent KSA. "
         "When set, generated ServiceAccount carries the iam.gke.io/gcp-service-account "
         "annotation so pods auth-impersonate this GSA (e.g. for AR-backed pypi.hexr.cloud). "
         "Auto-defaulted to hexr-pypi-reader@hexr-cloud-prod.iam.gserviceaccount.com when "
         "logged into Hexr Cloud."
)
@click.option(
    "--route",
    type=click.Choice(["kubernetes", "managed"], case_sensitive=False),
    default="kubernetes",
    show_default=True,
    help="Build route. 'kubernetes' (Route B) emits Dockerfile + K8s manifests for self-hosted "
         "EKS/GKE/AKS/on-prem clusters and is consumed by `hexr push` + `hexr deploy`. "
         "'managed' (Route A) skips all K8s/docker emission and instead writes Route A "
         "managed-runtime artifacts under .hexr/managed/ (BuildManifest.json, "
         "deploy-descriptor.<runtime>.yaml, control-mappings.json) for the customer to paste "
         "into their AgentCore / GEAP Agent Runtime / Azure AI Foundry deploy file. "
         "See HEXR_SDK_OVERHAUL_TECH_SPEC.md sec 19.5 item 8."
)
@click.pass_context
def build(
    ctx: click.Context,
    agent_file: Path,
    tenant: str,
    name: str | None,
    target: str,
    registry: str | None,
    pypi_url: str | None,
    python_version: str,
    base_image: str,
    multi_cloud: str | None,
    subprocess_support: bool,
    security_scan: bool,
    optimization_level: str,
    output_dir: Path | None,
    dockerfile_only: bool,
    dry_run: bool,
    mock_mode: bool,
    trust_domain: str,
    gcp_service_account: str | None,
    route: str,
):
    """
    Build agent container and Kubernetes manifests from Python code.

    Analyzes your Python agent file, extracts @hexr_agent metadata,
    generates optimized container images and production-ready Kubernetes manifests.

    Examples:
        hexr build agent.py --tenant acme-corp
        hexr build multi_agent.py --tenant demo-corp --target production
        hexr build financial_analyzer.py --tenant jpmorgan --multi-cloud aws,gcp --security-scan
    """
    # Auto-detect Hexr Cloud login and apply smart defaults.
    # If user ran 'hexr login', cloud config exists with api.hexr.cloud.
    # Override DO-era defaults with GKE-appropriate values unless user explicitly set them.
    try:
        from hexr.cli.cloud_config import CloudConfig
        cloud_cfg = CloudConfig.load()
        if cloud_cfg.is_authenticated and "hexr.cloud" in cloud_cfg.cloud_url:
            registry_source = ctx.get_parameter_source("registry")
            pypi_source = ctx.get_parameter_source("pypi_url")
            mock_mode_source = ctx.get_parameter_source("mock_mode")
            trust_domain_source = ctx.get_parameter_source("trust_domain")

            registry_was_explicit = bool(
                registry_source and registry_source.name != "DEFAULT"
            )
            pypi_was_explicit = bool(
                pypi_source and pypi_source.name != "DEFAULT"
            )
            use_cloud_defaults = not registry_was_explicit and not pypi_was_explicit

            # User is logged into Hexr Cloud — apply GKE defaults
            # Only override if user did NOT explicitly pass an alternate registry/PyPI path.
            if use_cloud_defaults and (registry is None or registry_source.name == "DEFAULT"):
                registry = "us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images"
            if use_cloud_defaults and (pypi_url is None or pypi_source.name == "DEFAULT"):
                pypi_url = "https://pypi.hexr.cloud/simple/"
            if use_cloud_defaults and mock_mode_source and mock_mode_source.name == "DEFAULT":
                mock_mode = False
            if use_cloud_defaults and trust_domain == "demo.hexr.dev" and trust_domain_source and trust_domain_source.name == "DEFAULT":
                trust_domain = "hexr.cloud"
            # Auto-bind agent KSA to the AR-reader GSA so the SDK install /
            # runtime resolves pypi.hexr.cloud via Workload Identity.
            # See HEXR_SDK_OVERHAUL_TECH_SPEC.md sec 19.5 item 5.
            gcp_sa_source = ctx.get_parameter_source("gcp_service_account")
            if (
                use_cloud_defaults
                and (gcp_service_account is None or (gcp_sa_source and gcp_sa_source.name == "DEFAULT"))
            ):
                gcp_service_account = "hexr-pypi-reader@hexr-cloud-prod.iam.gserviceaccount.com"
            if use_cloud_defaults:
                console.print("[dim]☁️  Cloud mode detected (hexr login active) — using GKE defaults[/dim]")
            else:
                console.print("[dim]☁️  Cloud login detected, but preserving explicit build target settings[/dim]")
    except Exception:
        pass  # Cloud config not available — use CLI defaults as-is

    try:
        result = asyncio.run(
            build_command(
                agent_file=agent_file,
                tenant=tenant,
                name=name,
                target=target,
                registry=registry,
                pypi_url=pypi_url,
                python_version=python_version,
                base_image=base_image,
                multi_cloud=multi_cloud.split(",") if multi_cloud else None,
                subprocess_support=subprocess_support,
                security_scan=security_scan,
                optimization_level=optimization_level,
                output_dir=output_dir or Path(".hexr"),
                dockerfile_only=dockerfile_only,
                dry_run=dry_run,
                verbose=ctx.obj.get("verbose", False),
                debug=ctx.obj.get("debug", False),
                mock_mode=mock_mode,
                trust_domain=trust_domain,
                gcp_service_account=gcp_service_account,
                route=route,
            )
        )

        if result.success:
            console.print("✅ [bold green]Build completed successfully![/bold green]")
            console.print(f"📦 Image: [cyan]{result.image_name}[/cyan]")
            console.print(f"📂 Artifacts: [cyan]{result.output_dir}[/cyan]")
            # Show more precision for very fast builds
            if result.duration < 0.1:
                duration_str = f"{result.duration * 1000:.0f}ms"
            else:
                duration_str = f"{result.duration:.1f}s"
            console.print(f"⏱️  Duration: [yellow]{duration_str}[/yellow]")

            if ctx.obj.get("verbose"):
                console.print(f"🔍 Framework detected: [blue]{result.framework}[/blue]")
                console.print(
                    f"☁️  Cloud providers: [blue]{', '.join(result.cloud_providers or [])}[/blue]"
                )
                console.print(
                    f"🛡️  Resources detected: [blue]{len(result.resources or [])}[/blue]"
                )
        else:
            console.print(f"❌ [bold red]Build failed: {result.error}[/bold red]")
            sys.exit(1)

    except Exception as e:
        console.print(f"💥 [bold red]Unexpected error: {e}[/bold red]")
        if ctx.obj.get("debug"):
            console.print_exception()
        sys.exit(1)


# Register commands
main.add_command(audit_command, name="audit")
main.add_command(analyze_command, name="analyze")
main.add_command(push_command, name="push")
main.add_command(deploy_command, name="deploy")
main.add_command(delete_command, name="delete")
main.add_command(cache_command, name="cache")
main.add_command(login_command, name="login")
main.add_command(logout_command, name="logout")
main.add_command(init_command, name="init")
main.add_command(update_command, name="update")
main.add_command(cluster_command, name="cluster")
main.add_command(trust_policy_command, name="trust-policy")


# Create CLI alias for external imports
cli = main


def cli_main():
    """Entry point for the hexr CLI command."""
    main()


if __name__ == "__main__":
    cli_main()
