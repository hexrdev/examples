"""Command-line interface for Hexr SDK."""
