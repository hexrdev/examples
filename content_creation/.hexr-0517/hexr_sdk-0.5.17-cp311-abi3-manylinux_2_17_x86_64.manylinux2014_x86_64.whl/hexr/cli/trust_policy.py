"""
`hexr trust-policy` — generate cloud-side IAM trust artifacts (spec §2.5.7c).

Subcommands:
    hexr trust-policy generate --tenant <slug> --cloud {aws|gcp|azure} [...]
    hexr trust-policy verify   --tenant <slug> --cloud {aws|gcp|azure}    (stub — wired in next PR)

All `generate` output is byte-identical to what the matching Terraform
submodule produces — so customers can choose CLI-paste or `terraform apply`
without divergence.

This command performs NO cloud API calls. Customer applies the artifact
in their own account, with their own credentials, in their own state.
"""

from __future__ import annotations

import sys
from typing import Optional

import click
from rich.console import Console

from hexr.trust_policy import (
    AzureFederation,
    TrustPolicyManifest,
    render_aws_trust_policy,
    render_azure_federated_credentials,
    render_gcp_wif_provider,
)

console = Console()


@click.group(name="trust-policy")
def trust_policy_command() -> None:
    """Generate cloud-side IAM trust-policy artifacts (spec §2.5.7c)."""


@trust_policy_command.command(name="generate")
@click.option("--tenant", required=True, help="Customer tenant slug (DNS-1123 label).")
@click.option(
    "--cloud",
    type=click.Choice(["aws", "gcp", "azure"]),
    required=True,
    help="Target cloud provider.",
)
@click.option(
    "--audience",
    default="hexr-credential-injector",
    show_default=True,
    help="JWT 'aud' claim the credential-injector validates.",
)
@click.option(
    "--out",
    type=click.Path(dir_okay=False, writable=True),
    default=None,
    help="Write to file instead of stdout.",
)
# AWS-specific
@click.option("--aws-account-id", default=None, help="[aws] 12-digit AWS account ID.")
# GCP-specific
@click.option("--gcp-project-number", default=None, help="[gcp] Numeric GCP project number.")
@click.option(
    "--gcp-pool-id",
    default="hexr",
    show_default=True,
    help="[gcp] Workload-identity-pool ID (one pool per Hexr trust domain).",
)
@click.option(
    "--gcp-target-sa",
    default=None,
    help="[gcp] Optional target service-account email to grant workloadIdentityUser.",
)
# Azure-specific
@click.option(
    "--azure-resource-group",
    default=None,
    help="[azure] Resource group hosting the user-assigned managed identity.",
)
@click.option(
    "--azure-federation",
    "azure_federations",
    multiple=True,
    metavar="FRAMEWORK/AGENT/SUBAGENT",
    help="[azure] One per FIC (no wildcards in Azure subjects). Repeatable.",
)
@click.option(
    "--azure-managed-identity-name",
    default=None,
    help="[azure] Override UAMI name (default 'hexr-<tenant>').",
)
def generate(
    tenant: str,
    cloud: str,
    audience: str,
    out: Optional[str],
    aws_account_id: Optional[str],
    gcp_project_number: Optional[str],
    gcp_pool_id: str,
    gcp_target_sa: Optional[str],
    azure_resource_group: Optional[str],
    azure_federations: tuple[str, ...],
    azure_managed_identity_name: Optional[str],
) -> None:
    """Render a trust-policy artifact for one (tenant, cloud) pair."""
    try:
        artifact = _render(
            tenant=tenant,
            cloud=cloud,
            audience=audience,
            aws_account_id=aws_account_id,
            gcp_project_number=gcp_project_number,
            gcp_pool_id=gcp_pool_id,
            gcp_target_sa=gcp_target_sa,
            azure_resource_group=azure_resource_group,
            azure_federation_specs=azure_federations,
            azure_managed_identity_name=azure_managed_identity_name,
        )
    except ValueError as exc:
        console.print(f"[bold red]error:[/bold red] {exc}")
        sys.exit(2)

    if out:
        with open(out, "w", encoding="utf-8") as fh:
            fh.write(artifact)
        console.print(f"[green]wrote[/green] {out} ({len(artifact)} bytes)")
    else:
        click.echo(artifact, nl=False)


def _render(
    *,
    tenant: str,
    cloud: str,
    audience: str,
    aws_account_id: Optional[str],
    gcp_project_number: Optional[str],
    gcp_pool_id: str,
    gcp_target_sa: Optional[str],
    azure_resource_group: Optional[str],
    azure_federation_specs: tuple[str, ...],
    azure_managed_identity_name: Optional[str],
) -> str:
    """Pure dispatcher — separated for unit testing without Click context."""
    if cloud == "aws":
        if not aws_account_id:
            raise ValueError("--aws-account-id is required for --cloud aws")
        m = TrustPolicyManifest(tenant_slug=tenant, cloud="aws", audience=audience)
        return render_aws_trust_policy(m, account_id=aws_account_id)

    if cloud == "gcp":
        if not gcp_project_number:
            raise ValueError("--gcp-project-number is required for --cloud gcp")
        m = TrustPolicyManifest(tenant_slug=tenant, cloud="gcp", audience=audience)
        return render_gcp_wif_provider(
            m,
            project_number=gcp_project_number,
            pool_id=gcp_pool_id,
            target_service_account_email=gcp_target_sa,
        )

    if cloud == "azure":
        if not azure_resource_group:
            raise ValueError("--azure-resource-group is required for --cloud azure")
        if not azure_federation_specs:
            raise ValueError(
                "at least one --azure-federation FRAMEWORK/AGENT/SUBAGENT is required "
                "(Azure AD has no wildcard subject support)"
            )
        feds: list[AzureFederation] = []
        for spec in azure_federation_specs:
            parts = spec.split("/")
            if len(parts) != 3:
                raise ValueError(
                    f"--azure-federation must be FRAMEWORK/AGENT/SUBAGENT, got {spec!r}"
                )
            feds.append(AzureFederation(framework=parts[0], agent=parts[1], sub_agent=parts[2]))
        m = TrustPolicyManifest(
            tenant_slug=tenant,
            cloud="azure",
            audience=audience,
            federations=tuple(feds),
        )
        return render_azure_federated_credentials(
            m,
            resource_group=azure_resource_group,
            managed_identity_name=azure_managed_identity_name,
        )

    raise ValueError(f"unsupported cloud {cloud!r}")


@trust_policy_command.command(name="verify")
@click.option("--tenant", required=True)
@click.option("--cloud", type=click.Choice(["aws", "gcp", "azure"]), required=True)
def verify(tenant: str, cloud: str) -> None:
    """Check live trust policy matches the Hexr manifest (NOT YET IMPLEMENTED).

    Will exit 0 if the customer's currently-provisioned cloud trust policy
    accepts the tenant's SPIFFE prefix end-to-end (round-trips an STS
    exchange and confirms a signed tool_call_success row appears).
    """
    console.print(
        f"[yellow]TODO:[/yellow] verify trust policy for tenant={tenant} cloud={cloud}\n"
        "Will be implemented after first successful apply against tenant-globex-azure."
    )
    sys.exit(1)
