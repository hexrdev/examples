"""
Hexr Sandbox Client — hardware-isolated code execution via SmolVM microVMs.

Provides ``hexr.exec()`` for running untrusted code in fresh Firecracker
microVMs with full hardware isolation.  Each execution boots a new VM,
runs the code, captures output, and destroys the VM — zero state leakage.

Environment variables:
    HEXR_SANDBOX_URL        Override the service URL (default: in-cluster discovery)
    HEXR_SANDBOX_ENABLED    Explicit enable/disable ("true"/"false")
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://hexr-sandbox.hexr-system.svc.cluster.local:8092"
_TIMEOUT = 60.0  # sandbox executions can take time


# ── Data types ───────────────────────────────────────────────────────────────

@dataclass
class ExecResult:
    """Result of a sandboxed code execution."""

    stdout: str
    stderr: str
    exit_code: int
    duration_ms: float

    @property
    def ok(self) -> bool:
        return self.exit_code == 0

    @property
    def output(self) -> str:
        return self.stdout.strip()


# ── Configuration ────────────────────────────────────────────────────────────

def _get_url() -> str | None:
    url = os.getenv("HEXR_SANDBOX_URL")
    if url:
        return url.rstrip("/")
    if os.getenv("KUBERNETES_SERVICE_HOST"):
        return _DEFAULT_URL
    return None


def is_enabled() -> bool:
    explicit = os.getenv("HEXR_SANDBOX_ENABLED")
    if explicit is not None:
        return explicit.lower() in ("1", "true", "yes")
    return _get_url() is not None


# ── Sync API ─────────────────────────────────────────────────────────────────

def exec(
    code: str,
    *,
    language: str = "python",
    timeout: int = 30,
    env_vars: dict[str, str] | None = None,
    packages: list[str] | None = None,
) -> ExecResult:
    """Execute code in a hardware-isolated microVM sandbox.

    Args:
        code: Source code to execute.
        language: Programming language (``"python"`` or ``"shell"``).
        timeout: Maximum execution time in seconds.
        env_vars: Environment variables to inject into the sandbox.
        packages: Python packages to ``pip install`` before execution.

    Returns:
        :class:`ExecResult` with stdout, stderr, exit_code, and duration_ms.

    Raises:
        RuntimeError: If sandbox service is unavailable.
    """
    url = _get_url()
    if url is None:
        raise RuntimeError(
            "Hexr Sandbox not available. Set HEXR_SANDBOX_URL or run in-cluster."
        )
    payload: dict[str, Any] = {
        "code": code,
        "language": language,
        "timeout": timeout,
    }
    if env_vars:
        payload["env_vars"] = env_vars
    if packages:
        payload["packages"] = packages

    resp = httpx.post(
        f"{url}/execute",
        json=payload,
        timeout=max(_TIMEOUT, timeout + 10),
    )
    resp.raise_for_status()
    data = resp.json()
    return ExecResult(
        stdout=data["stdout"],
        stderr=data["stderr"],
        exit_code=data["exit_code"],
        duration_ms=data["duration_ms"],
    )


# ── Async API ────────────────────────────────────────────────────────────────

async def exec_async(
    code: str,
    *,
    language: str = "python",
    timeout: int = 30,
    env_vars: dict[str, str] | None = None,
    packages: list[str] | None = None,
) -> ExecResult:
    """Async version of :func:`exec`."""
    url = _get_url()
    if url is None:
        raise RuntimeError(
            "Hexr Sandbox not available. Set HEXR_SANDBOX_URL or run in-cluster."
        )
    payload: dict[str, Any] = {
        "code": code,
        "language": language,
        "timeout": timeout,
    }
    if env_vars:
        payload["env_vars"] = env_vars
    if packages:
        payload["packages"] = packages

    async with httpx.AsyncClient(timeout=max(_TIMEOUT, timeout + 10)) as client:
        resp = await client.post(f"{url}/execute", json=payload)
        resp.raise_for_status()
        data = resp.json()
    return ExecResult(
        stdout=data["stdout"],
        stderr=data["stderr"],
        exit_code=data["exit_code"],
        duration_ms=data["duration_ms"],
    )
