"""Cloud client factory with SPIFFE-based authentication."""

import os
import threading
import time
from typing import Any

from .config import HexrConfig
from .context import HexrContext
from .evidence import post_evidence
from .exceptions import AuthenticationError, ConfigurationError, CredentialError
from .observability import get_tracer, get_meter, SpanNames, SpanAttributes, MetricNames
from .utils.simple_logging import get_logger

logger = get_logger(__name__)


# AG-15 — Auditor framework crosswalk for hexr_tool() invocations.
# Each cloud service points at a real, citable control. Auditors verify
# the row exists; the wedge is that the row never leaves the customer VPC.
_TOOL_CONTROL_MAP: dict[str, dict[str, str]] = {
    "aws_s3":        {"framework": "soc2",     "control_id": "CC6.1"},
    "aws_sts":       {"framework": "soc2",     "control_id": "CC6.1"},
    "aws_kms":       {"framework": "hipaa",    "control_id": "164.312(a)(2)(iv)"},
    "aws_dynamodb":  {"framework": "soc2",     "control_id": "CC6.1"},
    "gcp_storage":   {"framework": "soc2",     "control_id": "CC6.1"},
    "gcp_bigquery":  {"framework": "soc2",     "control_id": "CC6.1"},
    "azure_storage": {"framework": "soc2",     "control_id": "CC6.1"},
}


def _emit_tool_evidence(
    service_name: str,
    decision: str,
    region: str | None,
    error: str | None,
    trace_id: str | None,
) -> None:
    """Fire-and-forget evidence post — never blocks the tool call."""
    if os.getenv("HEXR_EVIDENCE_DISABLED", "").lower() in ("1", "true", "yes"):
        return

    ctl = _TOOL_CONTROL_MAP.get(
        service_name, {"framework": "nist-ssdf", "control_id": "PW.4"}
    )
    severity = "info" if decision == "allow" else "warning"
    event_type = (
        "tool_call_allowed" if decision == "allow" else "tool_call_denied"
    )
    details: dict[str, Any] = {
        "service": service_name,
        "region": region,
        "decision": decision,
    }
    if error:
        details["error"] = error[:512]

    spiffe_id = os.environ.get("HEXR_SPIFFE_ID", "")
    if not spiffe_id:
        try:
            from .synchronous_registration import get_last_registered_spiffe_id

            spiffe_id = get_last_registered_spiffe_id() or ""
        except Exception:
            spiffe_id = ""
    if not spiffe_id:
        try:
            from .credential.cache import CredentialCache

            summary = CredentialCache.get_instance().get_summary()
            spiffe_id = (summary.get("jwt_svid") or {}).get("spiffe_id", "") or ""
        except Exception:
            spiffe_id = ""

    def _bg() -> None:
        try:
            post_evidence(
                event_type,
                ctl["control_id"],
                details,
                source="hexr-sdk",
                framework=ctl["framework"],
                severity=severity,
                spiffe_id=spiffe_id or None,
                timeout=2.0,
            )
        except Exception as exc:  # never let evidence break agents
            logger.debug("evidence emit failed (non-fatal): %s", exc)

    threading.Thread(
        target=_bg, name="hexr-evidence-emit", daemon=True
    ).start()


def hexr_tool(service_name: str, region: str | None = None, **kwargs) -> Any:
    """
    Get authenticated cloud client using SPIFFE-based credential exchange.

    This is the main SDK function that:
    1. Gets JWT-SVID from SPIRE Agent (Phase 1) - Real implementation ✅
    2. Exchanges JWT-SVID for cloud credentials (Phase 2) - Real implementation ✅
    3. Creates authenticated cloud client (Phase 3) - Real implementation ✅

    Args:
        service_name: Cloud service ("aws_s3", "gcp_bigquery", "azure_storage")
        region: Cloud region override
        **kwargs: Additional client configuration

    Returns:
        Authenticated cloud client (boto3, google-cloud, azure-*)

    Example:
        s3_client = hexr_tool("aws_s3")
        bigquery_client = hexr_tool("gcp_bigquery", project_id="my-project")

    Environment Variables:
        HEXR_CREDENTIAL_INJECTOR_URL: Credential Injector URL (default: http://hexr-credential-injector.hexr-system:8080)
        SPIRE_AGENT_SOCKET: SPIRE Agent socket path (default: /run/spire/sockets/agent.sock)
    """
    config = HexrConfig.from_environment()

    # Determine provider for span attributes
    if service_name.startswith("aws_"):
        provider = "aws"
    elif service_name.startswith("gcp_"):
        provider = "gcp"
    elif service_name.startswith("azure_"):
        provider = "azure"
    else:
        provider = "unknown"

    tracer = get_tracer()
    meter = get_meter()
    _tool_counter = meter.create_counter(
        MetricNames.TOOL_INVOCATIONS,
        unit="1",
        description="Number of tool invocations",
    )
    _tool_duration = meter.create_histogram(
        MetricNames.TOOL_DURATION,
        unit="s",
        description="Tool invocation duration in seconds",
    )
    _metric_attrs = {
        "hexr.tool.service": service_name,
        "hexr.tool.provider": provider,
    }
    _tool_counter.add(1, _metric_attrs)
    _invoke_start = time.time()

    # PR-C20a — sub-agent attribution: copy hexr.agent.name from the enclosing
    # @hexr_agent span (or HEXR_AGENT_NAME env var as fallback) onto the
    # TOOL_INVOKE span attributes so the evidence exporter (see
    # observability/evidence_http_exporter.py::_span_to_row) attributes the
    # tool row to its parent agent instead of falling through to "unknown".
    _parent_agent_name: str | None = None
    try:
        from opentelemetry import trace as _otel_trace

        _current = _otel_trace.get_current_span()
        # OTel ReadableSpan / NonRecordingSpan don't all expose .attributes;
        # SDK Span (the recording one) does. Be defensive.
        _parent_attrs = getattr(_current, "attributes", None) or {}
        _parent_agent_name = _parent_attrs.get(SpanAttributes.AGENT_NAME)
    except Exception:
        _parent_agent_name = None
    if not _parent_agent_name:
        _parent_agent_name = os.environ.get("HEXR_AGENT_NAME") or None

    _tool_span_attrs: dict[str, Any] = {
        SpanAttributes.TOOL_SERVICE: service_name,
        SpanAttributes.TOOL_REGION: region or "default",
        SpanAttributes.TOOL_PROVIDER: provider,
        # Echo the tool's logical name into hexr.tool.name so the exporter's
        # `attrs.get("hexr.tool.name")` lookup succeeds even when service-name
        # IS the tool name (today they are 1:1).
        "hexr.tool.name": service_name,
    }
    if _parent_agent_name:
        _tool_span_attrs[SpanAttributes.AGENT_NAME] = _parent_agent_name

    with tracer.start_as_current_span(
        SpanNames.TOOL_INVOKE,
        attributes=_tool_span_attrs,
    ) as span:
        # Log credential request for audit trail in process context file
        _log_credential_request(service_name, config)

        # Always use real SPIRE-based authentication
        # Synchronous registration ensures identity is ready before this is called
        logger.info(f"Creating authenticated client for service: {service_name}")
        try:
            client = _create_real_client(service_name, region, **kwargs)
            # AG-15: emit ALLOW evidence row (fire-and-forget)
            try:
                ctx = span.get_span_context() if hasattr(span, "get_span_context") else None
                trace_id_hex = format(ctx.trace_id, "032x") if ctx and ctx.trace_id else None
            except Exception:
                trace_id_hex = None
            _emit_tool_evidence(
                service_name, "allow", region, None, trace_id_hex
            )
            return client
        except Exception as exc:
            span.set_attribute(SpanAttributes.ERROR_TYPE, type(exc).__name__)
            span.set_attribute(SpanAttributes.ERROR_MESSAGE, str(exc)[:256])
            span.record_exception(exc)
            try:
                from opentelemetry.trace import StatusCode
                span.set_status(StatusCode.ERROR, str(exc)[:256])
            except ImportError:
                pass
            # AG-15: emit DENY evidence row (fire-and-forget) before re-raising
            try:
                ctx = span.get_span_context() if hasattr(span, "get_span_context") else None
                trace_id_hex = format(ctx.trace_id, "032x") if ctx and ctx.trace_id else None
            except Exception:
                trace_id_hex = None
            _emit_tool_evidence(
                service_name, "deny", region, str(exc), trace_id_hex
            )
            raise
        finally:
            _tool_duration.record(time.time() - _invoke_start, _metric_attrs)


def _log_credential_request(service_name: str, config: HexrConfig) -> None:
    """Log credential request using ContextVars system."""
    try:
        # Log credential request via ContextVars system
        HexrContext.log_credential_request(
            service=service_name,
            success=True,  # Mock always succeeds
            error=None,
        )

        logger.debug(f"Logged credential request for {service_name}")

    except Exception as e:
        # Don't fail hexr_tool() on logging errors, but warn
        logger.warning(f"Failed to log credential request for {service_name}: {e}")


def _create_real_client(service_name: str, region: str | None, **kwargs) -> Any:
    """
    Create real authenticated cloud client using SPIRE + Credential Injector.

    This implements the complete flow WITH CACHING:
    1. Get JWT-SVID from cache or SPIRE Agent (proactive refresh in background)
    2. Get cloud credentials from cache or exchange (proactive refresh in background)
    3. Create authenticated cloud client

    Args:
        service_name: Cloud service name
        region: Cloud region
        **kwargs: Additional client config

    Returns:
        Authenticated cloud client

    Raises:
        AuthenticationError: If SPIRE authentication fails
        CredentialError: If credential exchange fails
    """
    from .credential.cache import CredentialCache

    try:
        # Get credential cache instance (singleton, per-process)
        cache = CredentialCache.get_instance()

        # Phase 1+2: Get credentials from cache (handles JWT-SVID and exchange internally)
        # This is typically <1ms (cache hit) due to proactive refresh in background
        logger.debug(f"Getting cached credentials for {service_name}")
        credentials = cache.get_cloud_credentials(service_name, region)

        logger.info(
            f"✅ Obtained credentials for {service_name} (cached: {credentials.get('fetched_at')} sec ago)"
        )

        # Phase 3: Create authenticated cloud client
        logger.debug("Phase 3: Creating authenticated cloud client")
        cloud_client = _create_authenticated_client(
            service_name, region, credentials, **kwargs
        )

        logger.info(f"✅ Created authenticated {service_name} client")

        return cloud_client

    except AuthenticationError as e:
        logger.error(f"SPIRE authentication failed: {e}")
        raise
    except CredentialError as e:
        logger.error(f"Credential exchange failed: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected error in hexr_tool: {e}")
        raise CredentialError(f"Failed to create authenticated client: {e}") from e


def _create_authenticated_client(
    service_name: str,
    region: str | None,
    credentials: dict[str, Any],
    **kwargs,
) -> Any:
    """
    Create authenticated cloud client using exchanged credentials.

    Args:
        service_name: Cloud service name
        region: Cloud region
        credentials: Cloud credentials from Credential Injector
        **kwargs: Additional client config

    Returns:
        Authenticated cloud client (boto3, google-cloud, azure-*)

    Raises:
        ConfigurationError: If service is unsupported
        CredentialError: If client creation fails
    """
    try:
        if service_name.startswith("aws_"):
            return _create_aws_client(service_name, region, credentials, **kwargs)
        elif service_name.startswith("gcp_"):
            return _create_gcp_client(service_name, credentials, **kwargs)
        elif service_name.startswith("azure_"):
            return _create_azure_client(service_name, credentials, **kwargs)
        else:
            raise ConfigurationError(f"Unsupported service: {service_name}")

    except ImportError as e:
        logger.error(f"Cloud client library not installed: {e}")
        raise CredentialError(
            f"Required cloud client library not installed for {service_name}. "
            f"Install with: pip install boto3 (AWS), google-cloud-* (GCP), or azure-* (Azure)"
        ) from e


def _create_aws_client(
    service_name: str,
    region: str | None,
    credentials: dict[str, Any],
    **kwargs,
) -> Any:
    """Create authenticated AWS client using boto3."""
    import boto3

    service_type = service_name.replace("aws_", "")
    region = region or credentials.get("region", "us-east-1")

    return boto3.client(
        service_type,
        region_name=region,
        aws_access_key_id=credentials["access_key_id"],
        aws_secret_access_key=credentials["secret_access_key"],
        aws_session_token=credentials.get("session_token"),
        **kwargs,
    )


def _create_gcp_client(service_name: str, credentials: dict[str, Any], **kwargs) -> Any:
    """Create authenticated GCP client using google-cloud libraries.

    Supports both WIF access tokens (from credential injector) and
    legacy service account JSON.
    """
    from google.oauth2 import credentials as oauth2_credentials

    service_type = service_name.replace("gcp_", "")

    # Build credentials from WIF access token (returned by credential injector)
    if "service_account_token" in credentials:
        creds = oauth2_credentials.Credentials(token=credentials["service_account_token"])
    elif "service_account_info" in credentials:
        # Legacy path: full service account JSON
        from google.oauth2 import service_account

        creds = service_account.Credentials.from_service_account_info(
            credentials["service_account_info"]
        )
    else:
        raise ConfigurationError(
            "GCP credentials must contain 'service_account_token' or 'service_account_info'"
        )

    project_id = credentials.get("project_id")

    # GCP client creation depends on service type
    if service_type == "bigquery":
        from google.cloud import bigquery

        return bigquery.Client(
            credentials=creds, project=project_id, **kwargs
        )

    elif service_type == "storage":
        from google.cloud import storage

        return storage.Client(
            credentials=creds, project=project_id, **kwargs
        )

    else:
        raise ConfigurationError(f"Unsupported GCP service: {service_type}")


def _create_azure_client(
    service_name: str, credentials: dict[str, Any], **kwargs
) -> Any:
    """Create authenticated Azure client using azure-* libraries."""
    service_type = service_name.replace("azure_", "")

    # Azure client creation depends on service type
    if service_type == "storage":
        from azure.identity import ClientSecretCredential
        from azure.storage.blob import BlobServiceClient

        credential = ClientSecretCredential(
            tenant_id=credentials["tenant_id"],
            client_id=credentials["client_id"],
            client_secret=credentials["client_secret"],
        )
        return BlobServiceClient(
            account_url=credentials["account_url"], credential=credential, **kwargs
        )

    else:
        raise ConfigurationError(f"Unsupported Azure service: {service_type}")


def _get_process_context() -> dict[str, Any]:
    """Get current process context for credential scoping."""
    return {
        "process_id": os.getpid(),
        "parent_pid": os.getppid(),
        "subprocess_role": os.getenv("HEXR_SUBPROCESS_ROLE"),
        "request_timestamp": time.time(),
    }
