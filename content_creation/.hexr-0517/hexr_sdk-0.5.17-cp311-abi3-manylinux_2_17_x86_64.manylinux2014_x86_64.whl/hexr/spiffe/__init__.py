"""SPIFFE/SPIRE integration for Hexr SDK."""

from .workload_api_client import WorkloadAPIClient

__all__ = ["WorkloadAPIClient"]
