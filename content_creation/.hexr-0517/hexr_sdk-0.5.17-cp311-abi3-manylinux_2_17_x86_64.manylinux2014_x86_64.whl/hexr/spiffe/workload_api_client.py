"""SPIRE Workload API client for JWT-SVID fetching."""

import os
from typing import Any

from ..exceptions import AuthenticationError
from ..utils.simple_logging import get_logger

logger = get_logger(__name__)


class WorkloadAPIClient:
    """
    Client for SPIRE Workload API to fetch JWT-SVIDs.

    Connects to SPIRE Agent via Unix socket and requests JWT-SVIDs
    for authenticating to downstream services.
    """

    def __init__(self, socket_path: str = "/run/spire/sockets/agent.sock"):
        """
        Initialize Workload API client.

        Args:
            socket_path: Path to SPIRE Agent Unix socket
        """
        self.socket_path = socket_path
        self._validate_socket()

    def _validate_socket(self) -> None:
        """Validate that SPIRE Agent socket exists and is accessible."""
        if not os.path.exists(self.socket_path):
            raise AuthenticationError(
                f"SPIRE Agent socket not found at {self.socket_path}. "
                "Ensure SPIRE Agent is running and socket is mounted."
            )

        if not os.access(self.socket_path, os.R_OK | os.W_OK):
            raise AuthenticationError(
                f"SPIRE Agent socket at {self.socket_path} is not accessible. "
                "Check file permissions."
            )

    def fetch_jwt_svid(
        self, audience: list[str], extra_audiences: list[str] | None = None
    ) -> dict[str, Any]:
        """
        Fetch JWT-SVID from SPIRE Agent.

        This method connects to SPIRE Agent via Unix socket. The Agent
        automatically extracts the caller's PID from the socket connection
        (via SO_PEERCRED), validates it against registration entries, and
        issues a JWT-SVID if authorized.

        Args:
            audience: Primary audience(s) for the JWT (e.g., ["hexr-credential-injector"])
            extra_audiences: Additional audiences to include

        Returns:
            dict with:
                - token: JWT-SVID string
                - spiffe_id: SPIFFE ID (sub claim)
                - expiry: Token expiration timestamp

        Raises:
            AuthenticationError: If SPIRE Agent denies the request

        Example:
            >>> client = WorkloadAPIClient()
            >>> svid = client.fetch_jwt_svid(["hexr-credential-injector"])
            >>> print(svid["spiffe_id"])
            spiffe://hexr/tenant/startup/framework/langchain/agent/workflow_coordinator/proc-4627
        """
        all_audiences = audience + (extra_audiences or [])

        try:
            # Use official spiffe library for SPIRE Workload API interaction
            from spiffe.svid.jwt_svid import JwtSvid
            from spiffe.workloadapi.workload_api_client import (
                WorkloadApiClient as SpiffeClient,
            )

            logger.info(
                f"Fetching JWT-SVID from SPIRE Agent at {self.socket_path} "
                f"with audience: {all_audiences}"
            )

            # Connect to SPIRE Agent via Unix socket
            # SpiffeClient handles the gRPC Workload API protocol
            # py-spiffe requires unix:// scheme prefix for socket paths
            socket_uri = self.socket_path if self.socket_path.startswith("unix://") else f"unix://{self.socket_path}"
            spiffe_client = SpiffeClient(socket_uri)

            # Fetch JWT-SVID - SPIRE Agent extracts our PID automatically
            # audience parameter expects a Set[str]
            jwt_svid: JwtSvid = spiffe_client.fetch_jwt_svid(
                audience=set(all_audiences)
            )

            logger.info(
                f"Successfully fetched JWT-SVID with SPIFFE ID: {jwt_svid.spiffe_id}"
            )

            return {
                "token": jwt_svid.token,
                "spiffe_id": str(jwt_svid.spiffe_id),
                "expiry": jwt_svid.expiry,
            }

        except ImportError as e:
            logger.error(
                "spiffe library not installed. Install with: pip install spiffe"
            )
            raise AuthenticationError(
                "spiffe library required for SPIRE integration. "
                "Install with: pip install spiffe"
            ) from e

        except Exception as e:
            logger.error(f"Failed to fetch JWT-SVID from SPIRE Agent: {e}")
            raise AuthenticationError(
                f"SPIRE Agent denied JWT-SVID request: {e}. "
                "Check that this process is registered with SPIRE and Auto-Registrar "
                "has created the registration entry."
            ) from e

    def validate_jwt_svid(
        self, token: str, expected_audience: list[str]
    ) -> dict[str, Any]:
        """
        Validate a JWT-SVID token.

        Args:
            token: JWT-SVID token string
            expected_audience: Expected audience values to validate

        Returns:
            Parsed and validated JWT claims

        Raises:
            AuthenticationError: If token is invalid
        """
        try:
            from spiffe.svid.jwt_svid import JwtSvid

            # Parse and validate JWT-SVID
            jwt_svid = JwtSvid.parse_insecure(token, audience=set(expected_audience))

            return {
                "spiffe_id": str(jwt_svid.spiffe_id),
                "audience": list(jwt_svid.audience),
                "expiry": jwt_svid.expiry,
                "token": jwt_svid.token,
            }

        except Exception as e:
            logger.error(f"Failed to validate JWT-SVID: {e}")
            raise AuthenticationError(f"Invalid JWT-SVID: {e}") from e

    def fetch_x509_svid(self) -> Any:
        """
        Fetch X509-SVID from SPIRE Agent.
        
        X509-SVIDs are PUSHED to Agent immediately via streaming gRPC (0-2s latency),
        unlike JWT-SVIDs which require Agent to POLL Server (5-30s latency).
        
        This provides enterprise-grade, consistent registration timing.
        
        Returns:
            X509Svid object with:
                - spiffe_id: SPIFFE ID of the workload
                - cert_chain: Certificate chain
                - private_key: Private key for the certificate
        
        Raises:
            AuthenticationError: If SPIRE Agent denies the request
        """
        try:
            from spiffe.svid.x509_svid import X509Svid
            from spiffe.workloadapi.workload_api_client import (
                WorkloadApiClient as SpiffeClient,
            )
            
            logger.debug(f"Fetching X509-SVID from SPIRE Agent at {self.socket_path}")
            
            # Connect to SPIRE Agent via Unix socket
            socket_uri = self.socket_path if self.socket_path.startswith("unix://") else f"unix://{self.socket_path}"
            spiffe_client = SpiffeClient(socket_uri)
            
            # Fetch X509-SVID - SPIRE Agent extracts our PID automatically
            # X509-SVIDs are streamed immediately (no polling delay)
            x509_svid: X509Svid = spiffe_client.fetch_x509_svid()
            
            logger.debug(f"✅ X509-SVID fetched: {x509_svid.spiffe_id}")
            
            return x509_svid
            
        except ImportError as e:
            logger.error(
                "spiffe library not installed. Install with: pip install spiffe"
            )
            raise AuthenticationError(
                "spiffe library required for SPIRE integration. "
                "Install with: pip install spiffe"
            ) from e
            
        except Exception as e:
            logger.debug(f"Failed to fetch X509-SVID from SPIRE Agent: {e}")
            raise AuthenticationError(
                f"SPIRE Agent denied X509-SVID request: {e}. "
                "Check that this process is registered with SPIRE."
            ) from e
