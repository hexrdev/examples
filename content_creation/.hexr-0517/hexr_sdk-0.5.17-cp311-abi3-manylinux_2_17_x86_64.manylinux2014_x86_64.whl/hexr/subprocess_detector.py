"""
Hexr Framework-Agnostic Subprocess Detection System.

This module provides userspace subprocess detection for process-level SPIFFE ID generation
without monkey-patching any frameworks. Works with CrewAI, LangChain, Strands, and custom Python.
"""

import os
import time
import psutil
import threading
import json
from pathlib import Path
from typing import Dict, List, Optional, Set, Callable, Any
from contextvars import copy_context
from dataclasses import dataclass

from .utils.simple_logging import get_logger
from .exceptions import ProcessContextError

logger = get_logger(__name__)


@dataclass
class ProcessInfo:
    """Information about a detected subprocess."""

    pid: int
    ppid: int
    cmdline: List[str]
    create_time: float
    framework_hint: Optional[str] = None
    role_hint: Optional[str] = None


class FrameworkSubprocessDetector:
    """
    Framework-agnostic subprocess detection using pure userspace monitoring.

    Detects subprocesses created by AI frameworks and generates context files
    for Enhanced Attestor to create process-level SPIFFE IDs.
    """

    def __init__(self):
        self._monitoring = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._initial_processes: Set[int] = set()
        self._detected_processes: Dict[int, ProcessInfo] = {}
        self._context_data: Dict[str, Any] = {}
        self._framework_detectors: Dict[str, Callable[[ProcessInfo], Optional[str]]] = {
            "crewai": self._detect_crewai_role,
            "langchain": self._detect_langchain_role,
            "strands": self._detect_strands_role,
            "custom": self._detect_custom_role,
        }

    def start_monitoring(self, context_data: Dict[str, Any]) -> None:
        """
        Start monitoring for subprocess creation.

        Args:
            context_data: Current agent context from ContextVars
        """
        if self._monitoring:
            return

        self._context_data = context_data
        self._monitoring = True

        # Capture initial process state
        current_process = psutil.Process(os.getpid())
        self._initial_processes = {
            p.pid for p in current_process.children(recursive=True)
        }
        self._initial_processes.add(os.getpid())

        logger.info(
            f"Started subprocess monitoring for agent '{context_data.get('agent_name')}'"
        )
        logger.debug(f"Initial processes: {self._initial_processes}")

        # Start monitoring thread
        self._monitor_thread = threading.Thread(
            target=self._monitor_subprocess_creation,
            daemon=True,
            name=f"hexr-subprocess-monitor-{os.getpid()}",
        )
        self._monitor_thread.start()

    def stop_monitoring(self) -> None:
        """Stop subprocess monitoring and cleanup."""
        if not self._monitoring:
            return

        self._monitoring = False

        if self._monitor_thread and self._monitor_thread.is_alive():
            self._monitor_thread.join(timeout=1.0)

        # Cleanup context files for detected subprocesses
        for pid in self._detected_processes:
            self._cleanup_subprocess_context_file(pid)

        logger.info("Stopped subprocess monitoring")

    def _monitor_subprocess_creation(self) -> None:
        """Main monitoring loop running in background thread."""
        try:
            current_process = psutil.Process(os.getpid())

            while self._monitoring:
                try:
                    # Get current subprocess tree
                    current_children = {
                        p.pid: p for p in current_process.children(recursive=True)
                    }

                    # Detect new processes
                    new_pids = (
                        set(current_children.keys())
                        - self._initial_processes
                        - set(self._detected_processes.keys())
                    )

                    for pid in new_pids:
                        try:
                            process = current_children[pid]
                            process_info = ProcessInfo(
                                pid=process.pid,
                                ppid=process.ppid(),
                                cmdline=process.cmdline(),
                                create_time=process.create_time(),
                            )

                            # Detect framework-specific role
                            framework = self._context_data.get("framework", "custom")
                            detector = self._framework_detectors.get(
                                framework, self._detect_custom_role
                            )
                            role = detector(process_info)

                            if role:
                                process_info.framework_hint = framework
                                process_info.role_hint = role

                                # Create context file for subprocess
                                self._create_subprocess_context_file(process_info)
                                self._detected_processes[pid] = process_info

                                logger.info(
                                    f"Detected {framework} subprocess: PID {pid}, role: {role}"
                                )

                        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
                            logger.debug(f"Failed to analyze process {pid}: {e}")

                    # Check for terminated processes
                    terminated_pids = []
                    for pid in self._detected_processes:
                        if pid not in current_children:
                            terminated_pids.append(pid)

                    for pid in terminated_pids:
                        self._cleanup_subprocess_context_file(pid)
                        del self._detected_processes[pid]
                        logger.debug(f"Cleaned up terminated subprocess: PID {pid}")

                    time.sleep(0.5)  # Check every 500ms

                except Exception as e:
                    logger.error(f"Error in subprocess monitoring loop: {e}")
                    time.sleep(1.0)

        except Exception as e:
            logger.error(f"Subprocess monitoring thread failed: {e}")

    def _detect_crewai_role(self, process_info: ProcessInfo) -> Optional[str]:
        """Detect CrewAI agent roles from process command line."""
        cmdline = " ".join(process_info.cmdline).lower()

        # CrewAI agent detection patterns
        if "researcher" in cmdline or "research" in cmdline:
            return "researcher"
        elif "analyst" in cmdline or "analysis" in cmdline:
            return "analyst"
        elif "writer" in cmdline or "writing" in cmdline:
            return "writer"
        elif "planner" in cmdline or "planning" in cmdline:
            return "planner"
        elif "reviewer" in cmdline or "review" in cmdline:
            return "reviewer"
        elif "coordinator" in cmdline or "orchestrat" in cmdline:
            return "coordinator"
        elif "crewai" in cmdline:
            return f"agent-{process_info.pid}"

        # Check if it's a Python subprocess with CrewAI patterns
        if "python" in cmdline and any(
            pattern in cmdline for pattern in ["crew", "agent", "task"]
        ):
            return f"subprocess-{process_info.pid}"

        return None

    def _detect_langchain_role(self, process_info: ProcessInfo) -> Optional[str]:
        """Detect LangChain executor/chain roles from process command line."""
        cmdline = " ".join(process_info.cmdline).lower()

        # LangChain detection patterns
        if "executor" in cmdline:
            return "executor"
        elif "chain" in cmdline:
            return "chain"
        elif "agent" in cmdline and "langchain" in cmdline:
            return "langchain-agent"
        elif "tool" in cmdline and "langchain" in cmdline:
            return "tool-executor"
        elif "langchain" in cmdline:
            return f"langchain-{process_info.pid}"

        # Check for Python subprocess with LangChain patterns
        if "python" in cmdline and any(
            pattern in cmdline for pattern in ["chain", "llm", "prompt"]
        ):
            return f"subprocess-{process_info.pid}"

        return None

    def _detect_strands_role(self, process_info: ProcessInfo) -> Optional[str]:
        """Detect Strands agent roles from process command line."""
        cmdline = " ".join(process_info.cmdline).lower()

        # Strands detection patterns
        if "strand" in cmdline:
            if "worker" in cmdline:
                return "strand-worker"
            elif "coordinator" in cmdline:
                return "strand-coordinator"
            else:
                return f"strand-{process_info.pid}"

        # Check for Python subprocess with Strands patterns
        if "python" in cmdline and any(
            pattern in cmdline for pattern in ["strand", "worker", "parallel"]
        ):
            return f"subprocess-{process_info.pid}"

        return None

    def _detect_custom_role(self, process_info: ProcessInfo) -> Optional[str]:
        """Detect custom Python agent roles from process command line."""
        cmdline = " ".join(process_info.cmdline).lower()

        # Generic Python subprocess detection
        if "python" in cmdline:
            # Look for common agent patterns
            if any(
                pattern in cmdline
                for pattern in ["agent", "worker", "process", "task", "job"]
            ):
                return f"worker-{process_info.pid}"
            elif "main.py" not in cmdline:  # Not the main script
                return f"subprocess-{process_info.pid}"

        return None

    def _create_subprocess_context_file(self, process_info: ProcessInfo) -> None:
        """Create context file for detected subprocess."""
        try:
            # Copy parent context and modify for subprocess
            subprocess_context = self._context_data.copy()
            subprocess_context.update(
                {
                    "sub_agent": process_info.role_hint,
                    "process_role": process_info.role_hint,
                    "process_id": process_info.pid,
                    "parent_pid": process_info.ppid,
                    "timestamp": int(time.time()),
                    "subprocess_info": {
                        "cmdline": process_info.cmdline,
                        "create_time": process_info.create_time,
                        "framework_hint": process_info.framework_hint,
                    },
                }
            )

            # Write JSON file for Enhanced Attestor
            context_dir = Path("/tmp/hexr-context")
            context_dir.mkdir(exist_ok=True, mode=0o755)

            context_file = context_dir / f"hexr-context-{process_info.pid}.json"

            with open(context_file, "w") as f:
                json.dump(subprocess_context, f, indent=2)

            logger.info(f"Created subprocess context file: {context_file}")

        except Exception as e:
            logger.error(
                f"Failed to create subprocess context file for PID {process_info.pid}: {e}"
            )

    def _cleanup_subprocess_context_file(self, pid: int) -> None:
        """Clean up context file when subprocess terminates."""
        try:
            context_file = Path(f"/tmp/hexr-context/hexr-context-{pid}.json")
            if context_file.exists():
                context_file.unlink()
                logger.debug(f"Cleaned up subprocess context file: {context_file}")
        except Exception as e:
            logger.warning(
                f"Failed to cleanup subprocess context file for PID {pid}: {e}"
            )


# Global subprocess detector instance
_subprocess_detector: Optional[FrameworkSubprocessDetector] = None


def start_subprocess_monitoring(context_data: Dict[str, Any]) -> None:
    """Start framework-agnostic subprocess monitoring."""
    global _subprocess_detector

    if _subprocess_detector is None:
        _subprocess_detector = FrameworkSubprocessDetector()

    _subprocess_detector.start_monitoring(context_data)


def stop_subprocess_monitoring() -> None:
    """Stop subprocess monitoring and cleanup."""
    global _subprocess_detector

    if _subprocess_detector is not None:
        _subprocess_detector.stop_monitoring()


def is_monitoring_active() -> bool:
    """Check if subprocess monitoring is currently active."""
    global _subprocess_detector
    return _subprocess_detector is not None and _subprocess_detector._monitoring
