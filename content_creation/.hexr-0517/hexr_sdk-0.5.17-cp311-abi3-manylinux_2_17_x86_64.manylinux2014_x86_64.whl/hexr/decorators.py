"""Hexr agent decorator for automatic identity and credential management."""

import contextvars
import functools
import inspect
import json
import os
import time
from collections.abc import Callable
from typing import Any, Dict, List, Optional
from pathlib import Path

from .config import HexrConfig
from .context import HexrContext, _get_context_manager
from .exceptions import ConfigurationError, ProcessContextError
from .observability import get_tracer, get_meter, SpanNames, SpanAttributes, MetricNames
from .runtime_metadata import initialize_runtime_context, start_subprocess_monitoring
from .utils.simple_logging import get_logger

logger = get_logger(__name__)


def _write_marker_file(agent_name: str) -> None:
    """
    Write marker file for current process to help PID mapper discover agent identity.
    
    Marker files enable explicit agent→PID mapping for multiprocess patterns.
    Format: /tmp/hexr-context/agent-markers/{agent_name}-{pid}.marker
    Content: {"agent_name": str, "pid": int, "ppid": int, "timestamp": float}
    """
    try:
        pid = os.getpid()
        ppid = os.getppid()
        
        # Create marker directory
        marker_dir = Path('/tmp/hexr-context/agent-markers')
        marker_dir.mkdir(parents=True, exist_ok=True, mode=0o755)
        
        # Write marker file
        marker_file = marker_dir / f"{agent_name}-{pid}.marker"
        marker_data = {
            "agent_name": agent_name,
            "pid": pid,
            "ppid": ppid,
            "timestamp": time.time()
        }
        
        with open(marker_file, 'w') as f:
            json.dump(marker_data, f, indent=2)
        
        logger.info(f"Created marker file: {marker_file} (PID={pid})")
    except Exception as e:
        # Silent failure - don't break agent execution
        logger.warning(f"Could not write marker file for {agent_name}: {e}")


def hexr_agent(
    name: str,
    tenant: str,
    resources: list[str] | None = None,
    subprocess_support: bool = False,
    regions: dict[str, str] | None = None,
    a2a: bool = False,
    skills: list[dict[str, str]] | None = None,
    description: str | None = None,
    version: str | None = None,
    **kwargs,
) -> Callable:
    """
    Production-grade Hexr agent decorator.

    Args:
        name: Agent name (DNS-safe, lowercase) - REQUIRED
        tenant: Tenant identifier for isolation - REQUIRED
        resources: List of cloud resources (e.g., ["s3:GetObject", "gcp:bigquery.jobs.create"])
        subprocess_support: Enable subprocess-level identity management
        regions: Cloud region mapping {"aws": "us-east-1", "gcp": "us-central1"}
        a2a: Enable A2A agent-to-agent communication (injects Go sidecar at build time)
        skills: List of A2A skill dicts [{"id": ..., "name": ..., "description": ...}]
        description: Agent description for the A2A Agent Card
        version: Agent version for the A2A Agent Card (default: "1.0.0")

    Note:
        Framework type is determined at build-time by `hexr build` and injected via
        HEXR_FRAMEWORK environment variable. Runtime detection is disabled to ensure
        consistency between build-time analysis and runtime attestation.

    Example:
        @hexr_agent(
            name="financial-analyst",
            tenant="company-corp",
            resources=["s3:GetObject", "gcp:bigquery.jobs.create"],
            subprocess_support=True,
            regions={"aws": "us-east-1", "gcp": "us-central1"}
        )
        def my_agent():
            s3 = hexr_tool("aws_s3")
            return s3.get_object(Bucket="data", Key="analysis.csv")

    A2A Example:
        @hexr_agent(
            name="research-agent",
            tenant="demo",
            a2a=True,
            skills=[
                {"id": "search", "name": "Web Search", "description": "Search the web"},
            ],
            description="A research agent that finds information",
        )
        async def my_agent(message):
            return f"Found results for: {message.text_content()}"
    """

    def decorator(func: Callable) -> Callable:
        # Framework metadata is build-time-authoritative as of the SDK overhaul:
        # the Rust analyzer records framework_id in BuildManifest.json during
        # `hexr build`, and the audit pack reads that manifest. The HEXR_FRAMEWORK
        # env var is now an OPTIONAL runtime hint used only as a span attribute,
        # so single-container managed runtimes (Bedrock AgentCore, GEAP Agent
        # Runtime, Azure AI Foundry) don't need to round-trip it. See
        # HEXR_SDK_OVERHAUL_TECH_SPEC.md §19.5 item 8 for the rationale.
        framework_value = os.getenv("HEXR_FRAMEWORK") or "unknown"
        if framework_value != "unknown":
            logger.info(f"hexr_agent: framework hint from HEXR_FRAMEWORK={framework_value}")

        # Tenant: env var (set by hexr deploy) takes precedence over decorator param
        # This ensures the CLI --tenant flag is authoritative, matching the namespace
        # and SPIRE identity chain. Decorator param is fallback for local dev.
        tenant_value = os.getenv("HEXR_TENANT", tenant)
        if tenant_value != tenant:
            logger.info(f"Using deploy-time tenant from HEXR_TENANT: {tenant_value} (decorator had: {tenant})")

        # Validate configuration
        _validate_agent_config(name, tenant_value, resources, framework_value)

        # Store metadata on function/class
        func._hexr_metadata = {
            "name": name,
            "tenant": tenant_value,
            "resources": resources or [],
            "framework": framework_value,
            "subprocess_support": subprocess_support,
            "regions": regions or {},
            "a2a": a2a,
            "skills": skills or [],
            "description": description,
            "version": version,
            **kwargs,
        }

        # CRITICAL SECURITY: Two-pass initialization
        # Pass 1 (DECORATION TIME): Write marker file for identity establishment
        # This happens BEFORE any agent code runs, preventing rogue code from executing
        # without identity. For classes, this is at import time. For functions, at definition time.
        if inspect.isclass(func):
            # CLASS: Write marker immediately at decoration time (multiprocess/async support)
            # Identity established before __init__ ever runs
            _write_marker_file(name)
            logger.debug(f"✅ Identity marker created at decoration time for class {name}")

            # Eagerly register the process with the auto-registrar at decoration
            # time so SPIRE has an entry even when the entrypoint never
            # instantiates the class (e.g. ``A2ABridge(handler=fn).start()``
            # against a module-level handler). Fixes hybrid spec §2.5.7.
            # Idempotent: wrapped_init below re-invokes _setup_runtime_context
            # to refresh per-instance context files; the auto-registrar dedupes
            # by (tenant, agent_name, pid) so a duplicate /register is a no-op.
            try:
                _setup_runtime_context(name, tenant_value, resources, regions,
                                       subprocess_support, framework_value, func)
                logger.debug(
                    f"✅ Eager runtime context established at decoration time for class {name}"
                )
            except Exception as exc:
                # Decoration-time failures must NOT abort module import. The
                # wrapped __init__ retries on first instantiation; if both
                # paths fail the runtime fails closed at the first @hexr_tool
                # call (PERMISSION_DENIED), which is the desired audit posture.
                logger.warning(
                    f"Eager registration deferred for class {name}: {exc}. "
                    "Will retry on first instantiation."
                )

            # Store tracer attributes for class-level span creation
            _span_attrs = {
                SpanAttributes.AGENT_NAME: name,
                SpanAttributes.AGENT_TENANT: tenant_value,
                SpanAttributes.AGENT_FRAMEWORK: framework_value,
            }
            
            # Pass 2: Wrap __init__ to set up runtime context when instantiated
            original_init = func.__init__
            
            @functools.wraps(original_init)
            def wrapped_init(self, *args, **kwargs):
                """Initialize runtime context after identity is established."""
                _setup_runtime_context(name, tenant_value, resources, regions, subprocess_support, framework_value, func)
                # Start root span for class-based agent lifecycle
                tracer = get_tracer()
                self._hexr_root_span = tracer.start_span(
                    SpanNames.AGENT_INVOKE,
                    attributes=_span_attrs,
                )
                # Record agent metrics
                meter = get_meter()
                meter.create_counter(
                    MetricNames.AGENT_INVOCATIONS,
                    unit="1",
                    description="Number of agent invocations",
                ).add(1, {"hexr.agent.name": name, "hexr.agent.framework": framework_value})
                meter.create_up_down_counter(
                    MetricNames.AGENT_ACTIVE,
                    unit="1",
                    description="Currently active agent instances",
                ).add(1, {"hexr.agent.name": name})
                self._hexr_invoke_start = time.time()
                original_init(self, *args, **kwargs)
            
            func.__init__ = wrapped_init

            # A2A: Store handler reference for bridge auto-start
            if a2a:
                func._hexr_a2a = True
                func._hexr_a2a_handler = None  # Set by user via .a2a_handler()

            return func
        else:
            # FUNCTION: Write marker when function executes (traditional function-based agents)
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                """Wrapper that establishes identity then sets up runtime context."""
                # Pass 1: Write marker file FIRST for PID mapper discovery
                _write_marker_file(name)
                logger.debug(f"✅ Identity marker created for function {name}")
                
                # Pass 2: Set up runtime context
                _setup_runtime_context(name, tenant_value, resources, regions, subprocess_support, framework_value, func)
                
                # Set up metric instruments
                meter = get_meter()
                _agent_counter = meter.create_counter(
                    MetricNames.AGENT_INVOCATIONS,
                    unit="1",
                    description="Number of agent invocations",
                )
                _agent_active = meter.create_up_down_counter(
                    MetricNames.AGENT_ACTIVE,
                    unit="1",
                    description="Currently active agent instances",
                )
                _agent_duration = meter.create_histogram(
                    MetricNames.AGENT_DURATION,
                    unit="s",
                    description="Agent invocation duration in seconds",
                )
                _metric_attrs = {"hexr.agent.name": name, "hexr.agent.framework": framework_value}

                _agent_counter.add(1, _metric_attrs)
                _agent_active.add(1, {"hexr.agent.name": name})
                _invoke_start = time.time()

                # Execute agent function with OTel root span
                tracer = get_tracer()
                with tracer.start_as_current_span(
                    SpanNames.AGENT_INVOKE,
                    attributes={
                        SpanAttributes.AGENT_NAME: name,
                        SpanAttributes.AGENT_TENANT: tenant_value,
                        SpanAttributes.AGENT_FRAMEWORK: framework_value,
                    },
                ) as span:
                    try:
                        result = func(*args, **kwargs)
                        return result
                    except Exception as exc:
                        span.set_attribute(SpanAttributes.ERROR_TYPE, type(exc).__name__)
                        span.set_attribute(SpanAttributes.ERROR_MESSAGE, str(exc)[:256])
                        span.record_exception(exc)
                        try:
                            from opentelemetry.trace import StatusCode
                            span.set_status(StatusCode.ERROR, str(exc)[:256])
                        except ImportError:
                            pass
                        raise
                    finally:
                        # Record duration and decrement active gauge
                        _agent_duration.record(time.time() - _invoke_start, _metric_attrs)
                        _agent_active.add(-1, {"hexr.agent.name": name})
                        # Cleanup
                        from .subprocess_detector import stop_subprocess_monitoring
                        stop_subprocess_monitoring()
                        HexrContext.cleanup_context_file()
                        logger.info(f"Cleaned up context for agent '{name}'")

            # A2A: Attach bridge metadata and run helper
            if a2a:
                wrapper._hexr_a2a = True

                async def _run_a2a(handler=None, host="127.0.0.1", port=8080):
                    """Start the A2A bridge server.

                    If no handler is provided, the decorated function itself is used
                    as the A2A handler (it must accept a Message and return str or
                    list[Artifact]).

                    Args:
                        handler: Optional override handler function.
                        host: Bridge bind address (default: 127.0.0.1).
                        port: Bridge listen port (default: 8080).
                    """
                    from .a2a.bridge import A2ABridge
                    bridge_handler = handler or func
                    bridge = A2ABridge(bridge_handler, host=host, port=port)
                    logger.info(f"Starting A2A bridge for '{name}' on {host}:{port}")
                    await bridge.start()

                wrapper.run_a2a = _run_a2a

            return wrapper

    return decorator


def _setup_runtime_context(
    name: str,
    tenant: str, 
    resources: list[str] | None,
    regions: dict[str, str] | None,
    subprocess_support: bool,
    framework_value: str,
    func: Callable
) -> None:
    """
    Set up runtime context after identity marker is established.
    This is Pass 2 of the two-pass initialization.
    """
    config = HexrConfig.from_environment()

    try:
        # Initialize runtime metadata generator for dynamic subprocess tracking
        from .runtime_metadata import RuntimeMetadataGenerator

        runtime_metadata = RuntimeMetadataGenerator()

        # Get source file for dynamic framework detection
        source_file = None
        try:
            source_file = Path(inspect.getfile(func))
        except (OSError, TypeError):
            pass

        # Initialize agent context with runtime tracking
        runtime_metadata.initialize_agent_context(
            agent_name=name,
            tenant=tenant,
            resources=resources or [],
            regions=regions or {},
            source_file=source_file,
        )

        # Runtime metadata generator already creates all necessary context files
        attestor_metadata = {
            "tenant": tenant,
            "resources": resources or [],
            "regions": regions or {},
            "subprocess_support": subprocess_support,
            "framework": framework_value,
            "runtime_metadata_enabled": True,
            "source_file": str(source_file) if source_file else None,
        }

        # Set agent context with framework-agnostic subprocess detection
        HexrContext.set_agent_context(
            agent_name=name,
            workload_id=f"{tenant}-{name}",
            framework=framework_value,
            metadata=attestor_metadata,
            enable_subprocess_detection=subprocess_support,
        )

        logger.info(
            f"Set agent context: {name} (tenant: {tenant}, framework: {framework_value})"
        )

        if subprocess_support:
            # Enable runtime subprocess monitoring
            runtime_metadata.monitor_subprocess_activity()

            # Enable enhanced framework subprocess detection
            from .framework_integration import (
                enable_framework_subprocess_detection,
            )

            enable_framework_subprocess_detection()
            logger.info(
                f"Enabled framework subprocess detection for {framework_value} multi-agentic patterns"
            )

    except Exception as e:
        logger.error(f"Failed to set up runtime context: {e}")
        raise ProcessContextError(f"Failed to manage agent context: {e}") from e


def _validate_agent_config(
    name: str, tenant: str, resources: list[str] | None, framework: str | None
) -> None:
    """Validate agent configuration parameters."""

    # Validate name (DNS-safe)
    if not name or not name.replace("-", "").replace("_", "").isalnum():
        raise ConfigurationError(
            f"Agent name '{name}' must be DNS-safe (alphanumeric + hyphens)"
        )

    if len(name) > 63:
        raise ConfigurationError(f"Agent name '{name}' must be 63 characters or less")

    # Validate tenant
    if not tenant or not tenant.replace("-", "").replace("_", "").isalnum():
        raise ConfigurationError(
            f"Tenant '{tenant}' must be alphanumeric with hyphens/underscores"
        )

    # Validate resources
    if resources:
        supported_resources = [
            "s3:GetObject",
            "s3:PutObject",
            "s3:ListBucket",
            "bedrock:InvokeModel",
            "bedrock:GetModelInvocationLoggingConfiguration",
            "dynamodb:GetItem",
            "dynamodb:PutItem",
            "dynamodb:Scan",
            "dynamodb:Query",
            "gcp:bigquery.jobs.create",
            "gcp:bigquery.datasets.get",
            "gcp:bigquery.tables.get",
            "gcp:storage.objects.get",
            "gcp:storage.objects.create",
            "gcp:storage.buckets.list",
            "azure:storage.blobs.read",
            "azure:storage.blobs.write",
            "azure:storage.containers.list",
            "azure:keyvault.secrets.get",
            "azure:cognitive.analyze",
        ]

        for resource in resources:
            if resource not in supported_resources:
                logger.warning(f"Resource '{resource}' not in supported list")

    # Framework validation - accept any framework for enterprise flexibility
    # Enterprise customers may use custom frameworks, internal tools, or emerging AI frameworks
    if framework:
        logger.debug(f"Using framework: {framework}")


def _build_static_metadata(
    func: Callable, framework: str, config: HexrConfig
) -> Dict[str, Any]:
    """Build static metadata from function analysis for JSON schema compliance."""
    import ast
    import sys
    from datetime import datetime, timezone

    try:
        # Get function source for AST analysis
        source = inspect.getsource(func)

        # Parse AST for deep analysis
        tree = ast.parse(source)

        # Extract function signature
        function_signature = (
            f"{func.__name__}({', '.join(inspect.signature(func).parameters.keys())})"
        )

        # Extract imports from source
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom):
                module = node.module or ""
                for alias in node.names:
                    imports.append(f"{module}.{alias.name}" if module else alias.name)

        # Detect hexr_tool() calls
        detected_tools = []
        for node in ast.walk(tree):
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "hexr_tool"
            ):
                if node.args and isinstance(node.args[0], ast.Constant):
                    tool_call = {
                        "service": node.args[0].value,
                        "arguments": {},  # Could extract kwargs if needed
                        "line_number": getattr(node, "lineno", 0),
                    }
                    detected_tools.append(tool_call)

        # Calculate complexity score (simple metric based on AST nodes)
        complexity_score = len(list(ast.walk(tree))) / 10.0

        # Get framework version if available
        framework_version = _get_framework_version(framework)

        # Get Hexr SDK version
        hexr_sdk_version = getattr(sys.modules.get("hexr"), "__version__", "0.1.0")

        static_metadata = {
            "framework_version": framework_version,
            "hexr_sdk_version": hexr_sdk_version,
            "build_timestamp": datetime.now(timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
            "container_image": _get_container_image_info(),
            "detected_tools": detected_tools,
            "ast_analysis": {
                "function_signature": function_signature,
                "imports": imports,
                "decorators": _extract_decorators(tree),
                "complexity_score": complexity_score,
            },
            # Framework-specific metadata
            "agent_dependencies": _analyze_agent_dependencies(tree, framework),
            "reasoning_depth": _estimate_reasoning_depth(tree, framework),
            "reflection_enabled": _detect_reflection_patterns(source, framework),
            "planning_horizon": _detect_planning_horizon(source, framework),
            "memory_persistence": _detect_memory_persistence(source, framework),
        }

        return static_metadata

    except Exception as e:
        logger.warning(f"Failed to build complete static metadata: {e}")
        # Return minimal metadata on error
        return {
            "framework_version": f"{framework}==unknown",
            "hexr_sdk_version": "0.1.0",
            "build_timestamp": datetime.now(timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
            "container_image": "hexr.registry/unknown",
            "detected_tools": [],
            "ast_analysis": {},
        }


def _get_framework_version(framework: str) -> str:
    """Get installed framework version."""
    try:
        if framework == "crewai":
            import crewai  # type: ignore

            return f"crewai=={crewai.__version__}"
        elif framework == "langchain":
            import langchain  # type: ignore

            return f"langchain=={langchain.__version__}"
        elif framework == "autogen":
            import autogen  # type: ignore

            return f"autogen=={autogen.__version__}"
        else:
            return f"{framework}==unknown"
    except ImportError:
        return f"{framework}==not-installed"
    except AttributeError:
        return f"{framework}==version-unknown"


def _get_container_image_info() -> str:
    """Get container image information from environment."""
    # Check common container environment variables
    image_env_vars = [
        "CONTAINER_IMAGE",
        "IMAGE_NAME",
        "HEXR_CONTAINER_IMAGE",
        "KUBERNETES_IMAGE",
    ]

    for env_var in image_env_vars:
        image = os.environ.get(env_var)
        if image:
            return image

    # Default fallback
    return "hexr.registry/unknown"


def _extract_decorators(tree) -> List[Dict[str, Any]]:
    """Extract decorators from AST."""
    import ast

    decorators = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef):
            for decorator in node.decorator_list:
                if isinstance(decorator, ast.Name):
                    decorators.append({"name": f"@{decorator.id}", "args": {}})
                elif isinstance(decorator, ast.Call) and isinstance(
                    decorator.func, ast.Name
                ):
                    decorators.append({"name": f"@{decorator.func.id}", "args": {}})
    return decorators


def _analyze_agent_dependencies(tree, framework: str) -> List[str]:
    """Analyze agent dependencies based on framework patterns."""
    # Framework-specific dependency analysis could be implemented here
    # For now, return empty list
    return []


def _estimate_reasoning_depth(tree, framework: str) -> int:
    """Estimate reasoning depth based on code complexity."""
    import ast

    # Simple heuristic: count nested function calls and control structures
    depth = 1
    for node in ast.walk(tree):
        if isinstance(node, (ast.If, ast.For, ast.While, ast.With)):
            depth += 1

    return min(depth, 10)  # Cap at 10 per schema


def _detect_reflection_patterns(source: str, framework: str) -> bool:
    """Detect if agent uses reflection patterns."""
    reflection_keywords = [
        "reflect",
        "critique",
        "evaluate",
        "review",
        "analyze_result",
    ]
    return any(keyword in source.lower() for keyword in reflection_keywords)


def _detect_planning_horizon(source: str, framework: str) -> str:
    """Detect planning horizon from code patterns."""
    if "long_term" in source.lower() or "strategic" in source.lower():
        return "long_term"
    elif "plan" in source.lower() or "strategy" in source.lower():
        return "short_term"
    else:
        return "immediate"


def _detect_memory_persistence(source: str, framework: str) -> bool:
    """Detect if agent uses persistent memory."""
    memory_keywords = ["memory", "persist", "store", "save", "database", "cache"]
    return any(keyword in source.lower() for keyword in memory_keywords)


def get_agent_metadata(func: Callable) -> dict[str, Any] | None:
    """Get Hexr metadata from decorated function."""
    return getattr(func, "_hexr_metadata", None)
