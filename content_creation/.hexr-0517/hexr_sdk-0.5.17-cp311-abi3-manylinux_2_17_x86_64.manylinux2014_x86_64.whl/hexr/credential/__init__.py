"""Credential exchange integration for Hexr SDK."""

from .injector_client import CredentialInjectorClient

__all__ = ["CredentialInjectorClient"]
