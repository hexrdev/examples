"""Credential Injector client for cloud credential exchange."""

import os
import time
from typing import Any

import requests

from ..exceptions import CredentialError
from ..observability import get_tracer, inject_b3_headers, SpanNames, SpanAttributes
from ..utils.simple_logging import get_logger

logger = get_logger(__name__)

# Default URLs for credential injector access
# When Envoy mTLS sidecar is enabled, route through localhost:15001
# When disabled (legacy/testing), route directly to service
ENVOY_MTLS_URL = "http://localhost:15001"
DIRECT_URL = "http://hexr-credential-injector.hexr-system.svc.cluster.local:8080"


def _get_default_injector_url() -> str:
    """
    Determine the default credential injector URL based on configuration.
    
    Priority:
    1. HEXR_CREDENTIAL_INJECTOR_URL env var (explicit override)
    2. HEXR_USE_ENVOY_MTLS=true -> localhost:15001 (Envoy sidecar)
    3. HEXR_USE_ENVOY_MTLS=false -> direct service URL
    
    Default: Envoy mTLS enabled (localhost:15001)
    """
    # Explicit URL override takes highest priority
    explicit_url = os.getenv("HEXR_CREDENTIAL_INJECTOR_URL")
    if explicit_url:
        return explicit_url
    
    # Check if Envoy mTLS is enabled (default: true in production)
    use_envoy = os.getenv("HEXR_USE_ENVOY_MTLS", "true").lower() in ("true", "1", "yes")
    
    if use_envoy:
        logger.debug("Using Envoy mTLS sidecar for credential exchange (localhost:15001)")
        return ENVOY_MTLS_URL
    else:
        logger.debug("Using direct connection to credential-injector (Envoy mTLS disabled)")
        return DIRECT_URL


class CredentialInjectorClient:
    """
    Client for Hexr Credential Injector service.

    Exchanges JWT-SVIDs for cloud credentials (AWS, GCP, Azure) via OIDC federation.
    
    In production, requests are routed through the local Envoy sidecar which:
    1. Establishes mTLS with credential-injector's Envoy sidecar
    2. Presents the pod's X.509-SVID for mutual authentication
    3. Routes the request to credential-injector
    
    Set HEXR_USE_ENVOY_MTLS=false to bypass Envoy (for testing/legacy).
    """

    def __init__(self, injector_url: str | None = None, timeout: int = 30):
        """
        Initialize Credential Injector client.

        Args:
            injector_url: URL of Credential Injector service
                         (default: determined by HEXR_USE_ENVOY_MTLS setting)
                         - true: http://localhost:15001 (via Envoy sidecar)
                         - false: http://hexr-credential-injector.hexr-system:8080 (direct)
            timeout: HTTP request timeout in seconds
        """
        self.injector_url = injector_url or _get_default_injector_url()
        self.timeout = timeout
        
        logger.info(f"CredentialInjectorClient initialized with URL: {self.injector_url}")

    def exchange_credentials(
        self,
        jwt_svid: str,
        service_name: str,
        region: str | None = None,
        **kwargs,
    ) -> dict[str, Any]:
        """
        Exchange JWT-SVID for cloud credentials.

        Args:
            jwt_svid: JWT-SVID token from SPIRE Agent
            service_name: Cloud service ("aws_s3", "gcp_bigquery", "azure_storage")
            region: Cloud region override
            **kwargs: Additional service-specific parameters

        Returns:
            dict with cloud credentials:
                - For AWS: access_key_id, secret_access_key, session_token
                - For GCP: service_account_token, project_id
                - For Azure: access_token, tenant_id

        Raises:
            CredentialError: If exchange fails

        Example:
            >>> client = CredentialInjectorClient()
            >>> creds = client.exchange_credentials(
            ...     jwt_svid="eyJhbGc...",
            ...     service_name="aws_s3",
            ...     region="us-east-1"
            ... )
            >>> print(creds["access_key_id"])
            ASIATESTACCESSKEY...
        """
        # Parse service provider from service_name prefix
        # Supported: aws_s3, aws_bedrock, gcp_bigquery, azure_storage, etc.
        if service_name.startswith("aws_"):
            provider = "aws"
        elif service_name.startswith("gcp_"):
            provider = "gcp"
        elif service_name.startswith("azure_"):
            provider = "azure"
        else:
            raise CredentialError(f"Unsupported service: {service_name}")

        # Build request payload matching Go credential-injector API
        # The Go service auto-selects IAM role from tenant config based on SPIFFE ID
        payload = {
            "region": region or "us-east-1",
            "service_name": service_name,  # For OPA policy evaluation
        }
        
        # Add any additional kwargs (e.g., iam_role override)
        if kwargs:
            payload.update(kwargs)

        # Build request headers with JWT-SVID as Bearer token
        headers = {
            "Authorization": f"Bearer {jwt_svid}",
            "Content-Type": "application/json",
            "User-Agent": "hexr-sdk-python/0.1.6",
        }

        # Inject B3 + W3C trace propagation headers for cross-service tracing
        inject_b3_headers(headers)

        # Exchange endpoint
        exchange_url = f"{self.injector_url}/v1/credentials/exchange"

        logger.info(f"Exchanging JWT-SVID for {provider} credentials at {exchange_url}")

        # Retry configuration for Envoy sidecar startup race condition
        # Envoy may take ~2-3 seconds to fully initialize after container start
        max_retries = 5
        base_delay = 0.5  # 500ms base delay with exponential backoff

        tracer = get_tracer()
        with tracer.start_as_current_span(
            SpanNames.CREDENTIAL_EXCHANGE,
            attributes={
                SpanAttributes.CREDENTIAL_PROVIDER: provider,
                SpanAttributes.CREDENTIAL_INJECTOR_URL: exchange_url,
                SpanAttributes.TOOL_SERVICE: service_name,
                SpanAttributes.TOOL_REGION: region or "us-east-1",
            },
        ) as span:

            response = None
            for attempt in range(max_retries):
                try:
                    # Make HTTP POST request to Credential Injector
                    response = requests.post(
                        exchange_url,
                        json=payload,
                        headers=headers,
                        timeout=self.timeout,
                    )
                    break  # Success, exit retry loop
                except requests.exceptions.ConnectionError as e:
                    span.add_event("connection_retry", {"attempt": attempt + 1})
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)  # Exponential backoff: 0.5, 1, 2, 4, 8s
                        logger.warning(
                            f"Connection to {self.injector_url} failed (attempt {attempt + 1}/{max_retries}), "
                            f"retrying in {delay:.1f}s... (Envoy sidecar may still be starting)"
                        )
                        time.sleep(delay)
                    else:
                        span.set_attribute(SpanAttributes.ERROR_TYPE, "ConnectionError")
                        span.record_exception(e)
                        raise CredentialError(
                            f"Failed to connect to Credential Injector at {self.injector_url} "
                            f"after {max_retries} attempts: {e}. "
                            "Check that Envoy sidecar is running and HEXR_CREDENTIAL_INJECTOR_URL is correct."
                        ) from e

            try:

                # Check for errors
                if response.status_code == 401:
                    span.set_attribute(SpanAttributes.ERROR_TYPE, "AuthenticationRejected")
                    raise CredentialError(
                        "Credential Injector rejected JWT-SVID. "
                        "Check that SPIFFE ID is authorized for cloud access."
                    )
                elif response.status_code == 403:
                    # OPA deny — record in span for Jaeger visibility
                    span.set_attribute(SpanAttributes.OPA_DECISION, "deny")
                    span.set_attribute(SpanAttributes.ERROR_TYPE, "OPADeny")
                    raise CredentialError(
                        f"Credential Injector denied access to {provider} service. "
                        "Check cloud provider OIDC configuration and IAM roles."
                    )
                elif response.status_code >= 400:
                    error_msg = response.text or "Unknown error"
                    span.set_attribute(SpanAttributes.ERROR_TYPE, f"HTTP_{response.status_code}")
                    raise CredentialError(
                        f"Credential exchange failed (HTTP {response.status_code}): {error_msg}"
                    )

                # Parse response
                credentials = response.json()

                logger.info(f"Successfully exchanged JWT-SVID for {provider} credentials")

                # Validate required fields based on provider
                self._validate_credentials(credentials, provider)
                
                # Convert expiration to expiry (unix timestamp) for cache compatibility
                # Go service returns "expiration" as ISO timestamp
                if "expiration" in credentials:
                    from datetime import datetime
                    try:
                        # Parse ISO timestamp from Go service
                        exp_str = credentials["expiration"]
                        if isinstance(exp_str, str):
                            # Handle ISO format: 2026-01-10T01:56:56Z
                            dt = datetime.fromisoformat(exp_str.replace("Z", "+00:00"))
                            credentials["expiry"] = int(dt.timestamp())
                        else:
                            # Already a timestamp
                            credentials["expiry"] = int(exp_str)
                    except (ValueError, TypeError) as e:
                        logger.warning(f"Failed to parse expiration: {e}, using 1h default")
                        credentials["expiry"] = int(time.time()) + 3600
                else:
                    # Default 1 hour expiry if not provided
                    credentials["expiry"] = int(time.time()) + 3600

                span.set_attribute(SpanAttributes.OPA_DECISION, "allow")
                span.set_attribute(SpanAttributes.CREDENTIAL_EXPIRY, credentials["expiry"])
                return credentials

            except requests.exceptions.Timeout as e:
                span.set_attribute(SpanAttributes.ERROR_TYPE, "Timeout")
                span.record_exception(e)
                raise CredentialError(
                    f"Credential Injector request timed out after {self.timeout}s. "
                    "Check that Credential Injector service is running."
                ) from e
            except requests.exceptions.RequestException as e:
                span.set_attribute(SpanAttributes.ERROR_TYPE, "RequestException")
                span.record_exception(e)
                raise CredentialError(f"Credential exchange request failed: {e}") from e

    def _validate_credentials(self, credentials: dict[str, Any], provider: str) -> None:
        """
        Validate that credentials contain required fields.

        Args:
            credentials: Credentials dict from Credential Injector
            provider: Cloud provider (aws/gcp/azure)

        Raises:
            CredentialError: If required fields are missing
        """
        if provider == "aws":
            required = ["access_key_id", "secret_access_key", "session_token"]
            missing = [f for f in required if f not in credentials]
            if missing:
                raise CredentialError(
                    f"AWS credentials missing required fields: {missing}"
                )

        elif provider == "gcp":
            required = ["service_account_token", "project_id"]
            missing = [f for f in required if f not in credentials]
            if missing:
                raise CredentialError(
                    f"GCP credentials missing required fields: {missing}"
                )

        elif provider == "azure":
            required = ["access_token", "tenant_id"]
            missing = [f for f in required if f not in credentials]
            if missing:
                raise CredentialError(
                    f"Azure credentials missing required fields: {missing}"
                )

    def health_check(self) -> dict[str, Any]:
        """
        Check if Credential Injector service is healthy.

        Returns:
            dict with health status

        Raises:
            CredentialError: If service is unhealthy
        """
        health_url = f"{self.injector_url}/health"

        try:
            response = requests.get(health_url, timeout=5)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            raise CredentialError(
                f"Credential Injector health check failed: {e}"
            ) from e
