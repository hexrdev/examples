"""
Credential Cache for hexr_tool() - Enterprise Implementation

Provides thread-safe, per-process credential caching with proactive refresh
to eliminate redundant SPIRE/Injector calls and ensure zero-latency tool access.

Architecture:
- Per-process singleton (matches SPIFFE ID scope)
- Thread-safe access with RLock
- Two-level cache: JWT-SVID + cloud credentials
- 10-minute expiry buffer for unpredictable agent patterns
- Proactive background refresh every 60 seconds
- Observable metrics for future monitoring integration

Usage:
    from hexr.credential.cache import CredentialCache

    cache = CredentialCache.get_instance()
    jwt = cache.get_jwt_svid()
    creds = cache.get_cloud_credentials("aws_s3", "us-east-1")
"""

import atexit
import json
import logging
import os
import threading
import time
from typing import TYPE_CHECKING, Any, Optional

from ..observability import get_tracer, get_meter, SpanNames, SpanAttributes, MetricNames

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from redis import Redis
    from redis.cluster import RedisCluster
    from redis.exceptions import RedisError

try:
    from redis import Redis as _Redis
    from redis.cluster import RedisCluster as _RedisCluster
    from redis.exceptions import RedisError as _RedisError
    REDIS_AVAILABLE = True
    Redis = _Redis
    RedisCluster = _RedisCluster
    RedisError = _RedisError
except ImportError:
    REDIS_AVAILABLE = False
    Redis = None  # type: ignore
    RedisCluster = None  # type: ignore
    RedisError = Exception  # type: ignore
    logger.warning("redis package not installed, L2 distributed cache disabled")


class CredentialCache:
    """
    Thread-safe, per-process credential cache.

    Lifetime: From process start to process termination.
    Scope: All hexr_tool() calls within the same Python process.
    Security: Credentials in memory only, never persisted to disk.
    """

    _instance: Optional["CredentialCache"] = None
    _lock = threading.RLock()

    # Configuration (seconds)
    EXPIRY_BUFFER_SECONDS = 600  # 10 minutes - conservative for reasoning LLMs
    REFRESH_CHECK_INTERVAL = 60  # Check for expiry every 60 seconds

    def __init__(self):
        """
        Initialize credential cache.

        Note: Use get_instance() instead of direct instantiation.
        """
        # JWT-SVID cache (single entry per process)
        self._jwt_svid: dict[str, Any] | None = None

        # Cloud credentials cache (keyed by service:region)
        self._cloud_credentials: dict[str, dict[str, Any]] = {}

        # L2: Distributed cache client (optional)
        self._redis_client: Optional[Any] = self._init_redis_client()
        self._tenant_id: str = self._get_tenant_id()

        # Metrics for observability
        self._metrics = {
            "jwt_svid": {
                "cache_hits": 0,
                "cache_misses": 0,
                "spire_fetches": 0,
                "proactive_refreshes": 0,
                "refresh_failures": 0,
            },
            "cloud_credentials": {
                "cache_hits": 0,
                "cache_misses": 0,
                "exchanges": 0,
                "proactive_refreshes": 0,
                "exchange_failures": 0,
                "l1_hits": 0,
                "l2_hits": 0,
                "l2_read_errors": 0,
                "l2_write_errors": 0,
                "l3_fetches": 0,
            },
            "by_service": {},
        }

        # OTel metric instruments (lazy, no-op safe)
        meter = get_meter()
        self._otel_cache_hits = meter.create_counter(
            MetricNames.CACHE_HITS,
            unit="1",
            description="Cache hits by tier",
        )
        self._otel_cache_misses = meter.create_counter(
            MetricNames.CACHE_MISSES,
            unit="1",
            description="Cache misses (L3 fetch required)",
        )
        self._otel_cred_exchanges = meter.create_counter(
            MetricNames.CREDENTIAL_EXCHANGES,
            unit="1",
            description="Credential exchange operations",
        )
        self._otel_cred_failures = meter.create_counter(
            MetricNames.CREDENTIAL_FAILURES,
            unit="1",
            description="Failed credential exchanges",
        )
        self._otel_exchange_duration = meter.create_histogram(
            MetricNames.CREDENTIAL_EXCHANGE_DURATION,
            unit="s",
            description="Credential exchange duration in seconds",
        )
        self._otel_lookup_duration = meter.create_histogram(
            MetricNames.CACHE_LOOKUP_DURATION,
            unit="s",
            description="Cache lookup duration in seconds",
        )

        # Background refresh thread
        self._shutdown_event = threading.Event()
        self._refresh_thread = threading.Thread(
            target=self._background_refresh_loop,
            daemon=True,
            name="hexr-credential-refresh",
        )
        self._refresh_thread.start()
        logger.info("CredentialCache initialized with proactive refresh enabled")

    @classmethod
    def get_instance(cls) -> "CredentialCache":
        """
        Get singleton instance of CredentialCache.

        Thread-safe lazy initialization.

        Returns:
            CredentialCache: Singleton instance
        """
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def _init_redis_client(self) -> Optional[Any]:
        """
        Initialize Redis Cluster client with graceful degradation.

        Reads configuration from environment variables:
        - HEXR_CACHE_REDIS_HOST: Service name (default: hexr-credential-cache.hexr-system)
        - HEXR_CACHE_REDIS_PASSWORD: Authentication password (required)
        - HEXR_CACHE_REDIS_PORT: Service port (default: 6379)
        - HEXR_CACHE_REDIS_CLUSTER: Set to "false" to use single-node mode (default: true)

        Returns:
            Optional[RedisCluster|Redis]: Client if successful, None if unavailable
        """
        if not REDIS_AVAILABLE:
            logger.info("L2 distributed cache disabled (redis package not installed)")
            return None

        try:
            # Default to the PRIMARY service, not the headless one. The
            # deployed Valkey is primary/replica replication (valkey chart with
            # replica.enabled=true, two pods, plus a separate
            # `hexr-credential-cache-read` service), not Redis Cluster. The
            # headless service resolves to every pod, so a write could land on
            # a replica and be rejected READONLY. `hexr-credential-cache` is the
            # writable primary, which is what build/k8s.py, build/a2a.py and
            # build/k8s_generator.py already inject as HEXR_CACHE_REDIS_HOST —
            # this default disagreed with all three.
            redis_host = os.getenv(
                "HEXR_CACHE_REDIS_HOST",
                "hexr-credential-cache.hexr-system"
            )
            redis_port = int(os.getenv("HEXR_CACHE_REDIS_PORT", "6379"))
            redis_password = os.getenv("HEXR_CACHE_REDIS_PASSWORD")
            use_cluster = os.getenv("HEXR_CACHE_REDIS_CLUSTER", "true").lower() != "false"

            if not redis_password:
                logger.info(
                    "HEXR_CACHE_REDIS_PASSWORD not set, L2 distributed cache disabled (using L1+L3 only)"
                )
                return None

            if use_cluster and RedisCluster is not None:
                # Initialize Redis Cluster client (handles MOVED/ASK redirects)
                try:
                    client = RedisCluster(
                        host=redis_host,
                        port=redis_port,
                        password=redis_password,
                        decode_responses=True,
                        socket_timeout=1.0,
                        socket_connect_timeout=1.0,
                        skip_full_coverage_check=True,  # Allow partial cluster
                    )
                    # Test connection
                    client.ping()
                    logger.info(
                        f"L2 distributed cache enabled (redis cluster: {redis_host}:{redis_port})"
                    )
                    return client
                except Exception as cluster_err:
                    logger.warning(f"Redis Cluster connection failed: {cluster_err}, trying single-node mode")
            
            # Fallback to single-node Redis (for non-cluster deployments)
            client = Redis(
                host=redis_host,
                port=redis_port,
                password=redis_password,
                decode_responses=True,
                socket_timeout=1.0,
                socket_connect_timeout=1.0,
            )

            # Test connection
            client.ping()
            logger.info(
                f"L2 distributed cache enabled (redis single-node: {redis_host}:{redis_port})"
            )
            return client

        except Exception as e:
            logger.warning(
                f"L2 distributed cache unavailable, using L1+L3 only: {e}"
            )
            return None

    def _get_tenant_id(self) -> str:
        """
        Get tenant ID from environment for cache key scoping.

        Reads from HEXR_TENANT_ID or falls back to NAMESPACE (Kubernetes namespace).
        Used to enforce tenant isolation in shared L2 cache.

        Returns:
            str: Tenant identifier
        """
        tenant_id = os.getenv("HEXR_TENANT_ID", os.getenv("NAMESPACE", "unknown"))
        logger.debug(f"Tenant ID: {tenant_id}")
        return tenant_id

    def is_credential_safe_to_use(self, expiry_timestamp: int) -> bool:
        """
        Check if credential has at least 10 minutes of validity remaining.

        Conservative buffer ensures safety for:
        - Multi-minute LLM reasoning delays
        - Long-running operations (file uploads, batch processing)
        - Network latency and retries

        Args:
            expiry_timestamp: Unix timestamp when credential expires

        Returns:
            bool: True if credential has >10 minutes left, False otherwise

        Examples:
            >>> # Credential expires in 11 minutes
            >>> cache.is_credential_safe_to_use(time.time() + 660)
            True

            >>> # Credential expires in 9 minutes
            >>> cache.is_credential_safe_to_use(time.time() + 540)
            False
        """
        time_until_expiry = expiry_timestamp - time.time()
        return time_until_expiry > self.EXPIRY_BUFFER_SECONDS

    def get_jwt_svid(self) -> dict[str, Any]:
        """
        Get cached JWT-SVID or fetch new if expired.

        Thread-safe, blocking call. Returns cached JWT if valid,
        otherwise fetches new JWT from SPIRE Agent.

        Returns:
            dict: {
                "token": str,           # JWT token string
                "spiffe_id": str,       # SPIFFE ID from JWT
                "expiry": int,          # Unix timestamp
                "fetched_at": int,      # When we got it
            }

        Raises:
            Exception: SPIRE Agent errors (socket not found, attestation failed)
        """
        with self._lock:
            # Check if we have cached JWT and it's still safe to use
            if self._jwt_svid is not None:
                if self.is_credential_safe_to_use(self._jwt_svid["expiry"]):
                    self._metrics["jwt_svid"]["cache_hits"] += 1
                    self._otel_cache_hits.add(1, {"hexr.cache.tier": "jwt_svid"})
                    logger.debug(
                        f"JWT-SVID cache hit (expires in {self._jwt_svid['expiry'] - time.time():.0f}s)"
                    )
                    return self._jwt_svid
                else:
                    logger.info(
                        f"JWT-SVID expired or expiring soon (< {self.EXPIRY_BUFFER_SECONDS}s remaining)"
                    )

            # Cache miss - fetch new JWT from SPIRE
            self._metrics["jwt_svid"]["cache_misses"] += 1
            self._otel_cache_misses.add(1, {"hexr.cache.tier": "jwt_svid"})
            logger.info("Fetching new JWT-SVID from SPIRE Agent")

            try:
                new_jwt = self._fetch_jwt_from_spire()
                self._jwt_svid = new_jwt
                self._metrics["jwt_svid"]["spire_fetches"] += 1
                logger.info(
                    f"JWT-SVID cached (expires at {new_jwt['expiry']}, SPIFFE ID: {new_jwt['spiffe_id']})"
                )
                return new_jwt
            except Exception as e:
                logger.error(f"Failed to fetch JWT-SVID from SPIRE: {e}")
                raise

    def get_cloud_credentials(
        self, service: str, region: str | None = None
    ) -> dict[str, Any]:
        """
        Get cached cloud credentials with hierarchical L1 → L2 → L3 lookup.

        Three-tier architecture:
        - L1 (Local): Per-process in-memory cache (fastest)
        - L2 (Distributed): Valkey cluster shared across pods (reduces L3 calls)
        - L3 (Source): Credential Injector (slowest, generates new credentials)

        Thread-safe, blocking call with graceful L2 degradation.

        Args:
            service: Service name (e.g., "aws_s3", "gcp_bigquery")
            region: Cloud region (e.g., "us-east-1", "us")

        Returns:
            dict: Cloud-specific credential structure
                AWS: {access_key_id, secret_access_key, session_token, ...}
                GCP: {service_account_token, project_id, ...}
                Azure: {client_id, client_secret, tenant_id, ...}

        Raises:
            Exception: Credential exchange errors (invalid JWT, timeout, etc.)
        """
        cache_key = self._make_cache_key(service, region)
        tracer = get_tracer()

        with tracer.start_as_current_span(
            SpanNames.CACHE_LOOKUP,
            attributes={
                SpanAttributes.CACHE_KEY: cache_key,
                SpanAttributes.TOOL_SERVICE: service,
                SpanAttributes.TOOL_REGION: region or "default",
            },
        ) as lookup_span:
            with self._lock:
                # Initialize per-service metrics if needed
                if cache_key not in self._metrics["by_service"]:
                    self._metrics["by_service"][cache_key] = {"hits": 0, "misses": 0}

                # L1: Check local process cache
                with tracer.start_as_current_span(
                    SpanNames.CACHE_L1,
                    attributes={SpanAttributes.CACHE_TIER: "l1", SpanAttributes.CACHE_KEY: cache_key},
                ) as l1_span:
                    if cache_key in self._cloud_credentials:
                        creds = self._cloud_credentials[cache_key]
                        if self.is_credential_safe_to_use(creds["expiry"]):
                            self._metrics["cloud_credentials"]["cache_hits"] += 1
                            self._metrics["cloud_credentials"]["l1_hits"] += 1
                            self._metrics["by_service"][cache_key]["hits"] += 1
                            self._otel_cache_hits.add(1, {"hexr.cache.tier": "l1", "hexr.tool.service": service})
                            ttl = creds["expiry"] - time.time()
                            l1_span.set_attribute(SpanAttributes.CACHE_HIT, True)
                            l1_span.set_attribute(SpanAttributes.CACHE_TTL_REMAINING, int(ttl))
                            lookup_span.set_attribute(SpanAttributes.CACHE_TIER, "l1")
                            lookup_span.set_attribute(SpanAttributes.CACHE_HIT, True)
                            logger.debug(
                                f"L1 cache hit: {cache_key} (expires in {ttl:.0f}s)"
                            )
                            return creds
                        else:
                            l1_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                            logger.debug(
                                f"L1 cache expired: {cache_key} (< {self.EXPIRY_BUFFER_SECONDS}s remaining)"
                            )
                    else:
                        l1_span.set_attribute(SpanAttributes.CACHE_HIT, False)

                # L2: Check distributed cache
                with tracer.start_as_current_span(
                    SpanNames.CACHE_L2,
                    attributes={SpanAttributes.CACHE_TIER: "l2", SpanAttributes.CACHE_KEY: cache_key},
                ) as l2_span:
                    if self._redis_client is not None:
                        redis_key = f"hexr:creds:{self._tenant_id}:{service}:{region}"
                        try:
                            cached_json = self._redis_client.get(redis_key)
                            if cached_json:
                                creds = json.loads(cached_json)

                                # Validate tenant matches (security)
                                if creds.get("tenant") == self._tenant_id:
                                    if self.is_credential_safe_to_use(creds["expiry"]):
                                        # Warm L1 cache for future calls
                                        self._cloud_credentials[cache_key] = creds
                                        self._metrics["cloud_credentials"]["cache_hits"] += 1
                                        self._metrics["cloud_credentials"]["l2_hits"] += 1
                                        self._metrics["by_service"][cache_key]["hits"] += 1
                                        self._otel_cache_hits.add(1, {"hexr.cache.tier": "l2", "hexr.tool.service": service})
                                        ttl = creds["expiry"] - time.time()
                                        l2_span.set_attribute(SpanAttributes.CACHE_HIT, True)
                                        l2_span.set_attribute(SpanAttributes.CACHE_TTL_REMAINING, int(ttl))
                                        lookup_span.set_attribute(SpanAttributes.CACHE_TIER, "l2")
                                        lookup_span.set_attribute(SpanAttributes.CACHE_HIT, True)
                                        logger.info(
                                            f"L2 cache hit: {cache_key} (expires in {ttl:.0f}s)"
                                        )
                                        return creds
                                    else:
                                        l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                                        logger.debug(f"L2 cache expired: {redis_key}")
                                else:
                                    l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                                    logger.warning(
                                        f"L2 cache tenant mismatch: expected {self._tenant_id}, got {creds.get('tenant')}"
                                    )
                            else:
                                l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                        except RedisError as e:
                            logger.warning(f"L2 cache read error: {e}")
                            l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                            l2_span.set_attribute(SpanAttributes.ERROR_TYPE, "RedisError")
                            self._metrics["cloud_credentials"]["l2_read_errors"] += 1
                            # Fall through to L3
                        except json.JSONDecodeError as e:
                            logger.warning(f"L2 cache corrupt data: {e}")
                            l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                            self._metrics["cloud_credentials"]["l2_read_errors"] += 1
                            # Fall through to L3
                    else:
                        l2_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                        l2_span.add_event("l2_disabled", {"reason": "redis_client_unavailable"})

                # L3: Fetch from Credential Injector
                with tracer.start_as_current_span(
                    SpanNames.CACHE_L3,
                    attributes={SpanAttributes.CACHE_TIER: "l3", SpanAttributes.CACHE_KEY: cache_key},
                ) as l3_span:
                    self._metrics["cloud_credentials"]["cache_misses"] += 1
                    self._metrics["cloud_credentials"]["l3_fetches"] += 1
                    self._metrics["by_service"][cache_key]["misses"] += 1
                    self._otel_cache_misses.add(1, {"hexr.cache.tier": "l3", "hexr.tool.service": service})
                    lookup_span.set_attribute(SpanAttributes.CACHE_TIER, "l3")
                    lookup_span.set_attribute(SpanAttributes.CACHE_HIT, False)
                    logger.info(f"L3 fetch: {cache_key} (new credential exchange)")

                    try:
                        _exchange_start = time.time()

                        # Get JWT-SVID (may fetch from cache or SPIRE)
                        jwt_svid = self.get_jwt_svid()

                        # Exchange with Credential Injector
                        new_creds = self._exchange_jwt_for_credentials(
                            jwt_svid=jwt_svid["token"], service=service, region=region
                        )

                        # Record exchange duration
                        self._otel_exchange_duration.record(
                            time.time() - _exchange_start,
                            {"hexr.tool.service": service},
                        )

                        # Add metadata for cache management
                        new_creds["service"] = service
                        new_creds["region"] = region
                        new_creds["tenant"] = self._tenant_id  # Tag with tenant for security
                        new_creds["jwt_svid_used"] = jwt_svid["token"]
                        new_creds["fetched_at"] = int(time.time())

                        # Write to L2 distributed cache (best effort)
                        if self._redis_client is not None:
                            redis_key = f"hexr:creds:{self._tenant_id}:{service}:{region}"
                            try:
                                ttl_seconds = 3000  # 50 minutes (10min buffer before 60min expiry)
                                self._redis_client.setex(
                                    name=redis_key,
                                    time=ttl_seconds,
                                    value=json.dumps(new_creds)
                                )
                                logger.debug(f"L2 cache write: {redis_key} (TTL: {ttl_seconds}s)")
                            except RedisError as e:
                                logger.warning(f"L2 cache write error: {e}")
                                self._metrics["cloud_credentials"]["l2_write_errors"] += 1
                                # Continue anyway - L1 still works

                        # Write to L1 local cache
                        self._cloud_credentials[cache_key] = new_creds
                        self._metrics["cloud_credentials"]["exchanges"] += 1
                        self._otel_cred_exchanges.add(1, {"hexr.tool.service": service})
                        l3_span.set_attribute(SpanAttributes.CREDENTIAL_EXPIRY, new_creds["expiry"])
                        l3_span.set_attribute(SpanAttributes.CREDENTIAL_SPIFFE_ID, jwt_svid.get("spiffe_id", "unknown"))
                        logger.info(f"L1/L2/L3 cached: {cache_key} (expires at {new_creds['expiry']})")
                        return new_creds
                    except Exception as e:
                        logger.error(f"Failed to exchange credentials for {cache_key}: {e}")
                        self._metrics["cloud_credentials"]["exchange_failures"] += 1
                        self._otel_cred_failures.add(1, {"hexr.tool.service": service})
                        l3_span.set_attribute(SpanAttributes.ERROR_TYPE, type(e).__name__)
                        l3_span.record_exception(e)
                        raise

    def _make_cache_key(self, service: str, region: str | None = None) -> str:
        """
        Create cache key for cloud credentials.

        Format: service:region or service:None

        Args:
            service: Service name
            region: Region name (optional)

        Returns:
            str: Cache key

        Examples:
            >>> cache._make_cache_key("aws_s3", "us-east-1")
            "aws_s3:us-east-1"
            >>> cache._make_cache_key("gcp_bigquery", None)
            "gcp_bigquery:None"
        """
        return f"{service}:{region}"

    def _background_refresh_loop(self):
        """
        Background thread that proactively refreshes credentials before expiry.

        Runs every 60 seconds to check if any credentials need refresh.
        Ensures zero-latency hexr_tool() calls by refreshing ahead of time.

        This is a daemon thread that runs for the lifetime of the process.
        """
        logger.info("Starting credential refresh background thread")

        while not self._shutdown_event.wait(timeout=self.REFRESH_CHECK_INTERVAL):
            try:
                self._check_and_refresh_jwt_svid()
                self._check_and_refresh_cloud_credentials()
            except Exception as e:
                logger.error(f"Background refresh error: {e}", exc_info=True)
                # Don't crash the thread - keep trying

        logger.info("Credential refresh thread shutting down")

    def _check_and_refresh_jwt_svid(self):
        """
        Proactively refresh JWT-SVID if expiring soon.

        Called by background thread every 60 seconds.
        Refreshes JWT if it has < 10 minutes remaining.
        """
        with self._lock:
            if self._jwt_svid is None:
                return  # No JWT cached yet

            if not self.is_credential_safe_to_use(self._jwt_svid["expiry"]):
                time_left = self._jwt_svid["expiry"] - time.time()
                logger.info(
                    f"Proactively refreshing JWT-SVID ({time_left:.0f}s remaining < {self.EXPIRY_BUFFER_SECONDS}s buffer)"
                )

                try:
                    new_jwt = self._fetch_jwt_from_spire()
                    old_expiry = self._jwt_svid["expiry"]
                    self._jwt_svid = new_jwt
                    self._metrics["jwt_svid"]["proactive_refreshes"] += 1
                    logger.info(
                        f"JWT-SVID proactively refreshed (old expiry: {old_expiry}, new expiry: {new_jwt['expiry']})"
                    )
                except Exception as e:
                    logger.error(f"Proactive JWT refresh failed: {e}", exc_info=True)
                    self._metrics["jwt_svid"]["refresh_failures"] += 1

    def _check_and_refresh_cloud_credentials(self):
        """
        Proactively refresh cloud credentials if expiring soon.

        Called by background thread every 60 seconds.
        Refreshes any credentials with < 10 minutes remaining.
        """
        with self._lock:
            for cache_key, creds in list(self._cloud_credentials.items()):
                if not self.is_credential_safe_to_use(creds["expiry"]):
                    time_left = creds["expiry"] - time.time()
                    logger.info(
                        f"Proactively refreshing {cache_key} ({time_left:.0f}s remaining < {self.EXPIRY_BUFFER_SECONDS}s buffer)"
                    )

                    try:
                        # Get fresh JWT-SVID (may trigger JWT refresh too)
                        jwt_svid = self.get_jwt_svid()

                        # Exchange for new credentials
                        new_creds = self._exchange_jwt_for_credentials(
                            jwt_svid=jwt_svid["token"],
                            service=creds["service"],
                            region=creds["region"],
                        )

                        # Preserve metadata
                        new_creds["service"] = creds["service"]
                        new_creds["region"] = creds["region"]
                        new_creds["jwt_svid_used"] = jwt_svid["token"]
                        new_creds["fetched_at"] = int(time.time())

                        old_expiry = creds["expiry"]
                        self._cloud_credentials[cache_key] = new_creds
                        self._metrics["cloud_credentials"]["proactive_refreshes"] += 1
                        logger.info(
                            f"{cache_key} proactively refreshed (old expiry: {old_expiry}, new expiry: {new_creds['expiry']})"
                        )
                    except Exception as e:
                        logger.error(
                            f"Proactive credential refresh failed for {cache_key}: {e}",
                            exc_info=True,
                        )
                        self._metrics["cloud_credentials"]["exchange_failures"] += 1

    def _fetch_jwt_from_spire(self) -> dict[str, Any]:
        """
        Fetch JWT-SVID from SPIRE Agent with retry for Agent sync timing.

        CRITICAL: After SPIRE Server registration completes, SyncAuthorizedEntries
        pushes entries to Agent immediately, but Agent needs processing time before
        it can issue JWT-SVIDs. This retry handles the Agent sync timing gap.

        Retries up to 10 seconds with 500ms intervals for "no identity issued" errors.
        Other errors fail immediately.

        Returns:
            dict: JWT-SVID structure

        Raises:
            Exception: SPIRE connection or attestation errors
        """
        # Import here to avoid circular dependency
        from hexr.spiffe import WorkloadAPIClient

        client = WorkloadAPIClient()
        max_retries = 20  # 20 × 500ms = 10 seconds max wait
        retry_delay = 0.5  # 500ms between retries
        
        for attempt in range(max_retries):
            try:
                jwt_svid = client.fetch_jwt_svid(audience=["hexr-credential-injector"])
                if attempt > 0:
                    logger.info(f"✅ JWT-SVID fetched after {attempt} retries ({attempt * retry_delay:.1f}s)")
                return jwt_svid
            except Exception as e:
                error_msg = str(e).lower()
                
                # Retry only for "no identity issued" (Agent sync timing gap)
                if "no identity issued" in error_msg:
                    if attempt < max_retries - 1:
                        logger.debug(f"⏳ Agent sync in progress, retry {attempt + 1}/{max_retries} after {retry_delay}s...")
                        time.sleep(retry_delay)
                        continue
                    else:
                        # Final retry exhausted
                        logger.error(f"SPIRE JWT-SVID fetch failed after {max_retries} retries ({max_retries * retry_delay:.1f}s): {e}")
                        raise
                else:
                    # Other errors (socket not found, etc.) fail immediately
                    logger.error(f"SPIRE JWT-SVID fetch failed: {e}")
                    raise

    def _exchange_jwt_for_credentials(
        self, jwt_svid: str, service: str, region: str | None = None
    ) -> dict[str, Any]:
        """
        Exchange JWT-SVID for cloud credentials via Credential Injector.

        This will be integrated with existing CredentialInjectorClient.
        For now, this is a placeholder that will be replaced in Phase 5 (integration).

        Args:
            jwt_svid: JWT-SVID token
            service: Service name
            region: Region name

        Returns:
            dict: Cloud credentials structure

        Raises:
            Exception: Credential exchange errors
        """
        # Import here to avoid circular dependency
        import os

        from hexr.credential import CredentialInjectorClient

        try:
            injector_url = os.environ.get(
                "HEXR_CREDENTIAL_INJECTOR_URL",
                "http://hexr-credential-injector.hexr-system.svc.cluster.local:8080",  # Direct to service
            )
            client = CredentialInjectorClient(injector_url=injector_url)
            credentials = client.exchange_credentials(
                jwt_svid=jwt_svid, service_name=service, region=region
            )
            return credentials
        except Exception as e:
            logger.error(f"Credential exchange failed: {e}")
            raise

    def get_metrics(self) -> dict[str, Any]:
        """
        Get cache performance metrics.

        Thread-safe, non-blocking.

        Returns:
            dict: Detailed cache statistics
        """
        with self._lock:
            # Create deep copy to avoid mutation
            import copy

            return copy.deepcopy(self._metrics)

    def get_cache_summary(self) -> dict[str, Any]:
        """
        Get human-readable cache summary.

        Returns:
            dict: Cache status and metrics summary
        """
        with self._lock:
            summary = {
                "jwt_svid": None,
                "credentials": {},
                "metrics": {
                    "total_spire_calls": self._metrics["jwt_svid"]["spire_fetches"],
                    "total_exchange_calls": self._metrics["cloud_credentials"][
                        "exchanges"
                    ],
                    "jwt_cache_hit_rate": 0.0,
                    "credentials_cache_hit_rate": 0.0,
                },
            }

            # JWT-SVID summary
            if self._jwt_svid is not None:
                expires_in = self._jwt_svid["expiry"] - time.time()
                summary["jwt_svid"] = {
                    "cached": True,
                    "expires_in_seconds": int(expires_in),
                    "spiffe_id": self._jwt_svid["spiffe_id"],
                }
            else:
                summary["jwt_svid"] = {"cached": False}

            # Cloud credentials summary
            for cache_key, creds in self._cloud_credentials.items():
                expires_in = creds["expiry"] - time.time()
                summary["credentials"][cache_key] = {
                    "cached": True,
                    "expires_in_seconds": int(expires_in),
                }

            # Calculate hit rates
            jwt_total = (
                self._metrics["jwt_svid"]["cache_hits"]
                + self._metrics["jwt_svid"]["cache_misses"]
            )
            if jwt_total > 0:
                summary["metrics"]["jwt_cache_hit_rate"] = (
                    self._metrics["jwt_svid"]["cache_hits"] / jwt_total
                )

            creds_total = (
                self._metrics["cloud_credentials"]["cache_hits"]
                + self._metrics["cloud_credentials"]["cache_misses"]
            )
            if creds_total > 0:
                summary["metrics"]["credentials_cache_hit_rate"] = (
                    self._metrics["cloud_credentials"]["cache_hits"] / creds_total
                )

            return summary

    def invalidate_jwt_svid(self):
        """Clear cached JWT-SVID (forces refetch on next access)."""
        with self._lock:
            if self._jwt_svid is not None:
                logger.info(
                    f"Invalidating cached JWT-SVID (SPIFFE ID: {self._jwt_svid['spiffe_id']})"
                )
                self._jwt_svid = None

    def invalidate_credentials(
        self, service: str | None = None, region: str | None = None
    ):
        """
        Clear cached credentials.

        Args:
            service: If provided, clear only this service
            region: If provided (with service), clear only this service+region
            If both None, clear ALL credentials
        """
        with self._lock:
            if service is None:
                # Clear all
                count = len(self._cloud_credentials)
                self._cloud_credentials.clear()
                logger.info(f"Invalidated all cached credentials ({count} entries)")
            else:
                # Clear specific service/region
                cache_key = self._make_cache_key(service, region)
                if cache_key in self._cloud_credentials:
                    del self._cloud_credentials[cache_key]
                    logger.info(f"Invalidated cached credentials for {cache_key}")

    def clear_all(self):
        """Clear entire cache (JWT + all credentials)."""
        with self._lock:
            jwt_cleared = self._jwt_svid is not None
            creds_count = len(self._cloud_credentials)

            self._jwt_svid = None
            self._cloud_credentials.clear()

            logger.info(
                f"Cache cleared (JWT: {jwt_cleared}, Credentials: {creds_count} entries)"
            )

    def shutdown(self):
        """
        Graceful shutdown of background refresh thread.

        Called automatically on process termination (atexit).
        Can also be called manually for testing.
        """
        logger.info("Shutting down credential cache")
        self._shutdown_event.set()
        self._refresh_thread.join(timeout=5.0)
        logger.info("Credential cache shutdown complete")


# Global cleanup on process exit
def _cleanup_cache():
    """Cleanup function called on process exit."""
    instance = CredentialCache._instance
    if instance is not None:
        instance.shutdown()


atexit.register(_cleanup_cache)
