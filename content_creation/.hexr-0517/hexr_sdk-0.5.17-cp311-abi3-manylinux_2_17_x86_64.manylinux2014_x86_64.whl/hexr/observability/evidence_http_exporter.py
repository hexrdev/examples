"""Direct-to-evidence-api span exporter for managed runtimes.

Background
----------
The default Hexr telemetry path is OTLP/gRPC to an OpenTelemetry Collector
sidecar that signs each span and writes the resulting evidence row to the
customer-side evidence-api. That works for the Route B (full hybrid) flow
where the agent runs in Kubernetes and Hexr can inject a sidecar.

Route A (managed runtimes — AWS Bedrock AgentCore, GCP GEAP Agent Runtime,
Azure AI Foundry Agent Service) is single-container by design. There is no
sidecar surface to attach a collector to, and the spec (HEXR_HYBRID_PIVOT_TECH_SPEC.md
§1.21.x) says the SDK itself must POST evidence rows directly to
``HEXR_EVIDENCE_API``.

This module supplies that path. It is a `SpanExporter` implementation that
serializes finished spans into Hexr evidence-row JSON and HTTP-POSTs each
batch to ``${HEXR_EVIDENCE_API}/v1/evidence/batch``.

Activation
----------
The exporter is installed automatically by `HexrOTelProvider` when:
  * ``HEXR_EVIDENCE_API`` is set, AND
  * ``OTEL_EXPORTER_OTLP_ENDPOINT`` is *not* set (no collector path)

If both are set, the OTLP exporter takes precedence and this exporter is a
no-op — so a customer who later adds a collector keeps the unified path.

The exported row shape mirrors the span-to-evidence mapping the OTel
collector contrib processor would have produced; the evidence-api stores
both shapes the same way.
"""

from __future__ import annotations

import json
import logging
import os
import time
from typing import TYPE_CHECKING, Any, Sequence
from urllib import error as _urlerror, request as _urlrequest

logger = logging.getLogger(__name__)

if TYPE_CHECKING:  # pragma: no cover
    from opentelemetry.sdk.trace import ReadableSpan
    from opentelemetry.sdk.trace.export import SpanExportResult

try:
    from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult
    _SDK_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SDK_AVAILABLE = False

    class SpanExporter:  # type: ignore[no-redef]
        pass

    class SpanExportResult:  # type: ignore[no-redef]
        SUCCESS = 0
        FAILURE = 1


_EVIDENCE_PATH = "/v1/evidence/batch"
_DEFAULT_TIMEOUT_S = 5.0


class HexrEvidenceHTTPExporter(SpanExporter):
    """POST each batch of spans to ``${HEXR_EVIDENCE_API}/v1/evidence/batch``.

    The exporter is best-effort: a network failure logs at WARNING but never
    raises, so a flaky evidence-api can never crash the agent runtime.
    Combine with `BatchSpanProcessor` to get back-pressure + retry behaviour
    matching the OTLP path.
    """

    def __init__(
        self,
        endpoint: str | None = None,
        *,
        tenant: str | None = None,
        timeout: float = _DEFAULT_TIMEOUT_S,
    ) -> None:
        base = endpoint or os.getenv("HEXR_EVIDENCE_API") or ""
        if base.endswith("/"):
            base = base[:-1]
        self._url = f"{base}{_EVIDENCE_PATH}" if base else ""
        self._tenant = tenant or os.getenv("HEXR_TENANT_ID") or os.getenv("HEXR_TENANT") or "unknown"
        self._timeout = timeout
        self._enabled = bool(self._url)
        if self._enabled:
            logger.info("HexrEvidenceHTTPExporter active: %s (tenant=%s)", self._url, self._tenant)
        else:
            logger.info("HexrEvidenceHTTPExporter disabled (HEXR_EVIDENCE_API unset)")

    # SpanExporter ---------------------------------------------------------

    def export(self, spans: "Sequence[ReadableSpan]") -> "SpanExportResult":
        if not self._enabled or not spans:
            return SpanExportResult.SUCCESS

        rows = [self._span_to_row(s) for s in spans]
        body = json.dumps({"tenant_id": self._tenant, "rows": rows}).encode("utf-8")
        req = _urlrequest.Request(
            self._url,
            data=body,
            headers={"Content-Type": "application/json", "User-Agent": "hexr-sdk/evidence-http"},
            method="POST",
        )
        try:
            with _urlrequest.urlopen(req, timeout=self._timeout) as resp:
                if 200 <= resp.status < 300:
                    return SpanExportResult.SUCCESS
                logger.warning(
                    "evidence-api returned %s for batch of %d rows", resp.status, len(rows),
                )
                return SpanExportResult.FAILURE
        except _urlerror.URLError as exc:
            logger.warning("evidence-api POST failed (%s); dropping %d rows", exc, len(rows))
            return SpanExportResult.FAILURE
        except Exception as exc:  # noqa: BLE001
            logger.warning("evidence-api POST raised %s; dropping %d rows", type(exc).__name__, len(rows))
            return SpanExportResult.FAILURE

    def shutdown(self) -> None:
        return None

    def force_flush(self, timeout_millis: int = 30000) -> bool:  # noqa: ARG002
        return True

    # ----------------------------------------------------------------------

    @staticmethod
    def _span_to_row(span: "ReadableSpan") -> dict[str, Any]:
        """Serialize an OTel ReadableSpan into a Hexr evidence row.

        Schema mirrors what the OTel Collector contrib processor produces
        when writing to evidence-api so both ingestion paths are
        interchangeable from the auditor's perspective.
        """
        ctx = span.get_span_context()
        attrs = dict(span.attributes or {})
        resource_attrs = dict((span.resource.attributes if span.resource else {}) or {})

        start_ns = int(span.start_time or 0)
        end_ns = int(span.end_time or start_ns)
        duration_ms = max(0.0, (end_ns - start_ns) / 1_000_000.0)

        return {
            "schema_version": "0.1.0",
            "trace_id": format(ctx.trace_id, "032x") if ctx else None,
            "span_id": format(ctx.span_id, "016x") if ctx else None,
            "parent_span_id": (
                format(span.parent.span_id, "016x") if span.parent else None
            ),
            "name": span.name,
            "kind": str(span.kind).split(".")[-1] if span.kind else "INTERNAL",
            "start_time_ns": start_ns,
            "end_time_ns": end_ns,
            "duration_ms": duration_ms,
            "attestation_class": "app_attested",
            "agent_name": (
                attrs.get("hexr.agent.name")
                or resource_attrs.get("hexr.agent.name")
                or "unknown"
            ),
            "tool_name": attrs.get("hexr.tool.name") or attrs.get("hexr.tool.service"),
            "framework": resource_attrs.get("hexr.agent.framework")
                or attrs.get("hexr.agent.framework"),
            "tenant_id": resource_attrs.get("hexr.tenant")
                or attrs.get("hexr.tenant.id"),
            "attributes": {str(k): _scalar(v) for k, v in attrs.items()},
            "resource": {str(k): _scalar(v) for k, v in resource_attrs.items()},
            "status": {
                "code": str(span.status.status_code).split(".")[-1] if span.status else "UNSET",
                "description": span.status.description if span.status else None,
            },
            "signed_at_ns": time.time_ns(),
        }


def _scalar(v: Any) -> Any:
    """Coerce OTel attribute values to JSON-safe scalars."""
    if v is None or isinstance(v, (bool, int, float, str)):
        return v
    if isinstance(v, (list, tuple)):
        return [_scalar(x) for x in v]
    return str(v)
