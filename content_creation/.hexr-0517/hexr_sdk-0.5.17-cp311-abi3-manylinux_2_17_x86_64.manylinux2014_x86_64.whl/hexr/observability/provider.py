"""
Hexr OpenTelemetry Provider - Singleton TracerProvider + MeterProvider

Configures OpenTelemetry with:
- OTLP gRPC exporter (to OTel Collector sidecar or cluster collector)
- B3 multi-header propagation (for Envoy mesh compatibility)
- W3C TraceContext propagation (standard)
- Automatic resource attributes (service.name, tenant, agent)

Environment variables:
- OTEL_EXPORTER_OTLP_ENDPOINT: Collector endpoint (default: http://localhost:4317)
- OTEL_SERVICE_NAME: Override service name (default: hexr-sdk)
- HEXR_TENANT_ID / HEXR_TENANT: Tenant identifier for resource attributes
- HEXR_AGENT_NAME: Agent name for resource attributes
- HEXR_OTEL_ENABLED: Set to "false" to disable tracing (default: true)
"""

import logging
import os
import threading
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Attempt to import OTel SDK components
# These are optional dependencies - graceful degradation if not installed
try:
    from opentelemetry import trace, context
    from opentelemetry.trace import Tracer, TracerProvider, StatusCode, SpanKind
    from opentelemetry.trace.propagation import get_current_span
    OTEL_API_AVAILABLE = True
except ImportError:
    OTEL_API_AVAILABLE = False
    logger.debug("opentelemetry-api not installed, tracing disabled")

try:
    from opentelemetry.sdk.trace import TracerProvider as SDKTracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor
    from opentelemetry.sdk.resources import Resource, SERVICE_NAME
    OTEL_SDK_AVAILABLE = True
except ImportError:
    OTEL_SDK_AVAILABLE = False
    logger.debug("opentelemetry-sdk not installed, using NoOp tracer")

try:
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    OTLP_EXPORTER_AVAILABLE = True
except ImportError:
    OTLP_EXPORTER_AVAILABLE = False
    logger.debug("opentelemetry-exporter-otlp-proto-grpc not installed, OTLP export disabled")

try:
    from opentelemetry.propagators.b3 import B3MultiFormat
    B3_AVAILABLE = True
except ImportError:
    B3_AVAILABLE = False
    logger.debug("opentelemetry-propagator-b3 not installed, B3 propagation disabled")

try:
    from opentelemetry.propagators.composite import CompositePropagator
    from opentelemetry.trace.propagation import TraceContextTextMapPropagator
    from opentelemetry import propagate
    PROPAGATION_AVAILABLE = True
except ImportError:
    PROPAGATION_AVAILABLE = False

try:
    from opentelemetry.sdk.metrics import MeterProvider as SDKMeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.metrics import Meter
    METRICS_AVAILABLE = True
except ImportError:
    METRICS_AVAILABLE = False
    logger.debug("opentelemetry-sdk metrics not available")

try:
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
    OTLP_METRIC_EXPORTER_AVAILABLE = True
except ImportError:
    OTLP_METRIC_EXPORTER_AVAILABLE = False
    logger.debug("opentelemetry-exporter-otlp-proto-grpc metric exporter not available")


class HexrOTelProvider:
    """
    Singleton OpenTelemetry provider for the Hexr SDK.

    Initializes TracerProvider, MeterProvider, and propagation on first use.
    Thread-safe lazy initialization. Gracefully degrades if OTel SDK is not
    installed — all spans become no-ops.

    Lifecycle:
        1. First call to get_tracer() or get_meter() triggers initialization
        2. TracerProvider configured with OTLP exporter → OTel Collector
        3. B3 + W3C propagation set globally for Envoy mesh compatibility
        4. shutdown() called on process exit for clean span flush
    """

    _instance: Optional["HexrOTelProvider"] = None
    _lock = threading.Lock()

    def __init__(self) -> None:
        self._tracer_provider: Any = None
        self._meter_provider: Any = None
        self._initialized = False
        self._enabled = os.getenv("HEXR_OTEL_ENABLED", "true").lower() in (
            "true", "1", "yes",
        )

    @classmethod
    def get_instance(cls) -> "HexrOTelProvider":
        """Get or create the singleton provider instance."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def _initialize(self) -> None:
        """
        Initialize OpenTelemetry TracerProvider and propagation.

        Called lazily on first get_tracer() / get_meter() call.
        """
        if self._initialized:
            return

        if not self._enabled:
            logger.info("Hexr OTel tracing disabled (HEXR_OTEL_ENABLED=false)")
            self._initialized = True
            return

        if not OTEL_API_AVAILABLE:
            logger.info("OTel API not available, tracing disabled")
            self._initialized = True
            return

        if not OTEL_SDK_AVAILABLE:
            logger.info("OTel SDK not installed, using NoOp tracer (install opentelemetry-sdk for tracing)")
            self._initialized = True
            return

        try:
            # Build resource with Hexr-specific attributes
            resource = self._build_resource()

            # Create TracerProvider
            self._tracer_provider = SDKTracerProvider(resource=resource)

            # Configure OTLP exporter if available
            otlp_endpoint = os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT")
            evidence_endpoint = os.getenv("HEXR_EVIDENCE_API")
            if OTLP_EXPORTER_AVAILABLE and otlp_endpoint:
                exporter = OTLPSpanExporter(
                    endpoint=otlp_endpoint,
                    insecure=True,  # Within cluster, TLS handled by mesh
                )
                self._tracer_provider.add_span_processor(
                    BatchSpanProcessor(
                        exporter,
                        max_queue_size=2048,
                        max_export_batch_size=512,
                        schedule_delay_millis=5000,
                    )
                )
                logger.info(f"OTel OTLP exporter configured: {otlp_endpoint}")
            elif evidence_endpoint:
                # Route A managed-runtime path: no OTel collector sidecar
                # available (single-container AgentCore / GEAP / Foundry).
                # Export evidence rows directly to HEXR_EVIDENCE_API per
                # HEXR_HYBRID_PIVOT_TECH_SPEC.md §1.21.x.
                from hexr.observability.evidence_http_exporter import (
                    HexrEvidenceHTTPExporter,
                )
                http_exporter = HexrEvidenceHTTPExporter(endpoint=evidence_endpoint)
                self._tracer_provider.add_span_processor(
                    BatchSpanProcessor(
                        http_exporter,
                        max_queue_size=2048,
                        max_export_batch_size=128,
                        schedule_delay_millis=5000,
                    )
                )
                logger.info(
                    "Hexr direct evidence-api exporter configured: %s",
                    evidence_endpoint,
                )
            else:
                logger.warning(
                    "Neither OTEL_EXPORTER_OTLP_ENDPOINT nor HEXR_EVIDENCE_API set; "
                    "spans will not be exported"
                )

            # Set as global TracerProvider
            trace.set_tracer_provider(self._tracer_provider)

            # Configure propagation: B3 multi-header (Envoy) + W3C TraceContext
            if PROPAGATION_AVAILABLE:
                propagators = [TraceContextTextMapPropagator()]
                if B3_AVAILABLE:
                    propagators.append(B3MultiFormat())
                    logger.info("B3 multi-header propagation enabled (Envoy mesh compatible)")

                propagate.set_global_textmap(CompositePropagator(propagators))

            # Configure MeterProvider with OTLP exporter (same endpoint as traces)
            if METRICS_AVAILABLE:
                metric_readers = []
                if OTLP_METRIC_EXPORTER_AVAILABLE:
                    metric_endpoint = os.getenv(
                        "OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4317"
                    )
                    metric_exporter = OTLPMetricExporter(
                        endpoint=metric_endpoint,
                        insecure=True,
                    )
                    metric_readers.append(
                        PeriodicExportingMetricReader(
                            metric_exporter,
                            export_interval_millis=15000,  # 15s for demo visibility
                        )
                    )
                    logger.info(f"OTel metric exporter configured: {metric_endpoint}")
                else:
                    logger.warning(
                        "OTLP metric exporter not installed, SDK metrics will not be exported"
                    )
                self._meter_provider = SDKMeterProvider(
                    resource=resource,
                    metric_readers=metric_readers,
                )
                logger.info("OTel MeterProvider initialized with OTLP export")

            self._initialized = True
            logger.info("Hexr OTel provider initialized successfully")

        except Exception as e:
            logger.error(f"Failed to initialize OTel provider: {e}", exc_info=True)
            self._initialized = True  # Don't retry — degrade gracefully

    def _build_resource(self) -> "Resource":
        """Build OTel Resource with Hexr-specific attributes."""
        service_name = os.getenv("OTEL_SERVICE_NAME", "hexr-sdk")
        tenant = os.getenv("HEXR_TENANT_ID", os.getenv("HEXR_TENANT", "unknown"))
        agent_name = os.getenv("HEXR_AGENT_NAME", "unknown")

        attributes = {
            SERVICE_NAME: service_name,
            "hexr.tenant": tenant,
            "hexr.agent.name": agent_name,
            "hexr.sdk.version": _get_sdk_version(),
            "deployment.environment": os.getenv("HEXR_ENVIRONMENT", "production"),
        }

        # Add Kubernetes-specific attributes if available
        pod_name = os.getenv("HOSTNAME")
        namespace = os.getenv("NAMESPACE")
        if pod_name:
            attributes["k8s.pod.name"] = pod_name
        if namespace:
            attributes["k8s.namespace.name"] = namespace

        return Resource.create(attributes)

    def get_tracer(self, name: str = "hexr-sdk") -> "Tracer":
        """
        Get an OTel Tracer instance.

        Initializes the provider on first call. Returns a NoOp tracer
        if OTel SDK is not installed.

        Args:
            name: Instrumentation scope name (default: hexr-sdk)

        Returns:
            Tracer: OTel Tracer (real or NoOp)
        """
        self._initialize()

        if not OTEL_API_AVAILABLE:
            return _NoOpTracer()

        if self._tracer_provider is not None:
            return self._tracer_provider.get_tracer(
                name, schema_url="https://opentelemetry.io/schemas/1.21.0"
            )

        # Fallback to global (possibly NoOp) tracer
        return trace.get_tracer(name)

    def get_meter(self, name: str = "hexr-sdk") -> Any:
        """
        Get an OTel Meter instance.

        Args:
            name: Instrumentation scope name

        Returns:
            Meter or NoOp equivalent
        """
        self._initialize()

        if self._meter_provider is not None:
            return self._meter_provider.get_meter(name)

        return _NoOpMeter()

    def shutdown(self) -> None:
        """Flush pending spans and shut down providers."""
        if self._tracer_provider is not None and hasattr(self._tracer_provider, "shutdown"):
            try:
                self._tracer_provider.shutdown()
                logger.info("OTel TracerProvider shut down")
            except Exception as e:
                logger.warning(f"OTel shutdown error: {e}")

        if self._meter_provider is not None and hasattr(self._meter_provider, "shutdown"):
            try:
                self._meter_provider.shutdown()
            except Exception:
                pass


def get_tracer(name: str = "hexr-sdk") -> "Tracer":
    """
    Module-level convenience: get a Tracer from the singleton provider.

    Usage:
        from hexr.observability import get_tracer
        tracer = get_tracer()
        with tracer.start_as_current_span("my-operation"):
            ...
    """
    return HexrOTelProvider.get_instance().get_tracer(name)


def get_meter(name: str = "hexr-sdk") -> Any:
    """Module-level convenience: get a Meter from the singleton provider."""
    return HexrOTelProvider.get_instance().get_meter(name)


def inject_b3_headers(headers: dict[str, str]) -> dict[str, str]:
    """
    Inject B3 + W3C trace propagation headers into an outgoing request.

    Used by injector_client.py to propagate trace context to the
    credential-injector Go service through Envoy.

    Args:
        headers: Existing HTTP headers dict (mutated in place)

    Returns:
        dict: Headers with trace propagation headers added
    """
    if not OTEL_API_AVAILABLE or not PROPAGATION_AVAILABLE:
        return headers

    try:
        propagate.inject(headers)
    except Exception as e:
        logger.debug(f"Failed to inject trace headers: {e}")

    return headers


def _get_sdk_version() -> str:
    """Get Hexr SDK version string."""
    try:
        from hexr.version import __version__
        return __version__
    except ImportError:
        return "unknown"


# ── NoOp fallbacks (when OTel SDK is not installed) ──────────────────────


class _NoOpSpan:
    """No-op span that silently accepts all operations."""

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, status: Any, description: str | None = None) -> None:
        pass

    def record_exception(self, exception: BaseException, **kwargs: Any) -> None:
        pass

    def add_event(self, name: str, attributes: dict | None = None) -> None:
        pass

    def end(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    @property
    def is_recording(self) -> bool:
        return False


class _NoOpTracer:
    """No-op tracer that returns no-op spans."""

    def start_as_current_span(self, name: str, **kwargs) -> "_NoOpSpan":
        return _NoOpSpan()

    def start_span(self, name: str, **kwargs) -> "_NoOpSpan":
        return _NoOpSpan()


class _NoOpMeter:
    """No-op meter that returns no-op instruments."""

    def create_counter(self, name: str, **kwargs):
        return _NoOpInstrument()

    def create_histogram(self, name: str, **kwargs):
        return _NoOpInstrument()

    def create_up_down_counter(self, name: str, **kwargs):
        return _NoOpInstrument()


class _NoOpInstrument:
    """No-op metric instrument."""

    def add(self, value: float, attributes: dict | None = None) -> None:
        pass

    def record(self, value: float, attributes: dict | None = None) -> None:
        pass
