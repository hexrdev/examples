"""
Hexr Span Names and Attribute Constants

Centralized constants for all Hexr OTel instrumentation.
Keeps span names and attribute keys consistent across the SDK.

Naming convention:
- Span names: hexr.<component>.<operation>
- Attributes: hexr.<component>.<attribute>
"""


class SpanNames:
    """
    Standard span names for Hexr SDK operations.

    Produces a trace tree like:
        hexr.agent.invoke (root)
        ├── hexr.tool.invoke
        │   ├── hexr.cache.lookup
        │   │   ├── hexr.cache.l1
        │   │   ├── hexr.cache.l2
        │   │   └── hexr.cache.l3
        │   └── hexr.credential.exchange
        └── hexr.tool.invoke
            └── hexr.cache.lookup
                └── hexr.cache.l1  (cache hit)
    """

    # Agent lifecycle
    AGENT_INVOKE = "hexr.agent.invoke"
    AGENT_SETUP = "hexr.agent.setup"

    # Tool operations
    TOOL_INVOKE = "hexr.tool.invoke"
    TOOL_CLIENT_CREATE = "hexr.tool.client_create"

    # Credential cache waterfall
    CACHE_LOOKUP = "hexr.cache.lookup"
    CACHE_L1 = "hexr.cache.l1"
    CACHE_L2 = "hexr.cache.l2"
    CACHE_L3 = "hexr.cache.l3"
    CACHE_JWT_FETCH = "hexr.cache.jwt_fetch"

    # Credential exchange (L3 detail)
    CREDENTIAL_EXCHANGE = "hexr.credential.exchange"

    # OPA authorization (server-side, but named here for consistency)
    OPA_CHECK = "hexr.opa.check"

    # A2A Client spans (outbound, Python SDK → remote agent)
    A2A_CLIENT_DISCOVER = "hexr.a2a.client.discover"
    A2A_CLIENT_SEND = "hexr.a2a.client.send"
    A2A_CLIENT_STREAM = "hexr.a2a.client.stream"
    A2A_CLIENT_GET_TASK = "hexr.a2a.client.get_task"
    A2A_CLIENT_CANCEL_TASK = "hexr.a2a.client.cancel_task"

    # A2A Bridge spans (inbound, sidecar → Python handler)
    A2A_BRIDGE_EXECUTE = "hexr.a2a.bridge.execute"

    # LLM call interception spans
    LLM_CHAT = "hexr.llm.chat"
    LLM_COMPLETIONS = "hexr.llm.completions"
    LLM_EMBEDDINGS = "hexr.llm.embeddings"


class GenAIAttributes:
    """
    OpenTelemetry GenAI semantic convention attributes.

    Follows: https://opentelemetry.io/docs/specs/semconv/gen-ai/
    These are standard OTel attribute keys — NOT prefixed with 'hexr.'
    so that downstream consumers (Langfuse, Galileo, Grafana) can parse
    them using the standard gen_ai.* namespace.
    """

    # System / provider
    SYSTEM = "gen_ai.system"  # openai, anthropic, google_genai, litellm, etc.

    # Request attributes (set before call)
    REQUEST_MODEL = "gen_ai.request.model"
    REQUEST_MAX_TOKENS = "gen_ai.request.max_tokens"
    REQUEST_TEMPERATURE = "gen_ai.request.temperature"
    REQUEST_TOP_P = "gen_ai.request.top_p"
    REQUEST_STOP_SEQUENCES = "gen_ai.request.stop_sequences"
    REQUEST_STREAM = "gen_ai.request.stream"

    # Response attributes (set after call)
    RESPONSE_MODEL = "gen_ai.response.model"
    RESPONSE_ID = "gen_ai.response.id"
    RESPONSE_FINISH_REASONS = "gen_ai.response.finish_reasons"

    # Token usage (set after call — raw facts, no cost computation)
    USAGE_INPUT_TOKENS = "gen_ai.usage.input_tokens"
    USAGE_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"


class SpanAttributes:
    """
    Standard attribute keys for Hexr spans.

    These follow OpenTelemetry semantic conventions where applicable,
    prefixed with 'hexr.' for domain-specific attributes.
    """

    # Agent attributes
    AGENT_NAME = "hexr.agent.name"
    AGENT_TENANT = "hexr.agent.tenant"
    AGENT_FRAMEWORK = "hexr.agent.framework"

    # Tool attributes
    TOOL_SERVICE = "hexr.tool.service"
    TOOL_REGION = "hexr.tool.region"
    TOOL_PROVIDER = "hexr.tool.provider"  # aws, gcp, azure

    # Cache attributes
    CACHE_TIER = "hexr.cache.tier"  # l1, l2, l3
    CACHE_HIT = "hexr.cache.hit"  # bool
    CACHE_KEY = "hexr.cache.key"
    CACHE_TTL_REMAINING = "hexr.cache.ttl_remaining_s"

    # Credential exchange attributes
    CREDENTIAL_SPIFFE_ID = "hexr.credential.spiffe_id"
    CREDENTIAL_PROVIDER = "hexr.credential.provider"
    CREDENTIAL_EXPIRY = "hexr.credential.expiry"
    CREDENTIAL_INJECTOR_URL = "hexr.credential.injector_url"

    # OPA attributes
    OPA_DECISION = "hexr.opa.decision"  # allow, deny
    OPA_POLICY = "hexr.opa.policy"
    OPA_DENY_REASONS = "hexr.opa.deny_reasons"

    # Error attributes
    ERROR_TYPE = "hexr.error.type"
    ERROR_MESSAGE = "hexr.error.message"

    # A2A attributes (shared vocabulary — client + bridge + sidecar)
    A2A_TASK_ID = "hexr.a2a.task.id"
    A2A_TASK_STATE = "hexr.a2a.task.state"
    A2A_CONTEXT_ID = "hexr.a2a.context.id"
    A2A_METHOD = "hexr.a2a.method"
    A2A_AGENT_TARGET = "hexr.a2a.agent.target"

    # LLM attributes (Hexr-specific, complements gen_ai.* standard attrs)
    LLM_PROVIDER = "hexr.llm.provider"
    LLM_DURATION_MS = "hexr.llm.duration_ms"
    LLM_STREAM = "hexr.llm.stream"
    LLM_OPERATION = "hexr.llm.operation"  # chat, completions, embeddings


class MetricNames:
    """
    Standard metric names for Hexr SDK counters and histograms.
    """

    # Counters
    AGENT_INVOCATIONS = "hexr.agent.invocations"
    TOOL_INVOCATIONS = "hexr.tool.invocations"
    CACHE_HITS = "hexr.cache.hits"
    CACHE_MISSES = "hexr.cache.misses"
    CREDENTIAL_EXCHANGES = "hexr.credential.exchanges"
    CREDENTIAL_FAILURES = "hexr.credential.failures"

    # UpDownCounters
    AGENT_ACTIVE = "hexr.agent.active"

    # Histograms
    TOOL_DURATION = "hexr.tool.duration"
    CACHE_LOOKUP_DURATION = "hexr.cache.lookup.duration"
    CREDENTIAL_EXCHANGE_DURATION = "hexr.credential.exchange.duration"
    AGENT_DURATION = "hexr.agent.duration"

    # A2A counters
    A2A_SENDS = "hexr.a2a.sends"
    A2A_SEND_FAILURES = "hexr.a2a.send_failures"
    A2A_BRIDGE_EXECUTIONS = "hexr.a2a.bridge.executions"
    A2A_BRIDGE_ERRORS = "hexr.a2a.bridge.errors"

    # A2A histograms
    A2A_SEND_DURATION = "hexr.a2a.send.duration"
    A2A_BRIDGE_EXECUTE_DURATION = "hexr.a2a.bridge.execute.duration"

    # LLM metrics
    LLM_CALLS = "hexr.llm.calls"
    LLM_CALL_ERRORS = "hexr.llm.call_errors"
    LLM_CALL_DURATION = "hexr.llm.call.duration"
    LLM_INPUT_TOKENS = "hexr.llm.input_tokens"
    LLM_OUTPUT_TOKENS = "hexr.llm.output_tokens"
