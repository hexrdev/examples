"""
Hexr Observability Module - OpenTelemetry Integration

Provides automatic distributed tracing for the Hexr agent lifecycle:
- Agent invocation (root span)
- Tool calls with cache tier tracking
- Credential cache waterfall (L1 → L2 → L3)
- Cross-service trace propagation via B3 headers

Usage:
    from hexr.observability import get_tracer, SpanNames, SpanAttributes

    tracer = get_tracer()
    with tracer.start_as_current_span(SpanNames.AGENT_INVOKE) as span:
        span.set_attribute(SpanAttributes.AGENT_NAME, "my-agent")
"""

from .provider import HexrOTelProvider, get_tracer, get_meter, inject_b3_headers
from .spans import SpanNames, SpanAttributes, MetricNames, GenAIAttributes

__all__ = [
    "HexrOTelProvider",
    "get_tracer",
    "get_meter",
    "inject_b3_headers",
    "SpanNames",
    "SpanAttributes",
    "GenAIAttributes",
    "MetricNames",
]
