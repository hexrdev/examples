"""SDK configuration management."""

import os
from dataclasses import dataclass, field


@dataclass
class HexrConfig:
    """Hexr SDK configuration."""

    # SPIFFE configuration
    spiffe_socket_path: str = "/run/spire/sockets/agent.sock"
    trust_domain: str = "hexr.demo-corp.com"

    # Credential injector configuration (Direct to service - Envoy disabled)
    credential_injector_url: str = "http://hexr-credential-injector.hexr-system.svc.cluster.local:8080"
    credential_timeout: int = 30

    # Development configuration
    debug_level: str = "INFO"

    # Container registry configuration (post-pivot: GCP AR is canonical)
    default_registry: str = "us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images"

    # Framework detection
    supported_frameworks: list[str] = field(
        default_factory=lambda: ["crewai", "langchain", "autogen", "custom"]
    )

    @classmethod
    def from_environment(cls) -> "HexrConfig":
        """Create configuration from environment variables."""
        return cls(
            spiffe_socket_path=os.getenv(
                "HEXR_SPIFFE_SOCKET", "/run/spire/sockets/agent.sock"
            ),
            trust_domain=os.getenv("HEXR_TRUST_DOMAIN", "hexr.demo-corp.com"),
            credential_injector_url=os.getenv(
                "HEXR_CREDENTIAL_URL",
                "http://hexr-credential-injector.hexr-system:8080",
            ),
            credential_timeout=int(os.getenv("HEXR_CREDENTIAL_TIMEOUT", "30")),
            debug_level=os.getenv("HEXR_DEBUG_LEVEL", "INFO"),
            default_registry=os.getenv(
                "HEXR_DEFAULT_REGISTRY",
                "us-central1-docker.pkg.dev/hexr-cloud-prod/hexr-images",
            ),
        )
