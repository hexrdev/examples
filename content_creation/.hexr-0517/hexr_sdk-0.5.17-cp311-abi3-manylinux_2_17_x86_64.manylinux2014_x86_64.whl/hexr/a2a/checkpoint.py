"""
Hexr A2A Task Checkpoint — Sidecar-Managed State Snapshots

The TaskCheckpoint class allows Python agent code to persist intermediate
state through the co-located A2A sidecar. Checkpoints are stored in Valkey
with the key ``hexr:a2a:checkpoint:{task_id}`` and survive agent restarts.

This is not for final results (which flow through the normal A2A response).
It's for long-running tasks that want crash-recovery safety.

Usage:
    from hexr.a2a import TaskCheckpoint

    checkpoint = TaskCheckpoint()

    # Save intermediate state during processing
    await checkpoint.save(task_id, {"step": 3, "partial": [1, 2, 3]})

    # Recover on restart
    state = await checkpoint.load(task_id)
    if state:
        resume_from(state)
"""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx

logger = logging.getLogger("hexr.a2a.checkpoint")

_DEFAULT_SIDECAR_URL = "http://localhost:8090"


class TaskCheckpoint:
    """Persist and recover task intermediate state via the A2A sidecar.

    The sidecar stores checkpoints in Valkey with a 24-hour TTL for
    active tasks (matching the task's own active-state TTL).

    Args:
        sidecar_url: Base URL of the co-located A2A sidecar (default: http://localhost:8090).
        timeout: Request timeout in seconds (default: 5).
    """

    def __init__(
        self,
        sidecar_url: str = _DEFAULT_SIDECAR_URL,
        timeout: float = 5.0,
    ) -> None:
        self.sidecar_url = sidecar_url.rstrip("/")
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> TaskCheckpoint:
        self._client = httpx.AsyncClient(timeout=self.timeout)
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def save(self, task_id: str, data: dict[str, Any]) -> None:
        """Save a checkpoint for the given task.

        The data dict is JSON-serialized and stored via the sidecar's
        /checkpoint endpoint, which persists it in Valkey.

        Args:
            task_id: The A2A task ID this checkpoint belongs to.
            data: Arbitrary JSON-serializable checkpoint state.

        Raises:
            httpx.HTTPStatusError: If the sidecar returns an error.
        """
        url = f"{self.sidecar_url}/checkpoint"
        client = self._get_client()
        payload = {"task_id": task_id, "data": json.dumps(data)}

        resp = await client.post(url, json=payload)
        resp.raise_for_status()
        logger.debug("Checkpoint saved for task %s", task_id)

    async def load(self, task_id: str) -> dict[str, Any] | None:
        """Load a previously saved checkpoint.

        Args:
            task_id: The A2A task ID to look up.

        Returns:
            The deserialized checkpoint dict, or None if no checkpoint exists.

        Raises:
            httpx.HTTPStatusError: If the sidecar returns an unexpected error.
        """
        url = f"{self.sidecar_url}/checkpoint"
        client = self._get_client()

        resp = await client.get(url, params={"task_id": task_id})

        if resp.status_code == 404:
            return None

        resp.raise_for_status()
        body = resp.json()

        if "data" in body and isinstance(body["data"], str):
            return json.loads(body["data"])

        return body.get("data")
