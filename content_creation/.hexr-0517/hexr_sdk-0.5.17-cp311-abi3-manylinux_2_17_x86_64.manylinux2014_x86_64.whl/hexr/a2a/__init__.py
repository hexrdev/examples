"""
Hexr A2A — Agent-to-Agent Communication

Runtime-native A2A implementation: Go sidecar handles infrastructure
(HTTP server, task state, durability, streaming), Python SDK provides
developer ergonomics (client, models, bridge, decorator integration).

Usage:
    from hexr.a2a import A2AClient, A2ABridge, Message, Task, TextPart

Wire format: A2A JSON-RPC 2.0 (message/send, message/stream, tasks/get, tasks/cancel)
Transport: Envoy mTLS (inter-pod), localhost (sidecar ↔ agent)
Task state: Valkey (Go sidecar manages all reads/writes)
"""

from .models import (
    AgentCard,
    AgentSkill,
    Artifact,
    DataPart,
    FilePart,
    Message,
    Part,
    Task,
    TaskState,
    TaskStatus,
    TextPart,
)
from .errors import (
    A2AError,
    InputRequiredError,
    TaskCancelledError,
    TaskNotFoundError,
    TaskTimeoutError,
)
from .json_rpc import (
    JSONRPCRequest,
    JSONRPCResponse,
    JSONRPCError,
    parse_json_rpc_response,
)
from .client import A2AClient
from .checkpoint import TaskCheckpoint
from .bridge import A2ABridge

__all__ = [
    # Models
    "AgentCard",
    "AgentSkill",
    "Artifact",
    "DataPart",
    "FilePart",
    "Message",
    "Part",
    "Task",
    "TaskState",
    "TaskStatus",
    "TextPart",
    # Errors
    "A2AError",
    "InputRequiredError",
    "TaskCancelledError",
    "TaskNotFoundError",
    "TaskTimeoutError",
    # JSON-RPC
    "JSONRPCRequest",
    "JSONRPCResponse",
    "JSONRPCError",
    "parse_json_rpc_response",
    # Client
    "A2AClient",
    # Checkpoint
    "TaskCheckpoint",
    # Bridge
    "A2ABridge",
]
