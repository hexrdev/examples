"""
Hexr A2A Error Definitions

Exception hierarchy for A2A operations. These map to JSON-RPC error codes
used by the Go A2A sidecar and understood by A2AClient.

Error code mapping (A2A protocol):
    -32001  TaskNotFoundError
    -32002  TaskCancelledError
    -32003  InputRequiredError
    -32004  TaskTimeoutError
    -32600  Invalid JSON-RPC request
    -32601  Method not found
    -32602  Invalid params
    -32603  Internal error
"""

from ..exceptions import HexrError


class A2AError(HexrError):
    """Base exception for all A2A operations.

    Attributes:
        code: JSON-RPC error code (negative integer).
        task_id: Optional task ID associated with the error.
        data: Optional additional error data from the server.
    """

    code: int = -32603  # Internal error by default

    def __init__(
        self,
        message: str,
        code: int | None = None,
        task_id: str | None = None,
        data: dict | None = None,
    ):
        super().__init__(message)
        if code is not None:
            self.code = code
        self.task_id = task_id
        self.data = data

    def __str__(self) -> str:
        parts = [super().__str__()]
        if self.task_id:
            parts.append(f"task_id={self.task_id}")
        if self.code:
            parts.append(f"code={self.code}")
        return " | ".join(parts)


class TaskNotFoundError(A2AError):
    """Raised when a task ID does not exist in the store.

    JSON-RPC error code: -32001
    Trigger: tasks/get or tasks/cancel with unknown task_id.
    """

    code: int = -32001

    def __init__(self, task_id: str, message: str | None = None):
        super().__init__(
            message or f"Task not found: {task_id}",
            code=-32001,
            task_id=task_id,
        )


class TaskCancelledError(A2AError):
    """Raised when a task has been cancelled (cooperative cancellation).

    JSON-RPC error code: -32002
    Trigger: Go sidecar detected cancel flag in Valkey before/after execution.
    """

    code: int = -32002

    def __init__(self, task_id: str, message: str | None = None):
        super().__init__(
            message or f"Task cancelled: {task_id}",
            code=-32002,
            task_id=task_id,
        )


class InputRequiredError(A2AError):
    """Raised when the agent needs additional input to continue.

    JSON-RPC error code: -32003
    Trigger: Handler returns input-required state. Client must send
    a follow-up message with the same context_id.
    """

    code: int = -32003

    def __init__(self, task_id: str, message: str | None = None):
        super().__init__(
            message or f"Input required for task: {task_id}",
            code=-32003,
            task_id=task_id,
        )


class TaskTimeoutError(A2AError):
    """Raised when a task exceeds its maximum duration.

    JSON-RPC error code: -32004
    Trigger: Task Reaper detects expired timeout key in Valkey,
    or client-side timeout in A2AClient.send().
    """

    code: int = -32004

    def __init__(self, task_id: str, timeout_seconds: float | None = None, message: str | None = None):
        msg = message or f"Task timed out: {task_id}"
        if timeout_seconds is not None:
            msg += f" (after {timeout_seconds:.1f}s)"
        super().__init__(
            msg,
            code=-32004,
            task_id=task_id,
            data={"timeout_seconds": timeout_seconds} if timeout_seconds else None,
        )


# JSON-RPC error code → exception class mapping
# Used by json_rpc.py to deserialize error responses from the Go sidecar.
ERROR_CODE_MAP: dict[int, type[A2AError]] = {
    -32001: TaskNotFoundError,
    -32002: TaskCancelledError,
    -32003: InputRequiredError,
    -32004: TaskTimeoutError,
}
