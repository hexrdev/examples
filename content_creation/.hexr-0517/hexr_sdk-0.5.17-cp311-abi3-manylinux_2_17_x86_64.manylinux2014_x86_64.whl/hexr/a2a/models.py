"""
Hexr A2A Data Models

Pydantic v2 models defining the shared data contract between:
  - Python SDK (client, bridge)
  - Go A2A sidecar (serializes/deserializes the same JSON)
  - External A2A-compliant clients

These models follow A2A protocol conventions where applicable, with Hexr-specific
extensions (hexr.* fields). The Go sidecar uses the same JSON shape — these models
are the authoritative schema definition.

Key design decisions:
  - All IDs are UUIDs (generated client-side for idempotency)
  - TaskState is a string enum matching A2A spec exactly
  - Parts are discriminated union via Literal type field
  - AgentCard includes Hexr extensions (spiffe_id, tenant, framework)
  - Timestamps are ISO 8601 strings (timezone-aware)
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Annotated, Any, Literal, Union

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Task State Machine
# ---------------------------------------------------------------------------

class TaskState(str, Enum):
    """A2A task lifecycle states.

    State machine:
        submitted → working → completed
                           → failed
                           → canceled
                           → input-required → (re-submit) → working → ...
    """

    SUBMITTED = "submitted"
    WORKING = "working"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"
    INPUT_REQUIRED = "input-required"

    @property
    def is_terminal(self) -> bool:
        """Whether this state is final (no further transitions)."""
        return self in (TaskState.COMPLETED, TaskState.FAILED, TaskState.CANCELED)


# ---------------------------------------------------------------------------
# Message Parts (discriminated union)
# ---------------------------------------------------------------------------

class TextPart(BaseModel):
    """Plain text content part."""

    type: Literal["text"] = "text"
    text: str

    model_config = {"frozen": True}


class DataPart(BaseModel):
    """Structured data content part (JSON-serializable)."""

    type: Literal["data"] = "data"
    data: dict[str, Any]
    metadata: dict[str, str] | None = None

    model_config = {"frozen": True}


class FilePart(BaseModel):
    """File reference or inline content part."""

    type: Literal["file"] = "file"
    file: FileContent

    model_config = {"frozen": True}


class FileContent(BaseModel):
    """File content — either inline bytes (base64) or a URI reference."""

    name: str | None = None
    mime_type: str | None = Field(None, alias="mimeType")
    bytes: str | None = None  # base64-encoded
    uri: str | None = None

    model_config = {"populate_by_name": True, "frozen": True}


# Discriminated union of part types
Part = Annotated[
    Union[TextPart, DataPart, FilePart],
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Message
# ---------------------------------------------------------------------------

class Message(BaseModel):
    """A2A message — the unit of communication between agents.

    Messages contain one or more Parts (text, data, file).
    The role indicates sender perspective (user = caller, agent = responder).
    """

    role: Literal["user", "agent"]
    parts: list[Part]
    metadata: dict[str, str] | None = None

    model_config = {"populate_by_name": True}

    @classmethod
    def user(cls, text: str, **metadata: str) -> Message:
        """Convenience: create a user message with a single text part."""
        return cls(
            role="user",
            parts=[TextPart(text=text)],
            metadata=metadata or None,
        )

    @classmethod
    def agent(cls, text: str, **metadata: str) -> Message:
        """Convenience: create an agent response with a single text part."""
        return cls(
            role="agent",
            parts=[TextPart(text=text)],
            metadata=metadata or None,
        )

    @classmethod
    def with_data(cls, role: Literal["user", "agent"], data: dict[str, Any], **metadata: str) -> Message:
        """Convenience: create a message with a single data part."""
        return cls(
            role=role,
            parts=[DataPart(data=data)],
            metadata=metadata or None,
        )

    def text_content(self) -> str:
        """Extract concatenated text from all TextParts."""
        return "\n".join(
            part.text for part in self.parts if isinstance(part, TextPart)
        )


# ---------------------------------------------------------------------------
# Artifact
# ---------------------------------------------------------------------------

class Artifact(BaseModel):
    """Output artifact produced by an agent task.

    Artifacts contain the agent's response data — parallel to messages but
    representing outputs rather than inputs.
    """

    name: str | None = None
    description: str | None = None
    parts: list[Part]
    index: int = 0
    metadata: dict[str, str] | None = None

    model_config = {"populate_by_name": True}

    @classmethod
    def text(cls, content: str, name: str | None = None) -> Artifact:
        """Convenience: create an artifact with a single text part."""
        return cls(name=name, parts=[TextPart(text=content)])

    @classmethod
    def data(cls, data: dict[str, Any], name: str | None = None) -> Artifact:
        """Convenience: create an artifact with a single data part."""
        return cls(name=name, parts=[DataPart(data=data)])


# ---------------------------------------------------------------------------
# Task Status
# ---------------------------------------------------------------------------

class TaskStatus(BaseModel):
    """Current status snapshot of a task.

    Includes the state, optional progress message, and timestamp.
    """

    state: TaskState
    message: Message | None = None
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    model_config = {"populate_by_name": True}


# ---------------------------------------------------------------------------
# Task
# ---------------------------------------------------------------------------

class Task(BaseModel):
    """A2A Task — the stateful unit of agent-to-agent work.

    Created by message/send, queried by tasks/get, cancelled by tasks/cancel.
    The Go sidecar manages task lifecycle in Valkey; this model is the
    serialization contract.

    Key fields:
        id: Client-generated UUID (enables idempotent submission via SETNX).
        context_id: Groups related tasks in a multi-turn conversation.
        status: Current lifecycle state + metadata.
        history: Ordered list of messages (input) in this task.
        artifacts: Ordered list of outputs produced by the agent.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    context_id: str | None = Field(None, alias="contextId")
    status: TaskStatus = Field(
        default_factory=lambda: TaskStatus(state=TaskState.SUBMITTED)
    )
    history: list[Message] = Field(default_factory=list)
    artifacts: list[Artifact] = Field(default_factory=list)
    metadata: dict[str, str] | None = None

    model_config = {"populate_by_name": True}

    @property
    def state(self) -> TaskState:
        """Shortcut to current state."""
        return self.status.state

    @property
    def is_terminal(self) -> bool:
        """Whether this task has reached a final state."""
        return self.status.state.is_terminal

    def text_result(self) -> str | None:
        """Extract text from the first artifact, if any."""
        if not self.artifacts:
            return None
        return self.artifacts[0].parts[0].text if self.artifacts[0].parts and isinstance(self.artifacts[0].parts[0], TextPart) else None


# ---------------------------------------------------------------------------
# Agent Card
# ---------------------------------------------------------------------------

class AgentSkill(BaseModel):
    """A capability/skill advertised by an agent.

    Skills appear in the Agent Card and are extracted from
    @hexr_agent(skills=[...]) at build time via AST analysis.
    """

    id: str
    name: str
    description: str | None = None
    tags: list[str] = Field(default_factory=list)
    examples: list[str] | None = None

    model_config = {"populate_by_name": True}


class AgentCapabilities(BaseModel):
    """Agent capability flags advertised in the Agent Card."""

    streaming: bool = False
    push_notifications: bool = False  # Always False for Hexr (we use SSE)
    state_transition_history: bool = True

    model_config = {
        "populate_by_name": True,
        "alias_generator": lambda field: {
            "push_notifications": "pushNotifications",
            "state_transition_history": "stateTransitionHistory",
        }.get(field, field),
    }


class AgentAuthentication(BaseModel):
    """Authentication scheme advertised in the Agent Card.

    For Hexr, this is always SPIFFE mTLS — Envoy handles it transparently.
    """

    schemes: list[str] = Field(default_factory=lambda: ["spiffe-mtls"])
    credentials: str | None = None  # Not used — SPIFFE is ambient

    model_config = {"populate_by_name": True}


class HexrExtensions(BaseModel):
    """Hexr-specific extensions to the A2A Agent Card.

    These fields are NOT part of the A2A standard but are critical for
    Hexr's identity and observability systems.
    """

    spiffe_id: str | None = Field(None, alias="spiffe_id")
    tenant: str | None = None
    framework: str | None = None

    model_config = {"populate_by_name": True}


class AgentCard(BaseModel):
    """A2A Agent Card — JSON metadata describing an agent's identity and capabilities.

    Generated at `hexr build` time from @hexr_agent() decorator metadata via
    AST extraction. Served by Envoy from a ConfigMap volume mount at
    GET /.well-known/agent.json — zero Python at runtime.

    See: https://a2a-protocol.org/latest/specification/#agent-card
    """

    name: str
    description: str | None = None
    url: str | None = None
    version: str | None = None
    capabilities: AgentCapabilities = Field(default_factory=AgentCapabilities)
    authentication: AgentAuthentication = Field(default_factory=AgentAuthentication)
    skills: list[AgentSkill] = Field(default_factory=list)
    default_input_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        alias="defaultInputModes",
    )
    default_output_modes: list[str] = Field(
        default_factory=lambda: ["text/plain"],
        alias="defaultOutputModes",
    )
    provider: dict[str, str] | None = None
    hexr: HexrExtensions | None = None

    model_config = {"populate_by_name": True}

    def to_json(self) -> str:
        """Serialize to JSON string (for ConfigMap generation at build time)."""
        return self.model_dump_json(by_alias=True, indent=2, exclude_none=True)
