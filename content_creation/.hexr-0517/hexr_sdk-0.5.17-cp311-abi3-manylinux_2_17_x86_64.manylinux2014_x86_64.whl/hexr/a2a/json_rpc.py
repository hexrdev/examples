"""
Hexr A2A JSON-RPC — Client-Side Parsing

Client-side JSON-RPC 2.0 request construction and response parsing.
Server-side JSON-RPC parsing is in the Go A2A sidecar (handler.go).

This module is intentionally thin — it builds outbound requests and
parses inbound responses. The Go sidecar handles all server-side
dispatch, validation, and error formatting.

A2A methods:
    message/send     — Submit a message to an agent (returns Task)
    message/stream   — Submit with SSE streaming response
    tasks/get        — Query task state by ID
    tasks/cancel     — Request cooperative cancellation
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from .errors import A2AError, ERROR_CODE_MAP
from .models import Task


# ---------------------------------------------------------------------------
# JSON-RPC Request (outbound — built by A2AClient)
# ---------------------------------------------------------------------------

class JSONRPCRequest(BaseModel):
    """JSON-RPC 2.0 request envelope.

    Built by A2AClient for outbound calls through Envoy mTLS.
    """

    jsonrpc: str = "2.0"
    id: str | int
    method: str
    params: dict[str, Any] | None = None

    model_config = {"populate_by_name": True}

    def to_dict(self) -> dict[str, Any]:
        """Serialize for HTTP POST body."""
        d: dict[str, Any] = {
            "jsonrpc": self.jsonrpc,
            "id": self.id,
            "method": self.method,
        }
        if self.params is not None:
            d["params"] = self.params
        return d


# ---------------------------------------------------------------------------
# JSON-RPC Response (inbound — returned by Go sidecar via Envoy)
# ---------------------------------------------------------------------------

class JSONRPCError(BaseModel):
    """JSON-RPC 2.0 error object."""

    code: int
    message: str
    data: dict[str, Any] | None = None

    model_config = {"populate_by_name": True}


class JSONRPCResponse(BaseModel):
    """JSON-RPC 2.0 response envelope.

    Exactly one of `result` or `error` will be present.
    """

    jsonrpc: str = "2.0"
    id: str | int | None = None
    result: dict[str, Any] | None = None
    error: JSONRPCError | None = None

    model_config = {"populate_by_name": True}

    @property
    def is_error(self) -> bool:
        return self.error is not None

    def task(self) -> Task:
        """Parse the result as a Task. Raises A2AError if response is an error."""
        if self.error:
            raise self.to_exception()
        if self.result is None:
            raise A2AError("Empty result in JSON-RPC response", code=-32603)
        return Task.model_validate(self.result)

    def to_exception(self) -> A2AError:
        """Convert error response to the appropriate A2AError subclass."""
        if not self.error:
            raise ValueError("Response is not an error")

        # Look up specific error class by code
        error_cls = ERROR_CODE_MAP.get(self.error.code, A2AError)

        # Extract task_id from error data if present
        task_id = None
        if self.error.data and "task_id" in self.error.data:
            task_id = self.error.data["task_id"]

        if error_cls is A2AError:
            return A2AError(
                message=self.error.message,
                code=self.error.code,
                task_id=task_id,
                data=self.error.data,
            )

        # Specific error classes have different constructors
        return error_cls(
            task_id=task_id or "unknown",
            message=self.error.message,
        )


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def parse_json_rpc_response(data: dict[str, Any]) -> JSONRPCResponse:
    """Parse a raw JSON dict into a JSONRPCResponse.

    Args:
        data: Deserialized JSON body from the Go sidecar response.

    Returns:
        Validated JSONRPCResponse.

    Raises:
        A2AError: If the response is malformed.
    """
    try:
        return JSONRPCResponse.model_validate(data)
    except Exception as e:
        raise A2AError(
            f"Malformed JSON-RPC response: {e}",
            code=-32600,
        ) from e


# ---------------------------------------------------------------------------
# Request builders (used by A2AClient)
# ---------------------------------------------------------------------------

def build_send_request(
    request_id: str | int,
    message_params: dict[str, Any],
) -> JSONRPCRequest:
    """Build a message/send JSON-RPC request."""
    return JSONRPCRequest(
        id=request_id,
        method="message/send",
        params=message_params,
    )


def build_stream_request(
    request_id: str | int,
    message_params: dict[str, Any],
) -> JSONRPCRequest:
    """Build a message/stream JSON-RPC request."""
    return JSONRPCRequest(
        id=request_id,
        method="message/stream",
        params=message_params,
    )


def build_get_task_request(
    request_id: str | int,
    task_id: str,
) -> JSONRPCRequest:
    """Build a tasks/get JSON-RPC request."""
    return JSONRPCRequest(
        id=request_id,
        method="tasks/get",
        params={"id": task_id},
    )


def build_cancel_task_request(
    request_id: str | int,
    task_id: str,
) -> JSONRPCRequest:
    """Build a tasks/cancel JSON-RPC request."""
    return JSONRPCRequest(
        id=request_id,
        method="tasks/cancel",
        params={"id": task_id},
    )
