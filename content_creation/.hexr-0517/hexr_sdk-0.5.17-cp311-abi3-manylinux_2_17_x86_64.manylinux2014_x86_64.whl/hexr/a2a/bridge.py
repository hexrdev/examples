"""
Hexr A2A Bridge — Receives execution requests from the Go sidecar.

The bridge runs an HTTP server on localhost:8080 that receives POST /execute
requests from the co-located A2A sidecar. It deserializes the request,
invokes the user's handler function, and returns artifacts or errors.

Flow:
    Envoy inbound → Go sidecar :8090 (message/send) → Bridge :8080 /execute
    → user handler → response with artifacts → sidecar stores in Valkey

The bridge is started automatically by the @hexr_agent decorator when
a2a=True is set. Users don't interact with this class directly — they
provide a handler function that receives a Message and returns text or
an Artifact list.

Usage (internal — called by decorator):
    bridge = A2ABridge(handler=my_handler)
    await bridge.start()  # Blocks on localhost:8080
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import os
import traceback
from typing import Any, Callable, Awaitable, Union

from .models import Artifact, Message, TextPart

logger = logging.getLogger("hexr.a2a.bridge")

# Module-level guard so concurrent bridges (rare) only register once.
_REGISTRATION_ATTEMPTED = False


def _ensure_spire_registration() -> None:
    """Register the calling process with SPIRE via auto-registrar if needed.

    Safety net for the documented gap in spec §2.5.7: when the agent uses
    ``A2ABridge(handler=fn).start()`` against a module-level handler and the
    ``@hexr_agent`` decorator either is absent or is attached to a class that
    the entrypoint never instantiates, the SDK's eager-register path never
    runs. The agent's process then has no SPIRE entry, every workload-API
    JWT-SVID request returns ``PERMISSION_DENIED no identity issued``, and
    every ``@hexr_tool`` call fails closed.

    This helper reads the runtime env vars that the build manifest always
    sets (HEXR_TENANT, HEXR_FRAMEWORK, HEXR_AGENT_NAME, POD_UID) and calls
    ``register_current_process`` for the *current* PID — the same process
    that will later own the workload-API socket connection. Idempotent:
    auto-registrar dedupes by (pod_uid, process_id, spiffe_id).
    """
    global _REGISTRATION_ATTEMPTED
    if _REGISTRATION_ATTEMPTED:
        return
    _REGISTRATION_ATTEMPTED = True

    try:
        from hexr.synchronous_registration import (
            get_last_registered_spiffe_id,
            register_current_process,
        )
    except Exception as exc:  # pragma: no cover - SDK is always available in agent runtime
        logger.debug("SPIRE registration helpers unavailable, skipping: %s", exc)
        return

    if get_last_registered_spiffe_id():
        logger.debug("A2A bridge: SPIRE registration already established by decorator path")
        return

    tenant = os.environ.get("HEXR_TENANT")
    framework = os.environ.get("HEXR_FRAMEWORK", "unknown")
    agent_name = os.environ.get("HEXR_AGENT_NAME")
    pod_uid = os.environ.get("POD_UID")

    missing = [n for n, v in [("HEXR_TENANT", tenant), ("HEXR_AGENT_NAME", agent_name), ("POD_UID", pod_uid)] if not v]
    if missing:
        logger.warning(
            "A2A bridge: skipping safety-net SPIRE registration — env vars not set: %s. "
            "If this is a production agent pod the build manifest should provide them; "
            "if hexr_tool() calls fail with PERMISSION_DENIED check the agent-pod.yaml.",
            ", ".join(missing),
        )
        return

    logger.info(
        "A2A bridge: invoking safety-net SPIRE registration (tenant=%s framework=%s agent=%s)",
        tenant, framework, agent_name,
    )
    try:
        register_current_process(
            tenant=tenant,
            framework=framework,
            agent_name=agent_name,
            sub_agent="main",
            process_role="main",
        )
    except Exception as exc:
        logger.error(
            "A2A bridge: safety-net SPIRE registration failed: %s. "
            "hexr_tool() calls will fail closed until SPIRE entry exists.",
            exc,
        )

# OTel integration — graceful degradation if not installed
try:
    from hexr.observability import get_tracer
    from hexr.observability.spans import SpanNames, SpanAttributes
    _tracer = get_tracer("hexr.a2a.bridge")
    _OTEL_AVAILABLE = True
except ImportError:
    _OTEL_AVAILABLE = False
    _tracer = None

# Type for user handler: receives Message, returns str or list[Artifact]
HandlerResult = Union[str, list[Artifact]]
AsyncHandler = Callable[[Message], Awaitable[HandlerResult]]
SyncHandler = Callable[[Message], HandlerResult]
Handler = Union[AsyncHandler, SyncHandler]


class A2ABridge:
    """HTTP bridge between Go A2A sidecar and Python agent handler.

    The sidecar POSTs to /execute with:
        {
            "task_id": "...",
            "context_id": "...",
            "message": { ... A2A Message ... },
            "protocol_version": "1"
        }

    The bridge responds with:
        {
            "artifacts": [ ... ],  // on success
            "error": "..."         // on failure
        }

    Args:
        handler: User function that processes an A2A Message.
                Can be sync or async. Returns str (auto-wrapped in
                TextPart/Artifact) or list[Artifact].
        host: Bind address (default: 127.0.0.1 — sidecar only).
        port: Listen port (default: 8080 — matches sidecar's -agent-port).
    """

    def __init__(
        self,
        handler: Handler,
        *,
        host: str = "127.0.0.1",
        port: int = 8080,
    ) -> None:
        self.handler = handler
        self.host = host
        self.port = port
        self._server: asyncio.Server | None = None

    async def start(self) -> None:
        """Start the bridge HTTP server. Runs until cancelled."""
        _ensure_spire_registration()
        self._server = await asyncio.start_server(
            self._handle_connection, self.host, self.port,
        )
        logger.info("A2A bridge listening on %s:%d", self.host, self.port)
        async with self._server:
            await self._server.serve_forever()

    async def start_background(self) -> None:
        """Start the bridge in background (non-blocking)."""
        _ensure_spire_registration()
        self._server = await asyncio.start_server(
            self._handle_connection, self.host, self.port,
        )
        logger.info("A2A bridge listening on %s:%d", self.host, self.port)
        await self._server.start_serving()

    async def stop(self) -> None:
        """Stop the bridge server."""
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
            logger.info("A2A bridge stopped")

    # -------------------------------------------------------------------
    # Connection handling (raw asyncio — no framework dependency)
    # -------------------------------------------------------------------

    async def _handle_connection(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        """Handle one HTTP connection from the sidecar."""
        try:
            # Read HTTP request line + headers
            request_line = await reader.readline()
            if not request_line:
                writer.close()
                return

            method, path, _ = request_line.decode().strip().split(" ", 2)
            headers: dict[str, str] = {}
            while True:
                line = await reader.readline()
                if line in (b"\r\n", b"\n", b""):
                    break
                key, _, value = line.decode().strip().partition(":")
                headers[key.strip().lower()] = value.strip()

            # Read body
            content_length = int(headers.get("content-length", "0"))
            body = b""
            if content_length > 0:
                body = await reader.readexactly(content_length)

            # Route
            if method == "POST" and path == "/execute":
                response_body = await self._handle_execute(body)
                status = "200 OK"
            elif method == "GET" and path == "/health":
                response_body = json.dumps({"status": "ok"}).encode()
                status = "200 OK"
            else:
                response_body = json.dumps({"error": "not found"}).encode()
                status = "404 Not Found"

            # Write HTTP response
            response = (
                f"HTTP/1.1 {status}\r\n"
                f"Content-Type: application/json\r\n"
                f"Content-Length: {len(response_body)}\r\n"
                f"Connection: close\r\n"
                f"\r\n"
            ).encode() + response_body

            writer.write(response)
            await writer.drain()

        except Exception as e:
            logger.error("Bridge connection error: %s", e)
            try:
                error_body = json.dumps({"error": str(e)}).encode()
                writer.write(
                    f"HTTP/1.1 500 Internal Server Error\r\n"
                    f"Content-Type: application/json\r\n"
                    f"Content-Length: {len(error_body)}\r\n"
                    f"Connection: close\r\n"
                    f"\r\n".encode() + error_body
                )
                await writer.drain()
            except Exception:
                pass
        finally:
            writer.close()

    async def _handle_execute(self, body: bytes) -> bytes:
        """Process an /execute request from the sidecar.

        Request format:
            {"task_id": str, "context_id": str, "message": {...}, "protocol_version": "1"}

        Response format (success):
            {"artifacts": [{...}, ...]}

        Response format (error):
            {"error": "description"}
        """
        try:
            data = json.loads(body)

            task_id = data.get("task_id", "unknown")
            context_id = data.get("context_id", "")
            message_data = data.get("message", {})

            # Normalize A2A spec "kind" → internal "type" discriminator on parts.
            # The A2A protocol uses "kind" for part discrimination, but our
            # Pydantic models use "type". Accept both for compatibility.
            for part in message_data.get("parts", []):
                if "kind" in part and "type" not in part:
                    part["type"] = part.pop("kind")

            # Deserialize the A2A Message
            message = Message.model_validate(message_data)

            logger.info("Executing task %s", task_id)

            # OTel span for handler execution
            span_attrs: dict[str, str] = {}
            if _OTEL_AVAILABLE:
                span_attrs[SpanAttributes.A2A_TASK_ID] = task_id
                if context_id:
                    span_attrs[SpanAttributes.A2A_CONTEXT_ID] = context_id

            span_cm = (
                _tracer.start_as_current_span(SpanNames.A2A_BRIDGE_EXECUTE, attributes=span_attrs)
                if _OTEL_AVAILABLE
                else contextlib.nullcontext()
            )

            with span_cm as span:
                # Call user handler (sync or async)
                if asyncio.iscoroutinefunction(self.handler):
                    result = await self.handler(message)
                else:
                    result = self.handler(message)

                # Normalize result to list[Artifact]
                artifacts = self._normalize_result(result)

                # Serialize artifacts
                artifact_dicts = [
                    a.model_dump(by_alias=True, exclude_none=True)
                    for a in artifacts
                ]

                logger.info("Task %s completed with %d artifact(s)", task_id, len(artifacts))
                return json.dumps({"artifacts": artifact_dicts}).encode()

        except Exception as e:
            logger.error("Task execution failed: %s\n%s", e, traceback.format_exc())
            if _OTEL_AVAILABLE:
                try:
                    # Record error on current span if available
                    from opentelemetry import trace as _trace
                    current_span = _trace.get_current_span()
                    if current_span and current_span.is_recording():
                        current_span.set_attribute(SpanAttributes.ERROR_TYPE, type(e).__name__)
                        current_span.set_attribute(SpanAttributes.ERROR_MESSAGE, str(e))
                except Exception:
                    pass
            return json.dumps({"error": str(e)}).encode()

    @staticmethod
    def _normalize_result(result: HandlerResult) -> list[Artifact]:
        """Convert handler return value to list[Artifact].

        Accepts:
            - str → wrapped in TextPart → single Artifact
            - list[Artifact] → used directly
            - Artifact → wrapped in list
        """
        if isinstance(result, str):
            return [Artifact(parts=[TextPart(text=result)])]
        elif isinstance(result, Artifact):
            return [result]
        elif isinstance(result, list):
            return result
        else:
            raise TypeError(
                f"Handler must return str, Artifact, or list[Artifact], "
                f"got {type(result).__name__}"
            )
