"""Structured logging utilities for Hexr SDK."""

import logging
import sys
from typing import Any

import structlog


def setup_logger(
    name: str, verbose: bool = False, debug: bool = False
) -> logging.Logger:
    """Setup logger with appropriate level and formatting."""
    logger = logging.getLogger(name)

    # Clear existing handlers
    logger.handlers.clear()

    # Set level based on flags
    if debug:
        logger.setLevel(logging.DEBUG)
    elif verbose:
        logger.setLevel(logging.INFO)
    else:
        logger.setLevel(logging.WARNING)

    # Create console handler
    handler = logging.StreamHandler(sys.stdout)

    # Create formatter
    if debug:
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
        )
    else:
        formatter = logging.Formatter("%(levelname)s - %(message)s")

    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger


def get_logger(name: str) -> Any:
    """Get a structured logger for the given name."""
    # Configure structlog for production
    structlog.configure(
        processors=[
            structlog.stdlib.filter_by_level,
            structlog.stdlib.add_logger_name,
            structlog.stdlib.add_log_level,
            structlog.stdlib.PositionalArgumentsFormatter(),
            structlog.processors.TimeStamper(fmt="iso"),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.processors.UnicodeDecoder(),
            structlog.processors.JSONRenderer(),
        ],
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    return structlog.get_logger(name)
