"""Shared utilities for Hexr SDK."""
