"""
Enhanced Process Context Manager for Hexr SDK.

Implements complete JSON contract-compliant context file generation
following the process-context-schema.json specification for Runtime
Enhanced Attestor integration.
"""

import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..config import HexrConfig
from ..exceptions import ProcessContextError
from ..utils.simple_logging import get_logger

logger = get_logger(__name__)


class EnhancedProcessContextManager:
    """
    Production-grade process context manager that creates JSON files
    compliant with process-context-schema.json for Runtime team integration.
    """

    def __init__(self, config: HexrConfig):
        self.config = config
        self.context_dir = Path("/tmp/hexr-context")

        # Use mocks if in mock mode
        if config.mock_mode:
            from ..testing.mocks import get_mock_process_manager

            self._mock_manager = get_mock_process_manager()
        else:
            self._mock_manager = None
            # Ensure context directory exists for real implementation
            self.context_dir.mkdir(exist_ok=True, mode=0o755)

    def create_process_context(
        self,
        agent_name: str,
        tenant: str,
        framework: str,
        resources: List[str],
        static_metadata: Dict[str, Any],
        subprocess_role: Optional[str] = None,
        parent_pid: Optional[int] = None,
    ) -> str:
        """
        Create complete process context file following JSON schema specification.

        Args:
            agent_name: Agent name from @hexr_agent decorator
            tenant: Tenant identifier
            framework: Detected or specified framework
            resources: Required cloud resources
            static_metadata: Build-time metadata from AST analysis
            subprocess_role: Role if this is a subprocess (e.g., "researcher", "analyst")
            parent_pid: Parent process ID if this is a subprocess

        Returns:
            Path to created context file
        """
        if self._mock_manager:
            return self._mock_manager.write_context_file(
                os.getpid(),
                self._build_context_data(
                    agent_name,
                    tenant,
                    framework,
                    resources,
                    static_metadata,
                    subprocess_role,
                    parent_pid,
                ),
            )

        pid = os.getpid()
        context_data = self._build_context_data(
            agent_name,
            tenant,
            framework,
            resources,
            static_metadata,
            subprocess_role,
            parent_pid,
        )

        file_path = self.context_dir / f"hexr-context-{pid}.json"

        try:
            with open(file_path, "w") as f:
                json.dump(context_data, f, indent=2, ensure_ascii=False)

            logger.info(
                f"Created process context file: {file_path} "
                f"(agent: {agent_name}, framework: {framework}, tenant: {tenant})"
            )
            return str(file_path)

        except Exception as e:
            raise ProcessContextError(f"Failed to create context file: {e}") from e

    def _build_context_data(
        self,
        agent_name: str,
        tenant: str,
        framework: str,
        resources: List[str],
        static_metadata: Dict[str, Any],
        subprocess_role: Optional[str] = None,
        parent_pid: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Build complete context data following JSON schema."""

        pid = os.getpid()
        current_timestamp = self._get_iso_timestamp()

        # Determine hierarchy level
        hierarchy_level = 0 if parent_pid is None else 1
        if parent_pid and self._get_process_hierarchy_depth(parent_pid) > 0:
            hierarchy_level = self._get_process_hierarchy_depth(parent_pid) + 1

        context_data = {
            # Required fields per schema
            "process_id": pid,
            "parent_process_id": parent_pid,
            "agent_name": agent_name,
            "tenant": tenant,
            "framework": framework,
            "subprocess_role": subprocess_role,
            "hierarchy_level": hierarchy_level,
            # Static metadata from build process
            "static_metadata": {
                "framework_version": static_metadata.get(
                    "framework_version", f"{framework}==unknown"
                ),
                "hexr_sdk_version": static_metadata.get("hexr_sdk_version", "0.1.0"),
                "build_timestamp": static_metadata.get(
                    "build_timestamp", current_timestamp
                ),
                "container_image": static_metadata.get(
                    "container_image", "hexr.registry/unknown"
                ),
                "required_resources": resources,
                "detected_tools": static_metadata.get("detected_tools", []),
                "ast_analysis": static_metadata.get("ast_analysis", {}),
            },
            # Dynamic runtime metadata
            "dynamic_metadata": {
                "creation_timestamp": current_timestamp,
                "runtime_state": "initializing",
                "spiffe_id": None,  # Set by Runtime Enhanced Attestor
                "pod_uid": self._get_pod_uid(),
                "container_id": self._get_container_id(),
                "cgroup_path": self._get_cgroup_path(),
                "credential_requests": [],
                "subprocess_spawned": [],
                "resource_usage": {
                    "cpu_usage_percent": 0.0,
                    "memory_usage_bytes": 0,
                    "network_bytes_sent": 0,
                    "network_bytes_received": 0,
                },
            },
            # Enhanced attestor metadata for Runtime processing
            "enhanced_attestor_metadata": {
                "framework_subprocess_pattern": self._get_framework_subprocess_pattern(
                    framework
                ),
                "multi_agent_coordination": {
                    "is_orchestrator": parent_pid is None,
                    "coordination_pattern": self._detect_coordination_pattern(
                        framework, subprocess_role
                    ),
                    "agent_dependencies": static_metadata.get("agent_dependencies", []),
                },
                "deep_agent_context": {
                    "reasoning_depth": static_metadata.get("reasoning_depth", 1),
                    "reflection_enabled": static_metadata.get(
                        "reflection_enabled", False
                    ),
                    "planning_horizon": static_metadata.get(
                        "planning_horizon", "immediate"
                    ),
                    "memory_persistence": static_metadata.get(
                        "memory_persistence", False
                    ),
                },
            },
        }

        return context_data

    def update_runtime_state(self, pid: int, new_state: str) -> None:
        """Update process runtime state (initializing -> running -> completed)."""
        if self._mock_manager:
            return self._mock_manager.update_context_file(
                pid, {"runtime_state": new_state}
            )

        self._update_dynamic_field(pid, "runtime_state", new_state)

    def log_credential_request(
        self, pid: int, service: str, success: bool, error_code: Optional[str] = None
    ) -> None:
        """Log hexr_tool() credential request for audit trails."""
        request_log = {
            "timestamp": self._get_iso_timestamp(),
            "service": service,
            "success": success,
            "error_code": error_code,
        }

        if self._mock_manager:
            # Mock manager handles this internally
            return

        self._append_to_dynamic_array(pid, "credential_requests", request_log)

    def register_subprocess(self, parent_pid: int, child_pid: int, role: str) -> None:
        """Register subprocess spawning for multi-agent coordination tracking."""
        subprocess_info = {
            "child_pid": child_pid,
            "spawned_at": self._get_iso_timestamp(),
            "role": role,
        }

        if self._mock_manager:
            return

        self._append_to_dynamic_array(parent_pid, "subprocess_spawned", subprocess_info)

    def cleanup_context_file(self, pid: int) -> None:
        """Clean up context file when process terminates."""
        if self._mock_manager:
            return self._mock_manager.cleanup_context_file(pid)

        file_path = self.context_dir / f"hexr-context-{pid}.json"

        try:
            if file_path.exists():
                # Update state to terminated before cleanup
                self.update_runtime_state(pid, "terminated")
                # Small delay to allow Runtime to process final state
                time.sleep(0.1)
                file_path.unlink()
                logger.info(f"Cleaned up context file: {file_path}")
        except Exception as e:
            logger.warning(f"Failed to cleanup context file {file_path}: {e}")

    def _update_dynamic_field(self, pid: int, field: str, value: Any) -> None:
        """Update a field in dynamic_metadata section."""
        file_path = self.context_dir / f"hexr-context-{pid}.json"

        if not file_path.exists():
            logger.warning(
                f"Context file for PID {pid} does not exist, skipping update"
            )
            return

        try:
            with open(file_path, "r") as f:
                context_data = json.load(f)

            context_data["dynamic_metadata"][field] = value

            with open(file_path, "w") as f:
                json.dump(context_data, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Failed to update dynamic field {field} for PID {pid}: {e}")

    def _append_to_dynamic_array(
        self, pid: int, array_field: str, new_item: Dict[str, Any]
    ) -> None:
        """Append item to an array in dynamic_metadata section."""
        file_path = self.context_dir / f"hexr-context-{pid}.json"

        if not file_path.exists():
            logger.warning(
                f"Context file for PID {pid} does not exist, skipping append"
            )
            return

        try:
            with open(file_path, "r") as f:
                context_data = json.load(f)

            if array_field not in context_data["dynamic_metadata"]:
                context_data["dynamic_metadata"][array_field] = []

            context_data["dynamic_metadata"][array_field].append(new_item)

            with open(file_path, "w") as f:
                json.dump(context_data, f, indent=2, ensure_ascii=False)

        except Exception as e:
            logger.error(f"Failed to append to {array_field} for PID {pid}: {e}")

    def _get_iso_timestamp(self) -> str:
        """Get current timestamp in ISO 8601 format."""
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _get_pod_uid(self) -> Optional[str]:
        """Extract Kubernetes pod UID from environment or cgroup."""
        # Check environment variables first (set by Kubernetes)
        pod_uid = os.environ.get("KUBERNETES_POD_UID")
        if pod_uid:
            return pod_uid

        # Try to extract from hostname (Kubernetes sets this to pod name)
        hostname = os.environ.get("HOSTNAME")
        if hostname and len(hostname) > 8:  # Basic validation
            return hostname

        return None

    def _get_container_id(self) -> Optional[str]:
        """Extract container ID from cgroup information."""
        try:
            with open("/proc/self/cgroup", "r") as f:
                for line in f:
                    if "docker" in line or "containerd" in line:
                        # Extract container ID from cgroup path
                        parts = line.strip().split("/")
                        for part in parts:
                            if len(part) == 64 and all(
                                c in "0123456789abcdef" for c in part
                            ):
                                return part
        except Exception:
            pass

        return None

    def _get_cgroup_path(self) -> Optional[str]:
        """Get complete cgroup path for process tracking."""
        try:
            with open("/proc/self/cgroup", "r") as f:
                lines = f.readlines()
                if lines:
                    # Return the first cgroup entry
                    return (
                        lines[0].strip().split(":", 2)[-1] if ":" in lines[0] else None
                    )
        except Exception:
            pass

        return None

    def _get_process_hierarchy_depth(self, pid: int) -> int:
        """Calculate process hierarchy depth by checking for existing context files."""
        try:
            parent_file = self.context_dir / f"hexr-context-{pid}.json"
            if parent_file.exists():
                with open(parent_file, "r") as f:
                    parent_data = json.load(f)
                    return parent_data.get("hierarchy_level", 0)
        except Exception:
            pass
        return 0

    def _get_framework_subprocess_pattern(self, framework: str) -> str:
        """Map framework to subprocess creation pattern."""
        patterns = {
            "crewai": "crewai_hierarchical",
            "langchain": "langchain_parallel",
            "autogen": "autogen_conversation",
            "swarm": "swarm_distributed",
            "strands": "strands_sequential",
            "custom": "custom_pattern",
        }
        return patterns.get(framework, "custom_pattern")

    def _detect_coordination_pattern(
        self, framework: str, subprocess_role: Optional[str]
    ) -> str:
        """Detect multi-agent coordination pattern based on framework and role."""
        if subprocess_role is None:
            return "hierarchical"  # Main orchestrator process

        framework_patterns = {
            "crewai": "hierarchical",
            "langchain": "sequential",
            "autogen": "conversational",
            "swarm": "parallel",
            "strands": "sequential",
        }

        return framework_patterns.get(framework, "hierarchical")


# Legacy compatibility - maintain existing interface
class ProcessContextManager(EnhancedProcessContextManager):
    """Legacy interface for backward compatibility."""

    def create_context_file(self, pid: int, context: dict[str, Any]) -> str:
        """Legacy method - converts old format to new schema-compliant format."""
        # Extract data from legacy format
        agent_name = context.get("agent_name", "unknown")
        tenant = context.get("tenant", "default")
        framework = context.get("framework", "custom")
        resources = context.get("resources", [])

        # Build static metadata from legacy context
        static_metadata = {
            "framework_version": f"{framework}==unknown",
            "hexr_sdk_version": "0.1.0",
            "build_timestamp": context.get("started_at", self._get_iso_timestamp()),
            "container_image": "hexr.registry/legacy",
            "detected_tools": [],
            "ast_analysis": {},
        }

        return self.create_process_context(
            agent_name=agent_name,
            tenant=tenant,
            framework=framework,
            resources=resources,
            static_metadata=static_metadata,
            subprocess_role=context.get("subprocess_role"),
            parent_pid=context.get("parent_pid"),
        )

    def update_context_file(self, pid: int, updates: dict[str, Any]) -> None:
        """Legacy method for updating context files."""
        # Map legacy updates to new methods
        if "runtime_state" in updates:
            self.update_runtime_state(pid, updates["runtime_state"])

        # Handle other legacy update patterns as needed
        for key, value in updates.items():
            if key != "runtime_state":
                self._update_dynamic_field(pid, key, value)

    def get_current_timestamp(self) -> str:
        """Legacy method."""
        return self._get_iso_timestamp()
