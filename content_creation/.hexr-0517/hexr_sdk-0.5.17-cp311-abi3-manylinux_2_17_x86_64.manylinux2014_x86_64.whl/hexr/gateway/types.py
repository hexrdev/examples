"""
Hexr Gateway Types - Data structures for MCP tool operations.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union
from enum import Enum


class ToolType(Enum):
    """Type of MCP tool."""
    FUNCTION = "function"
    RESOURCE = "resource"
    PROMPT = "prompt"


@dataclass
class ToolParameter:
    """Parameter definition for a tool."""
    name: str
    type: str
    description: str = ""
    required: bool = True
    default: Optional[Any] = None
    enum: Optional[List[str]] = None
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ToolParameter":
        return cls(
            name=data["name"],
            type=data.get("type", "string"),
            description=data.get("description", ""),
            required=data.get("required", True),
            default=data.get("default"),
            enum=data.get("enum"),
        )


@dataclass
class Tool:
    """
    MCP Tool definition.
    
    Attributes:
        name: Unique tool name.
        description: Human-readable description.
        parameters: Input parameters.
        source: Tool source (openapi, mcp, custom).
        endpoint: Backend endpoint URL.
        tags: Categorization tags.
        embedding: Semantic embedding for search.
    """
    name: str
    description: str
    parameters: List[ToolParameter] = field(default_factory=list)
    source: str = "mcp"
    endpoint: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    tool_type: ToolType = ToolType.FUNCTION
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Tool":
        params = [
            ToolParameter.from_dict(p)
            for p in data.get("parameters", [])
        ]
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            parameters=params,
            source=data.get("source", "mcp"),
            endpoint=data.get("endpoint"),
            tags=data.get("tags", []),
            tool_type=ToolType(data.get("type", "function")),
        )
    
    def to_mcp_format(self) -> Dict[str, Any]:
        """Convert to MCP JSON-RPC tool format."""
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": {
                "type": "object",
                "properties": {
                    param.name: {
                        "type": param.type,
                        "description": param.description,
                        **({"enum": param.enum} if param.enum else {}),
                        **({"default": param.default} if param.default is not None else {}),
                    }
                    for param in self.parameters
                },
                "required": [p.name for p in self.parameters if p.required],
            },
        }
    
    def to_openai_format(self) -> Dict[str, Any]:
        """Convert to OpenAI function calling format."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        param.name: {
                            "type": param.type,
                            "description": param.description,
                            **({"enum": param.enum} if param.enum else {}),
                        }
                        for param in self.parameters
                    },
                    "required": [p.name for p in self.parameters if p.required],
                },
            },
        }


@dataclass
class ToolResult:
    """
    Result of a tool invocation.
    
    Attributes:
        success: Whether the call succeeded.
        result: Return value on success.
        error: Error message on failure.
        tool_name: Name of the invoked tool.
        duration_ms: Execution time in milliseconds.
        metadata: Additional result metadata.
    """
    success: bool
    result: Any = None
    error: Optional[str] = None
    tool_name: str = ""
    duration_ms: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ToolResult":
        return cls(
            success=data.get("success", True),
            result=data.get("result"),
            error=data.get("error"),
            tool_name=data.get("tool_name", ""),
            duration_ms=data.get("duration_ms", 0.0),
            metadata=data.get("metadata", {}),
        )
    
    @classmethod
    def success_result(cls, result: Any, tool_name: str = "") -> "ToolResult":
        return cls(success=True, result=result, tool_name=tool_name)
    
    @classmethod
    def error_result(cls, error: str, tool_name: str = "") -> "ToolResult":
        return cls(success=False, error=error, tool_name=tool_name)


@dataclass
class SearchResult:
    """
    Search result with relevance score.
    
    Attributes:
        tool: The matched tool.
        score: Relevance score (0-1).
        highlights: Matching text snippets.
    """
    tool: Tool
    score: float
    highlights: List[str] = field(default_factory=list)
