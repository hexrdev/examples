"""
Hexr Gateway Client - MCP tool discovery and invocation.

Provides semantic tool search, MCP protocol support, and automatic
SPIFFE authentication for secure tool access.
"""

import json
import os
from typing import Any, Callable, Dict, List, Optional, Union
import httpx
from dataclasses import dataclass

from .types import Tool, ToolResult, SearchResult


class GatewayError(Exception):
    """Base exception for Gateway operations."""
    pass


class ToolNotFoundError(GatewayError):
    """Tool does not exist in registry."""
    pass


class ToolExecutionError(GatewayError):
    """Tool execution failed."""
    pass


class AuthenticationError(GatewayError):
    """SPIFFE authentication failed."""
    pass


class PolicyDeniedError(GatewayError):
    """OPA policy denied tool access."""
    pass


class GatewayClient:
    """
    MCP Gateway client for tool discovery and invocation.
    
    Features:
    - Semantic tool search using vector embeddings
    - MCP JSON-RPC 2.0 protocol support
    - Automatic SPIFFE authentication
    - OPA policy enforcement
    - OpenAPI-to-MCP automatic conversion
    
    Args:
        base_url: Gateway service URL. Defaults to in-cluster service.
        tenant: Override tenant ID.
        timeout: Request timeout in seconds.
        verify_ssl: Enable SSL verification.
    
    Example:
        gateway = GatewayClient()
        
        # Search for tools
        results = gateway.search_tools("send email")
        
        # Call a tool
        result = gateway.call_tool("send_email", {
            "to": "user@example.com",
            "subject": "Hello"
        })
    """
    
    DEFAULT_URL = "http://hexr-gateway.hexr-system.svc.cluster.local:8090"
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        tenant: Optional[str] = None,
        timeout: float = 60.0,
        verify_ssl: bool = True,
    ):
        self.base_url = base_url or os.getenv("HEXR_GATEWAY_URL", self.DEFAULT_URL)
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        
        # Get tenant from environment or SPIFFE
        self._tenant = tenant or os.getenv("HEXR_TENANT")
        
        # Build authentication headers
        self._headers = self._build_auth_headers()
        
        # HTTP client
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            verify=verify_ssl,
            headers=self._headers,
        )
        
        # Tool cache
        self._tool_cache: Dict[str, Tool] = {}
        self._cache_loaded = False
    
    def _build_auth_headers(self) -> Dict[str, str]:
        """Build authentication headers from SPIFFE identity."""
        headers = {"Content-Type": "application/json"}
        
        # Try to get SPIFFE ID
        spiffe_id = os.getenv("SPIFFE_ID")
        if spiffe_id:
            headers["X-SPIFFE-ID"] = spiffe_id
        
        # Fallback: tenant header
        if self._tenant:
            headers["X-Hexr-Tenant"] = self._tenant
        
        agent_name = os.getenv("HEXR_AGENT_NAME")
        if agent_name:
            headers["X-Hexr-Agent"] = agent_name
            
        return headers
    
    @property
    def tenant(self) -> Optional[str]:
        """Current tenant ID."""
        return self._tenant
    
    # ========== Tool Discovery ==========
    
    def list_tools(
        self,
        tags: Optional[List[str]] = None,
        source: Optional[str] = None,
        force_refresh: bool = False,
    ) -> List[Tool]:
        """
        List available tools.
        
        Args:
            tags: Filter by tags.
            source: Filter by source (openapi, mcp, custom).
            force_refresh: Bypass cache.
        
        Returns:
            List of available Tool objects.
        
        Example:
            tools = gateway.list_tools(tags=["database"])
        """
        if not force_refresh and self._cache_loaded and not tags and not source:
            return list(self._tool_cache.values())
        
        params = {}
        if tags:
            params["tags"] = ",".join(tags)
        if source:
            params["source"] = source
        
        try:
            response = self._client.get("/api/tools", params=params)
            
            if response.status_code == 401:
                raise AuthenticationError("SPIFFE authentication required")
            
            response.raise_for_status()
            data = response.json()
            
            tools = [Tool.from_dict(t) for t in data.get("tools", [])]
            
            # Update cache
            if not tags and not source:
                self._tool_cache = {t.name: t for t in tools}
                self._cache_loaded = True
            
            return tools
            
        except httpx.HTTPStatusError as e:
            raise GatewayError(f"Failed to list tools: {e}") from e
    
    def get_tool(self, name: str) -> Tool:
        """
        Get a specific tool by name.
        
        Args:
            name: Tool name.
        
        Returns:
            Tool definition.
        
        Raises:
            ToolNotFoundError: Tool doesn't exist.
        """
        # Check cache first
        if name in self._tool_cache:
            return self._tool_cache[name]
        
        try:
            response = self._client.get(f"/api/tools/{name}")
            
            if response.status_code == 404:
                raise ToolNotFoundError(f"Tool not found: {name}")
            
            response.raise_for_status()
            data = response.json()
            
            tool = Tool.from_dict(data)
            self._tool_cache[name] = tool
            return tool
            
        except httpx.HTTPStatusError as e:
            raise GatewayError(f"Failed to get tool: {e}") from e
    
    def search_tools(
        self,
        query: str,
        limit: int = 10,
        min_score: float = 0.5,
    ) -> List[SearchResult]:
        """
        Search tools using semantic similarity.
        
        Args:
            query: Natural language search query.
            limit: Maximum results to return.
            min_score: Minimum relevance score (0-1).
        
        Returns:
            List of SearchResult with relevance scores.
        
        Example:
            results = gateway.search_tools("query database for user info")
            for r in results:
                print(f"{r.tool.name}: {r.score:.2f}")
        """
        try:
            response = self._client.post(
                "/api/tools/search",
                json={
                    "query": query,
                    "limit": limit,
                    "min_score": min_score,
                },
            )
            
            response.raise_for_status()
            data = response.json()
            
            results = []
            for item in data.get("results", []):
                tool = Tool.from_dict(item["tool"])
                results.append(SearchResult(
                    tool=tool,
                    score=item.get("score", 0.0),
                    highlights=item.get("highlights", []),
                ))
            
            return results
            
        except httpx.HTTPStatusError as e:
            raise GatewayError(f"Search failed: {e}") from e
    
    # ========== Tool Invocation ==========
    
    def call_tool(
        self,
        name: str,
        arguments: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> ToolResult:
        """
        Invoke a tool.
        
        Args:
            name: Tool name.
            arguments: Tool input arguments.
            timeout: Override default timeout.
        
        Returns:
            ToolResult with success/error and result data.
        
        Raises:
            ToolNotFoundError: Tool doesn't exist.
            ToolExecutionError: Execution failed.
            PolicyDeniedError: OPA policy denied.
        
        Example:
            result = gateway.call_tool("sql_query", {
                "query": "SELECT * FROM users LIMIT 10"
            })
            if result.success:
                print(result.result)
        """
        try:
            response = self._client.post(
                f"/api/tools/{name}/invoke",
                json={"arguments": arguments or {}},
                timeout=timeout or self.timeout,
            )
            
            if response.status_code == 404:
                raise ToolNotFoundError(f"Tool not found: {name}")
            elif response.status_code == 403:
                raise PolicyDeniedError(f"Access denied to tool: {name}")
            elif response.status_code == 401:
                raise AuthenticationError("SPIFFE authentication required")
            
            response.raise_for_status()
            data = response.json()
            
            return ToolResult.from_dict(data)
            
        except httpx.HTTPStatusError as e:
            if e.response.status_code >= 500:
                raise ToolExecutionError(f"Tool execution failed: {e}") from e
            raise GatewayError(f"Tool call failed: {e}") from e
    
    def call_tool_mcp(
        self,
        name: str,
        arguments: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """
        Invoke a tool using MCP JSON-RPC protocol.
        
        Args:
            name: Tool name.
            arguments: Tool arguments.
        
        Returns:
            Raw tool result.
        """
        request = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {
                "name": name,
                "arguments": arguments or {},
            },
        }
        
        try:
            response = self._client.post(
                "/mcp",
                json=request,
            )
            response.raise_for_status()
            data = response.json()
            
            if "error" in data:
                raise ToolExecutionError(data["error"].get("message", "Unknown error"))
            
            return data.get("result")
            
        except httpx.HTTPStatusError as e:
            raise GatewayError(f"MCP call failed: {e}") from e
    
    # ========== OpenAPI Registration ==========
    
    def register_openapi(
        self,
        spec: Union[str, Dict[str, Any]],
        base_url: str,
        prefix: str = "",
    ) -> List[str]:
        """
        Register tools from an OpenAPI specification.
        
        Args:
            spec: OpenAPI spec as JSON string or dict.
            base_url: Backend service URL.
            prefix: Tool name prefix.
        
        Returns:
            List of registered tool names.
        """
        if isinstance(spec, str):
            spec = json.loads(spec)
        
        try:
            response = self._client.post(
                "/api/openapi/register",
                json={
                    "spec": spec,
                    "base_url": base_url,
                    "prefix": prefix,
                },
            )
            
            response.raise_for_status()
            data = response.json()
            
            # Invalidate cache
            self._cache_loaded = False
            
            return data.get("tools", [])
            
        except httpx.HTTPStatusError as e:
            raise GatewayError(f"OpenAPI registration failed: {e}") from e
    
    # ========== Format Conversion ==========
    
    def get_tools_openai_format(
        self,
        tool_names: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get tools in OpenAI function calling format.
        
        Args:
            tool_names: Specific tools (all if None).
        
        Returns:
            List of tools in OpenAI format.
        """
        if tool_names:
            tools = [self.get_tool(name) for name in tool_names]
        else:
            tools = self.list_tools()
        
        return [t.to_openai_format() for t in tools]
    
    def get_tools_mcp_format(
        self,
        tool_names: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get tools in MCP format.
        
        Args:
            tool_names: Specific tools (all if None).
        
        Returns:
            List of tools in MCP format.
        """
        if tool_names:
            tools = [self.get_tool(name) for name in tool_names]
        else:
            tools = self.list_tools()
        
        return [t.to_mcp_format() for t in tools]
    
    # ========== Utilities ==========
    
    def health(self) -> Dict[str, str]:
        """Check gateway service health."""
        try:
            response = self._client.get("/health")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}
    
    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()
    
    def __enter__(self) -> "GatewayClient":
        return self
    
    def __exit__(self, *args) -> None:
        self.close()


# Global client singleton
_global_client: Optional[GatewayClient] = None


def get_client() -> GatewayClient:
    """Get or create the global gateway client."""
    global _global_client
    if _global_client is None:
        _global_client = GatewayClient()
    return _global_client


def call_tool(name: str, arguments: Optional[Dict[str, Any]] = None) -> ToolResult:
    """Convenience function to call a tool using the global client."""
    return get_client().call_tool(name, arguments)


def search_tools(query: str, limit: int = 10) -> List[SearchResult]:
    """Convenience function to search tools using the global client."""
    return get_client().search_tools(query, limit)


def list_tools() -> List[Tool]:
    """Convenience function to list tools using the global client."""
    return get_client().list_tools()
