"""
Hexr Gateway - MCP client for tool discovery and invocation.

This module provides programmatic access to the Hexr Gateway service for
discovering and calling MCP tools with automatic SPIFFE authentication
and OPA policy enforcement.

Example usage:
    from hexr.gateway import GatewayClient
    
    # Connect to gateway
    gateway = GatewayClient()
    
    # Discover available tools
    tools = gateway.list_tools()
    
    # Search for tools semantically
    tools = gateway.search_tools("database query")
    
    # Call a tool
    result = gateway.call_tool("sql_query", {"query": "SELECT * FROM users"})
    
    # Use the @mcp_tool decorator for automatic routing
    from hexr.gateway import mcp_tool
    
    @mcp_tool("sql_query")
    def run_query(query: str) -> dict:
        pass  # Automatically routes to gateway
"""

from .client import GatewayClient, GatewayError, ToolNotFoundError, ToolExecutionError
from .decorators import mcp_tool, discover_tools, gateway_context
from .types import Tool, ToolResult, ToolParameter

__all__ = [
    "GatewayClient",
    "GatewayError",
    "ToolNotFoundError",
    "ToolExecutionError",
    "Tool",
    "ToolResult",
    "ToolParameter",
    "mcp_tool",
    "discover_tools",
    "gateway_context",
]
