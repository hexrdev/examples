"""
Hexr Gateway Decorators - Declarative MCP tool integration.

Provides decorators for automatic tool routing and discovery.
"""

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union
from contextlib import contextmanager

from .client import GatewayClient, get_client
from .types import Tool, ToolResult

F = TypeVar("F", bound=Callable[..., Any])


def mcp_tool(
    tool_name: str,
    timeout: Optional[float] = None,
    raise_on_error: bool = True,
) -> Callable[[F], F]:
    """
    Decorator that routes function calls through the MCP gateway.
    
    The decorated function's arguments are passed to the gateway tool.
    
    Args:
        tool_name: Name of the tool in the gateway registry.
        timeout: Override default timeout.
        raise_on_error: Raise exception on tool error (default True).
    
    Example:
        @mcp_tool("sql_query")
        def query_database(query: str, limit: int = 100) -> dict:
            pass  # Arguments are automatically sent to gateway
        
        # Call like a normal function
        result = query_database("SELECT * FROM users", limit=10)
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_client()
            
            # Build arguments from function signature
            import inspect
            sig = inspect.signature(func)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            
            # Call the tool
            result = client.call_tool(
                tool_name,
                arguments=dict(bound.arguments),
                timeout=timeout,
            )
            
            if not result.success and raise_on_error:
                from .client import ToolExecutionError
                raise ToolExecutionError(result.error or "Tool execution failed")
            
            return result.result if result.success else result
        
        # Attach metadata
        wrapper._mcp_tool_name = tool_name  # type: ignore
        wrapper._is_mcp_tool = True  # type: ignore
        
        return wrapper  # type: ignore
    return decorator


def discover_tools(
    prefix: str = "",
    tags: Optional[List[str]] = None,
) -> Callable[[type], type]:
    """
    Class decorator that auto-discovers and binds tools as methods.
    
    Discovered tools become callable methods on the class instance.
    
    Args:
        prefix: Tool name prefix filter.
        tags: Filter tools by tags.
    
    Example:
        @discover_tools(prefix="email_")
        class EmailTools:
            pass
        
        tools = EmailTools()
        tools.email_send(to="user@example.com", subject="Hi")
    """
    def decorator(cls: type) -> type:
        original_init = cls.__init__
        
        def new_init(self, *args, **kwargs):
            original_init(self, *args, **kwargs)
            
            # Discover tools and bind as methods
            client = get_client()
            tools = client.list_tools(tags=tags)
            
            for tool in tools:
                if prefix and not tool.name.startswith(prefix):
                    continue
                
                # Create method for this tool
                # Strip prefix from method name
                method_name = tool.name
                if prefix:
                    method_name = tool.name[len(prefix):]
                
                def make_method(t: Tool):
                    def method(inner_self, **kwargs):
                        return client.call_tool(t.name, kwargs)
                    method.__name__ = method_name
                    method.__doc__ = t.description
                    return method
                
                setattr(self, method_name, make_method(tool).__get__(self, cls))
        
        cls.__init__ = new_init
        return cls
    return decorator


@contextmanager
def gateway_context(
    base_url: Optional[str] = None,
    tenant: Optional[str] = None,
):
    """
    Context manager for temporary gateway configuration.
    
    Useful for testing or switching between gateway instances.
    
    Args:
        base_url: Override gateway URL.
        tenant: Override tenant ID.
    
    Example:
        with gateway_context(base_url="http://test-gateway:8090"):
            result = call_tool("test_tool", {})
    """
    from .client import _global_client
    import hexr.gateway.client as client_module
    
    # Save original
    original_client = client_module._global_client
    
    try:
        # Create new client with overrides
        client_module._global_client = GatewayClient(
            base_url=base_url,
            tenant=tenant,
        )
        yield client_module._global_client
    finally:
        # Restore original
        if client_module._global_client:
            client_module._global_client.close()
        client_module._global_client = original_client


class ToolProxy:
    """
    Dynamic proxy for calling tools by attribute access.
    
    Example:
        proxy = ToolProxy()
        result = proxy.sql_query(query="SELECT 1")
        result = proxy.send_email(to="user@example.com")
    """
    
    def __init__(
        self,
        client: Optional[GatewayClient] = None,
        prefix: str = "",
    ):
        self._client = client
        self._prefix = prefix
    
    @property
    def client(self) -> GatewayClient:
        if self._client is None:
            self._client = get_client()
        return self._client
    
    def __getattr__(self, name: str) -> Callable[..., ToolResult]:
        if name.startswith("_"):
            raise AttributeError(name)
        
        tool_name = self._prefix + name if self._prefix else name
        
        def tool_call(**kwargs) -> ToolResult:
            return self.client.call_tool(tool_name, kwargs)
        
        tool_call.__name__ = name
        return tool_call


def with_gateway(func: F) -> F:
    """
    Decorator that injects a GatewayClient instance as the first argument.
    
    Example:
        @with_gateway
        def process_with_tools(gateway: GatewayClient, data: dict):
            tools = gateway.list_tools()
            # ...
        
        process_with_tools({"key": "value"})
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        client = get_client()
        return func(client, *args, **kwargs)
    return wrapper  # type: ignore


def tool_fallback(
    primary: str,
    fallback: str,
    timeout: float = 30.0,
) -> Callable[[F], F]:
    """
    Decorator that tries primary tool, falls back to secondary on failure.
    
    Args:
        primary: Primary tool name.
        fallback: Fallback tool name.
        timeout: Timeout per tool attempt.
    
    Example:
        @tool_fallback("fast_search", "slow_search")
        def search(query: str) -> dict:
            pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_client()
            
            import inspect
            sig = inspect.signature(func)
            bound = sig.bind(*args, **kwargs)
            bound.apply_defaults()
            arguments = dict(bound.arguments)
            
            # Try primary
            try:
                result = client.call_tool(primary, arguments, timeout=timeout)
                if result.success:
                    return result.result
            except Exception:
                pass
            
            # Try fallback
            result = client.call_tool(fallback, arguments, timeout=timeout)
            if result.success:
                return result.result
            
            from .client import ToolExecutionError
            raise ToolExecutionError(result.error or f"Both {primary} and {fallback} failed")
        
        return wrapper  # type: ignore
    return decorator
