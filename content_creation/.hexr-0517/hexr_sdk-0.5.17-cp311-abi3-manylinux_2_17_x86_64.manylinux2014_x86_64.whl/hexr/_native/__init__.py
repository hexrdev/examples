"""Hexr native extensions + shipped detection packs.

This sub-package houses Rust-built CPython extensions that ship with the
SDK. The extension(s) are produced by maturin from the
``_hexr_analyzer/`` crate at the repository root and installed here at
build time:

    src/hexr/_native/hexr_analyzer.<abi>.so

The YAML detection packs (frameworks + patterns) live alongside the
extension at ``hexr/_native/packs/`` and ship inside the same wheel.
``default_pack_dirs()`` returns those resource directories so callers
never have to know the on-disk layout.

Importing this package does not import the extension; downstream callers
do ``from hexr._native import hexr_analyzer`` (or ``import
hexr._native.hexr_analyzer``) and handle the ``ImportError`` for
environments where the wheel was built without the native module.
"""
from __future__ import annotations

from importlib.resources import files
from pathlib import Path


def default_pack_dirs() -> tuple[Path, Path]:
    """Return ``(framework_pack_dir, pattern_pack_dir)`` for the bundled YAML packs.

    These paths point at the resource directories shipped inside the
    installed wheel (``hexr/_native/packs/{frameworks,patterns}/``).
    Both directories are guaranteed to exist for any wheel built from
    this repository because ``packs/`` is part of the package source
    tree under ``python-source``.
    """
    base = files(__name__) / "packs"
    return Path(str(base / "frameworks")), Path(str(base / "patterns"))
