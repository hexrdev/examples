"""Hexr SDK"""

from .config import HexrConfig
from .context import (
    HexrContext,
    get_tenant,
    get_framework,
    get_agent_name,
    get_sub_agent,
    get_resources,
)
from .decorators import hexr_agent
from .evidence import post_evidence
from .exceptions import AuthenticationError, CredentialError, GuardrailError, HexrError
from .llm import hexr_llm
from .tools import hexr_tool
from .version import __version__
from .synchronous_registration import register_current_process

# Lazy imports for optional modules
import importlib as _importlib
import sys as _sys

def __getattr__(name):
    _lazy_modules = {"vault", "gateway", "sandbox", "browser", "guard"}
    if name in _lazy_modules:
        module = _importlib.import_module(f".{name}", __name__)
        _sys.modules[f"{__name__}.{name}"] = module
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "hexr_agent",
    "hexr_llm",
    "hexr_tool",
    "post_evidence",
    "HexrContext",
    "get_tenant",
    "get_framework",
    "get_agent_name",
    "get_sub_agent",
    "get_resources",
    "HexrError",
    "AuthenticationError",
    "CredentialError",
    "GuardrailError",
    "HexrConfig",
    "__version__",
    "register_current_process",
    # Optional modules (lazy loaded)
    "vault",
    "gateway",
    "sandbox",
    "browser",
]
