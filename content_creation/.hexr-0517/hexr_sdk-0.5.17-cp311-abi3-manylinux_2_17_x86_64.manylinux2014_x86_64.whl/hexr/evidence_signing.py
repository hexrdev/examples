"""Per-row SVID signing for compliance evidence (spec §1.29.2).

Signs an evidence row with the private key of this process's SPIRE-issued
X.509-SVID before posting it, so the row is bound to an **attested process**
rather than to whoever holds database access.

Why that matters, and why it needs an SDK
-----------------------------------------
The evidence API already maintains a per-tenant hash chain (§1.29.1), which
proves a sequence has not been *altered*. It does not prove *who wrote it*:
anyone with write access to the table can recompute the whole chain forward and
it verifies clean. A signature made inside the emitting process closes that,
because the key never leaves the process and the certificate it lives in was
issued only after the SPIRE agent attested the process to the kernel.

This is the part a gateway cannot do. Signing has to happen inside the process,
and "change an endpoint, not your application" forbids being inside the
process.

Byte-for-byte agreement with the verifier
-----------------------------------------
``canonical_signable`` here MUST produce the same bytes as ``CanonicalSignable``
in ``hexr-evidence-api/signing.go``. If the two drift, every signature fails in
production and the failure looks exactly like tampering. Three specific traps
are handled, each of which cost a real incident elsewhere in this codebase:

* **JSONB reorders object keys.** Postgres does not preserve the bytes it
  received for a JSONB column, so ``details`` is re-serialised with sorted keys
  and no whitespace on both sides.
* **TIMESTAMPTZ holds microseconds.** Python datetimes already stop at
  microseconds, but the value is truncated explicitly so the intent is visible
  and a future move to nanoseconds cannot silently break every chain — which is
  precisely what happened to the v0.2.0 hash chain.
* **HTML escaping.** Go's ``encoding/json`` escapes ``<``, ``>`` and ``&``;
  Python's ``json.dumps`` does not. Any URL in a details payload would break.
  Both sides therefore use an explicit escaper (``_encode_json_string``) rather
  than their standard library's.

The golden vector in ``tests/test_evidence_signing.py`` is asserted in both
languages. Change one canonicaliser and exactly one suite goes red, which is
the point.

Failure is always non-fatal
---------------------------
If no SPIRE socket is reachable, or the ``spiffe`` package is not installed, or
the key type is unsupported, signing returns ``None`` and the row is posted
unsigned. The server records it and reports it as unsigned rather than
rejecting it. Dropping evidence because signing was unavailable would be a
worse outcome than unsigned evidence: the row is the thing the auditor needs,
and its absence cannot be detected later.
"""

from __future__ import annotations

import json
import logging
import os
import secrets
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# Prefixes the signable bytes so the canonical form can be revised later
# without a verifier silently reinterpreting old signatures under new rules.
# Must match SignableVersion in hexr-evidence-api/signing.go.
SIGNABLE_VERSION = "hexr-evidence-v1"

# Set to "0"/"false" to post unsigned even where an SVID is available. Exists
# for isolating whether a delivery problem is a signing problem.
_DISABLE_ENV = "HEXR_EVIDENCE_SIGNING"


def _encode_json_string(s: str) -> str:
    """Render a JSON string literal identically to the Go verifier.

    Deliberately not ``json.dumps``. Go's ``encoding/json`` HTML-escapes ``<``,
    ``>`` and ``&``; Python's does not. Rather than making one side imitate the
    other's quirk, both implement the minimal RFC 8259 rules: escape the two
    characters that must be escaped, short forms for the five named control
    characters, lower-case ``\\u00xx`` for the remaining C0 controls, and
    literal UTF-8 for everything else.
    """
    out = ['"']
    for ch in s:
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\b":
            out.append("\\b")
        elif ch == "\f":
            out.append("\\f")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif ord(ch) < 0x20:
            out.append(f"\\u{ord(ch):04x}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def _marshal_canonical(v: Any) -> str:
    """Serialise a decoded JSON value with object keys sorted.

    Numbers are carried through as the literal text that was parsed, never via
    ``float``, so ``1.50`` does not become ``1.5`` and a large integer does not
    lose precision. Mirrors ``marshalCanonical`` in signing.go.
    """
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, _RawNumber):
        return v.text
    if isinstance(v, str):
        return _encode_json_string(v)
    if isinstance(v, list):
        return "[" + ",".join(_marshal_canonical(e) for e in v) + "]"
    if isinstance(v, dict):
        return (
            "{"
            + ",".join(
                _encode_json_string(k) + ":" + _marshal_canonical(v[k])
                for k in sorted(v.keys())
            )
            + "}"
        )
    # int/float can only appear if a caller bypassed the parser below.
    if isinstance(v, int):
        return str(v)
    raise TypeError(f"canonical json: unsupported type {type(v).__name__}")


class _RawNumber:
    """Holds a numeric literal as written, mirroring Go's ``json.Number``."""

    __slots__ = ("text",)

    def __init__(self, text: str) -> None:
        self.text = text


def canonical_json(s: str) -> str:
    """Re-serialise a JSON document with sorted keys and no whitespace.

    Input that does not parse is returned unchanged, so a malformed payload
    fails verification loudly rather than raising here and losing the row.
    """
    try:
        v = json.loads(s, parse_float=_RawNumber, parse_int=_RawNumber)
    except (ValueError, TypeError):
        return s
    try:
        return _marshal_canonical(v)
    except TypeError:
        return s


def _signable_time(t: datetime) -> str:
    """Render a timestamp at microsecond resolution in UTC.

    Postgres TIMESTAMPTZ holds microseconds and silently truncates anything
    finer. Both sides truncate so the value read back renders identically to
    the value signed.
    """
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    return t.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f") + "Z"


def canonical_signable(
    *,
    tenant_id: str,
    source: str,
    event_type: str,
    severity: str,
    spiffe_id: str,
    agent_id: str,
    framework: str,
    control_id: str,
    details: str,
    trace_id: str,
    signed_at: datetime,
    nonce: str,
) -> str:
    """The exact bytes signed, and the exact bytes the server recomputes.

    Excludes ``id`` and ``recorded_at``: both are assigned by the server at
    ingest, so the client cannot know them and cannot sign over them.

    Every field is length-prefixed. Without prefixes, ``("ab","c")`` and
    ``("a","bc")`` concatenate identically, so one row could be crafted to
    forge another's digest.
    """
    parts = [
        SIGNABLE_VERSION,
        tenant_id,
        source,
        event_type,
        severity,
        spiffe_id,
        agent_id,
        framework,
        control_id,
        canonical_json(details),
        trace_id,
        _signable_time(signed_at),
        nonce,
    ]
    return "".join(f"{len(p)}:{p}|" for p in parts)


def new_nonce() -> str:
    """128 bits of randomness, hex-encoded.

    Without it, two byte-identical events emitted in the same microsecond
    produce byte-identical signable content, and a captured
    ``(payload, signature)`` pair could be replayed as a second
    legitimate-looking row.
    """
    return secrets.token_hex(16)


def signing_enabled() -> bool:
    return os.environ.get(_DISABLE_ENV, "1").strip().lower() not in (
        "0",
        "false",
        "no",
        "off",
    )


def sign_payload(payload: dict[str, Any], *, socket_path: str | None = None) -> bool:
    """Add ``signature``/``signing_svid``/``signed_at``/``nonce`` to ``payload``.

    Returns True when the payload was signed. Returns False — leaving the
    payload untouched and postable — whenever signing material is unavailable
    for any reason. See the module docstring on why this never raises: an
    unsigned row is recoverable, a dropped row is not.

    The four fields are added as a set. The server rejects a partial set,
    because a row with a signature but no nonce could never be re-verified.
    """
    if not signing_enabled():
        logger.debug("evidence signing disabled via %s", _DISABLE_ENV)
        return False

    try:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa
        from cryptography.hazmat.primitives.serialization import Encoding
    except ImportError:
        logger.debug("evidence signing: cryptography not installed — posting unsigned")
        return False

    try:
        from hexr.spiffe.workload_api_client import WorkloadAPIClient

        client = (
            WorkloadAPIClient(socket_path) if socket_path else WorkloadAPIClient()
        )
        svid = client.fetch_x509_svid()
    except Exception as exc:  # noqa: BLE001 - never fail the caller over signing
        logger.debug("evidence signing: no X509-SVID available (%s) — posting unsigned", exc)
        return False

    if svid is None:
        logger.debug("evidence signing: no X509-SVID available — posting unsigned")
        return False

    try:
        chain = getattr(svid, "cert_chain", None) or []
        key = getattr(svid, "private_key", None)
        if not chain or key is None:
            logger.debug("evidence signing: SVID carries no chain or key — posting unsigned")
            return False

        # Python datetimes already stop at microseconds, which is exactly what
        # Postgres TIMESTAMPTZ stores, so no truncation is needed here.
        signed_at = datetime.now(timezone.utc)
        nonce = new_nonce()

        # The row's spiffe_id must equal the SVID's identity: the server
        # rejects a row signed by one workload while claiming to be another.
        # Taking it from the certificate rather than the environment removes
        # the chance of them disagreeing.
        svid_id = str(getattr(svid, "spiffe_id", "") or payload.get("spiffe_id", ""))
        if svid_id:
            payload["spiffe_id"] = svid_id

        message = canonical_signable(
            tenant_id=payload.get("tenant_id", ""),
            source=payload.get("source", ""),
            event_type=payload.get("event_type", ""),
            severity=payload.get("severity", ""),
            spiffe_id=payload.get("spiffe_id", ""),
            agent_id=payload.get("agent_id", ""),
            framework=payload.get("framework", ""),
            control_id=payload.get("control_id", ""),
            details=payload.get("details", "{}"),
            trace_id=payload.get("trace_id", ""),
            signed_at=signed_at,
            nonce=nonce,
        ).encode("utf-8")

        if isinstance(key, ec.EllipticCurvePrivateKey):
            sig = key.sign(message, ec.ECDSA(hashes.SHA256()))
        elif isinstance(key, rsa.RSAPrivateKey):
            sig = key.sign(message, padding.PKCS1v15(), hashes.SHA256())
        elif isinstance(key, ed25519.Ed25519PrivateKey):
            sig = key.sign(message)
        else:
            logger.debug(
                "evidence signing: unsupported SVID key type %s — posting unsigned",
                type(key).__name__,
            )
            return False

        import base64

        pem_chain = b"".join(c.public_bytes(Encoding.PEM) for c in chain)

        payload["signature"] = base64.b64encode(sig).decode("ascii")
        payload["signing_svid"] = pem_chain.decode("ascii")
        payload["signed_at"] = _signable_time(signed_at)
        payload["nonce"] = nonce
        return True
    except Exception as exc:  # noqa: BLE001
        logger.debug("evidence signing failed (%s) — posting unsigned", exc)
        return False


__all__ = [
    "SIGNABLE_VERSION",
    "canonical_json",
    "canonical_signable",
    "new_nonce",
    "sign_payload",
    "signing_enabled",
]
