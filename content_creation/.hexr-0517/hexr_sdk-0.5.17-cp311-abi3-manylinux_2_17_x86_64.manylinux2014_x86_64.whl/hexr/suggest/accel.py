"""Accelerator backend auto-detection for `hexr analyze --suggest`.

Spec
----
HEXR_SDK_OVERHAUL_TECH_SPEC.md §21.5 PR-D7 — "Apple-Silicon selector-wheel
auto-detect at install time". Pure-Python runtime probe (no native calls)
that classifies the host into one of:

    "coreml"   — macOS / arm64 with onnxruntime + CoreMLExecutionProvider
    "cuda"     — onnxruntime + CUDAExecutionProvider (Linux x86_64 GPU)
    "openblas" — Linux x86_64 with onnxruntime CPU EP (BLAS via OpenBLAS)
    "cpu"      — generic onnxruntime CPU EP fallback
    "unavailable" — onnxruntime not importable; enterprise extras absent

The classifier is advisory: it never mutates manifests, never feeds OPA,
and never imports the native analyzer extension. It exists so the
`--suggest` CLI path can print a single diagnostic line on startup so
users immediately see which accelerator the wheel they installed will
actually exercise — closing the gap between "wheel built with
``--features apple-silicon``" and "user can see Accelerate is in use".

The function imports `onnxruntime` lazily so that base-install users
(without ``hexr-sdk[enterprise]``) never pay an import cost.
"""

from __future__ import annotations

import platform
import sys
from typing import Literal

Backend = Literal["coreml", "cuda", "openblas", "cpu", "unavailable"]


def detect_backend() -> Backend:
    """Return the most-specific accelerator identifier available.

    Probe order is from most-specific (CoreML on Apple Silicon) to
    least-specific (generic CPU). The first match wins.

    Returns
    -------
    Backend
        One of ``"coreml" | "cuda" | "openblas" | "cpu" | "unavailable"``.
    """
    try:
        import onnxruntime as ort  # type: ignore[import-not-found]
    except ImportError:
        return "unavailable"

    try:
        providers = set(ort.get_available_providers())
    except Exception:  # pragma: no cover — onnxruntime API drift guard
        providers = set()

    machine = platform.machine().lower()
    is_darwin_arm64 = sys.platform == "darwin" and machine in {"arm64", "aarch64"}
    is_linux_x86_64 = sys.platform.startswith("linux") and machine in {"x86_64", "amd64"}

    if is_darwin_arm64 and "CoreMLExecutionProvider" in providers:
        return "coreml"
    if "CUDAExecutionProvider" in providers:
        return "cuda"
    if is_linux_x86_64 and "CPUExecutionProvider" in providers:
        # On Linux x86_64 our enterprise wheel is built with
        # `--features openblas`, so the CPU EP is the OpenBLAS-backed
        # path. We report "openblas" rather than "cpu" to make that
        # explicit in the startup diagnostic.
        return "openblas"
    if "CPUExecutionProvider" in providers:
        return "cpu"
    return "unavailable"


def describe(backend: Backend) -> str:
    """Human-readable one-liner for `--suggest` startup output."""
    return {
        "coreml":      "Apple CoreML (Accelerate BLAS, ANE-eligible)",
        "cuda":        "NVIDIA CUDA execution provider",
        "openblas":    "OpenBLAS CPU execution provider",
        "cpu":         "generic ONNX CPU execution provider",
        "unavailable": "onnxruntime not installed — `pip install 'hexr-sdk[enterprise]'`",
    }[backend]


__all__ = ["Backend", "detect_backend", "describe"]
