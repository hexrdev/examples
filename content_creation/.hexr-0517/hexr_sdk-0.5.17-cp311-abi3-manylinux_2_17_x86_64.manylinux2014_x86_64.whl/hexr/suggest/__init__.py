# hexr.suggest — runtime helpers for the L3 advisory suggest backend.
#
# The actual ColBERT/MaxSim suggest engine is native (Rust + ONNX) and
# lives in the `hexr-suggest` workspace crate. This Python package only
# carries small runtime utilities — chiefly `accel.detect_backend()`
# used by `hexr analyze --suggest` for a one-line startup diagnostic.
#
# Spec: HEXR_SDK_OVERHAUL_TECH_SPEC.md §21.5 PR-D7, §21.7, §21.7.1, §21.8.
