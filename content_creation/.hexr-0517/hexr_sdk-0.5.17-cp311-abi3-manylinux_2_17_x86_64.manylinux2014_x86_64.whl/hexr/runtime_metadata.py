"""
Runtime Metadata Generator for Enhanced Attestor
================================================

CRITICAL: This system has TWO distinct phases:

BUILD-TIME PHASE (hexr build):
- Static AST analysis only (capture_runtime=False)
- Discovers agent patterns without executing code
- Generates metadata templates for Enhanced Attestor

RUNTIME PHASE (actual agent execution):
- ContextVars track LIVE subprocess spawning
- Process hierarchy captured during real agent coordination
- Dynamic SPIFFE ID generation based on actual process relationships

WHY capture_runtime=False during build?
- Build happens in CLI async context (asyncio.run() conflict)
- No real agents running yet - just analyzing code structure
- ContextVars designed for LIVE process tracking, not static analysis

The contextvars system enables Enhanced Attestor to:
1. Track parent-child process relationships during agent execution
2. Generate SPIFFE IDs based on actual subprocess roles
3. Map agent roles to specific PIDs for security attestation
"""

import os
import json
import time
import psutil
from pathlib import Path
from typing import Dict, List, Optional, Any
from contextvars import ContextVar
from dataclasses import dataclass, asdict

from .context import HexrContext
from .enterprise_pid_mapper import get_enterprise_host_pid, get_secure_pid_mapping_info
from .utils.simple_logging import get_logger

logger = get_logger(__name__)

# Runtime context variables for process tracking
_orchestration_pattern: ContextVar[Optional[str]] = ContextVar(
    "orchestration_pattern", default="SINGLE"
)
_current_subprocess_role: ContextVar[Optional[str]] = ContextVar(
    "current_subprocess_role", default="main"
)
_subprocess_counter: ContextVar[int] = ContextVar("subprocess_counter", default=0)
_agentic_introspection: ContextVar[Optional[Dict[str, Any]]] = ContextVar(
    "agentic_introspection", default=None
)
_detected_worker_roles: ContextVar[List[str]] = ContextVar(
    "detected_worker_roles", default=[]
)


@dataclass
class RuntimeProcessContext:
    """Runtime process context for Enhanced Attestor metadata generation."""

    framework: str
    version: str = "1.0.0"
    agent_name: str = ""
    sub_agent: str = "main"
    tenant: str = ""
    process_id: int = 0
    parent_pid: int = 0
    timestamp: int = 0
    resources: List[str] = None
    regions: Dict[str, str] = None
    subprocess_support: bool = True
    spiffe_id_components: Dict[str, str] = None
    process_relationships: Dict[str, Any] = None
    enhanced_attestor_metadata: Dict[str, str] = None

    def __post_init__(self):
        if self.resources is None:
            self.resources = []
        if self.regions is None:
            self.regions = {}
        if self.spiffe_id_components is None:
            self.spiffe_id_components = {}
        if self.process_relationships is None:
            self.process_relationships = {}
        if self.enhanced_attestor_metadata is None:
            self.enhanced_attestor_metadata = {}


class RuntimeMetadataGenerator:
    """
    Generates runtime metadata for Enhanced Attestor using agentic pattern detection
    and ContextVar tracking. Pattern-based detection adapts to any agentic framework.
    """

    def __init__(self):
        self.context_dir = Path("/tmp/hexr-context")
        self.context_dir.mkdir(exist_ok=True)
        self.subprocess_registry = {}

    def initialize_agent_context(
        self,
        agent_name: str,
        tenant: str,
        resources: Optional[List[str]] = None,
        regions: Optional[Dict[str, str]] = None,
        source_file: Optional[Path] = None,
    ) -> None:
        """
        Initialize runtime context when @hexr_agent decorator is processed.
        At runtime, uses pre-built manifests from `hexr build` instead of re-analyzing source.
        """
        # Runtime should NEVER re-analyze - only during hexr build
        # Simple detection: /tmp/hexr-context exists = runtime (in container)
        is_runtime = Path("/tmp/hexr-context").exists()
        
        if is_runtime:
            logger.debug(f"Initializing runtime context for agent: {agent_name}")
        else:
            logger.info(f"Initializing BUILD context for agent: {agent_name}")

        # Framework is build-time-authoritative (recorded in BuildManifest.json
        # by the Rust analyzer). HEXR_FRAMEWORK is an optional runtime hint;
        # absence is fine for managed runtimes that don't round-trip env vars.
        orchestration_pattern = os.getenv("HEXR_FRAMEWORK") or "unknown"
        if orchestration_pattern != "unknown":
            logger.info(f"runtime_metadata: framework hint from HEXR_FRAMEWORK={orchestration_pattern}")
        introspection = None

        logger.debug(f"Orchestration pattern: {orchestration_pattern}")

        # Set ContextVars for runtime tracking
        _orchestration_pattern.set(orchestration_pattern)
        _current_subprocess_role.set("main")
        _subprocess_counter.set(0)
        if introspection:
            _agentic_introspection.set(introspection)
            _detected_worker_roles.set(introspection.get("detected_roles", []))

        # Initialize Hexr context
        HexrContext.set_agent_context(
            agent_name=agent_name,
            workload_id=f"{tenant}-{agent_name}",
            framework=orchestration_pattern,  # Use build-time framework value
            tenant=tenant,
            resources=resources or [],
            regions=regions or {},
            enable_subprocess_detection=True,
        )

        # PROACTIVE REGISTRATION: Register with auto-registrar BEFORE writing files
        # This creates SPIRE entry synchronously, ensuring hexr_tool() works immediately
        try:
            from .synchronous_registration import register_current_process

            logger.info(
                f"⏳ Registering process with auto-registrar (proactive registration)..."
            )
            result = register_current_process(
                tenant=tenant,
                framework=orchestration_pattern,  # Use build-time framework value
                agent_name=agent_name,
                sub_agent="main",
                process_role="main",
                resources=resources or [],
            )
            logger.info(
                f"✅ Synchronous registration complete - SPIRE identity ready"
            )
            logger.info(f"   Entry ID: {result.entry_id}")
            logger.info(f"   SPIFFE ID: {result.spiffe_id}")
        except Exception as e:
            logger.error(
                f"❌ Synchronous registration failed: {e} - hexr_tool() may not work immediately"
            )
            # Don't fail hard - allow file-based fallback
            logger.warning(
                "⚠️  Falling back to file-based registration (reactive mode)"
            )

        # DISABLED: process-context-*.json generation (using hexr-agent-*.json from PID mapper instead)
        # self._generate_process_context_file("main")

        # CRITICAL: Create marker file for K8s Job PID mapping
        self._create_agent_marker_file(agent_name)

        logger.info(
            f"Runtime context initialized for {agent_name} with pattern {orchestration_pattern}"
        )

    def track_subprocess_spawn(self, pid: int) -> str:
        """
        Track subprocess spawn and determine role using dynamic analysis.
        Called when framework spawns new processes (detected via process monitoring).
        """
        try:
            process = psutil.Process(pid)
            cmdline = process.cmdline()

            # Use dynamic role detection based on framework introspection
            role = self._determine_subprocess_role_dynamically(pid, cmdline)

            # Increment subprocess counter
            counter = _subprocess_counter.get() + 1
            _subprocess_counter.set(counter)

            # Register subprocess
            self.subprocess_registry[pid] = {
                "role": role,
                "cmdline": cmdline,
                "spawn_time": time.time(),
                "counter": counter,
            }

            # DISABLED: process-context-*.json generation (using hexr-agent-*.json from PID mapper instead)
            # self._generate_process_context_file(role, pid)

            logger.info(f"Tracked subprocess PID {pid} as role '{role}'")
            return role

        except Exception as e:
            logger.error(f"Failed to track subprocess {pid}: {e}")
            return "unknown"

    def _detect_pattern_from_runtime(self) -> str:
        """
        Detect orchestration pattern from current runtime environment when source file unavailable.
        Uses loaded modules and process inspection to infer pattern.
        """
        import sys

        # Check loaded modules for orchestration indicators
        loaded_modules = list(sys.modules.keys())

        # Count potential orchestration indicators
        orchestration_indicators = 0

        # Check for multi-agent frameworks
        if any(module in loaded_modules for module in ["crewai", "strands", "swarm"]):
            orchestration_indicators += 2

        # Check for parallel execution
        if any(
            module in loaded_modules
            for module in ["threading", "multiprocessing", "asyncio"]
        ):
            orchestration_indicators += 1

        # Check for tool/client libraries
        if any(
            module in loaded_modules
            for module in ["openai", "requests", "boto3", "google"]
        ):
            orchestration_indicators += 1

        # Determine pattern based on indicators
        if orchestration_indicators >= 3:
            return "ORCHESTRATOR_WORKERS"
        elif orchestration_indicators >= 2:
            return "CHAIN"
        elif orchestration_indicators >= 1:
            return "AUTONOMOUS"
        else:
            return "SINGLE"

    def _determine_subprocess_role_dynamically(
        self, pid: int, cmdline: List[str]
    ) -> str:
        """
        Determine subprocess role using agentic pattern introspection.
        Uses discovered worker roles and orchestration patterns.
        """
        orchestration_pattern = _orchestration_pattern.get()
        introspection = _agentic_introspection.get()
        worker_roles = _detected_worker_roles.get() or []

        if not orchestration_pattern or not introspection:
            return self._fallback_role_detection(cmdline)

        cmdline_str = " ".join(cmdline).lower()

        # Use orchestration pattern to determine role detection strategy
        if orchestration_pattern == "ORCHESTRATOR_WORKERS":
            return self._detect_worker_role(cmdline_str, worker_roles, introspection)
        elif orchestration_pattern == "PARALLEL":
            return self._detect_parallel_role(cmdline_str, introspection)
        elif orchestration_pattern == "CHAIN":
            return self._detect_chain_role(cmdline_str, introspection)
        elif orchestration_pattern == "AUTONOMOUS":
            return self._detect_autonomous_role(cmdline_str, introspection)
        else:
            return "worker"

    def _detect_worker_role(
        self, cmdline_str: str, worker_roles: List[str], introspection: Dict[str, Any]
    ) -> str:
        """Detect worker role in orchestrator-workers pattern."""
        # Try to match with discovered worker roles
        for role in worker_roles:
            if role.lower() in cmdline_str:
                return role

        # Check for delegation methods in subprocess
        for method in introspection.get("delegation_methods", []):
            if method.lower() in cmdline_str:
                counter = _subprocess_counter.get()
                return f"worker-{counter}"

        return "worker"

    def _detect_parallel_role(
        self, cmdline_str: str, introspection: Dict[str, Any]
    ) -> str:
        """Detect role in parallel execution pattern."""
        # Check for parallel indicators
        for indicator in introspection.get("parallel_indicators", []):
            if indicator.lower() in cmdline_str:
                if "thread" in indicator:
                    counter = _subprocess_counter.get()
                    return f"thread-{counter}"
                elif "process" in indicator:
                    counter = _subprocess_counter.get()
                    return f"process-{counter}"

        return "parallel-worker"

    def _detect_chain_role(
        self, cmdline_str: str, introspection: Dict[str, Any]
    ) -> str:
        """Detect role in chain execution pattern."""
        # Check for delegation methods indicating chain steps
        for method in introspection.get("delegation_methods", []):
            if method.lower() in cmdline_str:
                counter = _subprocess_counter.get()
                return f"chain-step-{counter}"

        return "chain-worker"

    def _detect_autonomous_role(
        self, cmdline_str: str, introspection: Dict[str, Any]
    ) -> str:
        """Detect role in autonomous agent pattern."""
        # Check for tool usage patterns
        for tool in introspection.get("tool_indicators", []):
            if tool.lower() in cmdline_str:
                return f"tool-{tool.replace('_', '-')}"

        return "autonomous-agent"

    def _fallback_role_detection(self, cmdline: List[str]) -> str:
        """
        Fallback role detection when no framework introspection available.
        """
        cmdline_str = " ".join(cmdline).lower()
        counter = _subprocess_counter.get()

        # Very basic role hints
        if "python" in cmdline_str and len(cmdline) > 1:
            script_name = Path(cmdline[-1]).stem.lower()
            if any(keyword in script_name for keyword in ["agent", "worker", "task"]):
                return f"{script_name}-{counter}"

        return f"subprocess-{counter}"

    def _generate_process_context_file(
        self, sub_agent: str, pid: Optional[int] = None
    ) -> None:
        """
        Generate process context file for Enhanced Attestor using current ContextVar state.

        CRITICAL ENTERPRISE SECURITY FIX:
        This method now uses enterprise host PID mapping to ensure SPIRE Enhanced Attestor
        can match process IDs between container and host namespaces. Without this mapping,
        container PIDs in JSON context files don't match host PIDs that SPIRE sees,
        breaking SPIFFE ID issuance for production Envoy/OPA integration.
        """
        current_context = HexrContext.get_current_context()
        # Use enterprise host PID mapping for SPIRE integration (with fallback)
        from .enterprise_pid_mapper import get_enterprise_host_pid

        try:
            current_pid = get_enterprise_host_pid()
            parent_pid = get_enterprise_host_pid()  # Simplified for development
        except Exception as e:
            logger.warning(
                f"Could not get enterprise host PID: {e}. Using fallback PIDs."
            )
            # Fallback for development mode
            current_pid = (pid or os.getpid()) + 1000
            parent_pid = os.getppid() + 1000

        # Build SPIFFE ID components
        orchestration_pattern = _orchestration_pattern.get() or "SINGLE"
        spiffe_components = {
            "trust_domain": "hexr.internal",
            "tenant_path": f"tenant/{current_context['tenant']}",
            "framework_path": orchestration_pattern.lower(),
            "agent_path": current_context["agent_name"],
            "sub_agent_path": sub_agent,
            "process_path": f"proc-{current_pid}",
            "full_spiffe_id": f"spiffe://hexr.internal/tenant/{current_context['tenant']}/{orchestration_pattern.lower()}/{current_context['agent_name']}/{sub_agent}/proc-{current_pid}",
        }

        # Build process relationships
        relationships = {
            "children": list(self.subprocess_registry.keys())
            if sub_agent == "main"
            else [],
            "depth": 0 if sub_agent == "main" else 1,
            "role_hierarchy": ["main", sub_agent] if sub_agent != "main" else ["main"],
        }

        # Enhanced Attestor metadata
        enhanced_metadata = {
            "container_id": os.environ.get("HOSTNAME", "unknown"),
            "pod_uid": os.environ.get("HEXR_POD_UID", "unknown"),
            "kubernetes_namespace": f"tenant-{current_context['tenant']}",
            "spire_agent_socket": "/tmp/spire-agent/public/api.sock",
        }

        # Create runtime process context
        runtime_context = RuntimeProcessContext(
            framework=orchestration_pattern.lower(),
            agent_name=current_context["agent_name"],
            sub_agent=sub_agent,
            tenant=current_context["tenant"],
            process_id=current_pid,
            parent_pid=parent_pid,
            timestamp=int(time.time()),
            resources=current_context["resources"],
            regions=current_context["regions"],
            spiffe_id_components=spiffe_components,
            process_relationships=relationships,
            enhanced_attestor_metadata=enhanced_metadata,
        )

        # Write context file
        context_file = self.context_dir / f"process-context-{current_pid}.json"
        with open(context_file, "w") as f:
            json.dump(asdict(runtime_context), f, indent=2)

        logger.info(f"Generated process context file: {context_file}")
        logger.debug(f"SPIFFE ID: {spiffe_components['full_spiffe_id']}")

    def _create_agent_marker_file(self, agent_name: str) -> None:
        """
        Create marker file for K8s Job PID mapping.
        This enables hexr deploy to map real PIDs to agents.
        """
        from .enterprise_pid_mapper import get_enterprise_host_pid

        # Get host PID for SPIRE compatibility (with fallback for development)
        try:
            host_pid = get_enterprise_host_pid()
        except Exception as e:
            logger.warning(
                f"Could not get enterprise host PID: {e}. Using fallback PID."
            )
            # Fallback for development mode - use container PID + offset
            host_pid = os.getpid() + 1000

        # Create marker directory
        marker_dir = Path("/tmp/hexr-context/agent-markers")
        marker_dir.mkdir(parents=True, exist_ok=True)

        # Create marker file following pattern from JSON templates
        marker_content = {
            "agent_name": agent_name,
            "pid": os.getpid(),  # Container PID
            "host_pid": host_pid,  # Host PID for SPIRE
            "timestamp": time.time(),
            "process_info": {
                "cmdline": " ".join(psutil.Process().cmdline()),
                "ppid": os.getppid(),
                "cwd": os.getcwd(),
            },
        }

        # Use same pattern as generated in JSON templates: {agent_name}-{pid}.marker
        marker_file = marker_dir / f"{agent_name}-{host_pid}.marker"

        try:
            with open(marker_file, "w") as f:
                json.dump(marker_content, f, indent=2)
            logger.info(f"Created agent marker file: {marker_file}")
        except Exception as e:
            logger.error(f"Failed to create marker file {marker_file}: {e}")

    def monitor_subprocess_activity(self) -> None:
        """
        Monitor for new subprocess spawns and track them.
        Called periodically during agent execution.
        """
        try:
            current_process = psutil.Process()
            children = current_process.children(recursive=True)

            for child in children:
                if child.pid not in self.subprocess_registry:
                    self.track_subprocess_spawn(child.pid)

        except Exception as e:
            logger.error(f"Error monitoring subprocess activity: {e}")

    def cleanup_context_files(self) -> None:
        """
        DISABLED: No longer generating process-context-*.json files.
        Using hexr-agent-*.json from PID mapper instead (schema v1.1 compliant).
        """
        # No cleanup needed - process-context-*.json generation disabled
        pass


# Global runtime metadata generator instance
_runtime_generator = None


def get_runtime_generator() -> RuntimeMetadataGenerator:
    """Get or create the global runtime metadata generator."""
    global _runtime_generator
    if _runtime_generator is None:
        _runtime_generator = RuntimeMetadataGenerator()
    return _runtime_generator


def initialize_runtime_context(
    agent_name: str,
    tenant: str,
    resources: Optional[List[str]] = None,
    regions: Optional[Dict[str, str]] = None,
    source_file: Optional[Path] = None,
) -> None:
    """
    Initialize runtime context for Enhanced Attestor metadata generation.
    Called by @hexr_agent decorator.
    """
    generator = get_runtime_generator()
    generator.initialize_agent_context(
        agent_name, tenant, resources, regions, source_file
    )


def track_subprocess(pid: int) -> str:
    """
    Track a new subprocess spawn.
    Returns the detected role for the subprocess.
    """
    generator = get_runtime_generator()
    return generator.track_subprocess_spawn(pid)


def start_subprocess_monitoring() -> None:
    """
    Start monitoring for subprocess spawns.
    Should be called in a background thread during agent execution.
    """
    import threading
    import time

    def monitor_loop():
        generator = get_runtime_generator()
        while True:
            generator.monitor_subprocess_activity()
            time.sleep(1)  # Check every second

    monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
    monitor_thread.start()


def cleanup_runtime_context() -> None:
    """
    Clean up runtime context and files.
    Called when agent execution completes.
    """
    generator = get_runtime_generator()
    generator.cleanup_context_files()
