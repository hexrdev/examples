"""
Hexr Vault Decorators - Declarative secret injection.

Provides decorators for automatic secret injection into functions and classes.
"""

import functools
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union

from .client import VaultClient, get_client, SecretNotFoundError

F = TypeVar("F", bound=Callable[..., Any])


def secret(
    path: str,
    required: bool = True,
    default: Optional[str] = None,
    as_json: bool = False,
) -> Callable[[F], F]:
    """
    Decorator that injects a secret value as the function's return value.
    
    The decorated function becomes a getter that returns the secret value.
    
    Args:
        path: Secret path in vault.
        required: If True, raises error when secret not found.
        default: Default value if secret not found and not required.
        as_json: Parse secret value as JSON.
    
    Example:
        @secret("api-keys/openai")
        def openai_key():
            pass
        
        # Later in code:
        key = openai_key()  # Returns the secret value
        
        # With default:
        @secret("optional/key", required=False, default="fallback")
        def optional_key():
            pass
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_client()
            try:
                value = client.get(path)
                if as_json:
                    import json
                    return json.loads(value)
                return value
            except SecretNotFoundError:
                if required:
                    raise
                return default
        return wrapper  # type: ignore
    return decorator


def secrets_batch(*paths: str) -> Callable[[F], F]:
    """
    Decorator that injects multiple secrets as keyword arguments.
    
    Secret paths are converted to argument names by replacing "/" and "-" with "_".
    
    Args:
        *paths: Secret paths to inject.
    
    Example:
        @secrets_batch("db/host", "db/password", "api-keys/stripe")
        def configure(db_host: str, db_password: str, api_keys_stripe: str):
            # All secrets are automatically injected
            pass
        
        configure()  # Secrets are fetched and passed as kwargs
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_client()
            
            # Fetch all secrets
            secret_kwargs = {}
            for path in paths:
                # Convert path to valid Python identifier
                arg_name = path.replace("/", "_").replace("-", "_")
                try:
                    secret_kwargs[arg_name] = client.get(path)
                except SecretNotFoundError:
                    raise ValueError(f"Required secret not found: {path}")
            
            # Merge with provided kwargs (provided kwargs override secrets)
            merged_kwargs = {**secret_kwargs, **kwargs}
            return func(*args, **merged_kwargs)
        return wrapper  # type: ignore
    return decorator


class SecretProperty:
    """
    Descriptor for lazy secret loading on class attributes.
    
    Example:
        class Config:
            api_key = SecretProperty("api-keys/openai")
            db_password = SecretProperty("db/password")
        
        config = Config()
        print(config.api_key)  # Fetches from vault on first access
    """
    
    def __init__(
        self,
        path: str,
        required: bool = True,
        default: Optional[str] = None,
        cache: bool = True,
    ):
        self.path = path
        self.required = required
        self.default = default
        self.cache = cache
        self._cached_value: Optional[str] = None
        self._cache_set = False
    
    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name
    
    def __get__(self, obj: Any, objtype: type = None) -> Optional[str]:
        if obj is None:
            return self  # type: ignore
        
        if self.cache and self._cache_set:
            return self._cached_value
        
        client = get_client()
        try:
            value = client.get(self.path)
            if self.cache:
                self._cached_value = value
                self._cache_set = True
            return value
        except SecretNotFoundError:
            if self.required:
                raise
            return self.default
    
    def __set__(self, obj: Any, value: str) -> None:
        # Allow setting to update the vault
        client = get_client()
        client.put(self.path, value)
        if self.cache:
            self._cached_value = value
            self._cache_set = True
    
    def invalidate_cache(self) -> None:
        """Clear the cached value."""
        self._cached_value = None
        self._cache_set = False


def inject_secrets(**secret_map: str) -> Callable[[F], F]:
    """
    Decorator for explicit secret-to-argument mapping.
    
    Args:
        **secret_map: Mapping of argument names to secret paths.
    
    Example:
        @inject_secrets(
            openai_key="api-keys/openai",
            db_conn="database/connection-string"
        )
        def process(openai_key: str, db_conn: str, other_arg: str):
            # openai_key and db_conn are automatically injected
            pass
        
        process(other_arg="value")  # Only need to provide non-secret args
    """
    def decorator(func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            client = get_client()
            
            # Fetch mapped secrets
            for arg_name, secret_path in secret_map.items():
                if arg_name not in kwargs:  # Don't override provided values
                    kwargs[arg_name] = client.get(secret_path)
            
            return func(*args, **kwargs)
        return wrapper  # type: ignore
    return decorator


def with_vault(func: F) -> F:
    """
    Decorator that injects a VaultClient instance as the first argument.
    
    Example:
        @with_vault
        def store_credentials(vault: VaultClient, credentials: dict):
            vault.put_json("creds", credentials)
        
        store_credentials({"user": "admin", "pass": "secret"})
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs) -> Any:
        client = get_client()
        return func(client, *args, **kwargs)
    return wrapper  # type: ignore
