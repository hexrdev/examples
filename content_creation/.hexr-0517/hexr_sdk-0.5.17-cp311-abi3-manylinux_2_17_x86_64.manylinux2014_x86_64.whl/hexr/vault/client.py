"""
Hexr Vault Client - SPIFFE-native secrets management.

Provides secure secret storage and retrieval with automatic tenant isolation
and SPIFFE authentication.
"""

import json
import os
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin
import httpx
from dataclasses import dataclass


class VaultError(Exception):
    """Base exception for Vault operations."""
    pass


class SecretNotFoundError(VaultError):
    """Secret does not exist."""
    pass


class AuthenticationError(VaultError):
    """SPIFFE authentication failed."""
    pass


class PolicyDeniedError(VaultError):
    """OPA policy denied access."""
    pass


@dataclass
class Secret:
    """A retrieved secret with metadata."""
    path: str
    value: str
    version: int


class VaultClient:
    """
    SPIFFE-authenticated secrets management client.
    
    Features:
    - Automatic SPIFFE identity authentication
    - Tenant isolation (secrets are automatically namespaced)
    - Transparent encryption
    - OPA policy enforcement support
    
    Args:
        base_url: Vault service URL. Defaults to in-cluster service.
        tenant: Override tenant ID. If not provided, extracted from SPIFFE ID.
        timeout: Request timeout in seconds.
        verify_ssl: Enable SSL verification.
    
    Example:
        vault = VaultClient()
        vault.put("db/password", "secret123")
        password = vault.get("db/password")
    """
    
    DEFAULT_URL = "http://hexr-vault.hexr-system.svc.cluster.local:8091"
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        tenant: Optional[str] = None,
        timeout: float = 30.0,
        verify_ssl: bool = True,
    ):
        self.base_url = base_url or os.getenv("HEXR_VAULT_URL", self.DEFAULT_URL)
        self.timeout = timeout
        self.verify_ssl = verify_ssl
        
        # Get tenant from environment or SPIFFE
        self._tenant = tenant or os.getenv("HEXR_TENANT")
        
        # Build authentication headers
        self._headers = self._build_auth_headers()
        
        # HTTP client
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            verify=verify_ssl,
            headers=self._headers,
        )
    
    def _build_auth_headers(self) -> Dict[str, str]:
        """Build authentication headers from SPIFFE identity or environment."""
        headers = {"Content-Type": "application/json"}
        
        # Try to get SPIFFE ID from SPIRE workload API
        spiffe_id = os.getenv("SPIFFE_ID")
        if spiffe_id:
            headers["X-SPIFFE-ID"] = spiffe_id
        
        # Fallback: tenant header for dev mode
        if self._tenant:
            headers["X-Hexr-Tenant"] = self._tenant
        
        # Agent name if available
        agent_name = os.getenv("HEXR_AGENT_NAME")
        if agent_name:
            headers["X-Hexr-Agent"] = agent_name
            
        return headers
    
    @property
    def tenant(self) -> Optional[str]:
        """Current tenant ID."""
        return self._tenant
    
    def get(self, path: str) -> str:
        """
        Retrieve a secret value.
        
        Args:
            path: Secret path (e.g., "db/password", "api-keys/openai")
        
        Returns:
            The secret value as a string.
        
        Raises:
            SecretNotFoundError: Secret doesn't exist.
            PolicyDeniedError: OPA policy denied access.
            VaultError: Other errors.
        
        Example:
            password = vault.get("database/password")
        """
        try:
            response = self._client.get(f"/v1/secrets/{path}")
            
            if response.status_code == 404:
                raise SecretNotFoundError(f"Secret not found: {path}")
            elif response.status_code == 403:
                raise PolicyDeniedError(f"Access denied to secret: {path}")
            elif response.status_code == 401:
                raise AuthenticationError("SPIFFE authentication required")
            
            response.raise_for_status()
            data = response.json()
            return data["value"]
            
        except httpx.HTTPStatusError as e:
            raise VaultError(f"Failed to get secret: {e}") from e
        except httpx.RequestError as e:
            raise VaultError(f"Connection error: {e}") from e
    
    def get_secret(self, path: str) -> Secret:
        """
        Retrieve a secret with full metadata.
        
        Args:
            path: Secret path.
        
        Returns:
            Secret object with value, path, and version.
        """
        try:
            response = self._client.get(f"/v1/secrets/{path}")
            
            if response.status_code == 404:
                raise SecretNotFoundError(f"Secret not found: {path}")
            elif response.status_code == 403:
                raise PolicyDeniedError(f"Access denied to secret: {path}")
                
            response.raise_for_status()
            data = response.json()
            
            return Secret(
                path=data["path"],
                value=data["value"],
                version=data["version"],
            )
            
        except httpx.HTTPStatusError as e:
            raise VaultError(f"Failed to get secret: {e}") from e
    
    def put(
        self,
        path: str,
        value: str,
        metadata: Optional[Dict[str, str]] = None,
    ) -> int:
        """
        Store a secret.
        
        Args:
            path: Secret path.
            value: Secret value.
            metadata: Optional metadata key-value pairs.
        
        Returns:
            Version number of the stored secret.
        
        Raises:
            PolicyDeniedError: OPA policy denied write access.
            VaultError: Storage failed.
        
        Example:
            version = vault.put("api-keys/stripe", "sk_live_...")
        """
        payload = {"value": value}
        if metadata:
            payload["metadata"] = metadata
            
        try:
            response = self._client.put(
                f"/v1/secrets/{path}",
                json=payload,
            )
            
            if response.status_code == 403:
                raise PolicyDeniedError(f"Write access denied: {path}")
            elif response.status_code == 401:
                raise AuthenticationError("SPIFFE authentication required")
                
            response.raise_for_status()
            data = response.json()
            return data["version"]
            
        except httpx.HTTPStatusError as e:
            raise VaultError(f"Failed to store secret: {e}") from e
    
    def delete(self, path: str) -> None:
        """
        Delete a secret.
        
        Args:
            path: Secret path to delete.
        
        Raises:
            SecretNotFoundError: Secret doesn't exist.
            PolicyDeniedError: Delete access denied.
        """
        try:
            response = self._client.delete(f"/v1/secrets/{path}")
            
            if response.status_code == 404:
                raise SecretNotFoundError(f"Secret not found: {path}")
            elif response.status_code == 403:
                raise PolicyDeniedError(f"Delete access denied: {path}")
                
            response.raise_for_status()
            
        except httpx.HTTPStatusError as e:
            raise VaultError(f"Failed to delete secret: {e}") from e
    
    def list(self, prefix: str = "") -> List[str]:
        """
        List secret paths.
        
        Args:
            prefix: Optional path prefix filter.
        
        Returns:
            List of secret paths.
        
        Example:
            paths = vault.list("api-keys/")
        """
        try:
            params = {}
            if prefix:
                params["prefix"] = prefix
                
            response = self._client.get("/v1/secrets", params=params)
            response.raise_for_status()
            
            data = response.json()
            return data.get("paths", [])
            
        except httpx.HTTPStatusError as e:
            raise VaultError(f"Failed to list secrets: {e}") from e
    
    def exists(self, path: str) -> bool:
        """Check if a secret exists."""
        try:
            self.get(path)
            return True
        except SecretNotFoundError:
            return False
    
    def get_or_default(self, path: str, default: str) -> str:
        """Get a secret or return a default value if not found."""
        try:
            return self.get(path)
        except SecretNotFoundError:
            return default
    
    def get_json(self, path: str) -> Any:
        """Get a secret and parse it as JSON."""
        value = self.get(path)
        return json.loads(value)
    
    def put_json(self, path: str, value: Any) -> int:
        """Store a value as JSON."""
        return self.put(path, json.dumps(value))
    
    def health(self) -> Dict[str, str]:
        """Check vault service health."""
        try:
            response = self._client.get("/health")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {"status": "unhealthy", "error": str(e)}
    
    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()
    
    def __enter__(self) -> "VaultClient":
        return self
    
    def __exit__(self, *args) -> None:
        self.close()


# Global client singleton
_global_client: Optional[VaultClient] = None


def get_client() -> VaultClient:
    """Get or create the global vault client."""
    global _global_client
    if _global_client is None:
        _global_client = VaultClient()
    return _global_client


def get(path: str) -> str:
    """Convenience function to get a secret using the global client."""
    return get_client().get(path)


def put(path: str, value: str) -> int:
    """Convenience function to put a secret using the global client."""
    return get_client().put(path, value)


def delete(path: str) -> None:
    """Convenience function to delete a secret using the global client."""
    return get_client().delete(path)


def list_secrets(prefix: str = "") -> List[str]:
    """Convenience function to list secrets using the global client."""
    return get_client().list(prefix)
