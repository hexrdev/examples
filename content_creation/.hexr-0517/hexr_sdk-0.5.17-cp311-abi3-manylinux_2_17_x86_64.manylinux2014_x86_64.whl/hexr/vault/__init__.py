"""
Hexr Vault - SPIFFE-native secrets management client.

This module provides programmatic access to the Hexr Vault service for secure
secrets management with automatic SPIFFE identity authentication.

Example usage:
    from hexr.vault import VaultClient

    # Automatic SPIFFE authentication
    vault = VaultClient()
    
    # Store a secret
    vault.put("api-keys/openai", "sk-...")
    
    # Retrieve a secret
    api_key = vault.get("api-keys/openai")
    
    # Use the @secret decorator
    from hexr.vault import secret
    
    @secret("api-keys/openai")
    def my_api_key():
        pass  # Returns the secret value when called
"""

from .client import VaultClient, VaultError, SecretNotFoundError
from .decorators import secret, secrets_batch

__all__ = [
    "VaultClient",
    "VaultError",
    "SecretNotFoundError",
    "secret",
    "secrets_batch",
]
