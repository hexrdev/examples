"""
Enhanced Multi-Agentic Framework Integration for Sub-Agent Context Propagation.

This module solves the critical gap where ContextVars don't propagate to
framework-spawned subprocesses (CrewAI agents, LangChain executors, etc.).

Without monkey patching, we use:
1. Process environment variables for context inheritance
2. Shared memory/filesystem for inter-process communication
3. Pattern-based subprocess detection (uses AgenticPatternDetector)
4. Per-subprocess JSON context file generation
"""

import os
import json
import time
import multiprocessing
from pathlib import Path
from typing import Dict, List, Optional, Any
from contextvars import ContextVar

from .context import HexrContext
from .runtime_metadata import _orchestration_pattern, _detected_worker_roles
from .utils.simple_logging import get_logger

logger = get_logger(__name__)


class FrameworkSubprocessContext:
    """
    Handles context propagation to framework-spawned subprocesses without monkey patching.

    Key Challenge: CrewAI/LangChain spawn processes that don't inherit ContextVars
    Solution: Environment variables + shared filesystem for context inheritance
    """

    @staticmethod
    def prepare_subprocess_environment() -> Dict[str, str]:
        """
        Prepare environment variables for subprocess context inheritance.
        Called before framework spawns sub-agents.
        """
        current_context = HexrContext.get_current_context()

        env_vars = {
            "HEXR_PARENT_TENANT": current_context["tenant"],
            "HEXR_PARENT_FRAMEWORK": current_context["framework"],
            "HEXR_PARENT_AGENT": current_context["agent_name"],
            "HEXR_PARENT_RESOURCES": json.dumps(current_context["resources"]),
            "HEXR_PARENT_REGIONS": json.dumps(current_context["regions"]),
            "HEXR_SUBPROCESS_SUPPORT": "true",
            "HEXR_CONTEXT_DIR": "/tmp/hexr-context",
        }

        logger.info(
            f"Prepared subprocess environment for {current_context['agent_name']}"
        )
        return env_vars

    @staticmethod
    def detect_subprocess_role(pid: int) -> Optional[str]:
        """
        Detect the role of a subprocess using pattern-based detection.
        Uses AgenticPatternDetector instead of hardcoded framework rules.
        """
        try:
            import psutil

            process = psutil.Process(pid)
            cmdline = process.cmdline()
        except:
            return None

        if not cmdline:
            return None

        cmdline_str = " ".join(cmdline).lower()

        # First check if we have detected worker roles from pattern analysis
        detected_roles = _detected_worker_roles.get([])
        orchestration_pattern = _orchestration_pattern.get("UNKNOWN")

        # For ORCHESTRATOR_WORKERS pattern, match subprocess to detected roles
        if orchestration_pattern == "ORCHESTRATOR_WORKERS" and detected_roles:
            for role in detected_roles:
                if role.lower() in cmdline_str:
                    logger.info(
                        f"Detected {role} subprocess from pattern analysis: PID {pid}"
                    )
                    return role

        # Fall back to generic role detection based on common patterns
        if any(
            pattern in cmdline_str
            for pattern in [
                "researcher",
                "analyst",
                "writer",
                "reviewer",
                "planner",
                "coordinator",
                "evaluator",
                "summarizer",
                "strategist",
            ]
        ):
            for role in [
                "researcher",
                "analyst",
                "writer",
                "reviewer",
                "planner",
                "strategist",
            ]:
                if role in cmdline_str:
                    logger.info(
                        f"Detected {role} subprocess from pattern matching: PID {pid}"
                    )
                    return role

        # Chain/executor patterns for PARALLEL/CHAIN orchestration
        elif any(
            pattern in cmdline_str
            for pattern in ["chain", "executor", "retriever", "pipeline"]
        ):
            if "retrieval" in cmdline_str or "retriever" in cmdline_str:
                return "retriever"
            elif "executor" in cmdline_str:
                return "executor"
            elif "chain" in cmdline_str:
                return "chain"
            elif "pipeline" in cmdline_str:
                return "pipeline"
            else:
                return "worker"

        # Conversational patterns for AUTONOMOUS agents
        elif any(
            pattern in cmdline_str
            for pattern in ["conversation", "assistant", "user_proxy", "group_chat"]
        ):
            if "assistant" in cmdline_str:
                return "assistant"
            elif "user_proxy" in cmdline_str:
                return "user_proxy"
            else:
                return "conversational"

        return None

    @staticmethod
    def create_subprocess_context_file(pid: int, role: str, parent_pid: int) -> bool:
        """
        Create individual JSON context file for framework subprocess.
        Enhanced Attestor reads these files to generate granular SPIFFE IDs.
        """
        try:
            # Read shared process tree to get parent context
            process_tree_file = (
                Path("/tmp/hexr-context") / "hexr-process-relationships.json"
            )

            if process_tree_file.exists():
                with open(process_tree_file) as f:
                    process_tree = json.load(f)

                # Find parent context in process tree
                parent_context = None
                if str(parent_pid) in process_tree.get("processes", {}):
                    parent_context = process_tree["processes"][str(parent_pid)]
                elif process_tree.get("root_process"):
                    parent_context = process_tree["root_process"]
                else:
                    # Fallback to environment variables
                    parent_context = {
                        "tenant": os.getenv("HEXR_PARENT_TENANT", "default"),
                        "framework": os.getenv("HEXR_PARENT_FRAMEWORK", "custom"),
                        "agent_name": os.getenv("HEXR_PARENT_AGENT", "unnamed"),
                        "resources": json.loads(
                            os.getenv("HEXR_PARENT_RESOURCES", "[]")
                        ),
                        "regions": json.loads(os.getenv("HEXR_PARENT_REGIONS", "{}")),
                    }
            else:
                # Fallback to environment variables
                parent_context = {
                    "tenant": os.getenv("HEXR_PARENT_TENANT", "default"),
                    "framework": os.getenv("HEXR_PARENT_FRAMEWORK", "custom"),
                    "agent_name": os.getenv("HEXR_PARENT_AGENT", "unnamed"),
                    "resources": json.loads(os.getenv("HEXR_PARENT_RESOURCES", "[]")),
                    "regions": json.loads(os.getenv("HEXR_PARENT_REGIONS", "{}")),
                }  # Create subprocess-specific context per FINAL CONTRACT
            subprocess_context = {
                "framework": parent_context["framework"],
                "version": "1.0.0",
                "agent_name": parent_context["agent_name"],
                "sub_agent": role,
                "tenant": parent_context["tenant"],
                "process_id": pid,
                "parent_pid": parent_pid,
                "timestamp": int(time.time()),
                "resources": parent_context["resources"],
                "regions": parent_context["regions"],
                "subprocess_support": True,
                # SPIFFE ID components for Enhanced Attestor
                "spiffe_id_components": {
                    "trust_domain": "hexr.internal",
                    "tenant_path": f"tenant/{parent_context['tenant']}",
                    "framework_path": parent_context["framework"],
                    "agent_path": parent_context["agent_name"],
                    "sub_agent_path": role,
                    "process_path": f"proc-{pid}",
                    "full_spiffe_id": f"spiffe://hexr.internal/tenant/{parent_context['tenant']}/{parent_context['framework']}/{parent_context['agent_name']}/{role}/proc-{pid}",
                },
                # Process relationships for hierarchy tracking
                "process_relationships": {
                    "children": [],  # Will be updated as subprocess spawns children
                    "depth": 1,  # Subprocess = depth 1, root = depth 0
                    "role_hierarchy": ["orchestrator", role],
                },
                # Enhanced Attestor metadata
                "enhanced_attestor_metadata": {
                    "container_id": os.getenv("HOSTNAME", "unknown"),
                    "pod_uid": os.getenv("KUBERNETES_POD_UID", "pod-unknown"),
                    "kubernetes_namespace": os.getenv(
                        "KUBERNETES_NAMESPACE", f"tenant-{parent_context['tenant']}"
                    ),
                    "spire_agent_socket": "/tmp/spire-agent/public/api.sock",
                },
            }

            # Write subprocess context file
            context_dir = Path("/tmp/hexr-context")
            context_dir.mkdir(exist_ok=True, mode=0o755)

            context_file = context_dir / f"hexr-subprocess-{pid}.json"
            with open(context_file, "w") as f:
                json.dump(subprocess_context, f, indent=2)

            logger.info(f"Created subprocess context: {role} (PID {pid})")
            return True

        except Exception as e:
            logger.error(f"Failed to create subprocess context for PID {pid}: {e}")
            return False


class EnhancedMultiProcessMonitor:
    """
    Enhanced process monitor that handles framework-spawned subprocesses.
    Integrates with existing ProcessTreeManager for comprehensive coverage.
    """

    def __init__(self, root_pid: int):
        self.root_pid = root_pid
        self.detected_subprocesses = set()
        self._setup_process_relationships_file()

    def _setup_process_relationships_file(self):
        """Initialize shared process relationships file."""
        context_dir = Path("/tmp/hexr-context")
        context_dir.mkdir(exist_ok=True, mode=0o755)

        relationships_file = context_dir / "hexr-process-relationships.json"

        if not relationships_file.exists():
            initial_data = {
                "version": "1.0.0",
                "timestamp": int(time.time()),
                "root_pid": self.root_pid,
                "processes": {
                    str(self.root_pid): {
                        "role": "orchestrator",
                        "parent_pid": None,
                        "children": [],
                        "framework": os.getenv("HEXR_PARENT_FRAMEWORK", "custom"),
                        "agent_name": os.getenv("HEXR_PARENT_AGENT", "unnamed"),
                        "tenant": os.getenv("HEXR_PARENT_TENANT", "default"),
                    }
                },
            }

            with open(relationships_file, "w") as f:
                json.dump(initial_data, f, indent=2)

    def _update_process_relationships(self, pid: int, parent_pid: int, role: str):
        """Update shared process relationships with new subprocess."""
        relationships_file = (
            Path("/tmp/hexr-context") / "hexr-process-relationships.json"
        )

        try:
            with open(relationships_file, "r") as f:
                data = json.load(f)

            # Add new process
            data["processes"][str(pid)] = {
                "role": role,
                "parent_pid": parent_pid,
                "children": [],
                "framework": data["processes"]
                .get(str(parent_pid), {})
                .get("framework", "custom"),
                "agent_name": data["processes"]
                .get(str(parent_pid), {})
                .get("agent_name", "unnamed"),
                "tenant": data["processes"]
                .get(str(parent_pid), {})
                .get("tenant", "default"),
            }

            # Update parent's children list
            if str(parent_pid) in data["processes"]:
                if pid not in data["processes"][str(parent_pid)]["children"]:
                    data["processes"][str(parent_pid)]["children"].append(pid)

            # Update timestamp
            data["timestamp"] = int(time.time())

            with open(relationships_file, "w") as f:
                json.dump(data, f, indent=2)

        except Exception as e:
            logger.error(f"Failed to update process relationships: {e}")

    def monitor_framework_subprocesses(self) -> None:
        """
        Monitor for framework-spawned subprocesses and create context files.
        Extends existing subprocess detection with framework-aware patterns.
        """
        import psutil
        import time

        try:
            root_process = psutil.Process(self.root_pid)

            while True:
                # Get all child processes (CrewAI agents, LangChain executors, etc.)
                all_children = root_process.children(recursive=True)

                for child in all_children:
                    if child.pid not in self.detected_subprocesses:
                        # New subprocess detected
                        role = FrameworkSubprocessContext.detect_subprocess_role(
                            child.pid
                        )

                        if role:
                            # Create context file for Enhanced Attestor
                            success = FrameworkSubprocessContext.create_subprocess_context_file(
                                child.pid, role, child.ppid()
                            )

                            if success:
                                self.detected_subprocesses.add(child.pid)

                                # Update shared process relationships
                                self._update_process_relationships(
                                    child.pid, child.ppid(), role
                                )

                                logger.info(
                                    f"Registered framework subprocess: {role} (PID {child.pid})"
                                )

                time.sleep(0.5)  # Framework subprocess detection interval

        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            logger.debug(f"Framework subprocess monitoring stopped: {e}")


# Integration hook for @hexr_agent decorator
def enable_framework_subprocess_detection():
    """
    Enable framework-aware subprocess context propagation.
    Called by @hexr_agent decorator when subprocess_support=True.
    """
    # Prepare environment for subprocess inheritance
    env_vars = FrameworkSubprocessContext.prepare_subprocess_environment()

    # Update current process environment
    os.environ.update(env_vars)

    # Start enhanced monitoring
    monitor = EnhancedMultiProcessMonitor(os.getpid())

    # Run monitor in background thread
    import threading

    monitor_thread = threading.Thread(
        target=monitor.monitor_framework_subprocesses,
        daemon=True,
        name="hexr-framework-subprocess-monitor",
    )
    monitor_thread.start()

    logger.info("Enabled framework subprocess detection for multi-agentic patterns")

    return monitor
