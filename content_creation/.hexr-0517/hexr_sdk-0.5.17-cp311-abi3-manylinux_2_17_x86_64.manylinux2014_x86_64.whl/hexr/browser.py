"""
Hexr Browser Client — hardware-isolated headless browser via SmolVM microVMs.

Provides ``hexr.browse()`` for running headless Chromium in a fresh Firecracker
microVM.  Each session boots a new VM with Chromium + Playwright, executes
browser actions, captures screenshots/text, and destroys the VM.

Environment variables:
    HEXR_SANDBOX_URL        Override the service URL (default: in-cluster discovery)
    HEXR_SANDBOX_ENABLED    Explicit enable/disable ("true"/"false")
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://hexr-sandbox.hexr-system.svc.cluster.local:8092"
_TIMEOUT = 120.0  # browser sessions can be slow


# ── Data types ───────────────────────────────────────────────────────────────

@dataclass
class BrowseAction:
    """A single browser action to execute."""

    type: str  # navigate, click, type, screenshot, extract_text, wait, scroll
    selector: str | None = None
    value: str | None = None
    timeout: int | None = None


@dataclass
class BrowseResult:
    """Result of a browser session."""

    url: str
    title: str
    text: str
    screenshot: str  # base64 PNG
    action_results: list[dict[str, Any]] = field(default_factory=list)
    duration_ms: float = 0.0


# ── Configuration ────────────────────────────────────────────────────────────

def _get_url() -> str | None:
    url = os.getenv("HEXR_SANDBOX_URL")
    if url:
        return url.rstrip("/")
    if os.getenv("KUBERNETES_SERVICE_HOST"):
        return _DEFAULT_URL
    return None


def is_enabled() -> bool:
    explicit = os.getenv("HEXR_SANDBOX_ENABLED")
    if explicit is not None:
        return explicit.lower() in ("1", "true", "yes")
    return _get_url() is not None


# ── Sync API ─────────────────────────────────────────────────────────────────

def browse(
    url: str,
    *,
    actions: list[dict[str, Any]] | None = None,
    timeout: int = 60,
    viewport_width: int = 1280,
    viewport_height: int = 720,
) -> BrowseResult:
    """Browse a URL in a hardware-isolated microVM with headless Chromium.

    Args:
        url: The URL to navigate to.
        actions: Optional list of browser actions to execute after navigation.
            Each action is a dict with ``type`` and optional ``selector``,
            ``value``, ``timeout`` keys.  Supported types: ``navigate``,
            ``click``, ``type``, ``screenshot``, ``extract_text``, ``wait``,
            ``scroll``.
        timeout: Maximum session time in seconds.
        viewport_width: Browser viewport width in pixels.
        viewport_height: Browser viewport height in pixels.

    Returns:
        :class:`BrowseResult` with screenshot, text, title, and action results.

    Raises:
        RuntimeError: If sandbox service is unavailable.
    """
    service_url = _get_url()
    if service_url is None:
        raise RuntimeError(
            "Hexr Sandbox not available. Set HEXR_SANDBOX_URL or run in-cluster."
        )
    payload: dict[str, Any] = {
        "url": url,
        "timeout": timeout,
        "viewport_width": viewport_width,
        "viewport_height": viewport_height,
    }
    if actions:
        payload["actions"] = actions

    resp = httpx.post(
        f"{service_url}/browse",
        json=payload,
        timeout=max(_TIMEOUT, timeout + 30),
    )
    resp.raise_for_status()
    data = resp.json()
    return BrowseResult(
        url=data.get("url", url),
        title=data.get("title", ""),
        text=data.get("text", ""),
        screenshot=data.get("screenshot", ""),
        action_results=data.get("action_results", []),
        duration_ms=data.get("duration_ms", 0.0),
    )


# ── Async API ────────────────────────────────────────────────────────────────

async def browse_async(
    url: str,
    *,
    actions: list[dict[str, Any]] | None = None,
    timeout: int = 60,
    viewport_width: int = 1280,
    viewport_height: int = 720,
) -> BrowseResult:
    """Async version of :func:`browse`."""
    service_url = _get_url()
    if service_url is None:
        raise RuntimeError(
            "Hexr Sandbox not available. Set HEXR_SANDBOX_URL or run in-cluster."
        )
    payload: dict[str, Any] = {
        "url": url,
        "timeout": timeout,
        "viewport_width": viewport_width,
        "viewport_height": viewport_height,
    }
    if actions:
        payload["actions"] = actions

    async with httpx.AsyncClient(timeout=max(_TIMEOUT, timeout + 30)) as client:
        resp = await client.post(f"{service_url}/browse", json=payload)
        resp.raise_for_status()
        data = resp.json()
    return BrowseResult(
        url=data.get("url", url),
        title=data.get("title", ""),
        text=data.get("text", ""),
        screenshot=data.get("screenshot", ""),
        action_results=data.get("action_results", []),
        duration_ms=data.get("duration_ms", 0.0),
    )
