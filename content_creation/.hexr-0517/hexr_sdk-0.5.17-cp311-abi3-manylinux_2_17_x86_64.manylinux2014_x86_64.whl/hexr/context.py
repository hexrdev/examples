"""
Hexr Context Management System with Hierarchical Process Trees.

This module provides production-ready process tree management:
- Hierarchical process context with proper parent-child relationships
- Framework-agnostic subprocess detection without monkey patching
- Single process tree context file for Enhanced Attestor integration
- SPIFFE ID inheritance through process hierarchy
"""

import json
import os
import time
from contextvars import ContextVar, copy_context
from pathlib import Path
from typing import Any, Dict, List, Optional

import logging
import sys
import os

# Simple logging without complex imports
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ProcessContextError(Exception):
    """Process context related errors."""

    pass


# Logger already defined above

# AgentCore-style ContextVars for runtime correlation (Python SDK internal state)
_hexr_tenant: ContextVar[str] = ContextVar("hexr_tenant")
_hexr_framework: ContextVar[str] = ContextVar("hexr_framework")
_hexr_agent_name: ContextVar[str] = ContextVar("hexr_agent_name")
_hexr_sub_agent: ContextVar[str] = ContextVar("hexr_sub_agent")
_hexr_resources: ContextVar[List[str]] = ContextVar("hexr_resources")
_hexr_regions: ContextVar[Dict[str, str]] = ContextVar("hexr_regions")
_hexr_subprocess_support: ContextVar[bool] = ContextVar("hexr_subprocess_support")


class HexrContext:
    """
    AgentCore-style context management with Enhanced Attestor integration.

    Provides two-layer approach:
    1. ContextVars for Python SDK internal state (like AgentCore)
    2. JSON process files for Go Enhanced Attestor communication
    """

    @staticmethod
    def set_agent_context(
        agent_name: str,
        workload_id: str,
        framework: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        enable_subprocess_detection: bool = True,
        tenant: str = "default",
        resources: Optional[List[str]] = None,
        regions: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Set hierarchical agent context with process tree management.

        Args:
            agent_name: Name of the AI agent
            workload_id: Unique workload identifier
            framework: AI framework being used (e.g., 'crewai', 'langchain')
            metadata: Additional context metadata
            enable_subprocess_detection: Enable framework-agnostic subprocess monitoring
            tenant: Tenant identifier for SPIFFE ID hierarchy
            resources: Cloud resources for inheritance
            regions: Regional configuration
        """
        # Set ContextVars for internal SDK use
        _hexr_agent_name.set(agent_name)
        _hexr_framework.set(framework or "custom")
        _hexr_tenant.set(tenant)

        logger.info(f"Set agent context: {agent_name} (framework: {framework})")

        # Write process context file for SPIRE attestation
        HexrContext._write_process_context_file(
            {
                "agent": agent_name,
                "workload": workload_id,
                    "framework": framework,
                    "tenant": tenant,
                    "timestamp": int(time.time()),
                    "process_id": os.getpid(),
                    "metadata": metadata,
                }
            )

    @staticmethod
    def get_current_context() -> Dict[str, Any]:
        """Get current AgentCore-style context from ContextVars."""
        try:
            return {
                "tenant": _hexr_tenant.get("unknown"),
                "framework": _hexr_framework.get("custom"),
                "agent_name": _hexr_agent_name.get("unnamed"),
                "sub_agent": _hexr_sub_agent.get("main"),
                "resources": _hexr_resources.get([]),
                "regions": _hexr_regions.get({}),
                "subprocess_support": _hexr_subprocess_support.get(False),
            }
        except LookupError:
            # Context not set - return defaults
            return {
                "tenant": "unknown",
                "framework": "custom",
                "agent_name": "unnamed",
                "sub_agent": "main",
                "resources": [],
                "regions": {},
                "subprocess_support": False,
            }

    @staticmethod
    def update_subprocess_role(new_role: str) -> str:
        """
        Update subprocess role and regenerate JSON context file.
        Used when CrewAI/LangChain spawns specialized subprocesses.
        """
        # Update ContextVar
        _hexr_sub_agent.set(new_role)

        logger.info(f"Updated subprocess role to: {new_role}")

        # Regenerate JSON file for Enhanced Attestor with new role
        return HexrContext._write_process_context_file()

    @staticmethod
    def copy_context_to_subprocess():
        """
        Copy current context for subprocess execution.
        Returns context copy that can be run in subprocess.
        """
        current_ctx = copy_context()
        logger.debug("Copied context for subprocess execution")
        return current_ctx

    @staticmethod
    def _write_process_context_file(
        context_data: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Write JSON context file following original simple contract.
        Enhanced Attestor reads this file via shared volume mount.
        """
        try:
            if context_data:
                # Use provided context data (from set_agent_context)
                process_context = context_data
            else:
                # Get current context from ContextVars
                ctx = HexrContext.get_current_context()

                # Create simple JSON structure (matching original vision)
                process_context = {
                    "framework": ctx["framework"],
                    "version": "1.0.0",  # Framework version (simplified)
                    "agent_name": ctx["agent_name"],
                    "sub_agent": ctx["sub_agent"],
                    "tenant": ctx["tenant"],
                    "process_role": ctx["sub_agent"],  # Alias for compatibility
                    "resources": ctx["resources"],
                    "process_id": os.getpid(),
                    "parent_pid": os.getppid(),
                    "timestamp": int(time.time()),
                    "regions": ctx["regions"],
                    "subprocess_support": ctx["subprocess_support"],
                }

            # Write to shared volume (enhanced attestor reads this)
            # Use flat directory structure for simplicity
            context_dir = Path("/tmp/hexr-context")
            context_dir.mkdir(parents=True, exist_ok=True, mode=0o755)

            # CRITICAL: Use hexr-agent-<PID>-<role>.json pattern that attestor expects
            agent_name = process_context.get("agent_name", "agent")
            context_file = context_dir / f"hexr-agent-{os.getpid()}-{agent_name}.json"

            with open(context_file, "w") as f:
                json.dump(process_context, f, indent=2)

            logger.info(f"Created JSON context file: {context_file}")
            return str(context_file)

        except Exception as e:
            logger.error(f"Failed to write process context file: {e}")
            raise ProcessContextError(f"Failed to write context file: {e}") from e

    @staticmethod
    def cleanup_context_file() -> None:
        """Clean up JSON context file when process terminates."""
        try:
            context_base = Path("/tmp/hexr-context")
            agent_name = _hexr_agent_name.get("agent")
            
            # Use flat directory structure
            context_file = context_base / f"hexr-agent-{os.getpid()}-{agent_name}.json"
            
            if context_file.exists():
                context_file.unlink()
                logger.info(f"Cleaned up context file: {context_file}")
        except Exception as e:
            logger.warning(f"Failed to cleanup context file: {e}")

    @staticmethod
    def log_credential_request(
        service: str, success: bool, error: Optional[str] = None
    ) -> None:
        """
        Log hexr_tool() credential requests for audit trails.
        Updates the JSON context file for Enhanced Attestor monitoring.
        """
        try:
            context_base = Path("/tmp/hexr-context")
            agent_name = _hexr_agent_name.get("agent")
            
            # Use flat directory structure
            context_file = context_base / f"hexr-agent-{os.getpid()}-{agent_name}.json"

            if not context_file.exists():
                logger.warning("Context file not found for credential logging")
                return

            # Read existing context
            with open(context_file, "r") as f:
                context_data = json.load(f)

            # Add credential request log
            if "credential_requests" not in context_data:
                context_data["credential_requests"] = []

            credential_log = {
                "timestamp": int(time.time()),
                "service": service,
                "success": success,
                "error": error,
            }

            context_data["credential_requests"].append(credential_log)

            # Write back
            with open(context_file, "w") as f:
                json.dump(context_data, f, indent=2)

            logger.debug(f"Logged credential request: {service} (success: {success})")

        except Exception as e:
            logger.warning(f"Failed to log credential request: {e}")

    @staticmethod
    def register_subprocess(child_pid: int, role: str) -> None:
        """
        Register subprocess spawning for multi-agent coordination.
        Updates parent process JSON file with subprocess information.
        """
        try:
            context_base = Path("/tmp/hexr-context")
            agent_name = _hexr_agent_name.get("agent")
            
            # Use flat directory structure
            context_file = context_base / f"hexr-agent-{os.getpid()}-{agent_name}.json"

            if not context_file.exists():
                logger.warning("Context file not found for subprocess registration")
                return

            # Read existing context
            with open(context_file, "r") as f:
                context_data = json.load(f)

            # Add subprocess info
            if "subprocesses" not in context_data:
                context_data["subprocesses"] = []

            subprocess_info = {
                "pid": child_pid,
                "role": role,
                "spawned_at": int(time.time()),
            }

            context_data["subprocesses"].append(subprocess_info)

            # Write back
            with open(context_file, "w") as f:
                json.dump(context_data, f, indent=2)

            logger.info(f"Registered subprocess: PID {child_pid}, role: {role}")

        except Exception as e:
            logger.warning(f"Failed to register subprocess: {e}")


# Convenience functions for easy access (AgentCore pattern)
def get_tenant() -> str:
    """Get current tenant from context (like AgentCore)."""
    try:
        return _hexr_tenant.get()
    except LookupError:
        return "unknown"


def get_framework() -> str:
    """Get current framework from context."""
    try:
        return _hexr_framework.get()
    except LookupError:
        return "custom"


def get_agent_name() -> str:
    """Get current agent name from context."""
    try:
        return _hexr_agent_name.get()
    except LookupError:
        return "unnamed"


def get_sub_agent() -> str:
    """Get current sub-agent role from context."""
    try:
        return _hexr_sub_agent.get()
    except LookupError:
        return "main"


def get_resources() -> List[str]:
    """Get current required resources from context."""
    try:
        return _hexr_resources.get()
    except LookupError:
        return []


# Mock support for development/testing
class MockHexrContext:
    """Mock context manager for development and testing."""

    def __init__(self):
        self._context_files = {}

    def set_agent_context(
        self,
        tenant: str,
        framework: str,
        agent_name: str,
        sub_agent: str = "main",
        resources: Optional[List[str]] = None,
        regions: Optional[Dict[str, str]] = None,
        subprocess_support: bool = False,
    ) -> str:
        """Mock context setting - sets ContextVars AND stores in memory."""

        # 1. Set ContextVars just like the real implementation
        _hexr_tenant.set(tenant)
        _hexr_framework.set(framework)
        _hexr_agent_name.set(agent_name)
        _hexr_sub_agent.set(sub_agent)
        _hexr_resources.set(resources or [])
        _hexr_regions.set(regions or {})
        _hexr_subprocess_support.set(subprocess_support)

        # 2. Mock file for testing
        mock_file = f"/tmp/hexr-context/mock-hexr-context-{os.getpid()}.json"

        context_data = {
            "framework": framework,
            "version": "1.0.0",
            "agent_name": agent_name,
            "sub_agent": sub_agent,
            "tenant": tenant,
            "process_role": sub_agent,
            "resources": resources or [],
            "process_id": os.getpid(),
            "timestamp": int(time.time()),
        }

        self._context_files[os.getpid()] = context_data
        return mock_file

    def get_current_context(self) -> Dict[str, Any]:
        """Get mock context."""
        return self._context_files.get(
            os.getpid(),
            {
                "tenant": "mock-tenant",
                "framework": "mock-framework",
                "agent_name": "mock-agent",
                "sub_agent": "main",
            },
        )

    def cleanup_context_file(self) -> None:
        """Mock cleanup."""
        self._context_files.pop(os.getpid(), None)


# Global mock instance for testing
_mock_context: Optional[MockHexrContext] = None


def _get_context_manager():
    """Get context manager (always returns real context)."""
    return HexrContext
