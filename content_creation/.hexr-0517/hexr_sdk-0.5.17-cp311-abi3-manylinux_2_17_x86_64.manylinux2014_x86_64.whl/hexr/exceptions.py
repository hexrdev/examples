"""Hexr SDK exception definitions."""


class HexrError(Exception):
    """Base exception for all Hexr SDK errors."""

    pass


class AuthenticationError(HexrError):
    """Raised when SPIFFE authentication fails."""

    pass


class CredentialError(HexrError):
    """Raised when credential exchange fails."""

    pass


class ConfigurationError(HexrError):
    """Raised when SDK configuration is invalid."""

    pass


class BuildError(HexrError):
    """Raised when agent build process fails."""

    pass


class DeploymentError(HexrError):
    """Raised when agent deployment fails."""

    pass


class FrameworkError(HexrError):
    """Raised when framework detection or integration fails."""

    pass


class ProcessContextError(HexrError):
    """Raised when process context management fails."""

    pass


class GuardrailError(HexrError):
    """Raised when LLM Guard blocks a prompt or output."""

    def __init__(self, message: str, scanners: dict | None = None):
        super().__init__(message)
        self.scanners = scanners or {}
