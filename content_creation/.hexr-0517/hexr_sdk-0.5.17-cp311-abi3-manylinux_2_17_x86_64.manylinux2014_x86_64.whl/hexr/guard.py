"""
Hexr LLM Guard Client — prompt/output scanning via LLM Guard API.

Provides sync and async HTTP calls to the LLM Guard sidecar service
deployed in ``hexr-system``.  Enabled automatically when running
in-cluster (detects ``KUBERNETES_SERVICE_HOST``) or when
``HEXR_LLM_GUARD_URL`` is set explicitly.

Environment variables:
    HEXR_LLM_GUARD_URL      Override the service URL (default: in-cluster discovery)
    HEXR_LLM_GUARD_ENABLED  Explicit enable/disable ("true"/"false")
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)

_DEFAULT_URL = "http://hexr-runtime-hexr-llm-guard.hexr-system:8000"
_TIMEOUT = 10.0


# ── Configuration ────────────────────────────────────────────────────────────

def _get_url() -> str | None:
    """Resolve the LLM Guard service URL."""
    url = os.getenv("HEXR_LLM_GUARD_URL")
    if url:
        return url.rstrip("/")
    # Auto-detect in-cluster
    if os.getenv("KUBERNETES_SERVICE_HOST"):
        return _DEFAULT_URL
    return None


def is_enabled() -> bool:
    """Check whether LLM Guard scanning is active."""
    explicit = os.getenv("HEXR_LLM_GUARD_ENABLED")
    if explicit is not None:
        return explicit.lower() in ("1", "true", "yes")
    return _get_url() is not None


# ── Text extraction helpers ─────────────────────────────────────────────────

def extract_prompt_text(kwargs: dict[str, Any]) -> str | None:
    """Extract the user prompt text from LLM call kwargs.

    Handles OpenAI/Anthropic ``messages`` format and Google ``contents``.
    Returns the last user message content, or None if not found.
    """
    messages = kwargs.get("messages") or kwargs.get("contents")
    if not messages:
        # Single-string prompt (completions API)
        prompt = kwargs.get("prompt")
        if isinstance(prompt, str):
            return prompt
        return None

    # Walk backwards to find the last user message
    for msg in reversed(messages):
        if not isinstance(msg, dict):
            continue
        if msg.get("role") != "user":
            continue
        content = msg.get("content", "")
        if isinstance(content, str):
            return content
        # Multi-part content (vision models, etc.)
        if isinstance(content, list):
            parts = []
            for p in content:
                if isinstance(p, dict) and p.get("type") == "text":
                    parts.append(p.get("text", ""))
            return " ".join(parts) if parts else None
    return None


def extract_response_text(response: Any, provider: str) -> str | None:
    """Extract the assistant response text from an LLM response object."""
    try:
        if provider in ("openai", "litellm"):
            return response.choices[0].message.content
        elif provider == "anthropic":
            block = response.content[0]
            return block.text if hasattr(block, "text") else str(block)
        elif provider == "google_genai":
            return response.text
    except (IndexError, AttributeError):
        pass
    # Generic fallback
    try:
        if hasattr(response, "choices") and response.choices:
            return response.choices[0].message.content
    except (IndexError, AttributeError):
        pass
    return None


# ── Sync scanning ────────────────────────────────────────────────────────────

def scan_prompt(text: str) -> dict[str, Any]:
    """POST /analyze/prompt — returns ``{"is_valid": bool, "scanners": {...}}``."""
    url = _get_url()
    if url is None:
        return {"is_valid": True, "scanners": {}}
    try:
        resp = httpx.post(
            f"{url}/analyze/prompt",
            json={"prompt": text},
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception:
        logger.warning("LLM Guard prompt scan failed, proceeding (fail-open)", exc_info=True)
        return {"is_valid": True, "scanners": {}}


def scan_output(prompt_text: str, output_text: str) -> dict[str, Any]:
    """POST /analyze/output — returns ``{"is_valid": bool, "scanners": {...}}``."""
    url = _get_url()
    if url is None:
        return {"is_valid": True, "scanners": {}}
    try:
        resp = httpx.post(
            f"{url}/analyze/output",
            json={"prompt": prompt_text, "output": output_text},
            timeout=_TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()
    except Exception:
        logger.warning("LLM Guard output scan failed, proceeding (fail-open)", exc_info=True)
        return {"is_valid": True, "scanners": {}}


# ── Async scanning ───────────────────────────────────────────────────────────

async def scan_prompt_async(text: str) -> dict[str, Any]:
    """Async version of :func:`scan_prompt`."""
    url = _get_url()
    if url is None:
        return {"is_valid": True, "scanners": {}}
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(
                f"{url}/analyze/prompt",
                json={"prompt": text},
            )
            resp.raise_for_status()
            return resp.json()
    except Exception:
        logger.warning("LLM Guard async prompt scan failed, proceeding (fail-open)", exc_info=True)
        return {"is_valid": True, "scanners": {}}


async def scan_output_async(prompt_text: str, output_text: str) -> dict[str, Any]:
    """Async version of :func:`scan_output`."""
    url = _get_url()
    if url is None:
        return {"is_valid": True, "scanners": {}}
    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(
                f"{url}/analyze/output",
                json={"prompt": prompt_text, "output": output_text},
            )
            resp.raise_for_status()
            return resp.json()
    except Exception:
        logger.warning("LLM Guard async output scan failed, proceeding (fail-open)", exc_info=True)
        return {"is_valid": True, "scanners": {}}
