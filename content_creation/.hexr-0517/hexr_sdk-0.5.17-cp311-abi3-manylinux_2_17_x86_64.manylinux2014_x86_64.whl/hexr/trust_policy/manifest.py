"""
TrustPolicyManifest — canonical inputs for cloud-side trust-policy emitters.

One manifest per (tenant, cloud) tuple. The same manifest feeds the CLI
generator and the Terraform submodule, guaranteeing byte-identical artifacts.

Validation is performed at construction time: tenant slug must be a valid
DNS label, SPIFFE trust domain must be a hostname, audience must be a
non-empty token. Failures raise ValueError — never silently degrade.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Literal

DEFAULT_TRUST_DOMAIN = "agents.hexr.cloud"
DEFAULT_OIDC_ISSUER = "https://oidc.hexr.cloud"
DEFAULT_AUDIENCE = "hexr-credential-injector"

Cloud = Literal["aws", "gcp", "azure"]

_DNS_LABEL = re.compile(r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?$")
_HOSTNAME = re.compile(r"^[a-z0-9.-]+$")


@dataclass(frozen=True)
class TrustPolicyManifest:
    """Inputs shared by all three cloud-side trust-policy emitters."""

    tenant_slug: str
    """Customer tenant identifier. Must be a DNS-1123 label (e.g. 'globex-azure')."""

    cloud: Cloud
    """Target cloud — one of 'aws', 'gcp', 'azure'."""

    trust_domain: str = DEFAULT_TRUST_DOMAIN
    """SPIRE trust domain. Forms the SPIFFE ID prefix."""

    oidc_issuer: str = DEFAULT_OIDC_ISSUER
    """OIDC discovery endpoint hosting JWKS. Single point of change."""

    audience: str = DEFAULT_AUDIENCE
    """JWT `aud` claim value the credential-injector validates."""

    agent_glob: str = "*"
    """SPIFFE subject suffix below `spiffe://<trust_domain>/<tenant>/`.

    For AWS and GCP this becomes a wildcard pattern. For Azure (no wildcard
    support) callers must supply explicit `federations` instead.
    """

    federations: tuple["AzureFederation", ...] = field(default_factory=tuple)
    """Azure-only: explicit list of (framework, agent, sub_agent) tuples.

    Required for cloud='azure'; ignored for AWS/GCP.
    Imported from hexr.trust_policy.azure to avoid forward-ref churn.
    """

    def __post_init__(self) -> None:
        if not _DNS_LABEL.match(self.tenant_slug):
            raise ValueError(
                f"tenant_slug must be a DNS-1123 label, got {self.tenant_slug!r}"
            )
        if self.cloud not in ("aws", "gcp", "azure"):
            raise ValueError(
                f"cloud must be one of aws|gcp|azure, got {self.cloud!r}"
            )
        if not _HOSTNAME.match(self.trust_domain):
            raise ValueError(
                f"trust_domain must be a hostname, got {self.trust_domain!r}"
            )
        if not self.oidc_issuer.startswith("https://"):
            raise ValueError(
                f"oidc_issuer must use https://, got {self.oidc_issuer!r}"
            )
        if not self.audience:
            raise ValueError("audience must be non-empty")
        if self.cloud == "azure" and not self.federations:
            raise ValueError(
                "Azure requires explicit federations=[AzureFederation(...), ...]; "
                "azurerm_federated_identity_credential has no wildcard subject support"
            )

    @property
    def spiffe_prefix(self) -> str:
        """`spiffe://<trust_domain>/<tenant>/` — without trailing wildcard."""
        return f"spiffe://{self.trust_domain}/{self.tenant_slug}/"

    @property
    def spiffe_subject_pattern(self) -> str:
        """Full SPIFFE ID pattern with `agent_glob` suffix appended."""
        return f"{self.spiffe_prefix}{self.agent_glob}"
