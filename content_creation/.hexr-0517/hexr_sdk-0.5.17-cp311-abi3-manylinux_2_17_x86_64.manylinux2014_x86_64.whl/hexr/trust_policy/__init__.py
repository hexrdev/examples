"""
hexr.trust_policy — Cloud-side IAM trust-policy emitter (spec §2.5.7c).

Pure-Python module that renders deterministic, copy-paste-ready trust-policy
artifacts (AWS IAM JSON, GCP Workload Identity Federation HCL, Azure AD
Federated Identity Credential HCL/ARM) from a single canonical manifest.

This module performs NO cloud API calls. It is safe to import in any context
(CLI, library, unit test) without touching network or credentials. Cloud
provisioning is the customer's responsibility, applied via either:

  A. `hexr trust-policy generate` CLI (see hexr/cli/trust_policy.py)
  B. `hexr/deployment/terraform/{aws,gcp,azure}/iam-trust/` modules

The two surfaces share THIS module as the single source of truth — so the
artifact a customer copy-pastes from the CLI is byte-identical to what the
Terraform submodule produces.

Design rationale: spec §2.5.7c — openness over operator-pattern lock-in.
"""

from __future__ import annotations

from hexr.trust_policy.aws import render_aws_trust_policy
from hexr.trust_policy.azure import (
    AzureFederation,
    render_azure_federated_credentials,
)
from hexr.trust_policy.gcp import render_gcp_wif_provider
from hexr.trust_policy.manifest import TrustPolicyManifest

__all__ = [
    "TrustPolicyManifest",
    "AzureFederation",
    "render_aws_trust_policy",
    "render_gcp_wif_provider",
    "render_azure_federated_credentials",
]
