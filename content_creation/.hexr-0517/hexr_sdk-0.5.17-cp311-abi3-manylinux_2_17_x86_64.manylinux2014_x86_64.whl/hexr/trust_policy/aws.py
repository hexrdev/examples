"""
AWS IAM trust-policy emitter.

Produces a JSON IAM role trust policy that accepts an OIDC web-identity
token issued by `oidc.hexr.cloud`, restricted to a tenant's SPIFFE prefix
via `StringLike` on `oidc.hexr.cloud:sub`. Audience is pinned via
`StringEquals` on `oidc.hexr.cloud:aud`.

This module owns ONLY the trust half of the customer's IAM role. The
permission policies attached to the role (S3 access, BigQuery via STS,
etc.) are the customer's responsibility — Hexr never edits permissions.

Identical JSON is emitted by the CLI and by the AWS Terraform submodule
(`hexr/deployment/terraform/aws/iam-trust/`).
"""

from __future__ import annotations

import json
from urllib.parse import urlparse

from hexr.trust_policy.manifest import TrustPolicyManifest


def render_aws_trust_policy(manifest: TrustPolicyManifest, account_id: str) -> str:
    """Render AWS IAM role trust-policy JSON for the given tenant.

    Args:
        manifest: Canonical tenant manifest. `cloud` must be 'aws'.
        account_id: 12-digit AWS account ID owning the IAM role.

    Returns:
        Pretty-printed JSON string ready to paste into the AWS console
        or write to a file consumed by `aws iam create-role
        --assume-role-policy-document`.

    Raises:
        ValueError: If manifest.cloud != 'aws' or account_id is malformed.
    """
    if manifest.cloud != "aws":
        raise ValueError(f"render_aws_trust_policy requires cloud='aws', got {manifest.cloud!r}")
    if not (account_id.isdigit() and len(account_id) == 12):
        raise ValueError(f"account_id must be a 12-digit AWS account ID, got {account_id!r}")

    issuer_host = urlparse(manifest.oidc_issuer).netloc
    provider_arn = f"arn:aws:iam::{account_id}:oidc-provider/{issuer_host}"

    policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": f"HexrTrust{manifest.tenant_slug.replace('-', '')}",
                "Effect": "Allow",
                "Principal": {"Federated": provider_arn},
                "Action": "sts:AssumeRoleWithWebIdentity",
                "Condition": {
                    "StringEquals": {
                        f"{issuer_host}:aud": manifest.audience,
                    },
                    "StringLike": {
                        f"{issuer_host}:sub": f"{manifest.spiffe_prefix}*",
                    },
                },
            }
        ],
    }
    return json.dumps(policy, indent=2, sort_keys=False)
