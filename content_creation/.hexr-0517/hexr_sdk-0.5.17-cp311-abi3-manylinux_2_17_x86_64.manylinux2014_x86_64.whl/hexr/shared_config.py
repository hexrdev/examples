"""
Hexr SDK Configuration & Shared Data Classes

Shared configuration objects and data classes to avoid circular imports
between CLI, build, and other modules.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class BuildConfig:
    """Configuration for hexr build command."""

    agent_file: Path
    tenant: str
    name: str | None
    target: str
    framework: str
    registry: str | None
    python_version: str
    base_image: str
    multi_cloud: list[str] | None
    subprocess_support: bool
    security_scan: bool
    optimization_level: str
    output_dir: Path
    dockerfile_only: bool
    dry_run: bool
    verbose: bool
    debug: bool
    mock_mode: bool = True  # Default to mock mode for safety
    pypi_url: str | None = None  # Private PyPI URL for init container SDK install
    trust_domain: str = "demo.hexr.dev"  # SPIFFE trust domain for envoy mTLS config
    # GCP Workload Identity SA to bind the agent KSA to. Required for pods to
    # auth-impersonate against GCP-backed services (e.g. AR-backed pypi.hexr.cloud).
    # When set, k8s.py emits `iam.gke.io/gcp-service-account: <value>` on the
    # generated `hexr-agent` ServiceAccount. Auto-defaulted to
    # `hexr-pypi-reader@hexr-cloud-prod.iam.gserviceaccount.com` when the user is
    # logged into Hexr Cloud (see cli/main.py build()).
    gcp_service_account: str | None = None
    # Build route. "kubernetes" (default) emits Dockerfile + K8s manifests
    # for Route B (self-hosted EKS/GKE/AKS/on-prem). "managed" skips all
    # K8s/docker emission and instead writes the Route A artifacts under
    # .hexr/managed/: BuildManifest.json (already produced by analyzer),
    # deploy-descriptor.<runtime>.yaml (the patch the customer pastes into
    # their AgentCore / GEAP / Foundry deploy file), and control-mappings.json
    # (the per-tool control-framework matrix the audit pack PDF cites).
    # See HEXR_SDK_OVERHAUL_TECH_SPEC.md sec 19.5 item 8 + HEXR_HYBRID_PIVOT_TECH_SPEC.md sec 1.13.9 + 1.21.6.
    route: str = "kubernetes"


@dataclass
class AgentInfo:
    """Information about a detected agent."""

    name: str
    function_name: str
    tenant: str | None = None
    resources: list[str] = field(default_factory=list)
    line_number: int = 0
    framework_hints: list[str] = field(default_factory=list)


@dataclass
class AnalysisResult:
    """Complete analysis result of a Python agent file."""

    # Basic information
    file_path: Path
    framework: str | None = None
    framework_version: str | None = None

    # Detected agents
    agents: list[AgentInfo] = field(default_factory=list)

    # Resource requirements
    resources: list[str] = field(default_factory=list)
    cloud_providers: list[str] = field(default_factory=list)

    # Dependencies
    dependencies: list[str] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)

    # Framework-specific patterns
    framework_patterns: dict[str, Any] = field(default_factory=dict)
    subprocess_patterns: list[str] = field(default_factory=list)

    # Performance and security hints
    performance_hints: dict[str, Any] = field(default_factory=dict)
    security_requirements: list[str] = field(default_factory=list)


@dataclass
class BuildResult:
    """Result of hexr build command execution."""

    success: bool
    image_name: str | None = None
    output_dir: Path | None = None
    duration: float = 0.0
    framework: str | None = None
    cloud_providers: list[str] | None = None
    resources: list[str] | None = None
    error: str | None = None

    def __post_init__(self):
        if self.cloud_providers is None:
            self.cloud_providers = []
        if self.resources is None:
            self.resources = []


@dataclass
class PushResult:
    """Result of hexr push command execution."""

    success: bool
    registry_url: str | None = None
    image_digest: str | None = None
    scan_results: dict[str, Any] | None = None
    duration: float = 0.0
    error: str | None = None


# Framework detection patterns
FRAMEWORK_PATTERNS = {
    "crewai": {
        "imports": ["crewai", "crew", "agent", "task"],
        "classes": ["Crew", "Agent", "Task"],
        "functions": ["kickoff", "execute"],
        "dependencies": [
            "crewai>=0.20.0",
            "crewai-tools>=0.2.0",
            "pydantic>=2.0.0",
        ],
    },
    "langchain": {
        "imports": ["langchain", "chain", "llm"],
        "classes": ["Chain", "LLM", "BaseChain"],
        "functions": ["run", "invoke", "call"],
        "dependencies": [
            "langchain>=0.1.0",
            "langchain-community>=0.0.20",
            "langchain-core>=0.1.0",
        ],
    },
    "autogen": {
        "imports": ["autogen", "conversableagent"],
        "classes": ["ConversableAgent", "AssistantAgent", "UserProxyAgent"],
        "functions": ["initiate_chat", "generate_reply"],
        "dependencies": [
            "autogen-agentchat>=0.2.0",
        ],
    },
    "strandagent": {
        "imports": ["strand", "strandagent"],
        "classes": ["Agent", "StrandAgent"],
        "functions": ["execute", "run"],
        "dependencies": [
            "strandagent>=0.1.0",  # When available
        ],
    },
}

# Cloud service mapping
CLOUD_SERVICE_MAP = {
    "aws_s3": "aws",
    "aws_lambda": "aws",
    "aws_dynamodb": "aws",
    "aws_rds": "aws",
    "gcp_storage": "gcp",
    "gcp_bigquery": "gcp",
    "gcp_firestore": "gcp",
    "azure_storage": "azure",
    "azure_cosmosdb": "azure",
    "azure_sql": "azure",
}

# Cloud provider dependencies
CLOUD_DEPENDENCIES = {
    "aws": [
        "boto3>=1.34.0",
        "botocore>=1.34.0",
    ],
    "gcp": [
        "google-cloud-storage>=2.10.0",
        "google-cloud-bigquery>=3.11.0",
        "google-auth>=2.17.0",
    ],
    "azure": [
        "azure-storage-blob>=12.19.0",
        "azure-identity>=1.15.0",
        "azure-core>=1.26.0",
    ],
}
