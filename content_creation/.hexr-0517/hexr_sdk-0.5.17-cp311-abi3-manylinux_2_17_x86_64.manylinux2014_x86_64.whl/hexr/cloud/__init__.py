"""Cloud client factories for AWS, GCP, and Azure."""
