"""AWS client factory with SPIFFE-based authentication."""

from typing import Any

try:
    import boto3
    from botocore.credentials import Credentials
except ImportError:
    raise ImportError(
        "boto3 is required for AWS integration. "
        "Install with: pip install 'hexr-sdk[aws]'"
    )

from ..exceptions import CredentialError


def create_aws_client(
    service_name: str,
    credentials: dict[str, Any],
    region: str | None = None,
    **kwargs,
) -> Any:
    """Create authenticated AWS boto3 client."""

    # Extract service name (remove aws_ prefix)
    aws_service = service_name.replace("aws_", "")

    # Create boto3 credentials from Runtime response
    try:
        aws_credentials = Credentials(
            access_key=credentials["access_key"],
            secret_key=credentials["secret_key"],
            token=credentials.get("session_token"),
        )

        # Use region from credentials or parameter
        target_region = region or credentials.get("region", "us-east-1")

        # Create boto3 client
        client = boto3.client(
            aws_service,
            region_name=target_region,
            aws_access_key_id=credentials["access_key"],
            aws_secret_access_key=credentials["secret_key"],
            aws_session_token=credentials.get("session_token"),
            **kwargs,
        )

        return client

    except Exception as e:
        raise CredentialError(f"Failed to create AWS {aws_service} client: {e}") from e
