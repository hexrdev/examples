"""Azure client factory with SPIFFE-based authentication."""

from typing import Any

try:
    from azure.keyvault.secrets import SecretClient
    from azure.storage.blob import BlobServiceClient
except ImportError:
    raise ImportError(
        "azure-identity is required for Azure integration. "
        "Install with: pip install 'hexr-sdk[azure]'"
    )

from ..exceptions import CredentialError


def create_azure_client(
    service_name: str, credentials: dict[str, Any], **kwargs
) -> Any:
    """Create authenticated Azure client."""

    # Extract service name (remove azure_ prefix)
    azure_service = service_name.replace("azure_", "")

    try:
        # Create Azure credentials from Runtime response
        # This would use the access_token from Managed Identity federation

        if azure_service == "storage":
            account_name = credentials.get("account_name")
            account_url = f"https://{account_name}.blob.core.windows.net"

            client = BlobServiceClient(
                account_url=account_url,
                # Real implementation would set credentials here
                **kwargs,
            )
        elif azure_service == "keyvault":
            vault_url = credentials.get("vault_url")

            client = SecretClient(
                vault_url=vault_url,
                # Real implementation would set credentials here
                **kwargs,
            )
        else:
            raise CredentialError(f"Unsupported Azure service: {azure_service}")

        return client

    except Exception as e:
        raise CredentialError(
            f"Failed to create Azure {azure_service} client: {e}"
        ) from e
