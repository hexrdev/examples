"""GCP client factory with SPIFFE-based authentication."""

from typing import Any

try:
    from google.cloud import bigquery, storage
except ImportError:
    raise ImportError(
        "google-cloud-core is required for GCP integration. "
        "Install with: pip install 'hexr-sdk[gcp]'"
    )

from ..exceptions import CredentialError


def create_gcp_client(service_name: str, credentials: dict[str, Any], **kwargs) -> Any:
    """Create authenticated GCP google-cloud client."""

    # Extract service name (remove gcp_ prefix)
    gcp_service = service_name.replace("gcp_", "")

    try:
        # Create GCP credentials from Runtime response
        # This would use the access_token from Workload Identity federation
        project_id = credentials.get("project_id")

        if gcp_service == "bigquery":
            client = bigquery.Client(
                project=project_id,
                # Real implementation would set credentials here
                **kwargs,
            )
        elif gcp_service == "storage":
            client = storage.Client(
                project=project_id,
                # Real implementation would set credentials here
                **kwargs,
            )
        else:
            raise CredentialError(f"Unsupported GCP service: {gcp_service}")

        return client

    except Exception as e:
        raise CredentialError(f"Failed to create GCP {gcp_service} client: {e}") from e
