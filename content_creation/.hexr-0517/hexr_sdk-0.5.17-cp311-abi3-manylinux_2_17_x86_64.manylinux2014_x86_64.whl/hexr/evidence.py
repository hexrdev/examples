"""Runtime evidence helper — Stage 1 (hybrid pivot).

Posts a single compliance-evidence record to the data-plane evidence API
(`hexr-evidence-api`) running in the customer's VPC. This is the wedge:
the evidence never leaves the customer's cluster.

URL resolution (first match wins):
  1. ``HEXR_EVIDENCE_URL`` env var (any deployment)
  2. In-cluster default ``http://hexr-evidence-api.hexr-system.svc:8080``
     (detected via ``KUBERNETES_SERVICE_HOST``)

If neither resolves, no evidence is posted. That is deliberate: there is no
third option, and in particular no fall-back to the control plane.

A third branch used to exist here. When the first two missed, it loaded
``CloudConfig`` from ``~/.hexr/config.json`` and posted the record to
``cfg.cloud_url`` + ``/v1/evidence/record`` with the user's API key as a
bearer token. That was written while the SaaS still ran. After the hybrid
pivot it was actively harmful:

  * ``cloud_url`` on any machine that ever ran ``hexr login`` points at
    ``https://api.hexr.cloud`` — the CONTROL PLANE. So an agent run outside
    a cluster shipped evidence rows (tool name, SPIFFE ID, tenant, control
    mapping) plus a live API key to Hexr, breaking the single load-bearing
    promise of the pivot: evidence never leaves the customer's VPC, and only
    five scalars ever cross DP → CP.
  * It could not even succeed. ``/v1/evidence/record`` was served by the
    decommissioned cloud-api; ``hexr-license-api`` registers only
    ``/v1/healthz``, ``/v1/cli/agents`` and the two ``spire`` routes, so
    every attempt was a 404 that leaked the request before failing.

The data-plane API exposes ``POST /v1/evidence`` (no ``/record`` suffix).
"""

from __future__ import annotations

import json as _json
import logging
import os
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_DATAPLANE_URL = "http://hexr-evidence-api.hexr-system.svc:8080"
_DATAPLANE_PATH = "/v1/evidence"


def _resolve_endpoint() -> tuple[str, str, dict[str, str]]:
    """Return (base_url, path, headers). Empty base_url means 'no endpoint'."""
    override = os.environ.get("HEXR_EVIDENCE_URL", "").strip()
    if override:
        return override.rstrip("/"), _DATAPLANE_PATH, {}

    if os.environ.get("KUBERNETES_SERVICE_HOST"):
        return DEFAULT_DATAPLANE_URL, _DATAPLANE_PATH, {}

    # No fall-back. See module docstring: the removed CloudConfig branch sent
    # evidence to the control plane. Returning "" makes post_evidence a no-op.
    return "", _DATAPLANE_PATH, {}


def post_evidence(
    event_type: str,
    control_id: str,
    details: dict[str, Any] | None = None,
    *,
    source: str | None = None,
    framework: str = "soc2",
    severity: str = "info",
    spiffe_id: str | None = None,
    tenant_id: str | None = None,
    timeout: float = 5.0,
) -> bool:
    """Post a single compliance-evidence record. Returns True on 2xx."""
    base, path, headers = _resolve_endpoint()
    if not base:
        logger.debug("evidence: no endpoint resolved — skipping (%s/%s)", control_id, event_type)
        return False

    try:
        import httpx
    except ImportError:
        logger.warning("evidence: httpx not installed — skipping post")
        return False

    enriched = dict(details or {})
    enriched.setdefault("spiffe_id", spiffe_id or os.environ.get("HEXR_SPIFFE_ID", "local-dev"))
    enriched.setdefault("timestamp", datetime.now(timezone.utc).isoformat())

    payload = {
        "tenant_id": tenant_id or os.environ.get("HEXR_TENANT", "demo"),
        "source": source or os.environ.get("HEXR_AGENT_NAME", "hexr-sdk"),
        "event_type": event_type,
        "severity": severity,
        "framework": framework,
        "control_id": control_id,
        "spiffe_id": enriched.get("spiffe_id", ""),
        "details": _json.dumps(enriched),
    }

    # Sign with this process's X.509-SVID where one is reachable (spec
    # §1.29.2). Best-effort by design: sign_payload returns False and leaves
    # the payload untouched whenever signing material is unavailable, and the
    # server stores the row as unsigned rather than rejecting it. Dropping
    # evidence because signing was unavailable is the worse failure — the row
    # is what the auditor needs, and its absence cannot be detected later.
    try:
        from hexr.evidence_signing import sign_payload

        if sign_payload(payload):
            logger.debug("evidence: row signed with X509-SVID")
    except Exception as exc:  # noqa: BLE001
        logger.debug("evidence: signing unavailable (%s) — posting unsigned", exc)

    try:
        with httpx.Client(base_url=base, headers=headers, timeout=timeout) as client:
            r = client.post(path, json=payload)
        if 200 <= r.status_code < 300:
            return True
        logger.warning("evidence: %s%s → HTTP %d %s", base, path, r.status_code, r.text[:160])
    except Exception as exc:
        logger.warning("evidence: post failed (non-fatal): %s", exc)
    return False


__all__ = ["post_evidence", "DEFAULT_DATAPLANE_URL"]
